// Kodigen Crawler external visit client (docs/API.md).
//
// While enabled, the work loop claims up to crawlerLimit 'api'-agent pages via
// POST /v1/visits/claim, opens each in an inactive browser tab (in parallel),
// captures the rendered DOM after the page settles, and reports outcomes via
// POST /v1/visits/{id}/result. crawlerLimit defaults to 1 (sequential behavior).
//
// MV3 service workers are ephemeral: a 30s watchdog alarm restarts the loop
// after the worker is suspended. Visit leases on the server make interrupted
// work reclaimable, so a mid-visit suspension is safe.

const POLL_EMPTY_MS = 15_000;
const TAB_LOAD_TIMEOUT_MS = 60_000;
const SETTLE_MS = 2_000;
const MAX_BODY_BYTES = 10 * 1024 * 1024;
const WATCHDOG_ALARM = "kodigen-watchdog";
const DEFAULT_CRAWLER_LIMIT = 1;
const MAX_CRAWLER_LIMIT = 100;

let working = false;

chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === WATCHDOG_ALARM) maybeRun();
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "enabled-changed") {
    if (msg.enabled) {
      maybeRun();
    }
    sendResponse({ ok: true });
  }
  return false;
});

maybeRun();

async function setup() {
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: 0.5 });
  maybeRun();
}

function clampCrawlerLimit(value) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n) || n < 1) return DEFAULT_CRAWLER_LIMIT;
  if (n > MAX_CRAWLER_LIMIT) return MAX_CRAWLER_LIMIT;
  return n;
}

async function getState() {
  const state = await chrome.storage.local.get({
    apiUrl: "",
    apiKey: "",
    enabled: false,
    clientId: "",
    crawlerLimit: DEFAULT_CRAWLER_LIMIT,
    workTabIds: [],
  });
  if (!state.clientId) {
    state.clientId = "chrome-ext-" + crypto.randomUUID().slice(0, 8);
    await chrome.storage.local.set({ clientId: state.clientId });
  }
  state.crawlerLimit = clampCrawlerLimit(state.crawlerLimit);
  return state;
}

async function maybeRun() {
  const state = await getState();
  if (!working && state.workTabIds.length > 0) {
    await closeOrphanTabs(state.workTabIds);
    await chrome.storage.local.set({ workTabIds: [] });
  }
  if (state.enabled && state.apiUrl && state.apiKey) {
    runLoop();
  }
}

async function closeOrphanTabs(tabIds) {
  for (const tabId of tabIds) {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
      // Tab is already gone.
    }
  }
}

async function runLoop() {
  if (working) return;
  working = true;
  try {
    for (;;) {
      const state = await getState();
      if (!state.enabled || !state.apiUrl || !state.apiKey) break;

      const limit = state.crawlerLimit;
      let claim;
      try {
        claim = await apiFetch(state, "POST", "/v1/visits/claim", {
          limit,
          client_id: state.clientId,
        });
      } catch (err) {
        await updateStats({ lastError: `claim failed: ${errMessage(err)}` });
        schedulePoll();
        break;
      }

      const visits = (claim && claim.visits) || [];
      if (visits.length === 0) {
        await updateStats({ lastError: "" });
        schedulePoll();
        break;
      }

      const results = await Promise.all(
        visits.map((visit) => processVisit(state, visit)),
      );
      await applyVisitResults(results);
    }
  } finally {
    working = false;
  }
}

function schedulePoll() {
  setTimeout(maybeRun, POLL_EMPTY_MS);
}

/** @returns {Promise<{visitsDone?: number, visitsFailed?: number, lastUrl?: string, lastStatus?: string, lastError?: string}>} */
async function processVisit(state, visit) {
  const started = Date.now();
  let fetched = null;
  let fetchError = null;
  try {
    fetched = await fetchInTab(visit.target_url);
  } catch (err) {
    fetchError = errMessage(err);
  }
  const durationMs = Date.now() - started;

  let bodyBytes = null;
  if (fetched) {
    bodyBytes = new TextEncoder().encode(fetched.html);
    if (bodyBytes.length > MAX_BODY_BYTES) {
      fetched = null;
      fetchError = `rendered body exceeds ${MAX_BODY_BYTES} bytes`;
    }
  }

  try {
    if (fetched) {
      await apiFetch(state, "POST", `/v1/visits/${visit.page_id}/result`, {
        client_id: state.clientId,
        status: "done",
        http_status: fetched.httpStatus ?? undefined,
        final_url: fetched.url,
        content_type: fetched.contentType,
        body_base64: bytesToBase64(bodyBytes),
        duration_ms: durationMs,
      });
      return {
        visitsDone: 1,
        lastUrl: visit.target_url,
        lastStatus: "done",
        lastError: "",
      };
    }
    await apiFetch(state, "POST", `/v1/visits/${visit.page_id}/result`, {
      client_id: state.clientId,
      status: "failed",
      error: (fetchError || "fetch failed").slice(0, 500),
      duration_ms: durationMs,
    });
    return {
      visitsFailed: 1,
      lastUrl: visit.target_url,
      lastStatus: "failed",
      lastError: fetchError || "fetch failed",
    };
  } catch (err) {
    return {
      visitsFailed: 1,
      lastUrl: visit.target_url,
      lastStatus: "report-error",
      lastError: `result failed: ${errMessage(err)}`,
    };
  }
}

async function applyVisitResults(results) {
  let visitsDone = 0;
  let visitsFailed = 0;
  let lastUrl = "";
  let lastStatus = "";
  let lastError = "";
  for (const r of results) {
    visitsDone += r.visitsDone || 0;
    visitsFailed += r.visitsFailed || 0;
    if (r.lastUrl) {
      lastUrl = r.lastUrl;
      lastStatus = r.lastStatus || "";
      lastError = r.lastError || "";
    }
  }
  await updateStats({
    visitsDone,
    visitsFailed,
    lastUrl,
    lastStatus,
    lastError: visitsFailed > 0 && lastError ? lastError : "",
  });
}

async function addWorkTab(tabId) {
  const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
  if (!workTabIds.includes(tabId)) {
    await chrome.storage.local.set({ workTabIds: [...workTabIds, tabId] });
  }
}

async function removeWorkTab(tabId) {
  const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
  await chrome.storage.local.set({
    workTabIds: workTabIds.filter((id) => id !== tabId),
  });
}

async function fetchInTab(targetUrl) {
  const tab = await chrome.tabs.create({ url: targetUrl, active: false });
  const tabId = tab.id;
  await addWorkTab(tabId);

  let httpStatus = null;
  const onCompleted = (details) => {
    if (details.tabId === tabId) httpStatus = details.statusCode;
  };
  chrome.webRequest.onCompleted.addListener(onCompleted, {
    urls: ["http://*/*", "https://*/*"],
    types: ["main_frame"],
  });

  try {
    await waitForTabLoad(tabId, TAB_LOAD_TIMEOUT_MS);
    await sleep(SETTLE_MS);
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({
        html: "<!DOCTYPE html>\n" + document.documentElement.outerHTML,
        url: location.href,
        contentType: document.contentType || "text/html",
      }),
    });
    if (!injection || !injection.result) {
      throw new Error("could not read rendered page");
    }
    return { ...injection.result, httpStatus };
  } finally {
    chrome.webRequest.onCompleted.removeListener(onCompleted);
    try {
      await chrome.tabs.remove(tabId);
    } catch {
      // Tab was closed by the user or the browser.
    }
    await removeWorkTab(tabId);
  }
}

async function waitForTabLoad(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    let tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch {
      throw new Error("tab closed before load finished");
    }
    if (tab.status === "complete") {
      if (tab.url && tab.url.startsWith("chrome-error://")) {
        throw new Error("navigation failed (network or DNS error)");
      }
      return;
    }
    if (Date.now() > deadline) {
      throw new Error(`page load timed out after ${Math.round(timeoutMs / 1000)}s`);
    }
    await sleep(500);
  }
}

async function apiFetch(state, method, path, body) {
  const res = await fetch(state.apiUrl + path, {
    method,
    headers: {
      Authorization: "ApiKey " + state.apiKey,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    // Non-JSON error body; fall back to status code below.
  }
  if (!res.ok) {
    const msg = data && data.error ? data.error : `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return data;
}

async function updateStats(delta) {
  const cur = await chrome.storage.local.get({
    visitsDone: 0,
    visitsFailed: 0,
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  await chrome.storage.local.set({
    visitsDone: cur.visitsDone + (delta.visitsDone || 0),
    visitsFailed: cur.visitsFailed + (delta.visitsFailed || 0),
    lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
    lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
    lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
    lastActivityAt: Date.now(),
  });
}

function bytesToBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function errMessage(err) {
  return err instanceof Error ? err.message : String(err);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
