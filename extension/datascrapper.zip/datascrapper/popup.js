// Popup: main on/off switch + Settings (API URL / key). The background service
// worker owns the claim/visit/result loop.

const DEFAULT_API_URL = "https://api.datascraper.net";
const DEFAULT_CRAWLER_LIMIT = 1;
const MAX_CRAWLER_LIMIT = 100;

function clampCrawlerLimit(value) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n) || n < 1) return DEFAULT_CRAWLER_LIMIT;
  if (n > MAX_CRAWLER_LIMIT) return MAX_CRAWLER_LIMIT;
  return n;
}

const els = {
  headerTitle: document.getElementById("header-title"),
  btnSettings: document.getElementById("btn-settings"),
  viewMain: document.getElementById("view-main"),
  viewSettings: document.getElementById("view-settings"),
  settingsApiUrl: document.getElementById("settings-api-url"),
  settingsApiKey: document.getElementById("settings-api-key"),
  settingsCrawlerLimit: document.getElementById("settings-crawler-limit"),
  settingsKeyHint: document.getElementById("settings-key-hint"),
  settingsError: document.getElementById("settings-error"),
  btnSave: document.getElementById("btn-save"),
  btnCancel: document.getElementById("btn-cancel"),
  toggle: document.getElementById("toggle-enabled"),
  switchLabel: document.getElementById("switch-label"),
  statusDot: document.getElementById("status-dot"),
  statDone: document.getElementById("stat-done"),
  statFailed: document.getElementById("stat-failed"),
  lastUrl: document.getElementById("last-url"),
  mainError: document.getElementById("main-error"),
};

/** True when the user opened Settings from the main screen (Cancel returns there). */
let settingsFromMain = false;

init();

async function init() {
  const state = await loadState();

  if (state.apiKey) {
    showMain(state);
  } else {
    els.settingsApiUrl.value = state.apiUrl || DEFAULT_API_URL;
    els.settingsApiKey.value = "";
    els.settingsCrawlerLimit.value = String(DEFAULT_CRAWLER_LIMIT);
    showSettings({ firstRun: true });
  }

  els.btnSettings.addEventListener("click", () => openSettings());
  els.btnSave.addEventListener("click", onSave);
  els.btnCancel.addEventListener("click", onCancel);
  els.toggle.addEventListener("change", onToggle);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.visitsDone) els.statDone.textContent = changes.visitsDone.newValue;
    if (changes.visitsFailed) els.statFailed.textContent = changes.visitsFailed.newValue;
    if (changes.lastUrl) setLastUrl(changes.lastUrl.newValue);
    if (changes.lastError) setMainError(changes.lastError.newValue);
  });
}

async function loadState() {
  return chrome.storage.local.get({
    apiUrl: DEFAULT_API_URL,
    apiKey: "",
    enabled: false,
    visitsDone: 0,
    visitsFailed: 0,
    lastUrl: "",
    lastError: "",
    crawlerLimit: DEFAULT_CRAWLER_LIMIT,
  });
}

function showMain(state) {
  settingsFromMain = false;
  els.viewMain.hidden = false;
  els.viewSettings.hidden = true;
  els.btnSettings.hidden = false;
  els.headerTitle.textContent = "Crawler Agent";
  els.toggle.checked = state.enabled;
  renderEnabled(state.enabled);
  els.statDone.textContent = state.visitsDone;
  els.statFailed.textContent = state.visitsFailed;
  setLastUrl(state.lastUrl);
  setMainError(state.lastError);
}

function showSettings({ firstRun }) {
  els.viewMain.hidden = true;
  els.viewSettings.hidden = false;
  els.btnSettings.hidden = true;
  els.headerTitle.textContent = "Settings";
  els.settingsError.hidden = true;
  els.btnCancel.hidden = firstRun;
  els.settingsKeyHint.hidden = firstRun;
}

async function openSettings() {
  settingsFromMain = true;
  const state = await loadState();
  els.settingsApiUrl.value = state.apiUrl || DEFAULT_API_URL;
  els.settingsApiKey.value = "";
  els.settingsCrawlerLimit.value = String(clampCrawlerLimit(state.crawlerLimit));
  showSettings({ firstRun: false });
}

function renderEnabled(enabled) {
  els.switchLabel.textContent = enabled ? "On — visiting pages" : "Off";
  els.switchLabel.classList.toggle("on", enabled);
  els.statusDot.classList.toggle("on", enabled);
}

function setLastUrl(url) {
  els.lastUrl.hidden = !url;
  els.lastUrl.textContent = url ? `Last: ${url}` : "";
}

function setMainError(msg) {
  els.mainError.hidden = !msg;
  els.mainError.textContent = msg || "";
}

function showSettingsError(msg) {
  els.settingsError.hidden = false;
  els.settingsError.textContent = msg;
}

async function onSave() {
  const apiUrl = els.settingsApiUrl.value.trim().replace(/\/+$/, "");
  const keyInput = els.settingsApiKey.value.trim();
  const crawlerLimit = clampCrawlerLimit(els.settingsCrawlerLimit.value);
  const stored = await loadState();
  const apiKey = keyInput || stored.apiKey;

  els.settingsError.hidden = true;

  if (!apiUrl) {
    showSettingsError("API URL is required.");
    return;
  }
  if (!apiKey) {
    showSettingsError("API key is required.");
    return;
  }

  els.btnSave.disabled = true;
  els.btnSave.textContent = "Checking…";
  try {
    const res = await fetch(apiUrl + "/v1/stats", {
      headers: { Authorization: "ApiKey " + apiKey },
    });
    if (res.status === 401) throw new Error("API key rejected (401).");
    if (!res.ok) throw new Error(`API responded with HTTP ${res.status}.`);
  } catch (err) {
    showSettingsError(err instanceof Error ? err.message : "Could not reach the API.");
    els.btnSave.disabled = false;
    els.btnSave.textContent = "Save";
    return;
  }

  const patch = { apiUrl, apiKey, crawlerLimit };
  // First-time connect: stay off until the user flips the switch.
  if (!stored.apiKey) {
    patch.enabled = false;
  }
  await chrome.storage.local.set(patch);

  els.btnSave.disabled = false;
  els.btnSave.textContent = "Save";
  els.settingsApiKey.value = "";

  const state = await loadState();
  showMain(state);
}

async function onCancel() {
  if (!settingsFromMain) return;
  els.settingsApiKey.value = "";
  els.settingsError.hidden = true;
  const state = await loadState();
  showMain(state);
}

async function onToggle() {
  const enabled = els.toggle.checked;
  await chrome.storage.local.set({ enabled, lastError: "" });
  renderEnabled(enabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "enabled-changed", enabled }).catch(() => {});
}
