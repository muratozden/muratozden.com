const JOB_TYPES = {
  START_JOB: "START_JOB",
  STOP_JOB: "STOP_JOB",
};

const MESSAGE_TYPES = {
  JOB_STATUS: "JOB_STATUS",
  GTIN_RESULT: "GTIN_RESULT",
};

let job = null;

function postStatus(payload) {
  try {
    chrome.runtime.sendMessage({ type: MESSAGE_TYPES.JOB_STATUS, ...payload });
  } catch {
    // Popup açık değilse mesaj boşa gider; bu sorun değil.
  }
}

function buildGoogleUrl(query, extId) {
  const q = encodeURIComponent(query);
  return `https://www.google.com/search?q=${q}&ext_id=${encodeURIComponent(String(extId))}`;
}

function extractFromJobData(data, idx) {
  if (!Array.isArray(data)) return null;
  if (idx < 0 || idx >= data.length) return null;
  return data[idx];
}

async function loadUploadedJson() {
  const { uploadedJson } = await chrome.storage.local.get(["uploadedJson"]);
  return uploadedJson ?? null;
}

async function persistResolvedJson(resolvedJson) {
  await chrome.storage.local.set({
    resolvedJson,
    resolvedAt: Date.now(),
  });
}

function stopInternal({ reason = "Durduruldu" } = {}) {
  if (!job) return;

  // Job durdurulur; yeni sekme açılmaz.
  job.running = false;
  job.stopReason = reason;

  postStatus({
    running: false,
    message: reason,
    processedCount: job.processedCount,
    total: job.total,
  });
}

function openTabForIndex(index) {
  const item = extractFromJobData(job.originalData, index);
  if (!item) return;

  const h1 = item.h1 ? String(item.h1) : "";
  const query = `${h1} EAN`.trim();
  const url = buildGoogleUrl(query, index);

  chrome.tabs.create({ url, active: false }, (tab) => {
    if (chrome.runtime.lastError || !tab?.id) {
      // Sekme oluşturulamadıysa, sonucu boş sayıp ilerle.
      onGtinResult({ extId: index, gtin: null, raw: null, senderTabId: null }, { forced: true });
      return;
    }

    const tabId = tab.id;
    job.pendingByTabId.set(tabId, index);

    // Maks 15s bekle: SERP içeriği geç yüklenirse zaman aşımı olur.
    const timer = setTimeout(() => {
      const extId = job.pendingByTabId.get(tabId);
      job.pendingByTabId.delete(tabId);

      if (!job.running) return;
      onGtinResult(
        { extId, gtin: null, raw: null, senderTabId: tabId, timedOut: true },
        { forced: false }
      );
    }, 15000);

    job.timersByTabId.set(tabId, timer);
  });
}

async function startJob({ maxItems } = {}) {
  if (job?.running) return;

  const uploadedJson = await loadUploadedJson();
  if (!uploadedJson) {
    postStatus({ running: false, message: "Önce JSON yüklemeniz gerekiyor." });
    return;
  }

  const data = uploadedJson?.data;
  if (!Array.isArray(data)) {
    postStatus({ running: false, message: "JSON formatı beklenmiyor: `data` dizisi yok." });
    return;
  }

  const totalAll = data.length;
  const totalToProcess =
    Number.isFinite(maxItems) && maxItems > 0 ? Math.min(totalAll, maxItems) : totalAll;

  // Background'ta işleyeceğimiz kopyayı oluşturuyoruz.
  job = {
    running: true,
    stopReason: null,
    startedAt: Date.now(),
    total: totalToProcess,
    processedCount: 0,
    nextIndex: 0,
    originalData: data,
    resolvedJson:
      typeof structuredClone === "function"
        ? structuredClone(uploadedJson)
        : JSON.parse(JSON.stringify(uploadedJson)),
    timersByTabId: new Map(),
    pendingByTabId: new Map(),
    doneExtIds: new Set(),
  };

  // structuredClone ile `resolvedJson.data` kopyalanmış olur.
  // Ama index erişimi için resolvedData referansını kullanacağız.
  job.resolvedData = job.resolvedJson?.data;

  postStatus({
    running: true,
    message: `Başlandı. Toplam: ${job.total}`,
    processedCount: 0,
    total: job.total,
  });

  // Basit concurrency=1 (sekme başına sonuç bekleyeceğiz).
  while (job.running && job.nextIndex < job.total) {
    openTabForIndex(job.nextIndex);
    job.nextIndex++;
    // Sonraki sekmeyi, sonuç gelene kadar açmıyoruz.
    // (Concurrency=1)
    break;
  }
}

function closeTab(tabId) {
  if (!tabId) return;
  chrome.tabs.remove(tabId, () => {
    // ignore
  });
}

async function finishIfDone() {
  if (!job || !job.running) return;
  if (job.processedCount >= job.total) {
    job.running = false;
    const message = job.stopReason ? job.stopReason : "Tamamlandı.";
    await persistResolvedJson(job.resolvedJson);
    postStatus({
      running: false,
      message,
      processedCount: job.processedCount,
      total: job.total,
    });
  }
}

function onGtinResult(payload, { forced } = {}) {
  if (!job) return;
  const extId = payload?.extId;
  if (extId == null) return;
  if (extId < 0 || extId >= job.total) return;
  if (job.doneExtIds.has(extId)) return;
  job.doneExtIds.add(extId);

  // pending timer temizle
  if (payload.senderTabId != null) {
    const timer = job.timersByTabId.get(payload.senderTabId);
    if (timer) clearTimeout(timer);
    job.timersByTabId.delete(payload.senderTabId);
    job.pendingByTabId.delete(payload.senderTabId);
  }

  const resolvedItem = extractFromJobData(job.resolvedData, extId);
  if (resolvedItem) {
    resolvedItem.gtin = payload?.gtin ?? null;
    // Debug için istersen raw'u ekleyebilirsin; şimdilik saklamıyoruz.
  }

  job.processedCount++;

  postStatus({
    running: job.running,
    message:
      forced || payload?.timedOut
        ? `GTIN bulunamadı (timeout): #${extId}`
        : payload?.gtin
          ? `GTIN eklendi: #${extId}`
          : `GTIN bulunamadı: #${extId}`,
    processedCount: job.processedCount,
    total: job.total,
  });

  // Tamam mı?
  if (job.processedCount >= job.total) {
    // finishIfDone async; burada await gerekmez.
    finishIfDone();
    return;
  }

  // Sonraki index için tek sekme aç.
  if (job.running && job.nextIndex < job.total) {
    openTabForIndex(job.nextIndex);
    job.nextIndex++;
  } else {
    finishIfDone();
  }
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg?.type) return;

  if (msg.type === JOB_TYPES.STOP_JOB) {
    stopInternal({ reason: "Kullanıcı durdurdu." });
    // Bekleyen sekmeleri kapat.
    for (const tabId of job?.pendingByTabId?.keys?.() ?? []) {
      closeTab(tabId);
    }
    return;
  }

  if (msg.type === JOB_TYPES.START_JOB) {
    const maxItemsRaw = msg.maxItems;
    const maxItems =
      maxItemsRaw === "" || maxItemsRaw == null ? undefined : Number(maxItemsRaw);
    startJob({ maxItems }).catch((err) => {
      postStatus({ running: false, message: `Hata: ${String(err?.message ?? err)}` });
    });
    return;
  }

  if (msg.type === MESSAGE_TYPES.GTIN_RESULT) {
    const senderTabId = sender?.tab?.id ?? null;
    onGtinResult(
      { extId: msg.extId, gtin: msg.gtin ?? null, raw: msg.raw ?? null, senderTabId },
      { forced: false }
    );
    closeTab(senderTabId);
    return;
  }
});

