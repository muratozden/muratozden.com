function getQueryParam(name) {
  const url = new URL(window.location.href);
  return url.searchParams.get(name);
}

function pickBestGtin(text) {
  if (!text) return null;

  // Önce "EAN/GTIN" etiketli bir değer yakalamaya çalış.
  const labeled =
    /(?:EAN|GTIN)\s*[:\-]?\s*(\d{8,14})/gi.exec(text) ||
    null;
  if (labeled?.[1]) return labeled[1];

  // Daha sonra EAN-13 (en yaygın) öncelikli.
  const ean13 = /\b(\d{13})\b/.exec(text);
  if (ean13?.[1]) return ean13[1];

  // Son çare: 8-14 haneli ilk sayı dizisini dene.
  const any = /\b(\d{8,14})\b/.exec(text);
  return any?.[1] ?? null;
}

function extractSerpText() {
  const content = document.getElementById("content-placeholder");
  if (content) return content.innerText;
  return document.body?.innerText ?? "";
}

function tryExtractAndSend({ extId }) {
  const timeoutMs = 12000;
  const start = Date.now();

  const timer = setInterval(() => {
    const text = extractSerpText();
    const gtin = pickBestGtin(text);

    if (gtin || Date.now() - start > timeoutMs) {
      clearInterval(timer);
      chrome.runtime.sendMessage({
        type: "GTIN_RESULT",
        extId,
        gtin: gtin ?? null,
        raw: null,
      });
    }
  }, 600);
}

(() => {
  const extIdRaw = getQueryParam("ext_id");
  if (extIdRaw == null) return;

  const extId = Number(extIdRaw);
  if (!Number.isFinite(extId)) return;

  tryExtractAndSend({ extId });
})();

