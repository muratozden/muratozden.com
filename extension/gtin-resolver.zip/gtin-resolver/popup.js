function el(id) {
  return document.getElementById(id);
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return "-";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let value = bytes;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return `${value.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

async function saveJsonToStorage(parsed, file) {
  // chrome.storage.local kv: structured clone ile çalışır.
  const payload = {
    uploadedJson: parsed,
    uploadedJsonFilename: file?.name ?? null,
    uploadedJsonSize: file?.size ?? null,
    uploadedJsonAt: Date.now()
  };
  await chrome.storage.local.set(payload);
}

function setStatus(text, { isError = false } = {}) {
  const statusEl = el("status");
  statusEl.textContent = text;
  statusEl.classList.toggle("error", isError);
}

function setPreview(parsed) {
  const previewEl = el("preview");
  const metaEl = el("previewMeta");
  const type = Array.isArray(parsed) ? "Array" : typeof parsed;
  metaEl.textContent = `Tip: ${type}`;
  previewEl.value = JSON.stringify(parsed, null, 2);
}

document.addEventListener("DOMContentLoaded", () => {
  const jsonFileInput = el("jsonFile");
  const chooseBtn = el("chooseBtn");
  const closeBtn = el("closeBtn");

  const overlay = el("overlay");
  const maxStorageSizeBytes = 5 * 1024 * 1024; // yaklaşık; chrome.storage.local limit değişebilir

  const workArea = el("workArea");
  const jobMeta = el("jobMeta");
  const maxItemsEl = el("maxItems");
  const startBtn = el("startBtn");
  const stopBtn = el("stopBtn");
  const downloadBtn = el("downloadBtn");

  startBtn.disabled = true;
  stopBtn.disabled = true;
  downloadBtn.disabled = true;
  jobMeta.textContent = "";
  workArea.hidden = true;

  chooseBtn.addEventListener("click", () => {
    jsonFileInput.value = "";
    jsonFileInput.click();
  });

  closeBtn.addEventListener("click", () => {
    window.close();
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== "JOB_STATUS") return;

    const running = !!msg.running;
    const processedCount = msg.processedCount ?? 0;
    const total = msg.total ?? "";

    if (running) {
      startBtn.disabled = true;
      stopBtn.disabled = false;
      downloadBtn.disabled = true;
      chooseBtn.disabled = true;
    } else {
      stopBtn.disabled = true;
      chooseBtn.disabled = false;
      startBtn.disabled = false;
      // resolvedJson oluştuysa download butonunu aç.
      // (Gerçek kontrol download click anında da yapılır.)
      downloadBtn.disabled = false;
    }

    jobMeta.textContent =
      total !== "" && total !== undefined ? `${processedCount}/${total}` : "";

    if (msg.message) {
      setStatus(String(msg.message), { isError: /hata|bulunamadı/i.test(msg.message) });
    }
  });

  startBtn.addEventListener("click", async () => {
    const rawMax = String(maxItemsEl.value ?? "").trim();
    // Background, "" değerini "hepsi" olarak ele alıyor.
    await chrome.runtime.sendMessage({ type: "START_JOB", maxItems: rawMax });
  });

  stopBtn.addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ type: "STOP_JOB" });
  });

  downloadBtn.addEventListener("click", async () => {
    const { resolvedJson, resolvedAt, uploadedJsonFilename } =
      await chrome.storage.local.get([
        "resolvedJson",
        "resolvedAt",
        "uploadedJsonFilename"
      ]);

    if (!resolvedJson) {
      setStatus("Önce başlatıp sonuç üretmelisin.", { isError: true });
      return;
    }

    const baseName =
      uploadedJsonFilename?.replace(/\.json$/i, "") ?? "resolved-gtin";
    const stamp = resolvedAt ? new Date(resolvedAt).toISOString().slice(0, 10) : "";
    const fileName = stamp ? `${baseName}-gtin-${stamp}.json` : `${baseName}-gtin.json`;

    const blob = new Blob([JSON.stringify(resolvedJson, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);

    setStatus("İndiriliyor...");
  });

  jsonFileInput.addEventListener("change", async () => {
    const file = jsonFileInput.files?.[0];
    if (!file) return;

    setStatus("Dosya okunuyor...", { isError: false });
    overlay.classList.add("loading");

    try {
      if (file.size > maxStorageSizeBytes) {
        throw new Error(
          `Dosya çok büyük görünüyor (${formatBytes(file.size)}). Daha küçük bir JSON deneyin.`
        );
      }

      const text = await file.text();
      let parsed;
      try {
        parsed = JSON.parse(text);
      } catch (parseErr) {
        throw new Error("Geçersiz JSON. Lütfen doğru formatta bir dosya seçin.");
      }

      setPreview(parsed);
      setStatus(`Yüklendi: ${file.name} (${formatBytes(file.size)})`, {
        isError: false
      });

      await saveJsonToStorage(parsed, file);

      // JSON yüklendi: kullanıcı "Başlat" ile Google aramalarını başlatır.
      workArea.hidden = false;
      startBtn.disabled = false;
      stopBtn.disabled = true;
      downloadBtn.disabled = true;
      jobMeta.textContent = "";
      setStatus("JSON yüklendi. Başlat’a basarak GTIN’leri çıkarabilirsin.");
    } catch (err) {
      setPreview({ error: String(err?.message ?? err) });
      setStatus(String(err?.message ?? err), { isError: true });
    } finally {
      overlay.classList.remove("loading");
    }
  });
});

