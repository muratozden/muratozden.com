// Injected before DOM capture. Optionally expands Akakce #PL via the same pgList API
// the site uses for "Daha Fazla Göster" (showMore=true), then falls back to SAP clicks.

window.kodigenCaptureRenderedPage = async function kodigenCaptureRenderedPage() {
  if (isAkakceProductPage() && window.__kodigenExpandAkakcePrices === true) {
    await expandAkakcePriceList();
    await sleep(200);
  }

  return {
    html: "<!DOCTYPE html>\n" + document.documentElement.outerHTML,
    url: location.href,
    contentType: document.contentType || "text/html",
  };
};

function isAkakceProductPage() {
  return (
    location.hostname === "www.akakce.com" &&
    /\.html(?:$|[?#])/i.test(location.pathname + location.search)
  );
}

async function prepareAkakcePriceSection() {
  const ul = document.getElementById("PL");
  if (!ul) return;

  scrollPriceSectionIntoView(ul);
  window.dispatchEvent(new Event("scroll"));
  await sleep(400);
  scrollPriceSectionIntoView(ul);
  await sleep(400);
}

function scrollPriceSectionIntoView(ul) {
  ul.scrollIntoView({ block: "center", behavior: "instant" });
  document.getElementById("PL_h")?.scrollIntoView({ block: "center", behavior: "instant" });

  let el = ul.parentElement;
  while (el && el !== document.body) {
    if (el.tagName === "ASTRO-ISLAND" || el.id === "PL_h") {
      el.scrollIntoView({ block: "center", behavior: "instant" });
    }
    el = el.parentElement;
  }
}

async function expandAkakcePriceList() {
  const ul = document.getElementById("PL");
  if (!ul) return;

  const apiResult = await expandAkakcePriceListViaApi(ul);
  if (apiResult === "expanded" || apiResult === "complete") return;

  await prepareAkakcePriceSection();
  await expandAkakcePriceListViaSapClick(ul);
}

async function expandAkakcePriceListViaApi(ul) {
  const prCode = extractAkakcePrCode();
  if (!prCode) return "retry-sap";

  const before = ul.querySelectorAll("li").length;
  const apiUrl = buildAkakcePgListUrl(prCode);

  let payload;
  try {
    const res = await fetch(apiUrl, {
      credentials: "include",
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return "retry-sap";
    payload = await res.json();
  } catch {
    return "retry-sap";
  }

  const items = payload?.result?.pgList;
  if (!Array.isArray(items) || items.length === 0) return "retry-sap";

  // All offers already on the page — no "Daha Fazla Göster" / nothing to expand.
  if (items.length <= before) return "complete";

  ul.innerHTML = items.map((item) => buildAkakceOfferLi(item)).join("");
  hideSapButton();
  return "expanded";
}

async function expandAkakcePriceListViaSapClick(ul) {
  const btn = await waitForSapButton(2_500);
  if (!btn) return;

  const maxRounds = 20;
  for (let round = 0; round < maxRounds; round++) {
    const sapBtn = findSapButton();
    if (!isVisible(sapBtn)) break;

    const before = ul.querySelectorAll("li").length;
    clickSapButton(sapBtn);
    await waitForAkakcePriceExpansion(ul, before, 8000);
    await sleep(300);

    const after = ul.querySelectorAll("li").length;
    if (!isVisible(findSapButton())) break;
    if (after <= before) break;
  }
}

function extractAkakcePrCode() {
  const match = location.pathname.match(/,(\d+)\.html/i);
  return match ? match[1] : null;
}

function buildAkakcePgListUrl(prCode) {
  const env = window.ENV || {};
  const host = env.Api__Product__Host__External || "https://api6.akakce.com";
  const path = env.Api__Product__Path || "/product";
  const endpoint = env.Api__Product__Endpoint__PgList || "/pgList";
  const base = `${host}${path}${endpoint}`;
  const params = new URLSearchParams({
    prCode,
    sortChar: "p",
    showMore: "true",
  });
  return `${base}?${params.toString()}`;
}

function buildAkakceOfferLi(item) {
  const liClass = item.badgeId === 1 ? "c" : "";
  const href = escapeHtmlAttr(item.url || "");
  const vdName = escapeHtmlAttr(item.vdName || "");
  const vdCode = Number(item.vdCode) || 0;
  const priceHtml = formatAkakcePrice(item.price);

  return (
    `<li class="${liClass}">` +
    `<a href="${href}" class="iC xt_v8" rel="nofollow" target="_blank">` +
    `<span class="pb_v8"><span class="pt_v8 ">${priceHtml}</span></span>` +
    `<span class="w_v8"><span class="v_v8">` +
    `<img alt="${vdName}" src="https://cdn.akakce.com/im/m6/${vdCode}.svg" loading="lazy">` +
    `</span></span>` +
    `</a></li>`
  );
}

function formatAkakcePrice(price) {
  const n = Number(price);
  if (!Number.isFinite(n)) return "";
  const [whole, frac] = n.toFixed(2).split(".");
  const wholeFormatted = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `${wholeFormatted}<i>,${frac} TL</i>`;
}

function escapeHtmlAttr(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;");
}

function hideSapButton() {
  const btn = findSapButton();
  btn?.closest(".dg")?.remove();
  btn?.remove();
}

function findSapButton() {
  const byId = document.getElementById("SAP");
  if (byId) return byId;

  const roots = [
    document.getElementById("PL_h"),
    document.getElementById("PL")?.closest("section"),
    document.getElementById("PL")?.parentElement,
  ].filter(Boolean);

  for (const root of roots) {
    for (const btn of root.querySelectorAll("button#SAP, button.more, button.t2b")) {
      if (isSapButtonText(btn.textContent)) return btn;
    }
  }

  for (const btn of document.querySelectorAll("button#SAP, button.more")) {
    if (isSapButtonText(btn.textContent)) return btn;
  }
  return null;
}

function isSapButtonText(text) {
  const t = String(text || "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
  if (!t.includes("fazla")) return false;
  return (
    t.includes("fiyat") ||
    t.includes("gör") ||
    t.includes("goster") ||
    t.includes("göster")
  );
}

function clickSapButton(btn) {
  btn.scrollIntoView({ block: "center", behavior: "instant" });
  btn.focus({ preventScroll: true });

  const opts = { bubbles: true, cancelable: true, view: window };
  for (const type of ["pointerover", "pointerenter", "pointerdown", "mousedown"]) {
    btn.dispatchEvent(new PointerEvent(type, { ...opts, pointerId: 1, pointerType: "mouse" }));
  }
  for (const type of ["pointerup", "mouseup", "click"]) {
    btn.dispatchEvent(new PointerEvent(type, { ...opts, pointerId: 1, pointerType: "mouse" }));
  }
  btn.click();
}

async function waitForSapButton(timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const btn = findSapButton();
    if (btn && isVisible(btn)) return btn;
    document.getElementById("PL")?.scrollIntoView({ block: "center", behavior: "instant" });
    window.dispatchEvent(new Event("scroll"));
    await sleep(250);
  }
  return null;
}

function waitForAkakcePriceExpansion(ul, prevCount, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      observer.disconnect();
      clearTimeout(timer);
      clearInterval(poll);
      resolve();
    };

    const observer = new MutationObserver(() => {
      if (ul.querySelectorAll("li").length > prevCount) finish();
    });
    observer.observe(ul, { childList: true, subtree: true });

    const timer = setTimeout(finish, timeoutMs);
    const poll = setInterval(() => {
      if (ul.querySelectorAll("li").length > prevCount) finish();
    }, 150);
  });
}

function isVisible(el) {
  if (!el) return false;
  if (el.hidden) return false;
  const style = window.getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden") return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
