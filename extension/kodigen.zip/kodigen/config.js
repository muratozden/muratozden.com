// Production crawler API (shared with admin and other datascraper clients).
const DEFAULT_API_URL = "https://api.datascraper.net";
