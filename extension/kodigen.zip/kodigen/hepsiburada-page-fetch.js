// Injected into Hepsiburada review tabs. Must be fully self-contained.

window.__kodigenScrapeHepsiburadaReviewsPage = async function scrapeHepsiburadaReviewsPage() {
  await settleReviewListDom();
  const comments = scrapeReviewCardsFromDom();
  return {
    comments,
    totalPages: readPaginationTotalPages(),
    currentPage: readCurrentPageNumber(),
    price: extractProductPrice(),
    pageSize: comments.length,
  };
};

window.__kodigenResolveHepsiburadaSku = function resolveHepsiburadaSkuFromPage(fallbackSku) {
  return resolveSku(fallbackSku);
};

function resolveSku(fallbackSku) {
  const fromPath = location.pathname.match(/-p-([A-Za-z0-9]+)/i);
  if (fromPath) return fromPath[1];
  const html = document.documentElement?.innerHTML || "";
  for (const re of [/"sku"\s*:\s*"([A-Za-z0-9]+)"/, /"productId"\s*:\s*"([A-Za-z0-9]+)"/]) {
    const hit = html.match(re);
    if (hit) return hit[1];
  }
  return String(fallbackSku || "").trim();
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function textOf(el) {
  return el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : "";
}

function toNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function normalizeItem(item) {
  return {
    userFullName: String(item.userFullName || item.userName || item.author || ""),
    rate: item.rate ?? item.rating ?? item.score ?? null,
    comment: String(item.comment || item.reviewText || item.text || ""),
  };
}

async function settleReviewListDom() {
  const deadline = Date.now() + 20_000;
  while (Date.now() < deadline) {
    const cards = findReviewCards();
    if (cards.length > 0) break;
    window.scrollTo(0, document.body.scrollHeight);
    await sleep(500);
  }

  const cards = findReviewCards();
  if (!cards.length) {
    await sleep(2000);
    return;
  }

  cards[0].scrollIntoView({ block: "start" });
  await sleep(500);
  window.scrollTo(0, document.body.scrollHeight);
  await sleep(700);
  window.scrollTo(0, 0);
  await sleep(300);
}

function findReviewCards() {
  return [
    ...document.querySelectorAll(
      '[class*="hermes-ReviewCard-module"], [class*="ReviewCard-module"], [itemprop="review"]',
    ),
  ];
}

function findPaginationRoot() {
  return (
    document.querySelector('[class*="hermes-Pagination-module"]') ||
    document.querySelector('[class*="Pagination-module"]') ||
    document.querySelector('[class*="pagination"]') ||
    document.querySelector('[data-test-id*="pagination"]')
  );
}

function findPaginationList() {
  const root = findPaginationRoot();
  if (!root) return null;
  if (root.tagName === "UL") return root;
  return root.querySelector("ul");
}

function readPaginationPageNumbers() {
  const ul = findPaginationList();
  if (!ul) return [];

  const pages = [];
  for (const li of ul.querySelectorAll(":scope > li")) {
    const span = li.querySelector("span") || li;
    const fromText = parseInt(textOf(span), 10);
    if (Number.isFinite(fromText) && fromText > 0) {
      pages.push(fromText);
      continue;
    }
    const link = li.querySelector("a[href*='sayfa=']");
    if (link) {
      const match = link.getAttribute("href")?.match(/sayfa=(\d+)/i);
      if (match) {
        const n = parseInt(match[1], 10);
        if (Number.isFinite(n) && n > 0) pages.push(n);
      }
    }
  }
  return pages;
}

function readPaginationTotalPages() {
  const pages = readPaginationPageNumbers();
  if (!pages.length) return 1;
  return Math.max(...pages);
}

function readCurrentPageNumber() {
  const fromUrl = new URLSearchParams(location.search).get("sayfa");
  if (fromUrl) {
    const n = parseInt(fromUrl, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }

  const root = findPaginationRoot();
  if (root) {
    const currentEl =
      root.querySelector('[aria-current="page"]') ||
      root.querySelector('[class*="active"]') ||
      root.querySelector('[class*="selected"]');
    if (currentEl) {
      const n = parseInt(textOf(currentEl), 10);
      if (Number.isFinite(n) && n > 0) return n;
    }
  }
  return 1;
}

function extractProductPrice() {
  const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
  for (const script of ldScripts) {
    try {
      const data = JSON.parse(script.textContent || "");
      const nodes = Array.isArray(data) ? data : [data];
      for (const node of nodes) {
        if (node?.["@type"] !== "Product" && !node?.offers) continue;
        const offer = node?.offers;
        const offers = Array.isArray(offer) ? offer : offer ? [offer] : [];
        for (const item of offers) {
          const selling = toNumber(item.price ?? item.lowPrice ?? item.highPrice);
          if (selling != null) {
            return {
              selling_price: selling,
              original_price: toNumber(item.highPrice) ?? selling,
              discounted_price: toNumber(item.lowPrice),
              currency: String(item.priceCurrency || "TRY"),
            };
          }
        }
      }
    } catch {
      // ignore malformed JSON-LD
    }
  }

  const html = document.documentElement?.innerHTML || "";
  const priceMatch = html.match(/"price"\s*:\s*(\d+(?:\.\d+)?)/);
  if (priceMatch) {
    const selling = toNumber(priceMatch[1]);
    if (selling != null) {
      return {
        selling_price: selling,
        original_price: selling,
        discounted_price: null,
        currency: "TRY",
      };
    }
  }

  return null;
}

function parseRateFromElement(el) {
  if (!el) return null;

  const aria = el.getAttribute?.("aria-label") || "";
  const ariaMatch =
    aria.match(/(\d)\s*(?:\/\s*5|yıldız|star)/i) ||
    aria.match(/^(\d)$/);
  if (ariaMatch) return Number(ariaMatch[1]);

  const starsWrap = el.querySelector(
    '[class*="StarRating"], [class*="star-rating"], [class*="star"], [class*="rating"], [class*="puan"]',
  );
  if (starsWrap) {
    const active = starsWrap.querySelectorAll(
      '[class*="full"], [class*="filled"], [class*="active"], [class*="selected"], [class*="Full"]',
    ).length;
    if (active > 0 && active <= 5) return active;
  }

  const txt = textOf(el);
  const m = txt.match(/(\d)\s*\/\s*5/) || txt.match(/(\d)\s*yıldız/i);
  if (m) return Number(m[1]);
  return null;
}

function parseReviewCard(el) {
  if (!el || el.nodeType !== 1) return null;

  const comment = textOf(
    el.querySelector(
      [
        '[class*="ReviewContent"]',
        '[class*="review-content"]',
        '[class*="CommentText"]',
        '[class*="comment-text"]',
        '[class*="comment-body"]',
        '[class*="ReviewText"]',
        '[itemprop="reviewBody"]',
      ].join(", "),
    ),
  );

  const userFullName = textOf(
    el.querySelector(
      [
        '[class*="CustomerDisplay"]',
        '[class*="customer-display"]',
        '[class*="CustomerName"]',
        '[class*="customer-name"]',
        '[class*="displayName"]',
        '[class*="user-name"]',
        '[itemprop="author"]',
      ].join(", "),
    ),
  );

  const rate =
    parseRateFromElement(el) ??
    parseRateFromElement(
      el.querySelector(
        '[class*="StarRating"], [class*="star-rating"], [class*="rating"], [itemprop="ratingValue"]',
      ),
    );

  if (!comment && rate == null && !userFullName) {
    const raw = textOf(el);
    if (raw.length < 12) return null;
    return normalizeItem({ userFullName: "", rate: parseRateFromElement(el), comment: raw });
  }

  if (!comment && !userFullName && rate == null) return null;

  return normalizeItem({ userFullName, rate, comment });
}

function scrapeReviewCardsFromDom() {
  const items = [];
  for (const card of findReviewCards()) {
    const item = parseReviewCard(card);
    if (item) items.push(item);
  }
  return items;
}
