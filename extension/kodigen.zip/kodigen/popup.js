// Popup: mode toggles + compact activity + settings.

const DEFAULT_CRAWLER_LIMIT = 1;
const MAX_CRAWLER_LIMIT = 100;

function clampCrawlerLimit(value) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n) || n < 1) return DEFAULT_CRAWLER_LIMIT;
  if (n > MAX_CRAWLER_LIMIT) return MAX_CRAWLER_LIMIT;
  return n;
}

const els = {
  headerTitle: document.getElementById("header-title"),
  headerSub: document.getElementById("header-sub"),
  btnSettings: document.getElementById("btn-settings"),
  viewMain: document.getElementById("view-main"),
  viewSettings: document.getElementById("view-settings"),
  settingsApiUrl: document.getElementById("settings-api-url"),
  settingsApiKey: document.getElementById("settings-api-key"),
  settingsCrawlerLimit: document.getElementById("settings-crawler-limit"),
  settingsKeyHint: document.getElementById("settings-key-hint"),
  settingsError: document.getElementById("settings-error"),
  btnSave: document.getElementById("btn-save"),
  btnCancel: document.getElementById("btn-cancel"),
  toggle: document.getElementById("toggle-enabled"),
  toggleTour: document.getElementById("toggle-akakce-tour"),
  toggleMerchant: document.getElementById("toggle-merchant-links"),
  toggleBackfill: document.getElementById("toggle-merchant-backfill"),
  toggleReviews: document.getElementById("toggle-trendyol-reviews"),
  toggleHbReviews: document.getElementById("toggle-hepsiburada-reviews"),
  cardVisit: document.getElementById("card-visit"),
  cardTour: document.getElementById("card-tour"),
  cardMerchant: document.getElementById("card-merchant"),
  cardBackfill: document.getElementById("card-backfill"),
  cardReviews: document.getElementById("card-reviews"),
  cardHbReviews: document.getElementById("card-hb-reviews"),
  switchLabel: document.getElementById("switch-label"),
  tourSwitchLabel: document.getElementById("tour-switch-label"),
  merchantSwitchLabel: document.getElementById("merchant-switch-label"),
  backfillSwitchLabel: document.getElementById("backfill-switch-label"),
  reviewsSwitchLabel: document.getElementById("reviews-switch-label"),
  hbReviewsSwitchLabel: document.getElementById("hb-reviews-switch-label"),
  statusDot: document.getElementById("status-dot"),
  statDone: document.getElementById("stat-done"),
  statFailed: document.getElementById("stat-failed"),
  tourStats: document.getElementById("tour-stats"),
  merchantStats: document.getElementById("merchant-stats"),
  backfillStats: document.getElementById("backfill-stats"),
  reviewsStats: document.getElementById("reviews-stats"),
  hbReviewsStats: document.getElementById("hb-reviews-stats"),
  statTourDone: document.getElementById("stat-tour-done"),
  statTourVisited: document.getElementById("stat-tour-visited"),
  statMerchantDone: document.getElementById("stat-merchant-done"),
  statMerchantFailed: document.getElementById("stat-merchant-failed"),
  merchantCategory: document.getElementById("merchant-category"),
  merchantFilter: document.getElementById("merchant-filter"),
  statBackfillDone: document.getElementById("stat-backfill-done"),
  statBackfillFailed: document.getElementById("stat-backfill-failed"),
  statReviewsDone: document.getElementById("stat-reviews-done"),
  statReviewsFailed: document.getElementById("stat-reviews-failed"),
  statHbReviewsDone: document.getElementById("stat-hb-reviews-done"),
  statHbReviewsFailed: document.getElementById("stat-hb-reviews-failed"),
  reviewsReset: document.getElementById("reviews-reset"),
  hbReviewsReset: document.getElementById("hb-reviews-reset"),
  btnReviewsReset: document.getElementById("btn-reviews-reset"),
  btnHbReviewsReset: document.getElementById("btn-hb-reviews-reset"),
  lastUrl: document.getElementById("last-url"),
  mainError: document.getElementById("main-error"),
};

/** True when the user opened Settings from the main screen (Cancel returns there). */
let settingsFromMain = false;

init();

async function init() {
  const state = await loadState();

  if (state.apiKey) {
    showMain(state);
  } else {
    els.settingsApiUrl.value = state.apiUrl || DEFAULT_API_URL;
    els.settingsApiKey.value = "";
    els.settingsCrawlerLimit.value = String(DEFAULT_CRAWLER_LIMIT);
    showSettings({ firstRun: true });
  }

  els.btnSettings.addEventListener("click", () => openSettings());
  els.btnSave.addEventListener("click", onSave);
  els.btnCancel.addEventListener("click", onCancel);
  els.toggle.addEventListener("change", onToggle);
  els.toggleTour.addEventListener("change", onTourToggle);
  els.toggleMerchant.addEventListener("change", onMerchantToggle);
  els.toggleBackfill.addEventListener("change", onBackfillToggle);
  els.toggleReviews.addEventListener("change", onReviewsToggle);
  els.toggleHbReviews.addEventListener("change", onHbReviewsToggle);
  els.btnReviewsReset.addEventListener("click", onReviewsReset);
  els.btnHbReviewsReset.addEventListener("click", onHbReviewsReset);
  els.merchantCategory.addEventListener("change", onMerchantCategoryChange);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.visitsDone) els.statDone.textContent = changes.visitsDone.newValue;
    if (changes.visitsFailed) els.statFailed.textContent = changes.visitsFailed.newValue;
    if (changes.lastUrl) setLastUrl(changes.lastUrl.newValue);
    if (changes.lastError) setMainError(changes.lastError.newValue);
    if (changes.akakceTourDone) els.statTourDone.textContent = changes.akakceTourDone.newValue;
    if (changes.akakceTourVisitedUrls) {
      els.statTourVisited.textContent = (changes.akakceTourVisitedUrls.newValue || []).length;
    }
    if (changes.merchantLinkDone) els.statMerchantDone.textContent = changes.merchantLinkDone.newValue;
    if (changes.merchantLinkFailed) els.statMerchantFailed.textContent = changes.merchantLinkFailed.newValue;
    if (changes.merchantBackfillDone) els.statBackfillDone.textContent = changes.merchantBackfillDone.newValue;
    if (changes.merchantBackfillFailed) els.statBackfillFailed.textContent = changes.merchantBackfillFailed.newValue;
    if (changes.trendyolReviewsDone) els.statReviewsDone.textContent = changes.trendyolReviewsDone.newValue;
    if (changes.trendyolReviewsFailed) els.statReviewsFailed.textContent = changes.trendyolReviewsFailed.newValue;
    if (changes.hepsiburadaReviewsDone) els.statHbReviewsDone.textContent = changes.hepsiburadaReviewsDone.newValue;
    if (changes.hepsiburadaReviewsFailed) els.statHbReviewsFailed.textContent = changes.hepsiburadaReviewsFailed.newValue;
    if (changes.enabled) {
      renderEnabled(changes.enabled.newValue);
      renderStatusDot(
        changes.enabled.newValue,
        els.toggleTour.checked,
        els.toggleMerchant.checked,
        els.toggleBackfill.checked,
        els.toggleReviews.checked,
        els.toggleHbReviews.checked,
      );
    }
    if (changes.akakceTourEnabled) {
      renderTourEnabled(changes.akakceTourEnabled.newValue);
      renderStatusDot(
        els.toggle.checked,
        changes.akakceTourEnabled.newValue,
        els.toggleMerchant.checked,
        els.toggleBackfill.checked,
        els.toggleReviews.checked,
        els.toggleHbReviews.checked,
      );
    }
    if (changes.merchantLinkResolverEnabled) {
      renderMerchantEnabled(changes.merchantLinkResolverEnabled.newValue);
      renderStatusDot(
        els.toggle.checked,
        els.toggleTour.checked,
        changes.merchantLinkResolverEnabled.newValue,
        els.toggleBackfill.checked,
        els.toggleReviews.checked,
        els.toggleHbReviews.checked,
      );
    }
    if (changes.merchantLinkCategory) {
      els.merchantCategory.value = changes.merchantLinkCategory.newValue || "";
    }
    if (changes.merchantLinkBackfillEnabled) {
      renderBackfillEnabled(changes.merchantLinkBackfillEnabled.newValue);
      renderStatusDot(
        els.toggle.checked,
        els.toggleTour.checked,
        els.toggleMerchant.checked,
        changes.merchantLinkBackfillEnabled.newValue,
        els.toggleReviews.checked,
        els.toggleHbReviews.checked,
      );
    }
    if (changes.trendyolReviewsEnabled || changes.trendyolReviewsComplete || changes.lastStatus) {
      chrome.storage.local.get({
        trendyolReviewsEnabled: false,
        trendyolReviewsComplete: false,
        trendyolReviewsIgnoreDoneIds: false,
        lastStatus: "",
      }).then((cur) => {
        renderReviewsEnabled(
          changes.trendyolReviewsEnabled?.newValue ?? cur.trendyolReviewsEnabled,
          changes.trendyolReviewsComplete?.newValue ?? cur.trendyolReviewsComplete,
          changes.lastStatus?.newValue ?? cur.lastStatus,
        );
      });
    }
    if (changes.hepsiburadaReviewsEnabled || changes.hepsiburadaReviewsComplete || changes.lastStatus) {
      chrome.storage.local.get({
        hepsiburadaReviewsEnabled: false,
        hepsiburadaReviewsComplete: false,
        hepsiburadaReviewsIgnoreDoneIds: false,
        lastStatus: "",
      }).then((cur) => {
        renderHbReviewsEnabled(
          changes.hepsiburadaReviewsEnabled?.newValue ?? cur.hepsiburadaReviewsEnabled,
          changes.hepsiburadaReviewsComplete?.newValue ?? cur.hepsiburadaReviewsComplete,
          changes.lastStatus?.newValue ?? cur.lastStatus,
        );
      });
    }
    if (changes.trendyolReviewsEnabled) {
      renderStatusDot(
        els.toggle.checked,
        els.toggleTour.checked,
        els.toggleMerchant.checked,
        els.toggleBackfill.checked,
        changes.trendyolReviewsEnabled.newValue,
        els.toggleHbReviews.checked,
      );
    }
    if (changes.hepsiburadaReviewsEnabled) {
      renderStatusDot(
        els.toggle.checked,
        els.toggleTour.checked,
        els.toggleMerchant.checked,
        els.toggleBackfill.checked,
        els.toggleReviews.checked,
        changes.hepsiburadaReviewsEnabled.newValue,
      );
    }
  });
}

async function loadState() {
  return chrome.storage.local.get({
    apiUrl: DEFAULT_API_URL,
    apiKey: "",
    enabled: false,
    akakceTourEnabled: false,
    merchantLinkResolverEnabled: false,
    merchantLinkCategory: "",
    merchantLinkBackfillEnabled: false,
    trendyolReviewsEnabled: false,
    hepsiburadaReviewsEnabled: false,
    visitsDone: 0,
    visitsFailed: 0,
    akakceTourDone: 0,
    akakceTourVisitedUrls: [],
    merchantLinkDone: 0,
    merchantLinkFailed: 0,
    merchantBackfillDone: 0,
    merchantBackfillFailed: 0,
    trendyolReviewsDone: 0,
    trendyolReviewsFailed: 0,
    trendyolReviewsComplete: false,
    trendyolReviewsIgnoreDoneIds: false,
    hepsiburadaReviewsDone: 0,
    hepsiburadaReviewsFailed: 0,
    hepsiburadaReviewsComplete: false,
    hepsiburadaReviewsIgnoreDoneIds: false,
    lastStatus: "",
    lastUrl: "",
    lastError: "",
    crawlerLimit: DEFAULT_CRAWLER_LIMIT,
  });
}

function showMain(state) {
  settingsFromMain = false;
  els.viewMain.hidden = false;
  els.viewSettings.hidden = true;
  els.btnSettings.hidden = false;
  els.headerTitle.textContent = "n11 Crawler Agent";
  els.headerSub.textContent = "External visit client";
  els.toggle.checked = state.enabled;
  els.toggleTour.checked = state.akakceTourEnabled;
  els.toggleMerchant.checked = state.merchantLinkResolverEnabled;
  els.toggleBackfill.checked = state.merchantLinkBackfillEnabled;
  els.toggleReviews.checked = state.trendyolReviewsEnabled;
  els.toggleHbReviews.checked = state.hepsiburadaReviewsEnabled;
  els.merchantCategory.value = state.merchantLinkCategory || "";
  renderEnabled(state.enabled);
  renderTourEnabled(state.akakceTourEnabled);
  renderMerchantEnabled(state.merchantLinkResolverEnabled);
  renderBackfillEnabled(state.merchantLinkBackfillEnabled);
  renderReviewsEnabled(
    state.trendyolReviewsEnabled,
    state.trendyolReviewsComplete,
    state.lastStatus,
  );
  renderHbReviewsEnabled(
    state.hepsiburadaReviewsEnabled,
    state.hepsiburadaReviewsComplete,
    state.lastStatus,
  );
  renderStatusDot(
    state.enabled,
    state.akakceTourEnabled,
    state.merchantLinkResolverEnabled,
    state.merchantLinkBackfillEnabled,
    state.trendyolReviewsEnabled,
    state.hepsiburadaReviewsEnabled,
  );
  els.statDone.textContent = state.visitsDone;
  els.statFailed.textContent = state.visitsFailed;
  els.statTourDone.textContent = state.akakceTourDone;
  els.statTourVisited.textContent = (state.akakceTourVisitedUrls || []).length;
  els.statMerchantDone.textContent = state.merchantLinkDone;
  els.statMerchantFailed.textContent = state.merchantLinkFailed;
  els.statBackfillDone.textContent = state.merchantBackfillDone;
  els.statBackfillFailed.textContent = state.merchantBackfillFailed;
  els.statReviewsDone.textContent = state.trendyolReviewsDone;
  els.statReviewsFailed.textContent = state.trendyolReviewsFailed;
  els.statHbReviewsDone.textContent = state.hepsiburadaReviewsDone;
  els.statHbReviewsFailed.textContent = state.hepsiburadaReviewsFailed;
  setLastUrl(state.lastUrl);
  setMainError(state.lastError);
  loadMerchantCategories(state);
}

async function loadMerchantCategories(state) {
  if (!state.apiUrl || !state.apiKey) return;

  const selected = state.merchantLinkCategory || "";
  els.merchantCategory.disabled = true;

  try {
    const res = await fetch(state.apiUrl + "/v1/akakce-hub/merchant-links/categories", {
      headers: { Authorization: "ApiKey " + state.apiKey },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const items = (data && data.items) || [];

    const options = ['<option value="">All categories</option>'];
    for (const item of items) {
      const slug = String(item.slug || "");
      if (!slug) continue;
      const label = item.label || slug;
      const count = Number(item.pending_count) || 0;
      const suffix = count > 0 ? ` (${count})` : "";
      options.push(
        `<option value="${escapeHtml(slug)}">${escapeHtml(label)}${suffix}</option>`,
      );
    }
    els.merchantCategory.innerHTML = options.join("");
    els.merchantCategory.value = items.some((item) => item.slug === selected) ? selected : "";
    if (selected && els.merchantCategory.value !== selected) {
      await chrome.storage.local.set({
        merchantLinkCategory: "",
        merchantLinkCursor: "",
        trendyolReviewsCursor: "",
        trendyolReviewsComplete: false,
        trendyolReviewsIgnoreDoneIds: false,
        trendyolReviewsDoneContentIds: [],
        hepsiburadaReviewsCursor: "",
        hepsiburadaReviewsComplete: false,
        hepsiburadaReviewsIgnoreDoneIds: false,
        hepsiburadaReviewsDoneSkus: [],
      });
    }
  } catch {
    els.merchantCategory.innerHTML = '<option value="">All categories</option>';
    els.merchantCategory.value = "";
  } finally {
    els.merchantCategory.disabled = false;
  }
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function showSettings({ firstRun }) {
  els.viewMain.hidden = true;
  els.viewSettings.hidden = false;
  els.btnSettings.hidden = true;
  els.headerTitle.textContent = "Settings";
  els.headerSub.textContent = "API connection";
  els.settingsError.hidden = true;
  els.btnCancel.hidden = firstRun;
  els.settingsKeyHint.hidden = firstRun;
}

async function openSettings() {
  settingsFromMain = true;
  const state = await loadState();
  els.settingsApiUrl.value = state.apiUrl || DEFAULT_API_URL;
  els.settingsApiKey.value = "";
  els.settingsCrawlerLimit.value = String(clampCrawlerLimit(state.crawlerLimit));
  showSettings({ firstRun: false });
}

function renderEnabled(enabled) {
  els.cardVisit.classList.toggle("is-on", enabled);
  els.switchLabel.textContent = enabled ? "Running" : "Off";
}

function renderTourEnabled(enabled) {
  els.cardTour.classList.toggle("is-on", enabled);
  els.tourSwitchLabel.textContent = enabled ? "Running" : "Off";
  els.tourStats.hidden = !enabled;
}

function renderMerchantEnabled(enabled) {
  els.cardMerchant.classList.toggle("is-on", enabled);
  els.merchantSwitchLabel.textContent = enabled ? "Running" : "Off";
  els.merchantStats.hidden = !enabled;
}

function renderBackfillEnabled(enabled) {
  els.cardBackfill.classList.toggle("is-on", enabled);
  els.backfillSwitchLabel.textContent = enabled ? "Running" : "Off";
  els.backfillStats.hidden = !enabled;
}

function reviewStatusFor(prefix, lastStatus) {
  const status = String(lastStatus || "");
  return status.startsWith(prefix) ? status : "";
}

function renderReviewsEnabled(enabled, complete, lastStatus) {
  const status = reviewStatusFor("trendyol-reviews", lastStatus);
  const isDone =
    Boolean(enabled) &&
    Boolean(complete) &&
    status === "trendyol-reviews-complete";
  const isRunning =
    Boolean(enabled) &&
    !isDone &&
    status !== "trendyol-reviews-api-empty" &&
    status !== "trendyol-reviews-api-failed";
  els.cardReviews.classList.toggle("is-on", isRunning || status === "trendyol-reviews-reset");
  if (!enabled) {
    els.reviewsSwitchLabel.textContent = "Off";
  } else if (isDone) {
    els.reviewsSwitchLabel.textContent = "Done";
  } else if (status === "trendyol-reviews-waiting") {
    els.reviewsSwitchLabel.textContent = "Waiting";
  } else if (status === "trendyol-reviews-reset") {
    els.reviewsSwitchLabel.textContent = "Starting";
  } else if (status === "trendyol-reviews-api-empty" || status === "trendyol-reviews-api-failed") {
    els.reviewsSwitchLabel.textContent = "Error";
  } else {
    els.reviewsSwitchLabel.textContent = "Running";
  }
  els.reviewsStats.hidden = !enabled;
  els.reviewsReset.hidden = !enabled;
}

function renderHbReviewsEnabled(enabled, complete, lastStatus) {
  const status = reviewStatusFor("hepsiburada-reviews", lastStatus);
  const isDone =
    Boolean(enabled) &&
    Boolean(complete) &&
    status === "hepsiburada-reviews-complete";
  const isRunning =
    Boolean(enabled) &&
    !isDone &&
    status !== "hepsiburada-reviews-api-empty" &&
    status !== "hepsiburada-reviews-api-failed" &&
    status !== "hepsiburada-reviews-failed";
  els.cardHbReviews.classList.toggle(
    "is-on",
    isRunning || status === "hepsiburada-reviews-reset" || status === "hepsiburada-reviews-collecting",
  );
  if (!enabled) {
    els.hbReviewsSwitchLabel.textContent = "Off";
  } else if (isDone) {
    els.hbReviewsSwitchLabel.textContent = "Done";
  } else if (status === "hepsiburada-reviews-waiting" || status === "hepsiburada-reviews-collecting") {
    els.hbReviewsSwitchLabel.textContent = status === "hepsiburada-reviews-collecting" ? "Collecting" : "Waiting";
  } else if (status === "hepsiburada-reviews-reset") {
    els.hbReviewsSwitchLabel.textContent = "Starting";
  } else if (status === "hepsiburada-reviews-api-empty" || status === "hepsiburada-reviews-api-failed") {
    els.hbReviewsSwitchLabel.textContent = "Error";
  } else {
    els.hbReviewsSwitchLabel.textContent = "Running";
  }
  els.hbReviewsStats.hidden = !enabled;
  els.hbReviewsReset.hidden = !enabled;
}

function renderStatusDot(enabled, tourEnabled, merchantEnabled, backfillEnabled, reviewsEnabled, hbReviewsEnabled) {
  const on =
    Boolean(enabled) ||
    Boolean(tourEnabled) ||
    Boolean(merchantEnabled) ||
    Boolean(backfillEnabled) ||
    Boolean(reviewsEnabled) ||
    Boolean(hbReviewsEnabled);
  els.statusDot.classList.toggle("on", on);
}

function setLastUrl(url) {
  els.lastUrl.hidden = !url;
  els.lastUrl.textContent = url || "";
}

function setMainError(msg) {
  els.mainError.hidden = !msg;
  els.mainError.textContent = msg || "";
}

function showSettingsError(msg) {
  els.settingsError.hidden = false;
  els.settingsError.textContent = msg;
}

async function onSave() {
  const apiUrl = els.settingsApiUrl.value.trim().replace(/\/+$/, "");
  const keyInput = els.settingsApiKey.value.trim();
  const crawlerLimit = clampCrawlerLimit(els.settingsCrawlerLimit.value);
  const stored = await loadState();
  const apiKey = keyInput || stored.apiKey;

  els.settingsError.hidden = true;

  if (!apiUrl) {
    showSettingsError("API URL is required.");
    return;
  }
  if (!apiKey) {
    showSettingsError("API key is required.");
    return;
  }

  els.btnSave.disabled = true;
  els.btnSave.textContent = "Checking…";
  try {
    const res = await fetch(apiUrl + "/v1/stats", {
      headers: { Authorization: "ApiKey " + apiKey },
    });
    if (res.status === 401) throw new Error("API key rejected (401).");
    if (!res.ok) throw new Error(`API responded with HTTP ${res.status}.`);
  } catch (err) {
    showSettingsError(err instanceof Error ? err.message : "Could not reach the API.");
    els.btnSave.disabled = false;
    els.btnSave.textContent = "Save";
    return;
  }

  const patch = { apiUrl, apiKey, crawlerLimit };
  if (!stored.apiKey) {
    patch.enabled = false;
    patch.akakceTourEnabled = false;
    patch.merchantLinkResolverEnabled = false;
    patch.merchantLinkBackfillEnabled = false;
    patch.trendyolReviewsEnabled = false;
    patch.hepsiburadaReviewsEnabled = false;
  }
  await chrome.storage.local.set(patch);

  els.btnSave.disabled = false;
  els.btnSave.textContent = "Save";
  els.settingsApiKey.value = "";

  const state = await loadState();
  showMain(state);
}

async function onCancel() {
  if (!settingsFromMain) return;
  els.settingsApiKey.value = "";
  els.settingsError.hidden = true;
  const state = await loadState();
  showMain(state);
}

async function onToggle() {
  const enabled = els.toggle.checked;
  await chrome.storage.local.set({ enabled, lastError: "" });
  renderEnabled(enabled);
  const state = await loadState();
  renderStatusDot(enabled, state.akakceTourEnabled, state.merchantLinkResolverEnabled, state.merchantLinkBackfillEnabled, state.trendyolReviewsEnabled, state.hepsiburadaReviewsEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "enabled-changed", enabled }).catch(() => {});
}

async function onTourToggle() {
  const akakceTourEnabled = els.toggleTour.checked;
  await chrome.storage.local.set({ akakceTourEnabled, lastError: "" });
  renderTourEnabled(akakceTourEnabled);
  const state = await loadState();
  renderStatusDot(state.enabled, akakceTourEnabled, state.merchantLinkResolverEnabled, state.merchantLinkBackfillEnabled, state.trendyolReviewsEnabled, state.hepsiburadaReviewsEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "akakce-tour-changed", enabled: akakceTourEnabled }).catch(() => {});
}

async function onMerchantToggle() {
  const merchantLinkResolverEnabled = els.toggleMerchant.checked;
  await chrome.storage.local.set({ merchantLinkResolverEnabled, lastError: "" });
  renderMerchantEnabled(merchantLinkResolverEnabled);
  const state = await loadState();
  renderStatusDot(state.enabled, state.akakceTourEnabled, merchantLinkResolverEnabled, state.merchantLinkBackfillEnabled, state.trendyolReviewsEnabled, state.hepsiburadaReviewsEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "merchant-link-changed", enabled: merchantLinkResolverEnabled }).catch(() => {});
}

async function onMerchantCategoryChange() {
  const merchantLinkCategory = els.merchantCategory.value.trim();
  await chrome.storage.local.set({
    merchantLinkCategory,
    merchantLinkCursor: "",
    trendyolReviewsCursor: "",
    trendyolReviewsComplete: false,
    trendyolReviewsIgnoreDoneIds: false,
    trendyolReviewsDoneContentIds: [],
    trendyolReviewsDone: 0,
    trendyolReviewsFailed: 0,
    hepsiburadaReviewsCursor: "",
    hepsiburadaReviewsComplete: false,
    hepsiburadaReviewsIgnoreDoneIds: false,
    hepsiburadaReviewsDoneSkus: [],
    hepsiburadaReviewsDone: 0,
    hepsiburadaReviewsFailed: 0,
    lastError: "",
  });
  chrome.runtime.sendMessage({ type: "merchant-category-changed", category: merchantLinkCategory }).catch(() => {});
}

async function trendyolReviewsResetStorage() {
  await chrome.storage.local.remove([
    "trendyolReviewsDoneContentIds",
    "trendyolReviewsIgnoreDoneIds",
  ]);
  await chrome.storage.local.set({
    trendyolReviewsCursor: "",
    trendyolReviewsComplete: false,
    trendyolReviewsDone: 0,
    trendyolReviewsFailed: 0,
    lastError: "",
    lastStatus: "trendyol-reviews-reset",
    lastUrl: "",
  });
}

async function probeTrendyolReviewTargets(state) {
  const category = String(state.merchantLinkCategory || "").trim();
  let path = `/v1/products/trendyol-review-targets?limit=1`;
  if (category) {
    path += `&akakce_category=${encodeURIComponent(category)}`;
  }
  const res = await fetch(state.apiUrl + path, {
    headers: { Authorization: "ApiKey " + state.apiKey },
  });
  const data = await res.json().catch(() => ({}));
  const count = Array.isArray(data.items) ? data.items.length : 0;
  if (!res.ok) {
    throw new Error(`API ${res.status}: ${data.error || res.statusText}`);
  }
  return { count, path };
}

async function onReviewsReset() {
  const wasEnabled = els.toggleReviews.checked;
  els.statReviewsDone.textContent = "0";
  els.statReviewsFailed.textContent = "0";
  setLastUrl("");
  setMainError("");

  await trendyolReviewsResetStorage();
  renderReviewsEnabled(wasEnabled, false, "trendyol-reviews-reset");

  try {
    const state = await loadState();
    const probe = await probeTrendyolReviewTargets(state);
    if (probe.count === 0) {
      setMainError(`API returned 0 targets for ${state.merchantLinkCategory || "all categories"}`);
    }

    const res = await chrome.runtime.sendMessage({ type: "trendyol-reviews-reset" });
    if (!res?.ok) {
      throw new Error(res?.error || "background reset failed");
    }

    const after = await loadState();
    renderReviewsEnabled(
      after.trendyolReviewsEnabled,
      after.trendyolReviewsComplete,
      after.lastStatus,
    );
    if (!after.trendyolReviewsEnabled) {
      setMainError((els.mainError.textContent ? els.mainError.textContent + " — " : "") +
        "Turn on Trendyol reviews to start.");
    } else if (probe.count > 0) {
      setMainError(`Found ${probe.count}+ target(s). Downloading…`);
    }
  } catch (err) {
    setMainError(err instanceof Error ? err.message : "Reset failed");
  }
}

async function onReviewsToggle() {
  const trendyolReviewsEnabled = els.toggleReviews.checked;
  const state = await loadState();
  const patch = { trendyolReviewsEnabled, lastError: "" };
  if (trendyolReviewsEnabled) {
    patch.trendyolReviewsComplete = false;
    patch.trendyolReviewsCursor = "";
    patch.lastStatus = "";
  }
  await chrome.storage.local.set(patch);
  renderReviewsEnabled(
    trendyolReviewsEnabled,
    false,
    trendyolReviewsEnabled ? "" : state.lastStatus,
  );
  renderStatusDot(
    state.enabled,
    state.akakceTourEnabled,
    state.merchantLinkResolverEnabled,
    state.merchantLinkBackfillEnabled,
    trendyolReviewsEnabled,
    state.hepsiburadaReviewsEnabled,
  );
  setMainError("");
  chrome.runtime.sendMessage({ type: "trendyol-reviews-changed", enabled: trendyolReviewsEnabled }).catch(() => {});
}

async function hepsiburadaReviewsResetStorage() {
  await chrome.storage.local.remove([
    "hepsiburadaReviewsDoneSkus",
    "hepsiburadaReviewsIgnoreDoneIds",
  ]);
  await chrome.storage.local.set({
    hepsiburadaReviewsCursor: "",
    hepsiburadaReviewsComplete: false,
    hepsiburadaReviewsDone: 0,
    hepsiburadaReviewsFailed: 0,
    lastError: "",
    lastStatus: "hepsiburada-reviews-reset",
    lastUrl: "",
  });
}

async function probeHepsiburadaReviewTargets(state) {
  const category = String(state.merchantLinkCategory || "").trim();
  let path = `/v1/products/hepsiburada-review-targets?limit=1`;
  if (category) {
    path += `&akakce_category=${encodeURIComponent(category)}`;
  }
  const res = await fetch(state.apiUrl + path, {
    headers: { Authorization: "ApiKey " + state.apiKey },
  });
  const data = await res.json().catch(() => ({}));
  const count = Array.isArray(data.items) ? data.items.length : 0;
  if (!res.ok) {
    throw new Error(`API ${res.status}: ${data.error || res.statusText}`);
  }
  return { count, path };
}

async function onHbReviewsReset() {
  const wasEnabled = els.toggleHbReviews.checked;
  els.statHbReviewsDone.textContent = "0";
  els.statHbReviewsFailed.textContent = "0";
  setLastUrl("");
  setMainError("");

  await hepsiburadaReviewsResetStorage();
  renderHbReviewsEnabled(wasEnabled, false, "hepsiburada-reviews-reset");

  try {
    const state = await loadState();
    const probe = await probeHepsiburadaReviewTargets(state);
    if (probe.count === 0) {
      setMainError(`API returned 0 targets for ${state.merchantLinkCategory || "all categories"}`);
    }

    const res = await chrome.runtime.sendMessage({ type: "hepsiburada-reviews-reset" });
    if (!res?.ok) {
      throw new Error(res?.error || "background reset failed");
    }

    const after = await loadState();
    renderHbReviewsEnabled(
      after.hepsiburadaReviewsEnabled,
      after.hepsiburadaReviewsComplete,
      after.lastStatus,
    );
    if (!after.hepsiburadaReviewsEnabled) {
      setMainError((els.mainError.textContent ? els.mainError.textContent + " — " : "") +
        "Turn on Hepsiburada reviews to start.");
    } else if (probe.count > 0) {
      setMainError(`Found ${probe.count}+ target(s). Downloading…`);
    }
  } catch (err) {
    setMainError(err instanceof Error ? err.message : "Reset failed");
  }
}

async function onHbReviewsToggle() {
  const hepsiburadaReviewsEnabled = els.toggleHbReviews.checked;
  const state = await loadState();
  const patch = { hepsiburadaReviewsEnabled, lastError: "" };
  if (hepsiburadaReviewsEnabled) {
    patch.hepsiburadaReviewsComplete = false;
    patch.hepsiburadaReviewsCursor = "";
    patch.lastStatus = "";
  }
  await chrome.storage.local.set(patch);
  renderHbReviewsEnabled(
    hepsiburadaReviewsEnabled,
    false,
    hepsiburadaReviewsEnabled ? "" : state.lastStatus,
  );
  renderStatusDot(
    state.enabled,
    state.akakceTourEnabled,
    state.merchantLinkResolverEnabled,
    state.merchantLinkBackfillEnabled,
    state.trendyolReviewsEnabled,
    hepsiburadaReviewsEnabled,
  );
  setMainError("");
  chrome.runtime.sendMessage({ type: "hepsiburada-reviews-changed", enabled: hepsiburadaReviewsEnabled }).catch(() => {});
}

async function onBackfillToggle() {
  const merchantLinkBackfillEnabled = els.toggleBackfill.checked;
  await chrome.storage.local.set({ merchantLinkBackfillEnabled, lastError: "" });
  renderBackfillEnabled(merchantLinkBackfillEnabled);
  const state = await loadState();
  renderStatusDot(state.enabled, state.akakceTourEnabled, state.merchantLinkResolverEnabled, merchantLinkBackfillEnabled, state.trendyolReviewsEnabled, state.hepsiburadaReviewsEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "merchant-backfill-changed", enabled: merchantLinkBackfillEnabled }).catch(() => {});
}
