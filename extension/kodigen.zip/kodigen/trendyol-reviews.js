// Trendyol product review collector — shares the background service worker global scope.
let trendyolReviewsRunId = 0;

const TrendyolReviews = {
  working: false,

  isWorking() {
    return this.working;
  },

  isRunCurrent(runId) {
    return runId === trendyolReviewsRunId;
  },

  schedulePoll(delayMs) {
    setTimeout(() => maybeRun(), delayMs ?? TRENDYOL_REVIEW_POLL_EMPTY_MS);
  },

  async runLoop() {
    if (this.working) return;

    const runId = trendyolReviewsRunId;
    const state = await getState();
    if (!state.trendyolReviewsEnabled || !state.apiUrl || !state.apiKey) return;
    if (!this.isRunCurrent(runId)) return;
    if (state.trendyolReviewsComplete) return;

    if (working || tourWorking || merchantLinkWorking || merchantBackfillWorking || HepsiburadaReviews.isWorking() || activeFetches > 0) {
      await this.updateStats({
        lastStatus: "trendyol-reviews-waiting",
        lastError: "waiting for other extension tasks to finish",
      });
      this.schedulePoll(TRENDYOL_REVIEW_WAIT_POLL_MS);
      return;
    }

    this.working = true;
    await beginBackgroundWork();

    try {
      for (;;) {
        if (!this.isRunCurrent(runId)) break;

        const loopState = await getState();
        if (!loopState.trendyolReviewsEnabled || !loopState.apiUrl || !loopState.apiKey) break;
        if (loopState.trendyolReviewsComplete) break;

        let batch;
        try {
          batch = await this.fetchTargetBatch(loopState);
        } catch (err) {
          if (!this.isRunCurrent(runId)) break;
          await this.updateStats({
            lastError: errMessage(err),
            lastStatus: "trendyol-reviews-api-failed",
          });
          this.schedulePoll();
          break;
        }

        if (!batch.items.length) {
          const probe = await this.fetchTargetBatch(loopState, "");
          if (probe.items.length > 0) {
            await chrome.storage.local.set({ trendyolReviewsCursor: "" });
            batch = probe;
          }
        }

        if (!batch.items.length) {
          const done = Number(loopState.trendyolReviewsDone) || 0;
          const debug = batch.debugPath || "";
          if (done > 0) {
            await chrome.storage.local.set({ trendyolReviewsComplete: true, trendyolReviewsCursor: "" });
            await this.updateStats({
              lastStatus: "trendyol-reviews-complete",
              lastError: trendyolReviewsCollectedMessage(loopState.merchantLinkCategory, done),
            });
          } else {
            await this.updateStats({
              lastStatus: "trendyol-reviews-api-empty",
              lastError: trendyolReviewsEmptyMessage(loopState.merchantLinkCategory, debug),
            });
            this.schedulePoll(TRENDYOL_REVIEW_WAIT_POLL_MS);
          }
          break;
        }

        for (const target of batch.items) {
          if (!this.isRunCurrent(runId)) return;

          const midState = await getState();
          if (!midState.trendyolReviewsEnabled || !midState.apiUrl || !midState.apiKey) return;
          if (working || tourWorking || merchantLinkWorking || merchantBackfillWorking || HepsiburadaReviews.isWorking() || activeFetches > 0) {
            await this.updateStats({
              lastStatus: "trendyol-reviews-waiting",
              lastError: "waiting for other extension tasks to finish",
            });
            this.schedulePoll(TRENDYOL_REVIEW_WAIT_POLL_MS);
            return;
          }

          const result = await this.processTarget(target, runId);
          if (!this.isRunCurrent(runId)) return;
          if (result.error === "run cancelled") continue;

          if (result.ok) {
            await this.updateStats({
              trendyolReviewsDone: 1,
              lastUrl: target.trendyol_url,
              lastStatus: "trendyol-reviews-saved",
              lastError: "",
            });
          } else {
            await this.updateStats({
              trendyolReviewsFailed: 1,
              lastUrl: target.trendyol_url,
              lastStatus: "trendyol-reviews-failed",
              lastError: result.error || "trendyol reviews failed",
            });
          }

          await sleep(TRENDYOL_REVIEW_PAGE_DELAY_MS);
        }

        await chrome.storage.local.set({
          trendyolReviewsCursor: batch.nextCursor || "",
        });

        if (!batch.nextCursor) {
          await chrome.storage.local.set({ trendyolReviewsComplete: true });
          await this.updateStats({
            lastStatus: "trendyol-reviews-complete",
            lastError: "",
          });
          break;
        }
      }
    } finally {
      await endBackgroundWork();
      this.working = false;
      maybeRun();
    }
  },

  async fetchTargetBatch(state, cursorOverride) {
    const cursor =
      cursorOverride !== undefined ? String(cursorOverride || "") : state.trendyolReviewsCursor || "";
    const category = String(state.merchantLinkCategory || "").trim();
    let path =
      `/v1/products/trendyol-review-targets?limit=${TRENDYOL_REVIEW_TARGETS_BATCH}` +
      (cursor ? `&cursor=${encodeURIComponent(cursor)}` : "");
    if (category) {
      path += `&akakce_category=${encodeURIComponent(category)}`;
    }
    const batch = await apiFetch(state, "GET", path);
    const items = (batch && batch.items) || [];
    return { items, nextCursor: batch.next_cursor || "", debugPath: path };
  },

  async processTarget(target, runId) {
    try {
      if (!this.isRunCurrent(runId)) {
        return { ok: false, error: "run cancelled" };
      }
      const contentId = extractTrendyolContentId(target.trendyol_url);
      if (!contentId) {
        throw new Error("trendyol contentId not found in URL");
      }

      const fetched = await this.collectReviewsInTab(target.trendyol_url, contentId, runId);
      if (!this.isRunCurrent(runId)) {
        return { ok: false, error: "run cancelled" };
      }

      const comments = fetched.comments;
      const resolvedContentId = fetched.contentId || contentId;

      const payload = {
        akakce_url: target.akakce_url,
        n11_url: cleanTrendyolReviewUrl(target.n11_url),
        trendyol_url: cleanTrendyolReviewUrl(target.trendyol_url),
        content_id: resolvedContentId,
        source_page_id: target.source_page_id,
        collected_at: new Date().toISOString(),
        comment_count: comments.length,
        pages_fetched: fetched.pagesFetched || 0,
        price: fetched.price || null,
        comments,
      };

      await downloadTrendyolReviewJson(resolvedContentId, payload);
      return { ok: true, commentCount: comments.length, contentId: resolvedContentId };
    } catch (err) {
      return { ok: false, error: errMessage(err) };
    }
  },

  async collectReviewsInTab(trendyolUrl, contentId, runId) {
    activeFetches++;

    const targetWindowId = await resolveTargetWindowId();
    const tab = await chrome.tabs.create({
      url: trendyolUrl,
      windowId: targetWindowId,
      active: false,
    });
    const tabId = tab.id;
    await addWorkTab(tabId);
    await keepUserTabInForeground();

    try {
      await waitForTabLoad(tabId, TAB_LOAD_TIMEOUT_MS);
      if (!TrendyolReviews.isRunCurrent(runId)) {
        throw new Error("run cancelled");
      }
      await sleep(SETTLE_MS + 1000);

      await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        files: ["trendyol-page-fetch.js"],
      });

      const [{ result: prep }] = await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: (cid) => {
          if (typeof window.__kodigenPrepareTrendyolReviewsPage !== "function") {
            return { error: "trendyol prepare helper not loaded" };
          }
          return window.__kodigenPrepareTrendyolReviewsPage(cid);
        },
        args: [contentId],
      });

      if (!prep || typeof prep !== "object") {
        throw new Error("trendyol reviews prepare failed");
      }
      if (prep.error) {
        throw new Error(prep.error);
      }

      const reviewsUrl = prep.reviewsUrl || trendyolUrl;
      if (reviewsUrl !== trendyolUrl) {
        await chrome.tabs.update(tabId, { url: reviewsUrl });
        await waitForTabLoad(tabId, TAB_LOAD_TIMEOUT_MS);
        if (!TrendyolReviews.isRunCurrent(runId)) {
          throw new Error("run cancelled");
        }
        await sleep(SETTLE_MS + 1500);
        await chrome.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          files: ["trendyol-page-fetch.js"],
        });
      }

      const fetchOptions = {
        price: prep.price || null,
        merchantId: prep.merchantId || null,
        boutiqueId: prep.boutiqueId || null,
      };

      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: async (cid, size, opts) => {
          if (typeof window.__kodigenFetchTrendyolReviews !== "function") {
            return { error: "trendyol fetch helper not loaded" };
          }
          return await window.__kodigenFetchTrendyolReviews(cid, size, opts);
        },
        args: [contentId, TRENDYOL_REVIEW_PAGE_SIZE, fetchOptions],
      });

      if (!result || typeof result !== "object") {
        throw new Error("trendyol reviews injection failed");
      }
      if (result.error && (!Array.isArray(result.comments) || result.comments.length === 0)) {
        throw new Error(result.error);
      }
      if (!Array.isArray(result.comments)) {
        throw new Error(result.error || "trendyol reviews parse failed");
      }
      return {
        comments: result.comments,
        contentId: result.contentId || contentId,
        pagesFetched: result.pagesFetched || 0,
        price: result.price || prep.price || null,
      };
    } finally {
      try {
        await chrome.tabs.remove(tabId);
      } catch {
        // Tab already closed.
      }
      await removeWorkTab(tabId);
      activeFetches--;
    }
  },

  async updateStats(delta) {
    const cur = await chrome.storage.local.get({
      trendyolReviewsDone: 0,
      trendyolReviewsFailed: 0,
      lastUrl: "",
      lastStatus: "",
      lastError: "",
    });
    await chrome.storage.local.set({
      trendyolReviewsDone: cur.trendyolReviewsDone + (delta.trendyolReviewsDone || 0),
      trendyolReviewsFailed: cur.trendyolReviewsFailed + (delta.trendyolReviewsFailed || 0),
      lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
      lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
      lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
      lastActivityAt: Date.now(),
    });
  },
};

const TRENDYOL_REVIEW_POLL_EMPTY_MS = 30_000;
const TRENDYOL_REVIEW_WAIT_POLL_MS = 5_000;
const TRENDYOL_REVIEW_PAGE_DELAY_MS = 2_000;
const TRENDYOL_REVIEW_TARGETS_BATCH = 10;
const TRENDYOL_REVIEW_PAGE_SIZE = 20;

function trendyolReviewsEmptyMessage(category, debugPath) {
  const cat = category ? `category "${category}"` : "all categories";
  return `API returned 0 targets for ${cat}. Check API key and category. ${debugPath}`;
}

function trendyolReviewsCollectedMessage(category, count) {
  const label = category ? `category "${category}"` : "all categories";
  return `${count} Trendyol products collected for ${label}`;
}

function extractTrendyolContentId(url) {
  const match = String(url || "").match(/-p-(\d+)/i);
  return match ? match[1] : null;
}

function cleanTrendyolReviewUrl(url) {
  const raw = String(url || "").trim();
  if (!raw) return raw;
  const q = raw.indexOf("?");
  if (q >= 0) return raw.slice(0, q);
  const h = raw.indexOf("#");
  if (h >= 0) return raw.slice(0, h);
  return raw;
}

async function resetTrendyolReviewsProgress() {
  trendyolReviewsRunId += 1;
  TrendyolReviews.working = false;
  await chrome.storage.local.remove([
    "trendyolReviewsDoneContentIds",
    "trendyolReviewsIgnoreDoneIds",
  ]);
  await chrome.storage.local.set({
    trendyolReviewsCursor: "",
    trendyolReviewsComplete: false,
    trendyolReviewsDone: 0,
    trendyolReviewsFailed: 0,
    lastError: "",
    lastStatus: "trendyol-reviews-reset",
    lastUrl: "",
  });
  return trendyolReviewsRunId;
}

async function restartTrendyolReviewsAfterReset() {
  await resetTrendyolReviewsProgress();
  const state = await getState();
  if (!state.trendyolReviewsEnabled || !state.apiUrl || !state.apiKey) {
    return;
  }
  TrendyolReviews.runLoop();
}

function downloadTrendyolReviewJson(contentId, payload) {
  const json = JSON.stringify(payload, null, 2);
  const dataUrl = "data:application/json;charset=utf-8," + encodeURIComponent(json);
  const filename = `trendyol-reviews/${contentId}.json`;

  return new Promise((resolve, reject) => {
    chrome.downloads.download(
      {
        url: dataUrl,
        filename,
        saveAs: false,
        conflictAction: "overwrite",
      },
      (downloadId) => {
        const err = chrome.runtime.lastError;
        if (err || !downloadId) {
          reject(new Error(err?.message || "download failed"));
          return;
        }
        resolve(downloadId);
      },
    );
  });
}
