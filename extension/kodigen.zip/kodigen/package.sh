#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$ROOT/n11-crawler.zip}"

cd "$ROOT"
rm -f "$OUT"

zip -r "$OUT" . \
  -x '*.DS_Store' \
  -x 'n11-crawler.zip' \
  -x 'package.sh' \
  -x '.git/*'

echo "Created $OUT"
unzip -l "$OUT" | tail -1
