// Injected into Trendyol product tabs. Must be fully self-contained (no extension-scope helpers).

window.__kodigenPrepareTrendyolReviewsPage = function prepareTrendyolReviewsPage(contentId) {
  const resolvedId = resolveContentId(contentId);
  const merchant = extractMerchantReviewParams();
  return {
    contentId: resolvedId,
    reviewsUrl: buildYorumlarUrl(merchant.merchantId, merchant.boutiqueId),
    price: extractProductPrice(),
    merchantId: merchant.merchantId,
    boutiqueId: merchant.boutiqueId,
  };
};

window.__kodigenFetchTrendyolReviews = async function fetchTrendyolProductReviewsFromPage(
  contentId,
  pageSize,
  options,
) {
  const MAX_PAGES = 500;
  const PAGE_DELAY_MS = 350;
  const opts = options && typeof options === "object" ? options : {};

  const resolvedId = resolveContentId(contentId);
  const productPrice = opts.price != null ? opts.price : extractProductPrice();
  const merchantParams = {
    merchantId: opts.merchantId ?? extractMerchantReviewParams().merchantId,
    boutiqueId: opts.boutiqueId ?? extractMerchantReviewParams().boutiqueId,
  };

  await settleReviewListDom();

  const domComments = scrapeReviewListFromDom();
  let apiComments = [];
  let pagesFetched = 0;
  let lastError = "trendyol reviews API unavailable";

  const endpoints = [
    (ctx) =>
      "https://apigw.trendyol.com/discovery-storefront-trproductgw-service/api/review-read/product-reviews/detailed" +
      "?contentId=" + encodeURIComponent(ctx.id) +
      "&page=" + ctx.page +
      "&pageSize=" + ctx.size +
      "&order=DESC&orderBy=Score&channelId=1" +
      appendMerchantQuery(merchantParams),
    (ctx) =>
      "https://apigw.trendyol.com/discovery-web-websfxsocialreviewrating-santral/product-reviews-detailed" +
      "?contentId=" + encodeURIComponent(ctx.id) +
      "&page=" + ctx.page +
      "&pageSize=" + ctx.size +
      "&order=DESC&orderBy=Score&channelId=1" +
      appendMerchantQuery(merchantParams),
  ];

  for (const buildUrl of endpoints) {
    try {
      const result = await fetchFromEndpoint(buildUrl, resolvedId, pageSize);
      apiComments = result.comments;
      pagesFetched = result.pagesFetched;
      lastError = "";
      break;
    } catch (err) {
      lastError = err && err.message ? err.message : String(err);
    }
  }

  const comments = mergeComments(domComments, apiComments);
  if (comments.length > 0) {
    return {
      contentId: resolvedId,
      comments,
      pagesFetched: pagesFetched + (domComments.length > 0 ? 1 : 0),
      price: productPrice,
      sources: { dom: domComments.length, api: apiComments.length },
    };
  }

  if (domComments.length === 0 && lastError) {
    return {
      contentId: resolvedId,
      comments: [],
      pagesFetched: 0,
      price: productPrice,
      error: lastError,
    };
  }

  return {
    contentId: resolvedId,
    comments: [],
    pagesFetched: 0,
    price: productPrice,
    sources: { dom: 0, api: 0 },
  };

  function appendMerchantQuery(params) {
    let qs = "";
    if (params.merchantId != null && params.merchantId !== "") {
      qs += "&merchantId=" + encodeURIComponent(String(params.merchantId));
    }
    if (params.boutiqueId != null && params.boutiqueId !== "") {
      qs += "&boutiqueId=" + encodeURIComponent(String(params.boutiqueId));
    }
    return qs;
  }

  async function fetchFromEndpoint(buildUrl, id, size) {
    const headers = {
      accept: "application/json, text/plain, */*",
      "accept-language": "tr-TR,tr;q=0.9",
    };
    const all = [];
    let page = 1;
    let fetchedPages = 0;
    let knownTotalPages = null;

    while (page <= MAX_PAGES) {
      const res = await fetch(
        buildUrl({ id, page, size }),
        { method: "GET", credentials: "include", headers },
      );
      const contentType = res.headers.get("content-type") || "";
      const body = await res.text();
      if (!res.ok) {
        throw new Error("trendyol reviews HTTP " + res.status);
      }
      if (!contentType.includes("json") && body.trimStart().startsWith("<")) {
        throw new Error("trendyol reviews blocked (HTML response)");
      }

      let data;
      try {
        data = JSON.parse(body);
      } catch {
        throw new Error("trendyol reviews response is not JSON");
      }

      const content = extractReviewContent(data);
      if (!Array.isArray(content)) {
        throw new Error("trendyol reviews payload missing");
      }
      if (content.length === 0) break;

      const totalPages = readTotalPages(data, size);
      if (totalPages != null) {
        knownTotalPages = totalPages;
      }

      for (const item of content) {
        all.push(normalizeItem(item));
      }
      fetchedPages += 1;

      if (knownTotalPages != null && page >= knownTotalPages) break;
      if (knownTotalPages == null && content.length < size) break;

      page += 1;
      await sleep(PAGE_DELAY_MS);
    }

    return { comments: all, pagesFetched: fetchedPages };
  }
};

function resolveContentId(fallbackId) {
  const fromPath = location.pathname.match(/-p-(\d+)/i);
  if (fromPath) return fromPath[1];
  const html = document.documentElement?.innerHTML || "";
  for (const re of [/"contentId"\s*:\s*(\d+)/, /"productContentId"\s*:\s*(\d+)/]) {
    const hit = html.match(re);
    if (hit) return hit[1];
  }
  return String(fallbackId || "").trim();
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function textOf(el) {
  return el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : "";
}

function extractMerchantReviewParams() {
  const fromUrl = new URLSearchParams(location.search);
  const merchantFromUrl = fromUrl.get("merchantId");
  const boutiqueFromUrl = fromUrl.get("boutiqueId");
  if (merchantFromUrl || boutiqueFromUrl) {
    return {
      merchantId: merchantFromUrl,
      boutiqueId: boutiqueFromUrl,
    };
  }

  const state = readInitialProductState();
  const product = state?.product;
  const listing = product?.merchantListing;
  const merchant = listing?.merchant;

  return {
    merchantId:
      merchant?.id ??
      merchant?.merchantId ??
      listing?.merchantId ??
      product?.merchantId ??
      null,
    boutiqueId: listing?.boutiqueId ?? product?.boutiqueId ?? state?.boutiqueId ?? null,
  };
}

function buildYorumlarUrl(merchantId, boutiqueId) {
  const path = location.pathname.replace(/\/yorumlar\/?$/i, "");
  const params = new URLSearchParams();
  if (boutiqueId != null && boutiqueId !== "") {
    params.set("boutiqueId", String(boutiqueId));
  }
  if (merchantId != null && merchantId !== "") {
    params.set("merchantId", String(merchantId));
  }
  const qs = params.toString();
  return location.origin + path + "/yorumlar" + (qs ? "?" + qs : "");
}

async function settleReviewListDom() {
  const list = document.querySelector(".review-list");
  if (!list) {
    await sleep(800);
    return;
  }
  list.scrollIntoView({ block: "start" });
  await sleep(400);
  window.scrollTo(0, document.body.scrollHeight);
  await sleep(500);
  window.scrollTo(0, 0);
  await sleep(300);
}

function parseRateFromElement(el) {
  const aria = el.getAttribute?.("aria-label") || "";
  const ariaMatch =
    aria.match(/(\d)\s*(?:\/\s*5|yıldız|star)/i) ||
    aria.match(/^(\d)$/);
  if (ariaMatch) return Number(ariaMatch[1]);

  const starsWrap = el.querySelector('[class*="star"], [class*="rating"], [class*="puan"]');
  if (starsWrap) {
    const active = starsWrap.querySelectorAll(
      '[class*="full"], [class*="filled"], [class*="active"], [data-testid*="filled"], [class*="star-w"]',
    ).length;
    if (active > 0 && active <= 5) return active;
  }

  const txt = textOf(el);
  const m = txt.match(/(\d)\s*\/\s*5/) || txt.match(/(\d)\s*yıldız/i);
  if (m) return Number(m[1]);
  return null;
}

function parseReviewCard(el) {
  if (!el || el.nodeType !== 1) return null;

  const comment =
    textOf(
      el.querySelector(
        '[class*="comment-text"], [class*="comment-tx"], [class*="review-comment"], [class*="review-description"], [class*="comment-body"], [class*="rnr-com-tx"]',
      ),
    ) || textOf(el.querySelector("p"));

  const userFullName = textOf(
    el.querySelector(
      '[class*="user-name"], [class*="username"], [class*="review-user"], [class*="reviewer"], [class*="rnr-com-usr"]',
    ),
  );

  const rate = parseRateFromElement(el);
  if (!comment && rate == null && !userFullName) return null;

  return {
    userFullName,
    rate,
    comment,
  };
}

function scrapeReviewListFromDom() {
  const list = document.querySelector(".review-list");
  if (!list) return [];

  let cards = [...list.children].filter((el) => el.nodeType === 1);
  if (!cards.length) {
    cards = [...list.querySelectorAll('[class*="review"], [class*="comment"], li')];
  }

  const items = [];
  for (const card of cards) {
    const item = parseReviewCard(card);
    if (item) items.push(item);
  }
  return items;
}

function reviewKey(item) {
  return (String(item.userFullName || "") + "|" + String(item.comment || "")).toLowerCase().slice(0, 240);
}

function mergeComments(...groups) {
  const seen = new Set();
  const out = [];
  for (const group of groups) {
    if (!Array.isArray(group)) continue;
    for (const item of group) {
      if (!item) continue;
      const normalized = normalizeItem(item);
      if (!normalized.comment && normalized.rate == null && !normalized.userFullName) continue;
      const key = reviewKey(normalized);
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(normalized);
    }
  }
  return out;
}

function readInitialProductState() {
  const fromWindow = window.__PRODUCT_DETAIL_APP_INITIAL_STATE__;
  if (fromWindow && typeof fromWindow === "object") {
    return fromWindow;
  }

  const html = document.documentElement?.innerHTML || "";
  const marker = "__PRODUCT_DETAIL_APP_INITIAL_STATE__";
  const start = html.indexOf(marker);
  if (start < 0) return null;

  const eq = html.indexOf("=", start);
  if (eq < 0) return null;

  let i = eq + 1;
  while (i < html.length && /\s/.test(html[i])) i += 1;
  if (html[i] !== "{") return null;

  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let j = i; j < html.length; j += 1) {
    const ch = html[j];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }
    if (ch === '"') {
      inString = true;
      continue;
    }
    if (ch === "{") depth += 1;
    if (ch === "}") {
      depth -= 1;
      if (depth === 0) {
        try {
          return JSON.parse(html.slice(i, j + 1));
        } catch {
          return null;
        }
      }
    }
  }
  return null;
}

function pickPriceObject(product) {
  if (!product || typeof product !== "object") return null;

  const candidates = [
    product.price,
    product.merchantListing?.winnerVariant?.price,
    product.merchantListing?.merchant?.merchantVariants?.[0]?.price,
    product.merchantListing?.merchant?.listing?.price,
    product.variants?.find((v) => v && v.inStock !== false)?.price,
    product.variants?.[0]?.price,
    product.winningVariant?.price,
  ];
  for (const candidate of candidates) {
    if (candidate && typeof candidate === "object") return candidate;
  }

  if (
    product.sellingPrice != null ||
    product.discountedPrice != null ||
    product.originalPrice != null
  ) {
    return product;
  }
  return null;
}

function toNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function extractProductPrice() {
  const state = readInitialProductState();
  const product = state?.product;
  const priceObj = pickPriceObject(product);
  if (priceObj) {
    const selling =
      toNumber(priceObj.sellingPrice) ??
      toNumber(priceObj.discountedPrice) ??
      toNumber(priceObj.buyingPrice);
    const original =
      toNumber(priceObj.originalPrice) ??
      toNumber(priceObj.sellingPrice) ??
      selling;
    if (selling != null || original != null) {
      return {
        selling_price: selling,
        original_price: original,
        discounted_price: toNumber(priceObj.discountedPrice),
        currency: String(priceObj.currency || product?.currency || "TRY"),
      };
    }
  }

  const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
  for (const script of ldScripts) {
    try {
      const data = JSON.parse(script.textContent || "");
      const nodes = Array.isArray(data) ? data : [data];
      for (const node of nodes) {
        const offer = node?.offers;
        const offers = Array.isArray(offer) ? offer : offer ? [offer] : [];
        for (const item of offers) {
          const selling = toNumber(item.price);
          if (selling != null) {
            return {
              selling_price: selling,
              original_price: selling,
              discounted_price: null,
              currency: String(item.priceCurrency || "TRY"),
            };
          }
        }
      }
    } catch {
      // ignore malformed JSON-LD
    }
  }

  return null;
}

function looksLikeReview(item) {
  if (!item || typeof item !== "object") return false;
  return (
    item.comment !== undefined ||
    item.userFullName !== undefined ||
    item.rate !== undefined ||
    item.rating !== undefined
  );
}

function deepFindReviewArray(node, depth) {
  if (!node || depth > 8) return null;
  if (Array.isArray(node)) {
    if (node.length && looksLikeReview(node[0])) return node;
    return null;
  }
  if (typeof node !== "object") return null;
  if (Array.isArray(node.content) && node.content.length && looksLikeReview(node.content[0])) {
    return node.content;
  }
  for (const value of Object.values(node)) {
    const found = deepFindReviewArray(value, depth + 1);
    if (found) return found;
  }
  return null;
}

function extractReviewContent(data) {
  if (!data || typeof data !== "object") return [];

  const productReviews = data.result?.productReviews;
  if (productReviews && Array.isArray(productReviews.content)) {
    return productReviews.content;
  }
  if (Array.isArray(data.result?.content)) {
    return data.result.content;
  }
  if (productReviews && Array.isArray(productReviews.items)) {
    return productReviews.items;
  }
  if (Array.isArray(data.productReviews?.content)) {
    return data.productReviews.content;
  }

  const deep = deepFindReviewArray(data, 0);
  return deep || [];
}

function readTotalPages(data, size) {
  const productReviews = data?.result?.productReviews;
  const candidates = [
    productReviews?.totalPages,
    productReviews?.totalPage,
    data?.result?.totalPages,
    data?.result?.totalPage,
    data?.totalPages,
    data?.totalPage,
  ];
  for (const value of candidates) {
    const n = Number(value);
    if (Number.isFinite(n) && n > 0) return Math.floor(n);
  }

  const totalElements = Number(
    productReviews?.totalElements ??
      productReviews?.totalCount ??
      productReviews?.total ??
      data?.result?.totalElements ??
      data?.result?.totalCount,
  );
  if (Number.isFinite(totalElements) && totalElements > 0 && size > 0) {
    return Math.ceil(totalElements / size);
  }
  return null;
}

function normalizeItem(item) {
  return {
    userFullName: String(item.userFullName || item.userName || item.author || ""),
    rate: item.rate ?? item.rating ?? item.score ?? null,
    comment: String(item.comment || item.reviewText || item.text || ""),
  };
}
