// Hepsiburada product review collector — DOM scrape with ?sayfa=N URL pagination.
let hepsiburadaReviewsRunId = 0;

const HepsiburadaReviews = {
  working: false,

  isWorking() {
    return this.working;
  },

  isRunCurrent(runId) {
    return runId === hepsiburadaReviewsRunId;
  },

  schedulePoll(delayMs) {
    setTimeout(() => maybeRun(), delayMs ?? HEPSIBURADA_REVIEW_POLL_EMPTY_MS);
  },

  async runLoop() {
    if (this.working) return;

    const runId = hepsiburadaReviewsRunId;
    const state = await getState();
    if (!state.hepsiburadaReviewsEnabled || !state.apiUrl || !state.apiKey) return;
    if (!this.isRunCurrent(runId)) return;
    if (state.hepsiburadaReviewsComplete) return;

    if (
      working ||
      tourWorking ||
      merchantLinkWorking ||
      merchantBackfillWorking ||
      TrendyolReviews.isWorking() ||
      activeFetches > 0
    ) {
      await this.updateStats({
        lastStatus: "hepsiburada-reviews-waiting",
        lastError: "waiting for other extension tasks to finish",
      });
      this.schedulePoll(HEPSIBURADA_REVIEW_WAIT_POLL_MS);
      return;
    }

    this.working = true;
    await beginBackgroundWork();

    try {
      for (;;) {
        if (!this.isRunCurrent(runId)) break;

        const loopState = await getState();
        if (!loopState.hepsiburadaReviewsEnabled || !loopState.apiUrl || !loopState.apiKey) break;
        if (loopState.hepsiburadaReviewsComplete) break;

        let batch;
        try {
          batch = await this.fetchTargetBatch(loopState);
        } catch (err) {
          if (!this.isRunCurrent(runId)) break;
          await this.updateStats({
            lastError: errMessage(err),
            lastStatus: "hepsiburada-reviews-api-failed",
          });
          this.schedulePoll();
          break;
        }

        if (!batch.items.length) {
          const probe = await this.fetchTargetBatch(loopState, "");
          if (probe.items.length > 0) {
            await chrome.storage.local.set({ hepsiburadaReviewsCursor: "" });
            batch = probe;
          }
        }

        if (!batch.items.length) {
          const done = Number(loopState.hepsiburadaReviewsDone) || 0;
          const debug = batch.debugPath || "";
          if (done > 0) {
            await chrome.storage.local.set({ hepsiburadaReviewsComplete: true, hepsiburadaReviewsCursor: "" });
            await this.updateStats({
              lastStatus: "hepsiburada-reviews-complete",
              lastError: hepsiburadaReviewsCollectedMessage(loopState.merchantLinkCategory, done),
            });
          } else {
            await this.updateStats({
              lastStatus: "hepsiburada-reviews-api-empty",
              lastError: hepsiburadaReviewsEmptyMessage(loopState.merchantLinkCategory, debug),
            });
            this.schedulePoll(HEPSIBURADA_REVIEW_WAIT_POLL_MS);
          }
          break;
        }

        for (const target of batch.items) {
          if (!this.isRunCurrent(runId)) return;

          const midState = await getState();
          if (!midState.hepsiburadaReviewsEnabled || !midState.apiUrl || !midState.apiKey) return;
          if (
            working ||
            tourWorking ||
            merchantLinkWorking ||
            merchantBackfillWorking ||
            TrendyolReviews.isWorking() ||
            activeFetches > 0
          ) {
            await this.updateStats({
              lastStatus: "hepsiburada-reviews-waiting",
              lastError: "waiting for other extension tasks to finish",
            });
            this.schedulePoll(HEPSIBURADA_REVIEW_WAIT_POLL_MS);
            return;
          }

          const result = await this.processTarget(target, runId);
          if (!this.isRunCurrent(runId)) return;
          if (result.error === "run cancelled") continue;

          if (result.ok) {
            await this.updateStats({
              hepsiburadaReviewsDone: 1,
              lastUrl: target.hepsiburada_url,
              lastStatus: "hepsiburada-reviews-saved",
              lastError: "",
            });
          } else {
            await this.updateStats({
              hepsiburadaReviewsFailed: 1,
              lastUrl: target.hepsiburada_url,
              lastStatus: "hepsiburada-reviews-failed",
              lastError: result.error || "hepsiburada reviews failed",
            });
          }

          await sleep(HEPSIBURADA_REVIEW_PAGE_DELAY_MS);
        }

        await chrome.storage.local.set({
          hepsiburadaReviewsCursor: batch.nextCursor || "",
        });

        if (!batch.nextCursor) {
          await chrome.storage.local.set({ hepsiburadaReviewsComplete: true });
          await this.updateStats({
            lastStatus: "hepsiburada-reviews-complete",
            lastError: "",
          });
          break;
        }
      }
    } finally {
      await endBackgroundWork();
      this.working = false;
      maybeRun();
    }
  },

  async fetchTargetBatch(state, cursorOverride) {
    const cursor =
      cursorOverride !== undefined ? String(cursorOverride || "") : state.hepsiburadaReviewsCursor || "";
    const category = String(state.merchantLinkCategory || "").trim();
    let path =
      `/v1/products/hepsiburada-review-targets?limit=${HEPSIBURADA_REVIEW_TARGETS_BATCH}` +
      (cursor ? `&cursor=${encodeURIComponent(cursor)}` : "");
    if (category) {
      path += `&akakce_category=${encodeURIComponent(category)}`;
    }
    const batch = await apiFetch(state, "GET", path);
    const items = (batch && batch.items) || [];
    return { items, nextCursor: batch.next_cursor || "", debugPath: path };
  },

  async processTarget(target, runId) {
    try {
      if (!this.isRunCurrent(runId)) {
        return { ok: false, error: "run cancelled" };
      }
      const sku = extractHepsiburadaSku(target.hepsiburada_url);
      if (!sku) {
        throw new Error("hepsiburada sku not found in URL");
      }

      const fetched = await this.collectReviewsInTab(target.hepsiburada_url, sku, runId);
      if (!this.isRunCurrent(runId)) {
        return { ok: false, error: "run cancelled" };
      }

      const resolvedSku = fetched.sku || sku;
      const comments = fetched.comments;

      const payload = {
        akakce_url: target.akakce_url,
        n11_url: cleanHepsiburadaReviewUrl(target.n11_url),
        hepsiburada_url: cleanHepsiburadaReviewUrl(target.hepsiburada_url),
        sku: resolvedSku,
        source_page_id: target.source_page_id,
        collected_at: new Date().toISOString(),
        comment_count: comments.length,
        pages_fetched: fetched.pagesFetched || 0,
        price: fetched.price || null,
        comments,
      };

      await downloadHepsiburadaReviewJson(resolvedSku, payload);
      return { ok: true, commentCount: comments.length, sku: resolvedSku };
    } catch (err) {
      return { ok: false, error: errMessage(err) };
    }
  },

  async collectReviewsInTab(hepsiburadaUrl, sku, runId) {
    return withHepsiburadaTimeout(
      this.collectReviewsInTabInner(hepsiburadaUrl, sku, runId),
      HEPSIBURADA_REVIEW_COLLECT_TIMEOUT_MS,
      "hepsiburada review collection",
    );
  },

  async collectReviewsInTabInner(hepsiburadaUrl, sku, runId) {
    activeFetches++;

    const reviewsUrl = buildHepsiburadaReviewsPageUrl(hepsiburadaUrl, 1);
    const targetWindowId = await resolveTargetWindowId();
    const tab = await chrome.tabs.create({
      url: reviewsUrl,
      windowId: targetWindowId,
      active: false,
    });
    const tabId = tab.id;
    await addWorkTab(tabId);
    await keepUserTabInForeground();

    try {
      await this.updateStats({
        lastUrl: reviewsUrl,
        lastStatus: "hepsiburada-reviews-collecting",
        lastError: "",
      });

      await waitForTabLoad(tabId, TAB_LOAD_TIMEOUT_MS);
      if (!HepsiburadaReviews.isRunCurrent(runId)) {
        throw new Error("run cancelled");
      }
      await sleep(SETTLE_MS + 2500);

      const page1 = await scrapeHepsiburadaReviewsPageInTab(tabId);
      const allComments = [];
      mergeHepsiburadaCommentsInPlace(allComments, page1.comments);

      let pagesFetched = 1;
      let resolvedSku = sku;
      let price = page1.price || null;
      let totalPages = page1.totalPages || 1;
      totalPages = Math.min(totalPages, HEPSIBURADA_REVIEW_DOM_MAX_PAGES);

      await this.updateStats({
        lastStatus: "hepsiburada-reviews-collecting",
        lastError: `page 1/${totalPages}: ${allComments.length} reviews`,
      });

      for (let page = 2; page <= totalPages; page++) {
        if (!HepsiburadaReviews.isRunCurrent(runId)) {
          throw new Error("run cancelled");
        }

        const pageUrl = buildHepsiburadaReviewsPageUrl(hepsiburadaUrl, page);
        await chrome.tabs.update(tabId, { url: pageUrl });
        await waitForTabLoad(tabId, TAB_LOAD_TIMEOUT_MS);
        await sleep(SETTLE_MS + 1500);

        const pageResult = await scrapeHepsiburadaReviewsPageInTab(tabId);
        const beforeCount = allComments.length;
        mergeHepsiburadaCommentsInPlace(allComments, pageResult.comments);
        pagesFetched += 1;

        await this.updateStats({
          lastStatus: "hepsiburada-reviews-collecting",
          lastError: `page ${page}/${totalPages}: ${allComments.length} reviews`,
        });

        if (allComments.length === beforeCount) break;
      }

      const [{ result: skuResult }] = await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: (fallbackSku) => {
          if (typeof window.__kodigenResolveHepsiburadaSku !== "function") {
            return String(fallbackSku || "");
          }
          return window.__kodigenResolveHepsiburadaSku(fallbackSku);
        },
        args: [sku],
      });
      if (skuResult) resolvedSku = String(skuResult);

      if (allComments.length === 0) {
        throw new Error("hepsiburada reviews not found in DOM (0 review cards parsed)");
      }

      return {
        comments: allComments,
        sku: resolvedSku,
        pagesFetched,
        price,
      };
    } finally {
      try {
        await chrome.tabs.remove(tabId);
      } catch {
        // Tab already closed.
      }
      await removeWorkTab(tabId);
      activeFetches--;
    }
  },

  async updateStats(delta) {
    const cur = await chrome.storage.local.get({
      hepsiburadaReviewsDone: 0,
      hepsiburadaReviewsFailed: 0,
      lastUrl: "",
      lastStatus: "",
      lastError: "",
    });
    await chrome.storage.local.set({
      hepsiburadaReviewsDone: cur.hepsiburadaReviewsDone + (delta.hepsiburadaReviewsDone || 0),
      hepsiburadaReviewsFailed: cur.hepsiburadaReviewsFailed + (delta.hepsiburadaReviewsFailed || 0),
      lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
      lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
      lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
      lastActivityAt: Date.now(),
    });
  },
};

const HEPSIBURADA_REVIEW_POLL_EMPTY_MS = 30_000;
const HEPSIBURADA_REVIEW_WAIT_POLL_MS = 5_000;
const HEPSIBURADA_REVIEW_PAGE_DELAY_MS = 2_000;
const HEPSIBURADA_REVIEW_TARGETS_BATCH = 10;
const HEPSIBURADA_REVIEW_DOM_MAX_PAGES = 200;
const HEPSIBURADA_REVIEW_COLLECT_TIMEOUT_MS = 300_000;

function hepsiburadaReviewsEmptyMessage(category, debugPath) {
  const cat = category ? `category "${category}"` : "all categories";
  return `API returned 0 targets for ${cat}. Check API key and category. ${debugPath}`;
}

function hepsiburadaReviewsCollectedMessage(category, count) {
  const label = category ? `category "${category}"` : "all categories";
  return `${count} Hepsiburada products collected for ${label}`;
}

function extractHepsiburadaSku(url) {
  const match = String(url || "").match(/-p-([A-Za-z0-9]+)/i);
  return match ? match[1] : null;
}

function cleanHepsiburadaReviewUrl(url) {
  const raw = String(url || "").trim();
  if (!raw) return raw;
  const q = raw.indexOf("?");
  if (q >= 0) return raw.slice(0, q);
  const h = raw.indexOf("#");
  if (h >= 0) return raw.slice(0, h);
  return raw;
}

function buildHepsiburadaReviewsUrl(url) {
  const clean = cleanHepsiburadaReviewUrl(url).replace(/-yorumlari\/?$/i, "");
  return clean + "-yorumlari";
}

function buildHepsiburadaReviewsPageUrl(url, pageNum) {
  const base = buildHepsiburadaReviewsUrl(url);
  const page = Number(pageNum) || 1;
  return page <= 1 ? base : `${base}?sayfa=${page}`;
}

async function scrapeHepsiburadaReviewsPageInTab(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    files: ["hepsiburada-page-fetch.js"],
  });

  const [{ result: pageResult }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: async () => {
      if (typeof window.__kodigenScrapeHepsiburadaReviewsPage !== "function") {
        return { error: "hepsiburada page scrape helper not loaded" };
      }
      return await window.__kodigenScrapeHepsiburadaReviewsPage();
    },
  });

  if (!pageResult || typeof pageResult !== "object") {
    throw new Error("hepsiburada page scrape failed");
  }
  if (pageResult.error) {
    throw new Error(pageResult.error);
  }

  return {
    comments: Array.isArray(pageResult.comments) ? pageResult.comments : [],
    totalPages: Number(pageResult.totalPages) || 1,
    price: pageResult.price || null,
  };
}

async function resetHepsiburadaReviewsProgress() {
  hepsiburadaReviewsRunId += 1;
  HepsiburadaReviews.working = false;
  await chrome.storage.local.remove([
    "hepsiburadaReviewsDoneSkus",
    "hepsiburadaReviewsIgnoreDoneIds",
  ]);
  await chrome.storage.local.set({
    hepsiburadaReviewsCursor: "",
    hepsiburadaReviewsComplete: false,
    hepsiburadaReviewsDone: 0,
    hepsiburadaReviewsFailed: 0,
    lastError: "",
    lastStatus: "hepsiburada-reviews-reset",
    lastUrl: "",
  });
  return hepsiburadaReviewsRunId;
}

async function restartHepsiburadaReviewsAfterReset() {
  await resetHepsiburadaReviewsProgress();
  const state = await getState();
  if (!state.hepsiburadaReviewsEnabled || !state.apiUrl || !state.apiKey) {
    return;
  }
  HepsiburadaReviews.runLoop();
}

function hepsiburadaCommentKey(item) {
  return (String(item.userFullName || "") + "|" + String(item.comment || "")).toLowerCase().slice(0, 240);
}

function mergeHepsiburadaCommentsInPlace(target, incoming) {
  const seen = new Set(target.map((item) => hepsiburadaCommentKey(item)));
  for (const item of incoming) {
    if (!item) continue;
    const normalized = {
      userFullName: String(item.userFullName || ""),
      rate: item.rate ?? null,
      comment: String(item.comment || ""),
    };
    if (!normalized.comment && normalized.rate == null && !normalized.userFullName) continue;
    const key = hepsiburadaCommentKey(normalized);
    if (seen.has(key)) continue;
    seen.add(key);
    target.push(normalized);
  }
}

function withHepsiburadaTimeout(promise, timeoutMs, label) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(
      () => reject(new Error(`${label} timed out after ${Math.round(timeoutMs / 1000)}s`)),
      timeoutMs,
    );
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

function downloadHepsiburadaReviewJson(sku, payload) {
  const json = JSON.stringify(payload, null, 2);
  const dataUrl = "data:application/json;charset=utf-8," + encodeURIComponent(json);
  const filename = `hepsiburada-reviews/${sku}.json`;

  return new Promise((resolve, reject) => {
    chrome.downloads.download(
      {
        url: dataUrl,
        filename,
        saveAs: false,
        conflictAction: "overwrite",
      },
      (downloadId) => {
        const err = chrome.runtime.lastError;
        if (err || !downloadId) {
          reject(new Error(err?.message || "download failed"));
          return;
        }
        resolve(downloadId);
      },
    );
  });
}
