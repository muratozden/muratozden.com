// Watches Akakce product pages for manual "Daha fazla fiyat gör" / "Daha Fazla Göster"
// (#SAP) clicks and asks the background worker to upload the expanded DOM when the
// URL is registered.

const CAPTURE_DELAY_MS = 1500;

let captureTimer = null;

document.addEventListener(
  "click",
  (event) => {
    const btn = event.target.closest("#SAP, button.more, button.t2b");
    if (!btn || !isSapButtonText(btn.textContent)) return;
    scheduleCapture();
  },
  true,
);

function isSapButtonText(text) {
  const t = String(text || "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
  if (!t.includes("fazla")) return false;
  return (
    t.includes("fiyat") ||
    t.includes("gör") ||
    t.includes("goster") ||
    t.includes("göster")
  );
}

function scheduleCapture() {
  clearTimeout(captureTimer);
  captureTimer = setTimeout(() => {
    captureTimer = null;
    void captureExpandedPage();
  }, CAPTURE_DELAY_MS);
}

async function captureExpandedPage() {
  if (!document.getElementById("PL")) return;

  await sleep(400);

  const html = "<!DOCTYPE html>\n" + document.documentElement.outerHTML;
  const url = cleanAkakceUrl(location.href);

  try {
    const response = await chrome.runtime.sendMessage({
      type: "akakce-page-capture",
      url,
      finalUrl: location.href,
      html,
    });
    if (response?.ok) {
      showToast(`Crawler updated (${response.offers_saved ?? 0} offers)`);
    } else if (response?.reason === "not_found") {
      // URL is not registered — stay silent.
    } else if (response?.error) {
      showToast(response.error, true);
    }
  } catch {
    // Extension disabled or context invalidated.
  }
}

function cleanAkakceUrl(raw) {
  return raw.split(/[?#]/)[0];
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function showToast(message, isError = false) {
  const id = "kodigen-akakce-toast";
  let el = document.getElementById(id);
  if (!el) {
    el = document.createElement("div");
    el.id = id;
    el.style.cssText = [
      "position:fixed",
      "right:16px",
      "bottom:16px",
      "z-index:2147483647",
      "max-width:320px",
      "padding:12px 14px",
      "border-radius:12px",
      "font:600 13px/1.4 system-ui,sans-serif",
      "color:#fff",
      "box-shadow:0 12px 30px rgba(0,0,0,.18)",
      "transition:opacity .2s ease",
    ].join(";");
    document.documentElement.appendChild(el);
  }
  el.textContent = message;
  el.style.background = isError ? "#b42318" : "#067647";
  el.style.opacity = "1";
  clearTimeout(el._hideTimer);
  el._hideTimer = setTimeout(() => {
    el.style.opacity = "0";
  }, 3200);
}
