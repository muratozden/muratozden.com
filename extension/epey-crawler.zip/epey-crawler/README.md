# Epey Data Crawler Extension

This Chrome extension injects a `Data Crawler` button into `epey.com` pages.

## Features

- Floating `Data Crawler` button on the top-right corner.
- Modal with textarea for multiple product URLs.
- Sequential crawl of each page.
- Extraction of product attributes from the `#ozellikler` section.
- Automatic JSON download after crawl.

## Load in Chrome

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this folder: `epey-crawler`.

## Usage

1. Go to any `https://www.epey.com/...` page.
2. Click `Data Crawler`.
3. Paste product links (one URL per line, comma also supported).
4. Click `Start Crawl`.
5. The extension downloads a JSON file automatically.

