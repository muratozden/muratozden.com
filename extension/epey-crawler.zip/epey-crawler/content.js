(function initEpeyCrawler() {
  const ROOT_ID = "epey-data-crawler-root";
  const STORAGE_KEY = "epeyCrawlerCollectedLinks";
  const AUTO_COLLECT_MAX_PAGES = 200;
  if (document.getElementById(ROOT_ID)) {
    return;
  }

  const state = {
    running: false,
    lastPayload: null,
    storedLinks: []
  };

  const root = document.createElement("div");
  root.id = ROOT_ID;

  const button = document.createElement("button");
  button.id = "epey-data-crawler-button";
  button.type = "button";
  button.textContent = "Data Crawler";

  const modal = document.createElement("div");
  modal.id = "epey-data-crawler-modal";
  modal.classList.add("hidden");
  modal.innerHTML = [
    '<div class="epey-dc-header">',
    '  <h3>Data Crawler</h3>',
    '  <button type="button" id="epey-dc-close" aria-label="Close">X</button>',
    "</div>",
    '<p class="epey-dc-help">Paste one epey.com product URL per line.</p>',
    '<textarea id="epey-dc-input" placeholder="https://www.epey.com/akilli-telefonlar/xiaomi-15-ultra.html"></textarea>',
    '<div class="epey-dc-actions">',
    '  <button type="button" id="epey-dc-collect" class="secondary">Collect From Listing</button>',
    '  <button type="button" id="epey-dc-collect-auto" class="secondary">2 URL Auto Collect</button>',
    '  <button type="button" id="epey-dc-clear" class="secondary">Bellegi Temizle</button>',
    '  <button type="button" id="epey-dc-start">Start Crawl</button>',
    '  <button type="button" id="epey-dc-download" class="secondary">Download Last</button>',
    "</div>",
    '<div id="epey-dc-status">Ready</div>'
  ].join("");

  root.appendChild(button);
  root.appendChild(modal);
  document.documentElement.appendChild(root);

  const closeButton = modal.querySelector("#epey-dc-close");
  const collectButton = modal.querySelector("#epey-dc-collect");
  const collectAutoButton = modal.querySelector("#epey-dc-collect-auto");
  const clearButton = modal.querySelector("#epey-dc-clear");
  const startButton = modal.querySelector("#epey-dc-start");
  const downloadButton = modal.querySelector("#epey-dc-download");
  const input = modal.querySelector("#epey-dc-input");
  const status = modal.querySelector("#epey-dc-status");

  hydrateStoredLinks();

  button.addEventListener("click", () => {
    modal.classList.toggle("hidden");
  });

  closeButton.addEventListener("click", () => {
    modal.classList.add("hidden");
  });

  downloadButton.addEventListener("click", () => {
    if (!state.lastPayload) {
      setStatus("No previous crawl result.");
      return;
    }
    downloadPayload(state.lastPayload);
    setStatus("Downloaded last JSON.");
  });

  collectButton.addEventListener("click", async () => {
    if (state.running) {
      return;
    }

    state.running = true;
    collectButton.disabled = true;
    startButton.disabled = true;

    setStatus("Collecting product links from current page...");

    try {
      const collected = collectCurrentPageLinks(document, window.location.href);
      const mergedLinks = mergeLinks(state.storedLinks, getUrls(input.value), collected.links);
      state.storedLinks = mergedLinks;
      await setStoredLinks(mergedLinks);
      input.value = mergedLinks.join("\n");

      setStatus(
        `This page: ${collected.links.length} link, total memory: ${mergedLinks.length} link.`
      );
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setStatus(`Listing collect failed: ${message}`);
    }

    state.running = false;
    collectButton.disabled = false;
    startButton.disabled = false;
  });

  collectAutoButton.addEventListener("click", async () => {
    if (state.running) {
      return;
    }

    const urls = getUrls(input.value);
    if (urls.length < 2) {
      setStatus("Auto collect icin textarea'ya en az 2 liste URL'i ekleyin.");
      return;
    }

    state.running = true;
    collectButton.disabled = true;
    collectAutoButton.disabled = true;
    startButton.disabled = true;

    try {
      const firstPageUrl = urls[0];
      const secondPageUrl = urls[1];
      const autoCollected = await autoCollectFromTwoUrls(firstPageUrl, secondPageUrl);
      const mergedLinks = mergeLinks(state.storedLinks, getUrls(input.value), autoCollected.links);

      state.storedLinks = mergedLinks;
      await setStoredLinks(mergedLinks);
      input.value = mergedLinks.join("\n");

      setStatus(
        `Auto collect done: ${autoCollected.links.length} link, ${autoCollected.pagesVisited} page, total memory: ${mergedLinks.length}. ${autoCollected.stopReason || ""}`.trim()
      );
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setStatus(`Auto collect failed: ${message}`);
    }

    state.running = false;
    collectButton.disabled = false;
    collectAutoButton.disabled = false;
    startButton.disabled = false;
  });

  clearButton.addEventListener("click", async () => {
    if (state.running) {
      return;
    }

    state.storedLinks = [];
    input.value = "";
    state.lastPayload = null;
    await clearStoredLinks();
    setStatus("Memory cleared.");
  });

  startButton.addEventListener("click", async () => {
    if (state.running) {
      return;
    }

    const urls = getUrls(input.value);
    if (urls.length === 0) {
      setStatus("Please provide at least one valid URL.");
      return;
    }

    state.running = true;
    startButton.disabled = true;
    setStatus(`Crawling ${urls.length} page(s)...`);

    const results = [];

    for (let i = 0; i < urls.length; i += 1) {
      const url = urls[i];
      setStatus(`(${i + 1}/${urls.length}) Fetching ${url}`);

      try {
        const product = await crawlProduct(url);
        results.push(product);
        setStatus(`(${i + 1}/${urls.length}) Parsed ${product.title || url}`);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        results.push({ url, error: message });
        setStatus(`(${i + 1}/${urls.length}) Failed: ${message}`);
      }

      await sleep(250);
    }

    const payload = {
      generatedAt: new Date().toISOString(),
      source: "epey.com",
      total: urls.length,
      successCount: results.filter((item) => !item.error).length,
      data: results
    };

    state.lastPayload = payload;
    downloadPayload(payload);
    setStatus("Done. JSON downloaded.");

    state.running = false;
    startButton.disabled = false;
  });

  function setStatus(message) {
    status.textContent = message;
  }

  function getUrls(rawInput) {
    return rawInput
      .split(/\r?\n|,/g)
      .map((url) => url.trim())
      .filter((url) => /^https?:\/\/(www\.)?epey\.com\/.+/i.test(url));
  }

  function mergeLinks(...linkGroups) {
    const unique = new Set();
    linkGroups.forEach((links) => {
      (links || []).forEach((link) => {
        if (/^https?:\/\/(www\.)?epey\.com\/.+/i.test(link)) {
          unique.add(link);
        }
      });
    });
    return Array.from(unique);
  }

  function collectCurrentPageLinks(doc, currentUrl) {
    const collectedLinks = new Set();
    const productAnchors = Array.from(doc.querySelectorAll("div#sag a.urunadi[href]"));
    productAnchors.forEach((anchor) => {
      const href = anchor.getAttribute("href");
      const absoluteUrl = toAbsoluteUrl(href, currentUrl);
      if (absoluteUrl && /^https?:\/\/(www\.)?epey\.com\/.+/i.test(absoluteUrl)) {
        collectedLinks.add(absoluteUrl);
      }
    });

    return {
      links: Array.from(collectedLinks)
    };
  }

  async function autoCollectFromTwoUrls(firstPageUrl, secondPageUrl) {
    const allLinks = new Set();
    const visitedFinalUrls = new Set();
    let pagesVisited = 0;
    let stopReason = "";

    for (let page = 1; page <= AUTO_COLLECT_MAX_PAGES; page += 1) {
      const targetUrl = buildTargetPageUrl(page, firstPageUrl, secondPageUrl);
      if (!targetUrl) {
        stopReason = "Stopped: target URL could not be built.";
        break;
      }

      setStatus(`Auto collecting page ${page}: ${targetUrl}`);
      const pageResult = await fetchPageDocument(targetUrl);
      if (!pageResult.ok) {
        if ([301, 302, 303, 307, 308, 404].includes(pageResult.status)) {
          stopReason = `Stopped at page ${page} (HTTP ${pageResult.status}).`;
          break;
        }
        throw new Error(`HTTP ${pageResult.status} on ${targetUrl}`);
      }

      // If backend redirects to an already visited page, pagination ended.
      if (visitedFinalUrls.has(pageResult.finalUrl)) {
        stopReason = `Stopped at page ${page} (redirect loop/end).`;
        break;
      }
      visitedFinalUrls.add(pageResult.finalUrl);
      pagesVisited += 1;

      const pageLinks = collectCurrentPageLinks(pageResult.doc, pageResult.finalUrl).links;
      pageLinks.forEach((link) => allLinks.add(link));

      // End when there is no product card on current page.
      if (pageLinks.length === 0) {
        stopReason = `Stopped at page ${page} (no product on page).`;
        break;
      }

      await sleep(200);
    }

    return {
      links: Array.from(allLinks),
      pagesVisited,
      stopReason
    };
  }

  function buildTargetPageUrl(page, firstPageUrl, secondPageUrl) {
    if (page === 1) {
      return firstPageUrl;
    }
    if (page === 2) {
      return secondPageUrl;
    }

    try {
      const url = new URL(secondPageUrl);
      const segments = url.pathname.split("/").filter(Boolean);
      if (segments.length > 0 && /^\d+$/.test(segments[segments.length - 1])) {
        segments[segments.length - 1] = String(page);
      } else {
        segments.push(String(page));
      }
      url.pathname = `/${segments.join("/")}/`;
      return url.toString();
    } catch (error) {
      throw new Error("Second page URL format is not valid.");
    }
  }

  async function fetchPageDocument(url) {
    const response = await fetch(url, { credentials: "include" });
    if (!response.ok) {
      return {
        ok: false,
        status: response.status,
        finalUrl: response.url || url,
        doc: null
      };
    }

    const html = await response.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    return {
      ok: true,
      doc,
      status: response.status,
      finalUrl: response.url || url
    };
  }

  function toAbsoluteUrl(href, baseUrl) {
    if (!href) {
      return null;
    }

    const trimmedHref = String(href).trim();
    if (
      trimmedHref === "#" ||
      /^javascript:/i.test(trimmedHref) ||
      /^void\(0\)$/i.test(trimmedHref)
    ) {
      return null;
    }

    try {
      return new URL(trimmedHref, baseUrl).toString();
    } catch (error) {
      return null;
    }
  }

  async function hydrateStoredLinks() {
    const savedLinks = await getStoredLinks();
    state.storedLinks = savedLinks;
    const mergedLinks = mergeLinks(savedLinks, getUrls(input.value));
    input.value = mergedLinks.join("\n");
    if (savedLinks.length > 0) {
      setStatus(`Memory loaded: ${savedLinks.length} link.`);
    }
  }

  async function getStoredLinks() {
    const storage = chrome?.storage?.local;
    if (!storage) {
      return [];
    }

    return new Promise((resolve) => {
      storage.get([STORAGE_KEY], (result) => {
        const links = Array.isArray(result?.[STORAGE_KEY]) ? result[STORAGE_KEY] : [];
        resolve(getUrls(links.join("\n")));
      });
    });
  }

  async function setStoredLinks(links) {
    const storage = chrome?.storage?.local;
    if (!storage) {
      return;
    }

    return new Promise((resolve) => {
      storage.set({ [STORAGE_KEY]: links }, () => resolve());
    });
  }

  async function clearStoredLinks() {
    const storage = chrome?.storage?.local;
    if (!storage) {
      return;
    }

    return new Promise((resolve) => {
      storage.remove(STORAGE_KEY, () => resolve());
    });
  }

  async function crawlProduct(url) {
    const response = await fetch(url, { credentials: "include" });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const html = await response.text();
    return parseProductHtml(html, url);
  }

  function parseProductHtml(html, url) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    const h1Title = cleanText(doc.querySelector("h1")?.textContent);
    const title =
      h1Title ||
      doc.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
      "";

    const canonicalUrl =
      doc.querySelector('link[rel="canonical"]')?.getAttribute("href") || url;

    const attributes = {};
    const groups = doc.querySelectorAll("#ozellikler #grup");

    groups.forEach((group) => {
      const groupName = cleanText(group.querySelector("h3 span")?.textContent) || "GENEL";
      const groupAttributes = {};

      group.querySelectorAll("ul.grup > li").forEach((li) => {
        const key = cleanText(li.querySelector("strong#cell")?.textContent);
        if (!key) {
          return;
        }

        const values = extractValueParts(li);
        if (values.length === 0) {
          groupAttributes[key] = "";
        } else if (values.length === 1) {
          groupAttributes[key] = values[0];
        } else {
          groupAttributes[key] = values;
        }
      });

      if (Object.keys(groupAttributes).length > 0) {
        attributes[groupName] = groupAttributes;
      }
    });

    return {
      url,
      canonicalUrl,
      h1: h1Title,
      title,
      attributes
    };
  }

  function extractValueParts(li) {
    const valueContainer = li.querySelector("span.cell.cs1") || li.querySelector("span.cell");
    if (!valueContainer) {
      return [];
    }

    const firstLevelSpans = Array.from(valueContainer.querySelectorAll(":scope > span"));
    const rawValues = firstLevelSpans.length > 0
      ? firstLevelSpans.map((span) => cleanText(span.textContent))
      : [cleanText(valueContainer.textContent)];

    const uniqueValues = [];
    rawValues.forEach((value) => {
      if (!value) {
        return;
      }
      if (!uniqueValues.includes(value)) {
        uniqueValues.push(value);
      }
    });
    return uniqueValues;
  }

  function cleanText(value) {
    return (value || "").replace(/\s+/g, " ").trim();
  }

  function sleep(ms) {
    return new Promise((resolve) => {
      window.setTimeout(resolve, ms);
    });
  }

  function downloadPayload(payload) {
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json;charset=utf-8"
    });
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = objectUrl;
    anchor.download = buildFileName(payload);
    anchor.click();
    URL.revokeObjectURL(objectUrl);
  }

  function buildFileName(payload) {
    const firstProduct = Array.isArray(payload?.data)
      ? payload.data.find((item) => item && !item.error)
      : null;
    const baseName = sanitizeFileName(firstProduct?.h1 || firstProduct?.title || "epey-data");
    return `${baseName}.json`;
  }

  function sanitizeFileName(value) {
    const normalized = String(value || "epey-data")
      .replace(/ı/g, "i")
      .replace(/İ/g, "I")
      .replace(/ş/g, "s")
      .replace(/Ş/g, "S")
      .replace(/ğ/g, "g")
      .replace(/Ğ/g, "G")
      .replace(/ü/g, "u")
      .replace(/Ü/g, "U")
      .replace(/ö/g, "o")
      .replace(/Ö/g, "O")
      .replace(/ç/g, "c")
      .replace(/Ç/g, "C")
      .normalize("NFD")
      .toLowerCase();

    return normalized
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 80) || "epey-data";
  }
})();
