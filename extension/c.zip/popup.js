const toggle = document.getElementById("toggle");
const save = document.getElementById("save");
const badge = document.getElementById("badge");
const doneEl = document.getElementById("done");
const keepEl = document.getElementById("keep");
const dropEl = document.getElementById("drop");
const statusEl = document.getElementById("status");
const apiUrlEl = document.getElementById("apiUrl");
const tokenEl = document.getElementById("token");

function paint(running, status) {
  badge.textContent = running ? "ON" : "OFF";
  badge.className = running ? "badge on" : "badge off";
  toggle.textContent = running ? "Durdur" : "Başlat";
  statusEl.textContent = status || (running ? "çalışıyor" : "hazır");
}

async function loadConfig() {
  const stored = await chrome.storage.local.get({
    apiUrl: "https://product.n11.works",
    token: ""
  });
  apiUrlEl.value = stored.apiUrl || "https://product.n11.works";
  tokenEl.value = stored.token || "";
}

async function persistConfig() {
  await chrome.storage.local.set({
    apiUrl: apiUrlEl.value.trim() || "https://product.n11.works",
    token: tokenEl.value.trim()
  });
  chrome.runtime.sendMessage({ type: "config-updated" });
}

async function refresh() {
  const local = await chrome.runtime.sendMessage({ type: "status" });
  const stats = local?.stats;
  if (stats && stats.total != null) {
    const done = Number(stats.keep || 0) + Number(stats.drop || 0) + Number(stats.unknown || 0);
    doneEl.textContent = `${done} / ${stats.total}`;
    keepEl.textContent = String(stats.keep ?? "—");
    dropEl.textContent = String(stats.drop ?? "—");
  }
  const detail = [local?.last, local?.lastError].filter(Boolean).join(" — ");
  paint(Boolean(local?.running), detail);
}

save.addEventListener("click", async () => {
  save.disabled = true;
  await persistConfig();
  save.disabled = false;
  await refresh();
});

toggle.addEventListener("click", async () => {
  const running = badge.textContent === "ON";
  toggle.disabled = true;
  if (!running) await persistConfig();
  await chrome.runtime.sendMessage({ type: running ? "stop" : "start" });
  toggle.disabled = false;
  await refresh();
});

loadConfig().then(refresh);
setInterval(refresh, 1500);
