const state = {
  running: false,
  looping: false,
  last: "",
  lastError: "",
  tabId: 0,
  stats: null
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function getConfig() {
  const stored = await chrome.storage.local.get({
    enabled: false,
    apiUrl: "https://product.n11.works",
    token: ""
  });
  return {
    enabled: Boolean(stored.enabled),
    apiUrl: String(stored.apiUrl || "https://product.n11.works").replace(/\/$/, ""),
    token: String(stored.token || "").trim()
  };
}

async function api(path, { method = "GET", body } = {}) {
  const cfg = await getConfig();
  if (!cfg.token) throw new Error("token gerekli");
  const response = await fetch(`${cfg.apiUrl}/api${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${cfg.token}`,
      "Content-Type": "application/json"
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await response.json().catch(() => ({}));
  if (response.status === 401) throw new Error("token geçersiz");
  if (!response.ok) throw new Error(data.error || `api_${response.status}`);
  return data;
}

function waitForTab(tabId) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve();
    }, 20000);
    function onUpdated(updatedId, info) {
      if (updatedId === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(onUpdated);
  });
}

async function ensureTab() {
  if (state.tabId) {
    try {
      const tab = await chrome.tabs.get(state.tabId);
      if (tab?.id && String(tab.url || "").startsWith("https://www.trendyol.com/")) return tab.id;
    } catch {
      state.tabId = 0;
    }
  }
  const created = await chrome.tabs.create({
    url: "https://www.trendyol.com/",
    active: false
  });
  if (!created.id) throw new Error("trendyol_sekmesi_acilamadi");
  state.tabId = created.id;
  await waitForTab(created.id);
  return created.id;
}

async function reloadOwnedTab() {
  const tabId = await ensureTab();
  await chrome.tabs.reload(tabId);
  await waitForTab(tabId);
  return tabId;
}

function contentUrl(merchantId, contentId) {
  return "https://apigw.trendyol.com/discovery-storefront-trproductgw-service/api/product-detail/content"
    + `?contentId=${encodeURIComponent(contentId)}`
    + `&merchantId=${encodeURIComponent(merchantId)}`
    + "&culture=tr-TR&channelId=1";
}

function classify(merchantId, product, httpStatus) {
  const listing = product?.merchantListing || {};
  const seller = String(listing.merchant?.id || "");
  const others = Array.isArray(listing.otherMerchants) ? listing.otherMerchants : [];
  const soldByStore = seller === String(merchantId)
    || others.some((merchant) => String(merchant.id) === String(merchantId));
  if (soldByStore) return { status: "keep", seller };
  if (!seller) return { status: "unknown", http: httpStatus };
  return { status: "drop", seller };
}

async function checkInTab(tabId, mid, cid) {
  const [injection] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    args: [String(mid), String(cid)],
    func: async (merchantId, contentId) => {
      const frame = document.createElement("iframe");
      frame.setAttribute("style", "display:none");
      document.documentElement.appendChild(frame);
      const url = "https://apigw.trendyol.com/discovery-storefront-trproductgw-service/api/product-detail/content"
        + `?contentId=${encodeURIComponent(contentId)}`
        + `&merchantId=${encodeURIComponent(merchantId)}`
        + "&culture=tr-TR&channelId=1";
      try {
        const win = frame.contentWindow;
        if (!win) return { status: "unknown", error: "global scope is shutting down" };
        const nativeFetch = win.fetch.bind(win);
        const response = await nativeFetch(url, {
          credentials: "include",
          headers: { Accept: "application/json" }
        });
        if (response.status === 429 || response.status === 403 || !response.ok) {
          return { status: "unknown", http: response.status };
        }
        const payload = await response.json();
        const product = payload.result || payload;
        const listing = product.merchantListing || {};
        const seller = String(listing.merchant?.id || "");
        const others = Array.isArray(listing.otherMerchants) ? listing.otherMerchants : [];
        const soldByStore = seller === String(merchantId)
          || others.some((merchant) => String(merchant.id) === String(merchantId));
        if (soldByStore) return { status: "keep", seller };
        if (!seller) return { status: "unknown", http: response.status };
        return { status: "drop", seller };
      } catch (error) {
        return { status: "unknown", error: String(error && error.message || error) };
      } finally {
        frame.remove();
      }
    }
  });
  return injection?.result || { status: "unknown", error: "bos_cevap" };
}

async function checkPair(mid, cid) {
  try {
    const response = await fetch(contentUrl(mid, cid), {
      credentials: "include",
      headers: {
        Accept: "application/json",
        "Accept-Language": "tr-TR,tr;q=0.9"
      }
    });
    if (response.ok) {
      const payload = await response.json();
      const verdict = classify(mid, payload.result || payload, response.status);
      if (verdict.status !== "unknown") return verdict;
    }
  } catch {
    /* Sayfa içindeki temiz fetch denenecek. */
  }
  const tabId = await ensureTab();
  return checkInTab(tabId, mid, cid);
}

async function refreshStats() {
  try {
    state.stats = await api("/extension/merchant-check/stats");
  } catch (error) {
    state.lastError = String(error && error.message || error);
  }
}

async function loop() {
  if (state.looping) return;
  state.looping = true;
  state.running = true;
  chrome.action.setBadgeText({ text: "ON" });
  chrome.action.setBadgeBackgroundColor({ color: "#34c759" });
  try {
    while (state.running && (await getConfig()).enabled) {
      let claim;
      try {
        claim = await api("/extension/merchant-check/claim", { method: "POST", body: { limit: 1 } });
      } catch (error) {
        state.lastError = String(error && error.message || error);
        state.last = "sunucu bekleniyor";
        await sleep(8000);
        continue;
      }
      const item = claim.items?.[0];
      if (!item) {
        await refreshStats();
        const open = Number(state.stats?.pending || 0) + Number(state.stats?.running || 0);
        state.last = open ? "başka cihaz çalışıyor" : "liste bitti";
        state.lastError = "";
        if (!open) {
          await chrome.storage.local.set({ enabled: false });
          break;
        }
        await sleep(15000);
        continue;
      }
      const result = await checkPair(item.merchantId, item.contentId);
      if (!result || result.status === "unknown") {
        state.lastError = result?.error || `http ${result?.http || "?"}`;
        state.last = `${item.contentId} bekliyor`;
        if (/failed to fetch|shutting down|failed to execute/i.test(state.lastError)) {
          await reloadOwnedTab().catch(() => {});
        }
        const retry = /failed to fetch|shutting down|failed to execute|429|403/i.test(state.lastError);
        await api("/extension/merchant-check/result", {
          method: "POST",
          body: {
            merchantId: item.merchantId,
            contentId: item.contentId,
            status: "unknown",
            seller: "",
            retry,
            error: state.lastError
          }
        }).catch((error) => {
          state.lastError = String(error && error.message || error);
        });
        await sleep(8000);
        continue;
      }
      await api("/extension/merchant-check/result", {
        method: "POST",
        body: {
          merchantId: item.merchantId,
          contentId: item.contentId,
          status: result.status,
          seller: result.seller || ""
        }
      });
      state.lastError = "";
      state.last = `${item.contentId} ${result.status === "keep" ? "kalır" : "çıkar"}`;
      await refreshStats();
      await sleep(900);
    }
  } catch (error) {
    state.lastError = String(error && error.message || error);
  } finally {
    state.running = false;
    state.looping = false;
    if (!(await getConfig()).enabled) chrome.action.setBadgeText({ text: "" });
  }
}

async function start() {
  const cfg = await getConfig();
  if (!cfg.token) {
    state.lastError = "token gerekli";
    return;
  }
  await chrome.storage.local.set({ enabled: true });
  if (!state.looping) loop();
}

async function stop() {
  state.running = false;
  await chrome.storage.local.set({ enabled: false });
  chrome.action.setBadgeText({ text: "" });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    if (message?.type === "start") await start();
    if (message?.type === "stop") await stop();
    if (message?.type === "config-updated" && (await getConfig()).enabled && !state.looping) loop();
    if (!state.stats) await refreshStats().catch(() => {});
    sendResponse({
      running: state.running,
      last: state.last,
      lastError: state.lastError,
      stats: state.stats
    });
  })();
  return true;
});

chrome.alarms.create("merchant-check-watchdog", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "merchant-check-watchdog") return;
  const cfg = await getConfig();
  if (cfg.enabled && cfg.token && !state.looping) await loop();
});

getConfig().then((cfg) => {
  if (cfg.enabled && cfg.token) loop();
});
