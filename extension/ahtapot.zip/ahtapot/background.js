'use strict';

importScripts('lib/trendyol-price.js', 'lib/trendyol-seller-url.js');

/** Panel ingest API (npm run api). Astro `/api/*` proxy’sine bağlı kalmayın. */
const PANEL_API_BASE = 'https://ahtapot.datascraper.net/api';
function panelApiUrl(path) {
	const p = path.startsWith('/') ? path : `/${path}`;
	return `${PANEL_API_BASE}${p}`;
}

/** İndirilenler altında güvenli dosya adı (Data Crawler ile uyumlu). */
function sanitizeDownloadFilename(name) {
	const s = String(name || 'download.txt').replace(/[/\\?%*:|"<>]/g, '_').trim();
	return s.slice(0, 200) || 'download.txt';
}

function utf8TextToDataUrlBase64(text) {
	const utf8 = new TextEncoder().encode(text);
	if (utf8.length > 2 * 1024 * 1024) {
		return null;
	}
	let binary = '';
	const chunk = 0x8000;
	for (let i = 0; i < utf8.length; i += chunk) {
		binary += String.fromCharCode.apply(null, utf8.subarray(i, i + chunk));
	}
	return 'data:text/plain;charset=utf-8;base64,' + btoa(binary);
}

function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Panel / content script scrape durum satırı */
function emitScrapeProgress(info) {
	if (!info || typeof info !== 'object') return;
	const message = String(info.message || '').trim();
	if (!message) return;
	try {
		chrome.runtime
			.sendMessage({
				type: 'kg-scrape-progress',
				phase: info.phase || '',
				message,
				url: info.url || '',
				index: info.index ?? null,
				total: info.total ?? null,
			})
			.catch(() => {});
	} catch {
		/* ignore */
	}
}

let reviewProgressPollTimer = null;
let pdpProgressPollTimer = null;

function stopPdpProgressPoll() {
	if (pdpProgressPollTimer) {
		clearInterval(pdpProgressPollTimer);
		pdpProgressPollTimer = null;
	}
}

function startPdpProgressPoll(tabId, ctx) {
	stopPdpProgressPoll();
	if (!Number.isFinite(tabId)) return;
	const base = { url: ctx?.url || '', index: ctx?.index ?? null, total: ctx?.total ?? null };
	pdpProgressPollTimer = setInterval(() => {
		chrome.scripting
			.executeScript({
				target: { tabId },
				world: 'MAIN',
				func: () =>
					typeof window.__ahtapotScrapeStatus === 'string' ? window.__ahtapotScrapeStatus : null,
			})
			.then((results) => {
				const text = results && results[0] ? results[0].result : null;
				if (text) {
					emitScrapeProgress({
						...base,
						phase: 'pdp_fetch',
						message: text,
					});
				}
			})
			.catch(() => {});
	}, 500);
}

function stopReviewProgressPoll() {
	if (reviewProgressPollTimer) {
		clearInterval(reviewProgressPollTimer);
		reviewProgressPollTimer = null;
	}
}

function startReviewProgressPoll(tabId, ctx) {
	stopReviewProgressPoll();
	if (!Number.isFinite(tabId)) return;
	const base = { url: ctx?.url || '', index: ctx?.index ?? null, total: ctx?.total ?? null };
	reviewProgressPollTimer = setInterval(() => {
		chrome.scripting
			.executeScript({
				target: { tabId },
				world: 'MAIN',
				func: () =>
					typeof window.__ahtapotScrapeStatus === 'string' ? window.__ahtapotScrapeStatus : null,
			})
			.then((results) => {
				const text = results && results[0] ? results[0].result : null;
				if (text) {
					emitScrapeProgress({
						...base,
						phase: 'reviews_fetch',
						message: text,
					});
				}
			})
			.catch(() => {});
	}, 700);
}

function isTransientTabEditError(error) {
	const msg = String(error && error.message ? error.message : error || '').toLowerCase();
	return (
		msg.includes('tabs cannot be edited right now') ||
		msg.includes('user may be dragging a tab') ||
		msg.includes('tabs cannot be edited')
	);
}

async function withTabRetry(task, options) {
	const maxAttempts = options?.maxAttempts ?? 5;
	const baseDelayMs = options?.baseDelayMs ?? 150;
	let lastErr = null;
	for (let attempt = 1; attempt <= maxAttempts; attempt++) {
		try {
			return await task();
		} catch (err) {
			lastErr = err;
			if (!isTransientTabEditError(err) || attempt === maxAttempts) break;
			const backoff = baseDelayMs * Math.pow(2, attempt - 1);
			await sleep(backoff);
		}
	}
	throw lastErr || new Error('Tab işlemi başarısız.');
}

function createInactiveTab(url, options) {
	const active = options?.active === true;
	return new Promise((resolve, reject) => {
		chrome.tabs.create({ url, active }, (tab) => {
			if (chrome.runtime.lastError) {
				reject(new Error(chrome.runtime.lastError.message));
				return;
			}
			if (!tab || typeof tab.id !== 'number') {
				reject(new Error('Sekme oluşturulamadı.'));
				return;
			}
			resolve(tab.id);
		});
	});
}

function waitForTabComplete(tabId, timeoutMs) {
	return new Promise((resolve, reject) => {
		let done = false;
		const timer = setTimeout(() => {
			if (done) return;
			done = true;
			chrome.tabs.onUpdated.removeListener(onUpdated);
			reject(new Error('Sekme yükleme zaman aşımı.'));
		}, timeoutMs);
		function onUpdated(updatedTabId, changeInfo) {
			if (done) return;
			if (updatedTabId !== tabId) return;
			if (changeInfo.status !== 'complete') return;
			done = true;
			clearTimeout(timer);
			chrome.tabs.onUpdated.removeListener(onUpdated);
			resolve();
		}
		chrome.tabs.onUpdated.addListener(onUpdated);
	});
}

function closeTabSafe(tabId) {
	return new Promise((resolve) => {
		chrome.tabs.remove(tabId, () => {
			resolve();
		});
	});
}

function executeExtractInTab(tabId) {
	return new Promise((resolve, reject) => {
		chrome.scripting.executeScript(
			{
				target: { tabId },
				func: () => {
					function pickFirstNonEmpty(values) {
						for (let i = 0; i < values.length; i++) {
							const v = values[i];
							if (typeof v === 'string' && v.trim()) return v.trim();
						}
						return null;
					}
					function numberOrNull(value) {
						if (typeof value === 'number' && Number.isFinite(value)) return value;
						if (typeof value === 'string') {
							const cleaned = value.replace(/[^\d.,-]/g, '').replace(/\./g, '').replace(',', '.');
							const n = Number(cleaned);
							return Number.isFinite(n) ? n : null;
						}
						return null;
					}
					function extractTrendyolPriceRaw(priceNode) {
						if (typeof globalThis.extractTrendyolPriceRaw === 'function') {
							return globalThis.extractTrendyolPriceRaw(priceNode);
						}
						if (priceNode == null) return null;
						if (typeof priceNode === 'number' && Number.isFinite(priceNode)) return priceNode;
						if (typeof priceNode === 'string') return numberOrNull(priceNode);
						if (typeof priceNode !== 'object') return null;
						const candidates = [
							priceNode.sellingPrice?.value,
							priceNode.discountedPrice?.value,
							priceNode.couponApplicablePrice?.value,
							priceNode.price,
							priceNode.lowPrice,
							priceNode.value,
						];
						for (let i = 0; i < candidates.length; i++) {
							const v = candidates[i];
							if (v == null) continue;
							const n = typeof v === 'number' ? (Number.isFinite(v) ? v : null) : numberOrNull(v);
							if (n != null) return n;
						}
						return null;
					}
					function normalizeTrendyolPrice(raw, currency) {
						if (typeof globalThis.normalizeTrendyolPrice === 'function') {
							return globalThis.normalizeTrendyolPrice(raw, currency);
						}
						const n = extractTrendyolPriceRaw(raw);
						if (n == null) return null;
						const cur = String(currency || 'TRY').toUpperCase();
						if (cur !== 'TRY') return n;
						if (!Number.isInteger(n)) return Math.round(n * 100) / 100;
						if (n >= 1000) return n / 100;
						return n;
					}
					function normalizeImageUrl(image) {
						function fixN11Placeholder(url) {
							return String(url || '').replace('/{0}/', '/320/');
						}
						if (!image) return null;
						if (typeof image === 'string') {
							const fixed = fixN11Placeholder(image).trim();
							return fixed || null;
						}
						if (Array.isArray(image)) return normalizeImageUrl(image[0]);
						if (typeof image === 'object') {
							const raw = pickFirstNonEmpty([image.url, image.contentUrl, image.thumbnailUrl]);
							return raw ? fixN11Placeholder(raw) : null;
						}
						return null;
					}
					function normalizeAttributes(additionalProperty) {
						const list = Array.isArray(additionalProperty) ? additionalProperty : [];
						const out = [];
						for (let i = 0; i < list.length; i++) {
							const row = list[i] || {};
							const name = pickFirstNonEmpty([row.name]);
							const value = pickFirstNonEmpty([row.value, row.unitText]);
							if (!name || !value) continue;
							out.push({ name, value });
						}
						return out;
					}
					function extractCategoryPathFromBreadcrumb(breadcrumb) {
						if (!breadcrumb || typeof breadcrumb !== 'object') return null;
						const list = Array.isArray(breadcrumb.itemListElement) ? breadcrumb.itemListElement : [];
						const names = [];
						for (let i = 0; i < list.length; i++) {
							const item = list[i];
							const name =
								typeof item?.name === 'string'
									? item.name
									: typeof item?.item?.name === 'string'
										? item.item.name
										: null;
							if (name && name.trim()) names.push(name.trim());
						}
						return names.length ? names : null;
					}
					function flattenJsonLdNodes(nodes) {
						const out = [];
						function walk(node) {
							if (!node || typeof node !== 'object') return;
							out.push(node);
							if (Array.isArray(node['@graph'])) {
								for (let i = 0; i < node['@graph'].length; i++) walk(node['@graph'][i]);
							}
						}
						for (let i = 0; i < nodes.length; i++) walk(nodes[i]);
						return out;
					}
					function hasType(node, target) {
						const t = node && node['@type'];
						if (typeof t === 'string') return t.toLowerCase() === target;
						if (Array.isArray(t)) return t.some((x) => String(x || '').toLowerCase() === target);
						return false;
					}
					function parseJsonLdNodes() {
						const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
						const nodes = [];
						for (let i = 0; i < scripts.length; i++) {
							const text = String(scripts[i].textContent || '').trim();
							if (!text) continue;
							try {
								const parsed = JSON.parse(text);
								if (Array.isArray(parsed)) nodes.push(...parsed);
								else nodes.push(parsed);
							} catch {
								/* ignore */
							}
						}
						return nodes;
					}
					function parseN11StateProduct() {
						function normalizeAttrText(value) {
							return String(value || '')
								.replace(/\s+/g, ' ')
								.replace(/^[:\-\s]+|[:\-\s]+$/g, '')
								.trim();
						}
						function extractN11AttributesFromDom() {
							const out = [];
							const seen = new Set();
							const rows = Array.from(
								document.querySelectorAll(
									'#productAttributes .unf-prop-list-item, #productAttributes .catalogAttributeItem, #productAttributes li',
								),
							);
							for (let i = 0; i < rows.length; i++) {
								const row = rows[i];
								let name = normalizeAttrText(
									row.querySelector('.unf-prop-list-title, .attrKey, dt, span:first-child')
										?.textContent || '',
								);
								let value = normalizeAttrText(
									row.querySelector('.unf-prop-list-prop, .attrValue, dd, span:last-child')
										?.textContent || '',
								);
								if ((!name || !value) && row.childElementCount === 0) {
									const text = normalizeAttrText(row.textContent || '');
									const idx = text.indexOf(':');
									if (idx > 0) {
										name = normalizeAttrText(text.slice(0, idx));
										value = normalizeAttrText(text.slice(idx + 1));
									}
								}
								if (!name || !value || name === value) continue;
								const key = `${name}::${value}`;
								if (seen.has(key)) continue;
								seen.add(key);
								out.push({ name, value });
							}
							return out;
						}
						function extractN11AttributesFromFeatureTable() {
							const out = [];
							const seen = new Set();
							const rows = Array.from(
								document.querySelectorAll(
									'table#attr-table tr, #attr-table tr, table.product-features tr, .product-features-table tr, #productDescription table tr',
								),
							);
							for (let i = 0; i < rows.length; i++) {
								const row = rows[i];
								const name = normalizeAttrText(
									row.querySelector('th, td.attr-name, td.key, td:first-child, .attr-name')?.textContent ||
										'',
								);
								const value = normalizeAttrText(
									row.querySelector('td.attr-value, td.value, td:last-child, .attr-value')?.textContent ||
										'',
								);
								if (!name || !value || name === value) continue;
								const key = `${name}::${value}`;
								if (seen.has(key)) continue;
								seen.add(key);
								out.push({ name, value });
							}
							return out;
						}
						function extractN11AttributesFromDescriptionText(text) {
							const out = [];
							const seen = new Set();
							const blockedCssKeys = new Set([
								'font-size',
								'color',
								'padding',
								'padding-bottom',
								'padding-top',
								'padding-left',
								'padding-right',
								'margin',
								'margin-bottom',
								'margin-top',
								'margin-left',
								'margin-right',
								'line-height',
								'font-family',
								'background',
								'border',
								'border-radius',
								'max-width',
								'height',
								'width',
								'display',
								'position',
								'overflow',
								'text-align',
							]);
							function shouldSkipCssNoise(name, value) {
								const n = String(name || '').toLowerCase().trim();
								const v = String(value || '').toLowerCase().trim();
								if (!n || !v) return true;
								if (blockedCssKeys.has(n)) return true;
								if (n.includes('{') || n.includes('}') || n.includes('.')) return true;
								if (/^\.|^#|^\@|^\*/.test(n)) return true;
								if (/(px|em|rem|vh|vw|%|rgb\(|rgba\(|#(?:[0-9a-f]{3}|[0-9a-f]{6}))/i.test(v) && blockedCssKeys.has(n)) {
									return true;
								}
								if (/^[a-z\-]+\s*\{?/i.test(n) && /;/.test(v)) return true;
								return false;
							}
							const lines = String(text || '')
								.replace(/&nbsp;/gi, ' ')
								.replace(/<br\s*\/?>/gi, '\n')
								.replace(/<\/p>/gi, '\n')
								.replace(/<\/li>/gi, '\n')
								.replace(/<[^>]+>/g, ' ')
								.split(/\r?\n+/)
								.map((x) => normalizeAttrText(x))
								.filter(Boolean);
							for (let i = 0; i < lines.length; i++) {
								const line = lines[i];
								const idx = line.indexOf(':');
								if (idx <= 0) continue;
								const name = normalizeAttrText(line.slice(0, idx));
								const value = normalizeAttrText(line.slice(idx + 1));
								if (shouldSkipCssNoise(name, value)) continue;
								if (!name || !value || name === value) continue;
								const key = `${name}::${value}`;
								if (seen.has(key)) continue;
								seen.add(key);
								out.push({ name, value });
							}
							return out;
						}
						const scripts = Array.from(document.querySelectorAll('script'));
						for (let i = 0; i < scripts.length; i++) {
							const text = String(scripts[i].textContent || '');
							if (!text.includes('"productDetailType"') || !text.includes('"product"')) continue;
							const keyIdx = text.indexOf('"product"');
							if (keyIdx === -1) continue;
							const braceStart = text.indexOf('{', keyIdx);
							if (braceStart === -1) continue;
							let depth = 0;
							let inString = false;
							let escaped = false;
							let end = -1;
							for (let j = braceStart; j < text.length; j++) {
								const ch = text[j];
								if (inString) {
									if (escaped) escaped = false;
									else if (ch === '\\') escaped = true;
									else if (ch === '"') inString = false;
									continue;
								}
								if (ch === '"') {
									inString = true;
									continue;
								}
								if (ch === '{') depth++;
								else if (ch === '}') {
									depth--;
									if (depth === 0) {
										end = j;
										break;
									}
								}
							}
							if (end === -1) continue;
							try {
								const product = JSON.parse(text.slice(braceStart, end + 1));
								if (!product || typeof product !== 'object') continue;
								const breadcrumb = Array.isArray(product.breadcrumb)
									? product.breadcrumb
											.map((x) => (typeof x?.name === 'string' ? x.name.trim() : ''))
											.filter(Boolean)
									: [];
								const attrsFromState = Array.isArray(product.productAttributes)
									? product.productAttributes
											.map((x) => {
												const name = pickFirstNonEmpty([x?.key]);
												const value = pickFirstNonEmpty([x?.value]);
												if (!name || !value) return null;
												return { name, value };
											})
											.filter(Boolean)
									: [];
								const attrsFromDom = extractN11AttributesFromDom();
								const attrsFromTable = extractN11AttributesFromFeatureTable();
								const attrsFromDescription = extractN11AttributesFromDescriptionText(
									product?.description || product?.catalogDescription || '',
								);
								const merged = [];
								const seen = new Set();
								for (const group of [attrsFromDom, attrsFromTable, attrsFromDescription, attrsFromState]) {
									for (let k = 0; k < group.length; k++) {
										const row = group[k];
										const key = `${row.name}::${row.value}`;
										if (seen.has(key)) continue;
										seen.add(key);
										merged.push(row);
									}
								}
								const attrs = merged;
								const firstImage = Array.isArray(product.images) ? product.images[0] : null;
								const firstOffer = Array.isArray(product?.marketplaceMeta?.platformIds?.n11?.offers)
									? product.marketplaceMeta.platformIds.n11.offers[0]
									: null;
								const barcode = pickFirstNonEmpty([
									product?.gtin8,
									product?.barcode,
									product?.defaultGtin,
									Array.isArray(product?.skus) ? product.skus[0]?.gtin : null,
								]);
								return {
									url: pickFirstNonEmpty([product.productUrlWithoutSellerShop, product.productUrl, location.href]),
									sku: pickFirstNonEmpty([product.defaultSkuId ? String(product.defaultSkuId) : null]),
									barcode,
									title: pickFirstNonEmpty([product.title, document.title]),
									brand: pickFirstNonEmpty([product.productBrand]),
									price: numberOrNull(product.priceFloat ?? product.displayPriceFloat ?? product.price),
									currency: 'TRY',
									availability: product.outOfStock ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock',
									categoryPath: breadcrumb.length ? breadcrumb : null,
									imageUrl: normalizeImageUrl(firstImage?.path || firstOffer?.imageUrl),
									attributes: attrs,
									rawProductJson: {
										schemaVersion: 'api-json-scraping-n11-state-1',
										source: 'n11-product-state',
										product,
									},
								};
							} catch {
								/* continue */
							}
						}
						return null;
					}
					function parseHepsiburadaStateProduct() {
						const scripts = Array.from(document.querySelectorAll('script'));
						for (let i = 0; i < scripts.length; i++) {
							const text = String(scripts[i].textContent || '');
							if (!text.includes('"accountState"') || !text.includes('"productState"')) continue;
							const start = text.indexOf('{"accountState":');
							if (start === -1) continue;
							let depth = 0;
							let inString = false;
							let escaped = false;
							let end = -1;
							for (let j = start; j < text.length; j++) {
								const ch = text[j];
								if (inString) {
									if (escaped) escaped = false;
									else if (ch === '\\') escaped = true;
									else if (ch === '"') inString = false;
									continue;
								}
								if (ch === '"') {
									inString = true;
									continue;
								}
								if (ch === '{') depth++;
								else if (ch === '}') {
									depth--;
									if (depth === 0) {
										end = j;
										break;
									}
								}
							}
							if (end === -1) continue;
							try {
								const parsed = JSON.parse(text.slice(start, end + 1));
								const product = parsed?.productState?.product;
								if (!product || typeof product !== 'object') continue;
								const attrs = [];
								const techRoot = document.querySelector('#techSpecs, [data-test-id="KeyFeaturesTable"]');
								if (techRoot && techRoot.children && techRoot.children.length > 1) {
									const grid = techRoot.children[1];
									const rows = Array.from(grid.children || []);
									for (let r = 0; r < rows.length; r++) {
										const row = rows[r];
										if (!row || !row.children || row.children.length < 2) continue;
										const name = pickFirstNonEmpty([row.children[0]?.textContent]);
										const value = pickFirstNonEmpty([row.children[1]?.textContent]);
										if (!name || !value) continue;
										attrs.push({ name, value });
									}
								}
								const imageUrl = Array.isArray(product?.media) && product.media[0]?.url
									? String(product.media[0].url).replace(/\{size\}/g, '424-600')
									: null;
								return {
									url: location.href,
									sku: pickFirstNonEmpty([product.sku]),
									barcode: pickFirstNonEmpty([product.barcode]),
									title: pickFirstNonEmpty([product.name, document.title]),
									brand: pickFirstNonEmpty([product.brand]),
									price: numberOrNull(product?.prices?.[0]?.value),
									currency: 'TRY',
									availability: product?.stockInformation?.isInStock === false ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock',
									categoryPath: null,
									imageUrl: normalizeImageUrl(imageUrl),
									attributes: attrs,
									rawProductJson: {
										schemaVersion: 'api-json-scraping-hepsiburada-state-1',
										source: 'hepsiburada-product-state',
										product,
									},
								};
							} catch {
								/* continue */
							}
						}
						return null;
					}
					function parseNextDataProduct() {
						const el = document.querySelector('#__NEXT_DATA__');
						if (!el) return null;
						try {
							const raw = String(el.textContent || '').trim();
							if (!raw) return null;
							const parsed = JSON.parse(raw);
							const product = parsed?.props?.pageProps?.product;
							if (!product || typeof product !== 'object') return null;
							const brand =
								typeof product.brand?.name === 'string'
									? product.brand.name
									: typeof product.brandName === 'string'
										? product.brandName
										: null;
							const categoryPath = Array.isArray(product.categories)
								? product.categories
										.map((x) => (typeof x?.name === 'string' ? x.name.trim() : ''))
										.filter(Boolean)
								: null;
							const attributes = Array.isArray(product.attributes)
								? product.attributes
										.map((x) => {
											const name = pickFirstNonEmpty([x?.key?.name, x?.attribute?.name, x?.name]);
											const value = pickFirstNonEmpty([x?.value?.name, x?.value, x?.displayValue]);
											if (!name || !value) return null;
											return { name, value };
										})
										.filter(Boolean)
								: [];
							const firstVariant = Array.isArray(product.variants) ? product.variants[0] : null;
							const barcode = pickFirstNonEmpty([product.barcode, firstVariant?.barcode, product?.sellerSku]);
							return {
								url: pickFirstNonEmpty([product.url, location.href]),
								sku: pickFirstNonEmpty([product.id ? String(product.id) : null, product.sku]),
								barcode,
								title: pickFirstNonEmpty([product.name, document.title]),
								brand,
								price: normalizeTrendyolPrice(product?.price, product?.price?.currency ?? 'TRY'),
								currency: pickFirstNonEmpty([product?.price?.currency, 'TRY']),
								availability:
									product?.stock > 0 || product?.hasStock === true
										? 'https://schema.org/InStock'
										: product?.stock === 0
											? 'https://schema.org/OutOfStock'
											: null,
								categoryPath: categoryPath && categoryPath.length ? categoryPath : null,
								imageUrl: normalizeImageUrl(product.images),
								attributes,
								rawProductJson: {
									schemaVersion: 'api-json-scraping-next-data-1',
									source: '__NEXT_DATA__',
									product,
								},
							};
						} catch {
							return null;
						}
					}
					function extractBarcodeFromEnvoyProps() {
						const productIdFromUrl = (() => {
							const m = String(location.href || '').match(/-p-(\d+)/i);
							return m ? m[1] : null;
						})();
						const scripts = Array.from(document.querySelectorAll('script'));
						for (let i = 0; i < scripts.length; i++) {
							const text = String(scripts[i].textContent || '');
							if (!text.includes('__envoy') || !text.includes('__PROPS')) continue;
							if (productIdFromUrl && !text.includes(`"id":${productIdFromUrl}`)) continue;
							const winnerVariantMatch = text.match(
								/"winnerVariant"\s*:\s*\{[\s\S]*?"barcode"\s*:\s*"([0-9]{8,14})"/,
							);
							if (winnerVariantMatch && winnerVariantMatch[1]) return winnerVariantMatch[1];
							const genericBarcodeMatch = text.match(/"barcode"\s*:\s*"([0-9]{8,14})"/);
							if (genericBarcodeMatch && genericBarcodeMatch[1]) return genericBarcodeMatch[1];
							const match = text.match(
								/window\["[^"]*__PROPS"\]\s*=\s*(\{[\s\S]*\})\s*;?$/,
							);
							if (!match) continue;
							try {
								const parsed = JSON.parse(match[1]);
								const candidate = pickFirstNonEmpty([
									parsed?.product?.merchantListing?.winnerVariant?.barcode,
									Array.isArray(parsed?.product?.variants) ? parsed.product.variants[0]?.barcode : null,
									parsed?.product?.barcode,
								]);
								if (!candidate) continue;
								const digits = String(candidate).replace(/\D/g, '');
								if (digits.length >= 8 && digits.length <= 14) return digits;
							} catch {
								/* ignore parse errors and continue */
							}
						}
						return null;
					}
					function parseDomFallbackProduct() {
						const title = pickFirstNonEmpty([
							document.querySelector('h1')?.textContent,
							document.querySelector('[data-testid="product-name"]')?.textContent,
							document.title,
						]);
						if (!title) return null;
						const priceText = pickFirstNonEmpty([
							document.querySelector('[data-testid="price-current-price"]')?.textContent,
							document.querySelector('.product-price-container')?.textContent,
							document.querySelector('.prc-dsc')?.textContent,
						]);
						const breadcrumbNodes = Array.from(
							document.querySelectorAll('ul.breadcrumb-list li a, .breadcrumb a, nav[aria-label*="breadcrumb" i] a'),
						);
						const categoryPath = breadcrumbNodes
							.map((a) => String(a.textContent || '').trim())
							.filter(Boolean);
						const attrs = [];
						const seenAttr = new Set();
						const noiseAttrs = new Set(['ürün güvenliği bilgileri']);
						const labelHints = [
							'Materyal',
							'Renk',
							'Uyumlu Marka',
							'Menşei',
							'Model',
							'Marka',
							'Garanti Süresi',
							'Garanti Tipi',
						];
						function findEarliestLabel(text, fromIndex) {
							const haystack = String(text || '').toLowerCase();
							let best = null;
							for (let i = 0; i < labelHints.length; i++) {
								const label = labelHints[i];
								const idx = haystack.indexOf(label.toLowerCase(), fromIndex);
								if (idx === -1) continue;
								if (!best || idx < best.index || (idx === best.index && label.length > best.label.length)) {
									best = { index: idx, label };
								}
							}
							return best;
						}
						function splitConcatenatedChain(name, value) {
							const out = [];
							const baseName = cleanupAttrToken(name);
							const source = cleanupAttrToken(value);
							if (!baseName || !source) return out;
							let currentLabel = baseName;
							let cursor = 0;
							while (cursor < source.length) {
								const next = findEarliestLabel(source, cursor + 1);
								if (!next) {
									const tail = cleanupAttrToken(source.slice(cursor));
									if (tail) out.push({ name: currentLabel, value: tail });
									break;
								}
								const chunk = cleanupAttrToken(source.slice(cursor, next.index));
								if (chunk) out.push({ name: currentLabel, value: chunk });
								currentLabel = next.label;
								cursor = next.index + next.label.length;
							}
							return out.length ? out : [{ name: baseName, value: source }];
						}
						function pushOneAttr(name, value) {
							const n = cleanupAttrToken(name);
							const v = cleanupAttrToken(value);
							if (!n || !v || n === v) return;
							const key = `${n}::${v}`;
							if (seenAttr.has(key)) return;
							seenAttr.add(key);
							attrs.push({ name: n, value: v });
						}
						function cleanupAttrToken(text) {
							return String(text || '')
								.replace(/\s+/g, ' ')
								.replace(/^[:\-–\s]+|[:\-–\s]+$/g, '')
								.trim();
						}
						function pushAttr(name, value) {
							let n = cleanupAttrToken(name);
							let v = cleanupAttrToken(value);
							if (!n && !v) return;
							if (n && !v && n.includes(':')) {
								const idx = n.indexOf(':');
								const left = cleanupAttrToken(n.slice(0, idx));
								const right = cleanupAttrToken(n.slice(idx + 1));
								if (left && right) {
									n = left;
									v = right;
								}
							}
							// Bazı DOM varyasyonlarında "MateryalSilikon : Materyal" gibi ters birleşik çift geliyor.
							if (n && v) {
								const nl = n.toLowerCase();
								const vl = v.toLowerCase();
								if (nl.startsWith(vl) && n.length > v.length) {
									const remainder = cleanupAttrToken(n.slice(v.length));
									if (remainder) {
										n = cleanupAttrToken(v);
										v = remainder;
									}
								}
							}
							if (v) {
								for (let i = 0; i < labelHints.length; i++) {
									const label = labelHints[i];
									if (!v.toLowerCase().startsWith(label.toLowerCase())) continue;
									const rest = cleanupAttrToken(v.slice(label.length));
									if (rest && rest.toLowerCase() !== label.toLowerCase()) {
										n = label;
										v = rest;
										break;
									}
								}
							}
							if (
								n &&
								v &&
								noiseAttrs.has(n.toLowerCase()) &&
								/detaylar[ıi]\s*g[oö]r/i.test(v.toLowerCase())
							) {
								return;
							}
							if (!n || !v || n === v) return;
							const split = splitConcatenatedChain(n, v);
							for (let i = 0; i < split.length; i++) {
								pushOneAttr(split[i].name, split[i].value);
							}
						}
						const scopedContainers = Array.from(
							document.querySelectorAll(
								'#product-attributes-ürün-özellikleri .attributes, [id^="product-attributes"] .attributes, #product-attributes-ürün-özellikleri, [id^="product-attributes"]',
							),
						);
						for (let c = 0; c < scopedContainers.length; c++) {
							const container = scopedContainers[c];
							const rows = Array.from(
								container.querySelectorAll(
									'li, .attribute, .attribute-item, .detail-attr-item, .product-property-item, .attribute-row, .ty-display-flex',
								),
							);
							for (let i = 0; i < rows.length; i++) {
								const row = rows[i];
								const name = pickFirstNonEmpty([
									row.querySelector('.attr-name, .property-name, .detail-attr-item-name, .attribute-name, dt, span:first-child')?.textContent,
								]);
								const value = pickFirstNonEmpty([
									row.querySelector('.attr-value, .property-value, .detail-attr-item-value, .attribute-value, dd, span:last-child')?.textContent,
								]);
								pushAttr(name, value);
							}
						}
						if (!attrs.length) {
							const attrRows = Array.from(
								document.querySelectorAll(
									'.product-detail-container .detail-attr-item, .product-detail-properties .product-property-item, .detail-attr-container li',
								),
							);
							for (let i = 0; i < attrRows.length; i++) {
								const row = attrRows[i];
								const name = pickFirstNonEmpty([
									row.querySelector('.attr-name, .property-name, .detail-attr-item-name, span:first-child')?.textContent,
									row.querySelector('dt')?.textContent,
								]);
								const value = pickFirstNonEmpty([
									row.querySelector('.attr-value, .property-value, .detail-attr-item-value, span:last-child')?.textContent,
									row.querySelector('dd')?.textContent,
								]);
								pushAttr(name, value);
							}
						}
						const imageUrl = normalizeImageUrl(
							pickFirstNonEmpty([
								document.querySelector('meta[property="og:image"]')?.getAttribute('content'),
								document.querySelector('img[src*="dsmcdn"], img[class*="product"]')?.getAttribute('src'),
							]),
						);
						const skuFromUrl = (() => {
							const m = String(location.href).match(/-p-(\d+)/i);
							return m ? m[1] : null;
						})();
						const brandFromTitle = title ? title.split(' ')[0] : null;
						return {
							url: location.href,
							sku: skuFromUrl,
							barcode: null,
							title,
							brand: brandFromTitle,
							price: normalizeTrendyolPrice(priceText, 'TRY'),
							currency: priceText && /TL|TRY/i.test(priceText) ? 'TRY' : null,
							availability: null,
							categoryPath: categoryPath.length ? categoryPath : null,
							imageUrl,
							attributes: attrs,
							rawProductJson: {
								schemaVersion: 'api-json-scraping-dom-fallback-1',
								source: 'dom-fallback',
								capturedAt: new Date().toISOString(),
							},
						};
					}
					function parseAmazonProductFromDom() {
						function cleanText(value) {
							return String(value || '').replace(/\s+/g, ' ').trim();
						}
						function pushAttr(attrs, seen, name, value) {
							const n = cleanText(name);
							const v = cleanText(value);
							if (!n || !v || n === v) return;
							const key = `${n}::${v}`;
							if (seen.has(key)) return;
							seen.add(key);
							attrs.push({ name: n, value: v });
						}
						function detectAvailabilitySchema(text) {
							const t = cleanText(text).toLowerCase();
							if (!t) return null;
							if (
								t.includes('stokta') ||
								t.includes('adet kaldı') ||
								t.includes('hemen kargoda') ||
								t.includes('ship')
							) {
								return 'https://schema.org/InStock';
							}
							if (
								t.includes('stokta yok') ||
								t.includes('tükendi') ||
								t.includes('currently unavailable') ||
								t.includes('out of stock')
							) {
								return 'https://schema.org/OutOfStock';
							}
							return null;
						}
						const title = cleanText(
							pickFirstNonEmpty([
								document.querySelector('#productTitle')?.textContent,
								document.querySelector('meta[name="title"]')?.getAttribute('content'),
								document.title,
							]),
						);
						if (!title) return null;
						const attrs = [];
						const seen = new Set();
						const detailRows = Array.from(
							document.querySelectorAll('#prodDetails table.prodDetTable tr, #productOverview_feature_div tr'),
						);
						for (let i = 0; i < detailRows.length; i++) {
							const row = detailRows[i];
							const name = row.querySelector('th, td:first-child')?.textContent || '';
							const value = row.querySelector('td.prodDetAttrValue, td:last-child')?.textContent || '';
							pushAttr(attrs, seen, name, value);
						}
						const asin = cleanText(
							pickFirstNonEmpty([
								document.querySelector('#ASIN')?.getAttribute('value'),
								document.querySelector('input[name="ASIN"]')?.getAttribute('value'),
								document.querySelector('input[name="asin"]')?.getAttribute('value'),
							]),
						);
						const brandText = cleanText(
							pickFirstNonEmpty([
								document.querySelector('#bylineInfo')?.textContent,
								document.querySelector('#brand')?.textContent,
							]),
						);
						const brand = brandText.replace(/^Marka:\s*/i, '').trim() || null;
						const priceText = pickFirstNonEmpty([
							document.querySelector('#corePrice_feature_div .a-price .a-offscreen')?.textContent,
							document.querySelector('.priceToPay .a-price-whole')?.textContent,
							document.querySelector('#price_inside_buybox')?.textContent,
						]);
						const hiddenPrice = numberOrNull(
							pickFirstNonEmpty([
								document.querySelector('#twister-plus-price-data-price')?.getAttribute('value'),
								document.querySelector('#priceValue')?.getAttribute('value'),
							]),
						);
						const availabilityText = pickFirstNonEmpty([
							document.querySelector('#availability .primary-availability-message')?.textContent,
							document.querySelector('#availability span')?.textContent,
						]);
						const breadcrumbNodes = Array.from(
							document.querySelectorAll('#wayfinding-breadcrumbs_feature_div a, #desktop-breadcrumbs_feature_div a'),
						);
						const categoryPath = breadcrumbNodes
							.map((a) => cleanText(a.textContent))
							.filter(Boolean);
						const imageUrl = normalizeImageUrl(
							pickFirstNonEmpty([
								document.querySelector('#landingImage')?.getAttribute('src'),
								document.querySelector('#imgTagWrapperId img')?.getAttribute('src'),
								document.querySelector('meta[property="og:image"]')?.getAttribute('content'),
								document.querySelector('#productImageUrl')?.getAttribute('value'),
							]),
						);
						return {
							url: pickFirstNonEmpty([
								document.querySelector('link[rel="canonical"]')?.getAttribute('href'),
								location.href,
							]),
							sku: asin || null,
							barcode: null,
							title,
							brand,
							price: hiddenPrice ?? numberOrNull(priceText),
							currency: pickFirstNonEmpty([
								document.querySelector('#currencyOfPreference')?.getAttribute('value'),
								/(\bTL\b|\bTRY\b)/i.test(String(priceText || '')) ? 'TRY' : null,
							]),
							availability: detectAvailabilitySchema(availabilityText),
							categoryPath: categoryPath.length ? categoryPath : null,
							imageUrl,
							attributes: attrs,
							rawProductJson: {
								schemaVersion: 'api-json-scraping-amazon-dom-1',
								source: 'amazon-prodDetails-dom',
								availabilityText: availabilityText || null,
							},
						};
					}
					const host = String(location.hostname || '').toLowerCase();
					if (host === 'www.hepsiburada.com' || host === 'hepsiburada.com') {
						const hbState = parseHepsiburadaStateProduct();
						if (hbState) {
							return {
								ok: true,
								item: {
									linkId: null,
									platform: 'hepsiburada',
									url: hbState.url,
									sku: hbState.sku,
									barcode: hbState.barcode,
									title: hbState.title,
									brand: hbState.brand,
									price: hbState.price,
									currency: hbState.currency,
									availability: hbState.availability,
									categoryPath: hbState.categoryPath,
									imageUrl: hbState.imageUrl,
									attributes: hbState.attributes,
									rawProductJson: {
										...hbState.rawProductJson,
										sourceUrl: location.href,
										scrapedAt: new Date().toISOString(),
									},
								},
							};
						}
					}
					const defaultPlatform =
						host === 'www.hepsiburada.com' || host === 'hepsiburada.com'
							? 'hepsiburada'
							: host === 'www.n11.com' || host === 'n11.com'
								? 'n11'
								: host === 'www.amazon.com.tr' || host === 'amazon.com.tr'
									? 'amazon'
									: 'trendyol';
					if (host === 'www.n11.com' || host === 'n11.com') {
						const n11State = parseN11StateProduct();
						if (n11State) {
							return {
								ok: true,
								item: {
									linkId: null,
									platform: 'n11',
									url: n11State.url,
									sku: n11State.sku,
									barcode: n11State.barcode,
									title: n11State.title,
									brand: n11State.brand,
									price: n11State.price,
									currency: n11State.currency,
									availability: n11State.availability,
									categoryPath: n11State.categoryPath,
									imageUrl: n11State.imageUrl,
									attributes: n11State.attributes,
									rawProductJson: {
										...n11State.rawProductJson,
										sourceUrl: location.href,
										scrapedAt: new Date().toISOString(),
									},
								},
							};
						}
					}
					if (host === 'www.amazon.com.tr' || host === 'amazon.com.tr') {
						const amzDom = parseAmazonProductFromDom();
						if (amzDom) {
							return {
								ok: true,
								item: {
									linkId: null,
									platform: 'amazon',
									url: amzDom.url,
									sku: amzDom.sku,
									barcode: amzDom.barcode,
									title: amzDom.title,
									brand: amzDom.brand,
									price: amzDom.price,
									currency: amzDom.currency,
									availability: amzDom.availability,
									categoryPath: amzDom.categoryPath,
									imageUrl: amzDom.imageUrl,
									attributes: amzDom.attributes,
									rawProductJson: {
										...amzDom.rawProductJson,
										sourceUrl: location.href,
										scrapedAt: new Date().toISOString(),
									},
								},
							};
						}
					}

					const nodes = parseJsonLdNodes();
					const flat = flattenJsonLdNodes(nodes);
					let product = null;
					let webPage = null;
					for (let i = 0; i < flat.length; i++) {
						const item = flat[i];
						if (!product && (hasType(item, 'product') || hasType(item, 'productgroup'))) product = item;
						if (!webPage && hasType(item, 'webpage')) webPage = item;
						if (product && webPage) break;
					}
					if (!product) {
						const fallback = parseNextDataProduct();
						if (fallback) {
							return {
								ok: true,
								item: {
									linkId: null,
									platform: defaultPlatform,
									url: fallback.url,
									sku: fallback.sku,
									barcode: fallback.barcode,
									title: fallback.title,
									brand: fallback.brand,
									price: fallback.price,
									currency: fallback.currency,
									availability: fallback.availability,
									categoryPath: fallback.categoryPath,
									imageUrl: fallback.imageUrl,
									attributes: fallback.attributes,
									rawProductJson: {
										...fallback.rawProductJson,
										sourceUrl: location.href,
										scrapedAt: new Date().toISOString(),
									},
								},
							};
						}
						const domFallback = parseDomFallbackProduct();
						if (domFallback) {
							return {
								ok: true,
								item: {
									linkId: null,
									platform: defaultPlatform,
									url: domFallback.url,
									sku: domFallback.sku,
									barcode: domFallback.barcode,
									title: domFallback.title,
									brand: domFallback.brand,
									price: domFallback.price,
									currency: domFallback.currency,
									availability: domFallback.availability,
									categoryPath: domFallback.categoryPath,
									imageUrl: domFallback.imageUrl,
									attributes: domFallback.attributes,
									rawProductJson: {
										...domFallback.rawProductJson,
										sourceUrl: location.href,
									},
								},
							};
						}
						return { ok: false, error: 'JSON-LD, __NEXT_DATA__ ve DOM fallback verisi bulunamadı.' };
					}
					const offers = product.offers && typeof product.offers === 'object' ? product.offers : {};
					const brand =
						typeof product.brand === 'string'
							? product.brand
							: typeof product.brand?.name === 'string'
								? product.brand.name
								: null;
					const skuFromUrl = (() => {
						const m = String(location.href).match(/-p-(\d+)/i);
						return m ? m[1] : null;
					})();
					const categoryPath =
						extractCategoryPathFromBreadcrumb(webPage?.breadcrumb) ||
						extractCategoryPathFromBreadcrumb(product?.breadcrumb);
					const envoyBarcode = extractBarcodeFromEnvoyProps();
					return {
						ok: true,
						item: {
							linkId: null,
							platform: defaultPlatform,
							url: pickFirstNonEmpty([product.url, product['@id'], webPage?.url, location.href]),
							sku: pickFirstNonEmpty([product.sku, skuFromUrl]),
							barcode: pickFirstNonEmpty([
								envoyBarcode,
								product.barcode,
								product.gtin13,
								product.gtin14,
								product.gtin,
								product.mpn,
							]),
							title: pickFirstNonEmpty([product.name, webPage?.name, document.title]),
							brand: pickFirstNonEmpty([brand]),
							price: normalizeTrendyolPrice(
								offers,
								pickFirstNonEmpty([offers.priceCurrency, 'TRY']),
							),
							currency: pickFirstNonEmpty([offers.priceCurrency, 'TRY']),
							availability: pickFirstNonEmpty([offers.availability]),
							categoryPath,
							imageUrl: normalizeImageUrl(
								pickFirstNonEmpty([
									product.image,
									webPage?.primaryImageOfPage,
									document.querySelector('meta[property="og:image"]')?.getAttribute('content'),
									document.querySelector('meta[name="twitter:image"]')?.getAttribute('content'),
									document.querySelector('img[src*="dsmcdn"]')?.getAttribute('src'),
								]),
							),
							attributes: normalizeAttributes(product.additionalProperty),
							rawProductJson: {
								schemaVersion: 'api-json-scraping-1',
								sourceUrl: location.href,
								scrapedAt: new Date().toISOString(),
								product,
								webPage: webPage || null,
							},
						},
					};
				},
			},
			(results) => {
				if (chrome.runtime.lastError) {
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				const payload = results && results[0] ? results[0].result : null;
				if (!payload || payload.ok !== true) {
					reject(new Error(payload?.error || 'Sekmeden veri okunamadı.'));
					return;
				}
				resolve(payload.item);
			},
		);
	});
}

function isTrendyolPdpUrl(url) {
	try {
		const u = new URL(url);
		const host = u.hostname.toLowerCase();
		if (!host.includes('trendyol.com')) return false;
		return /-p-\d+/i.test(u.pathname) && !/\/yorumlar\/?$/i.test(u.pathname);
	} catch {
		return false;
	}
}

function isTrendyolProductUrl(url) {
	try {
		const u = new URL(url);
		if (!u.hostname.toLowerCase().includes('trendyol.com')) return false;
		return /-p-\d+/i.test(u.pathname);
	} catch {
		return false;
	}
}

function trendyolContentIdFromUrl(url) {
	const m = String(url || '').match(/-p-(\d+)/i);
	return m ? m[1] : null;
}

/** @returns {'product_only'|'product_and_reviews'|'reviews_only'} */
function resolveScrapeMode(options) {
	const raw = options?.scrapeMode;
	if (raw === 'product_only' || raw === 'product_and_reviews' || raw === 'reviews_only') {
		return raw;
	}
	if (options?.skipReviews === true) return 'product_only';
	return 'product_and_reviews';
}

function resolveTabConcurrency(options) {
	const n = Number(options?.tabConcurrency);
	if (!Number.isFinite(n)) return 1;
	return Math.max(1, Math.min(10, Math.floor(n)));
}

function injectTrendyolAbbrevNumberInTab(tabId) {
	return new Promise((resolve, reject) => {
		chrome.scripting.executeScript(
			{ target: { tabId }, files: ['lib/trendyol-abbrev-number.js'] },
			() => {
				if (chrome.runtime.lastError) {
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				resolve();
			},
		);
	});
}

function executeFuncInTab(tabId, func, args) {
	return new Promise((resolve, reject) => {
		const details = { target: { tabId }, func };
		if (args != null) details.args = args;
		chrome.scripting.executeScript(details, (results) => {
			if (chrome.runtime.lastError) {
				reject(new Error(chrome.runtime.lastError.message));
				return;
			}
			resolve(results);
		});
	});
}

function getTabUrlSafe(tabId) {
	return new Promise((resolve) => {
		chrome.tabs.get(tabId, (tab) => {
			resolve(tab?.url && typeof tab.url === 'string' ? tab.url : null);
		});
	});
}

function resolveSellerStoreUrl(sources, merchantId, merchantName) {
	const ordered = Array.isArray(sources) ? sources : [];
	for (let i = 0; i < ordered.length; i++) {
		const raw = ordered[i];
		if (!raw || typeof raw !== 'string' || !raw.trim()) continue;
		const normalized = normalizeTrendyolStoreUrl(raw.trim(), merchantId, merchantName);
		if (normalized && !isGenericTrendyolMagazaUrl(normalized)) return normalized;
	}
	return normalizeTrendyolStoreUrl(null, merchantId, merchantName);
}

async function executeTrendyolSellerSrExtractInTab(tabId, merchantId) {
	await injectTrendyolAbbrevNumberInTab(tabId);
	return executeFuncInTab(
		tabId,
		(mid) => {
			function extractStoreUrlFromPage(merchantIdArg) {
				const id = String(merchantIdArg);
				const idSuffix = `-m-${id}`;
				const anchors = document.querySelectorAll('a[href*="/magaza/"]');
				for (let i = 0; i < anchors.length; i++) {
					const href = anchors[i].getAttribute('href') || '';
					if (!href.includes(idSuffix)) continue;
					try {
						const u = new URL(href, 'https://www.trendyol.com');
						if (/trendyol\.com/i.test(u.hostname) && u.pathname.includes('/magaza/')) {
							return (u.origin + u.pathname).replace(/\/$/, '');
						}
					} catch {
						/* ignore */
					}
				}
				const html = document.documentElement?.innerHTML || '';
				const escapedId = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
				const m = html.match(
					new RegExp('/magaza/[^"\\s<>]*' + escapedId + '(?:[/?#]|")', 'i'),
				);
				if (m) {
					return `https://www.trendyol.com${m[0].replace(/["/?#].*$/, '').replace(/\/$/, '')}`;
				}
				return null;
			}
			const parseAbbrev =
				typeof parseTrendyolAbbreviatedNumber === 'function'
					? parseTrendyolAbbreviatedNumber
					: (t) => {
							const n = Number(String(t).replace(/[^\d]/g, ''));
							return Number.isFinite(n) ? n : null;
						};
			const resultEl = document.querySelector('[data-testid="result-count-info"]');
			const rawProductCountText = resultEl ? String(resultEl.textContent || '').trim() : '';
			let platformProductCount = null;
			let platformProductCountMinimum = false;
			const productMatch = rawProductCountText.match(/([\d][\d.,]*\s*[BbMmKk]?)\s*\+?/i);
			if (productMatch) {
				platformProductCount = parseAbbrev(productMatch[1]);
				platformProductCountMinimum = rawProductCountText.includes('+');
			}
			return {
				platformProductCount,
				platformProductCountMinimum,
				rawProductCountText,
				storeUrl: extractStoreUrlFromPage(mid),
			};
		},
		[merchantId],
	);
}

async function executeTrendyolSellerMagazaFollowerExtractInTab(tabId) {
	await injectTrendyolAbbrevNumberInTab(tabId);
	return executeFuncInTab(tabId, () => {
		const parseAbbrev =
			typeof parseTrendyolAbbreviatedNumber === 'function'
				? parseTrendyolAbbreviatedNumber
				: (t) => {
						const n = Number(String(t).replace(/[^\d]/g, ''));
						return Number.isFinite(n) ? n : null;
					};
		const followEl =
			document.querySelector('[data-testid="follow-text"]') ||
			document.querySelector('.header-card__follow-wrapper__follow-text') ||
			document.querySelector('[class*="follow-wrapper"][class*="follow-text"]');
		let rawFollowerText = '';
		if (followEl) {
			const span = followEl.querySelector('span');
			rawFollowerText = span
				? String(span.textContent || '').trim()
				: String(followEl.textContent || '').trim();
			if (!/takipçi/i.test(rawFollowerText)) {
				rawFollowerText = String(followEl.textContent || '').trim();
			}
		}
		if (!rawFollowerText) {
			const bodyMatch = String(document.body?.innerText || '').match(
				/([\d][\d.,]*\s*[BbMmKk]?)\s*Takipçi/i,
			);
			if (bodyMatch) rawFollowerText = bodyMatch[1].trim();
		}
		let followerCount = null;
		if (rawFollowerText) {
			followerCount = parseAbbrev(rawFollowerText);
		}
		return { followerCount, rawFollowerText };
	});
}

async function scrapeTrendyolSellerProfileEntry(entry) {
	const merchantId = Number(entry?.merchantId);
	if (!Number.isFinite(merchantId) || merchantId <= 0) {
		throw new Error('Geçersiz satıcı kimliği.');
	}
	const merchantName = typeof entry?.name === 'string' ? entry.name.trim() : '';
	const srUrl =
		typeof entry?.srUrl === 'string' && entry.srUrl.trim()
			? entry.srUrl.trim()
			: buildTrendyolSellerSearchUrl(merchantId);
	let storeUrl = resolveSellerStoreUrl(
		[entry?.storeUrl],
		merchantId,
		merchantName,
	);
	let platformProductCount = null;
	let platformProductCountMinimum = false;
	let followerCount = null;
	let rawProductCountText = '';
	let rawFollowerText = '';
	let storeUrlFromSr = null;
	let storeUrlFromMagaza = null;

	const srTabId = await withTabRetry(() => createInactiveTab(srUrl), {
		maxAttempts: 6,
		baseDelayMs: 120,
	});
	try {
		await waitForTabComplete(srTabId, 35000);
		await sleep(2200);
		const srResults = await withTabRetry(
			() => executeTrendyolSellerSrExtractInTab(srTabId, merchantId),
			{
				maxAttempts: 4,
				baseDelayMs: 200,
			},
		);
		const srExtracted = srResults?.[0]?.result;
		if (srExtracted && typeof srExtracted === 'object') {
			platformProductCount = srExtracted.platformProductCount ?? null;
			platformProductCountMinimum = Boolean(srExtracted.platformProductCountMinimum);
			rawProductCountText = srExtracted.rawProductCountText || '';
			if (srExtracted.storeUrl) storeUrlFromSr = srExtracted.storeUrl;
		}
	} finally {
		await withTabRetry(() => closeTabSafe(srTabId), {
			maxAttempts: 6,
			baseDelayMs: 120,
		}).catch(() => {});
	}

	storeUrl = resolveSellerStoreUrl(
		[storeUrlFromSr, entry?.storeUrl, storeUrl],
		merchantId,
		merchantName,
	);

	const magazaTabId = await withTabRetry(() => createInactiveTab(storeUrl), {
		maxAttempts: 6,
		baseDelayMs: 120,
	});
	try {
		await waitForTabComplete(magazaTabId, 35000);
		await sleep(2800);
		storeUrlFromMagaza = await getTabUrlSafe(magazaTabId);
		const magazaResults = await withTabRetry(
			() => executeTrendyolSellerMagazaFollowerExtractInTab(magazaTabId),
			{ maxAttempts: 5, baseDelayMs: 250 },
		);
		const magazaExtracted = magazaResults?.[0]?.result;
		if (magazaExtracted && typeof magazaExtracted === 'object') {
			followerCount = magazaExtracted.followerCount ?? null;
			rawFollowerText = magazaExtracted.rawFollowerText || '';
		}
	} finally {
		await withTabRetry(() => closeTabSafe(magazaTabId), {
			maxAttempts: 6,
			baseDelayMs: 120,
		}).catch(() => {});
	}

	storeUrl = resolveSellerStoreUrl(
		[storeUrlFromMagaza, storeUrlFromSr, entry?.storeUrl],
		merchantId,
		merchantName,
	);

	const extracted = {
		platformProductCount,
		platformProductCountMinimum,
		followerCount,
		rawProductCountText,
		rawFollowerText,
	};

	if (extracted.followerCount == null && extracted.platformProductCount == null) {
		throw new Error(
			'Takipçi veya ürün sayısı bulunamadı. Trendyol’da oturum açık mı, mağaza ve arama sayfası yüklendi mi kontrol edin.',
		);
	}

	const merchant = {
		id: merchantId,
		storeUrl,
		followerCount: extracted.followerCount,
		platformProductCount: extracted.platformProductCount,
		platformProductCountMinimum: Boolean(extracted.platformProductCountMinimum),
		sellerProfileCrawledAt: new Date().toISOString(),
		sellerProfileSource: 'trendyol-sr+magaza',
	};
	return {
		merchantId,
		storeUrl,
		srUrl,
		extracted,
		merchant,
	};
}

async function patchSellerProfileToApi(merchantId, merchant) {
	const res = await fetch(panelApiUrl('/scraped-products/merchants/profile'), {
		method: 'PATCH',
		headers: { 'Content-Type': 'application/json' },
		body: JSON.stringify({ merchantId, merchant }),
	});
	const data = await res.json().catch(() => ({}));
	if (!res.ok || !data.ok) {
		throw new Error(data.error || `Profil kaydedilemedi (HTTP ${res.status})`);
	}
	return data;
}

async function scrapeOneSellerProfileEntry(entry) {
	try {
		const scraped = await scrapeTrendyolSellerProfileEntry(entry);
		const save = await patchSellerProfileToApi(scraped.merchantId, scraped.merchant);
		return {
			ok: true,
			merchantId: scraped.merchantId,
			name: entry?.name || null,
			storeUrl: scraped.storeUrl,
			extracted: scraped.extracted,
			save,
		};
	} catch (err) {
		return {
			ok: false,
			merchantId: entry?.merchantId ?? null,
			name: entry?.name || null,
			storeUrl: entry?.storeUrl || null,
			error: err && err.message ? err.message : String(err),
		};
	}
}

async function scrapeSellerProfileEntriesWithConcurrency(entries, options) {
	const list = Array.isArray(entries) ? entries : [];
	const concurrency = resolveTabConcurrency(options);
	const delayMsRaw = Number(options?.delayMs);
	const delayMs =
		Number.isFinite(delayMsRaw) && delayMsRaw >= 0
			? Math.min(5000, Math.floor(delayMsRaw))
			: 0;
	const total = list.length;
	const results = new Array(total);
	if (total === 0) return results;

	if (concurrency <= 1) {
		for (let i = 0; i < total; i++) {
			results[i] = await scrapeOneSellerProfileEntry(list[i]);
			if (i < total - 1 && delayMs > 0) await sleep(delayMs);
		}
		return results;
	}

	let nextIndex = 0;
	async function worker() {
		while (true) {
			const i = nextIndex++;
			if (i >= total) break;
			results[i] = await scrapeOneSellerProfileEntry(list[i]);
		}
	}
	await Promise.all(Array.from({ length: Math.min(concurrency, total) }, () => worker()));
	return results;
}

async function scrapeOneQueueEntry(row, scrapeOptions, progressIndex, progressTotal) {
	const linkIdRaw = row.linkId != null ? Number(row.linkId) : null;
	const linkId = Number.isFinite(linkIdRaw) ? linkIdRaw : null;
	const scrapedProductId = String(row.scrapedProductId || row.productId || '').trim() || null;
	const contentId =
		row.contentId != null && String(row.contentId).trim() ? String(row.contentId).trim() : null;
	const url = typeof row.url === 'string' ? row.url.trim() : '';
	const scrapeMode = resolveScrapeMode(scrapeOptions);
	if (!url) {
		return { ok: false, url, error: 'Geçersiz URL.' };
	}
	if (scrapeMode === 'reviews_only') {
		if (!scrapedProductId) {
			return { ok: false, url, error: 'Ürün kimliği (productId) gerekli.' };
		}
	} else if (!Number.isFinite(linkId)) {
		return { ok: false, url, error: 'Geçersiz link kaydı.' };
	}
	await sleep(90);
	try {
		const merchantIdRaw = row.merchantId ?? row.merchant_id;
		const merchantId =
			merchantIdRaw != null && Number.isFinite(Number(merchantIdRaw))
				? Math.trunc(Number(merchantIdRaw))
				: null;
		return await scrapeProductPdpViaTab(
			{
				linkId,
				scrapedProductId,
				contentId,
				merchantId,
				url,
				platform: String(row.platform || '').trim().toLowerCase() || null,
			},
			{
				...scrapeOptions,
				progress: {
					index: progressIndex,
					total: progressTotal,
					url,
				},
			},
		);
	} catch (err) {
		return {
			ok: false,
			url,
			error: err && err.message ? err.message : 'Sekme scrape hatası',
		};
	}
}

async function scrapeQueueEntriesWithConcurrency(links, scrapeOptions) {
	const concurrency = resolveTabConcurrency(scrapeOptions);
	const total = links.length;
	const results = new Array(total);
	if (total === 0) return results;
	if (concurrency <= 1) {
		for (let i = 0; i < total; i++) {
			results[i] = await scrapeOneQueueEntry(links[i], scrapeOptions, i + 1, total);
		}
		return results;
	}
	let nextIndex = 0;
	async function worker() {
		while (true) {
			const i = nextIndex++;
			if (i >= total) break;
			results[i] = await scrapeOneQueueEntry(links[i], scrapeOptions, i + 1, total);
		}
	}
	await Promise.all(Array.from({ length: Math.min(concurrency, total) }, () => worker()));
	return results;
}

function resolveTrendyolPdpUrl(url, entry) {
	return normalizeTrendyolPdpUrl(url, {
		merchantId: entry?.merchantId ?? entry?.merchant?.id,
		boutiqueId: entry?.boutiqueId,
	});
}

function buildTrendyolReviewsUrl(pdpUrl, entry) {
	const u = new URL(resolveTrendyolPdpUrl(pdpUrl, entry));
	if (!/\/yorumlar\/?$/i.test(u.pathname)) {
		u.pathname = `${u.pathname.replace(/\/$/, '')}/yorumlar`;
	}
	const merchantIdRaw =
		entry?.merchantId ??
		entry?.merchant?.id ??
		(u.searchParams.get('merchantId') || null);
	const boutiqueIdRaw = entry?.boutiqueId ?? u.searchParams.get('boutiqueId') ?? null;
	if (merchantIdRaw != null && String(merchantIdRaw).trim() && !u.searchParams.has('merchantId')) {
		u.searchParams.set('merchantId', String(merchantIdRaw).trim());
	}
	if (boutiqueIdRaw != null && String(boutiqueIdRaw).trim() && !u.searchParams.has('boutiqueId')) {
		u.searchParams.set('boutiqueId', String(boutiqueIdRaw).trim());
	}
	return u.href;
}

function mergeTrendyolMerchants(primary, secondary) {
	if (!primary && !secondary) return null;
	if (!primary) return secondary;
	if (!secondary) return primary;
	return {
		...primary,
		...secondary,
		sellerScore: secondary.sellerScore || primary.sellerScore,
		followerCount: secondary.followerCount ?? primary.followerCount,
		storeUrl: secondary.storeUrl || primary.storeUrl,
	};
}

function mergeTrendyolRatingSummary(primary, secondary) {
	if (!primary && !secondary) return null;
	if (!primary) return secondary;
	if (!secondary) return primary;
	return {
		...primary,
		...secondary,
		averageRating: secondary.averageRating ?? primary.averageRating,
		ratingValue: secondary.ratingValue ?? primary.ratingValue,
		commentCount: secondary.commentCount ?? primary.commentCount,
		reviewCount: secondary.reviewCount ?? primary.reviewCount,
		totalCount: secondary.totalCount ?? primary.totalCount,
		ratingCount: secondary.ratingCount ?? primary.ratingCount,
		hasReview: secondary.hasReview ?? primary.hasReview,
	};
}

async function tabHasNoReviewsEmptyState(tabId) {
	try {
		const results = await chrome.scripting.executeScript({
			target: { tabId },
			world: 'MAIN',
			func: () => {
				const root =
					document.querySelector('.review-list') ||
					document.querySelector('[class*="review-list"]');
				if (root && root.querySelectorAll('[class*="review"]').length > 0) return false;
				const html = document.documentElement?.innerHTML || '';
				if (
					/"commentCount"\s*:\s*[1-9]\d*/.test(html) &&
					/"reviewId"\s*:\s*\d+/.test(html)
				) {
					return false;
				}
				const el =
					document.querySelector('.no-reviews-found') ||
					document.querySelector('[class*="no-reviews-found"]');
				if (!el) {
					if (!/no-reviews-found/i.test(html)) return false;
					return /henüz yorum|yorum yazılmamış|yorum yazilmamis/i.test(html);
				}
				const text = (el.textContent || '').trim().toLowerCase();
				if (!text) return true;
				return (
					text.includes('henüz yorum') ||
					text.includes('yorum yazılmamış') ||
					text.includes('yorum yazilmamis') ||
					text.includes('no review')
				);
			},
		});
		return results && results[0] ? results[0].result === true : false;
	} catch {
		return false;
	}
}

async function executeTrendyolExtractInTab(tabId, options) {
	await chrome.scripting.executeScript({
		target: { tabId },
		world: 'MAIN',
		files: ['lib/trendyol-price.js', 'lib/trendyol-abbrev-number.js', 'lib/trendyol-page-extract.js'],
	});
	const results = await chrome.scripting.executeScript({
		target: { tabId },
		world: 'MAIN',
		func: async (opts) => {
			if (typeof window.__ahtapotExtractTrendyol !== 'function') {
				return { ok: false, error: 'Trendyol extract yüklenemedi.' };
			}
			return await window.__ahtapotExtractTrendyol(opts);
		},
		args: [options || {}],
	});
	const payload = results && results[0] ? results[0].result : null;
	if (!payload || payload.ok !== true) {
		throw new Error(payload?.error || 'Trendyol veri çıkarılamadı.');
	}
	return payload;
}

async function scrapeTrendyolReviewsOnlyViaTab(entry, options) {
	const prog = options?.progress && typeof options.progress === 'object' ? options.progress : {};
	const report = (phase, message) =>
		emitScrapeProgress({
			phase,
			message,
			url: entry.url || prog.url || '',
			index: prog.index ?? null,
			total: prog.total ?? null,
		});
	let pdpUrl = resolveTrendyolPdpUrl(entry.url, entry);
	try {
		const u = new URL(pdpUrl);
		if (/\/yorumlar\/?$/i.test(u.pathname)) {
			u.pathname = u.pathname.replace(/\/yorumlar\/?$/i, '');
			pdpUrl = u.href;
		}
	} catch {
		/* keep normalized */
	}
	const reviewsUrl = buildTrendyolReviewsUrl(pdpUrl, entry);
	const entryContentId =
		entry.contentId != null && String(entry.contentId).trim() ? String(entry.contentId).trim() : null;
	const urlContentId =
		trendyolContentIdFromUrl(entry.url) || trendyolContentIdFromUrl(pdpUrl) || null;
	// URL'deki -p-{id} her zaman öncelikli (DB'deki hatalı content_id yorum API'sini bozabilir)
	let contentId = urlContentId || entryContentId;
	const merchantId =
		entry.merchantId != null && Number.isFinite(Number(entry.merchantId))
			? Math.trunc(Number(entry.merchantId))
			: null;
	let revTabId = null;
	report('reviews_open', 'Yorumlar sayfası açılıyor…');
	revTabId = await withTabRetry(() => createInactiveTab(reviewsUrl), {
		maxAttempts: 6,
		baseDelayMs: 120,
	});
	try {
		report('reviews_load', 'Yorumlar sayfası yükleniyor…');
		await waitForTabComplete(revTabId, 32000);
		await sleep(900);
		const noReviewsOnPage = await tabHasNoReviewsEmptyState(revTabId);
		if (!noReviewsOnPage) await sleep(3600);
		if (!contentId) {
			if (noReviewsOnPage) {
				contentId = trendyolContentIdFromUrl(reviewsUrl) || null;
			} else {
				report('reviews_id', 'Ürün kimliği okunuyor…');
				const idProbe = await withTabRetry(
					() =>
						executeTrendyolExtractInTab(revTabId, {
							mode: 'reviews',
							fetchReviewsApi: false,
							reviewsWaitMs: 8000,
							reviewsPollMs: 400,
							merchantId,
						}),
					{ maxAttempts: 2, baseDelayMs: 150 },
				).catch(() => null);
				contentId = idProbe?.contentId || trendyolContentIdFromUrl(reviewsUrl) || null;
			}
		}
		report(
			noReviewsOnPage ? 'reviews_none' : 'reviews_extract',
			noReviewsOnPage ? 'Henüz yorum yok' : 'Yorumlar ve AI özeti çekiliyor…',
		);
		startReviewProgressPoll(revTabId, {
			url: entry.url || prog.url || '',
			index: prog.index ?? null,
			total: prog.total ?? null,
		});
		let rev;
		try {
			rev = await withTabRetry(
				() =>
					executeTrendyolExtractInTab(revTabId, {
						mode: 'reviews',
						contentId,
						merchantId,
						fetchReviewsApi: !noReviewsOnPage,
						fetchFollowerApi: !noReviewsOnPage,
						fetchStoreApi: !noReviewsOnPage,
						skipAiSummary: noReviewsOnPage,
						reviewsWaitMs: noReviewsOnPage ? 2000 : 16000,
						reviewsPollMs: noReviewsOnPage ? 200 : 400,
						pageSize: 20,
						maxPages: 500,
						pageDelayMs: 150,
					}),
				{ maxAttempts: 3, baseDelayMs: 200 },
			);
		} finally {
			stopReviewProgressPoll();
		}
		const resolvedContentId = contentId || rev.contentId || null;
		const merchant = rev.merchant || null;
		report('done', noReviewsOnPage ? 'Yorum yok (kontrol edildi)' : 'Yorumlar alındı');
		return {
			ok: true,
			item: {
				scrapedProductId: entry.scrapedProductId || null,
				linkId: entry.linkId,
				platform: 'trendyol',
				contentId: resolvedContentId,
				url: pdpUrl,
				sku: resolvedContentId,
				title: null,
				brand: null,
				price: null,
				currency: null,
				availability: null,
				categoryPath: null,
				imageUrl: null,
				attributes: null,
				merchant,
				merchantId: merchant?.id ?? null,
				merchantName: merchant?.name ?? null,
				ratingSummary: rev.ratingSummary || null,
				aiReviewSummary: rev.aiReviewSummary || null,
				reviews: rev.reviews || [],
				rawProductJson: {
					schemaVersion: 'trendyol-reviews-only-1',
					scrapedAt: new Date().toISOString(),
					sourceUrl: pdpUrl,
					reviewsUrl,
					reviewsOnly: true,
					reviewsMeta: rev.reviewsMeta || null,
					reviewsPage: rev,
				},
			},
		};
	} finally {
		stopReviewProgressPoll();
		if (revTabId != null) {
			await withTabRetry(() => closeTabSafe(revTabId), {
				maxAttempts: 6,
				baseDelayMs: 120,
			}).catch(() => {});
		}
	}
}

async function scrapeTrendyolProductViaTab(entry, options) {
	const scrapeMode = resolveScrapeMode(options);
	if (scrapeMode === 'reviews_only') {
		return scrapeTrendyolReviewsOnlyViaTab(entry, options);
	}
	const skipReviews = scrapeMode === 'product_only';
	const prog = options?.progress && typeof options.progress === 'object' ? options.progress : {};
	const report = (phase, message) =>
		emitScrapeProgress({
			phase,
			message,
			url: entry.url || prog.url || '',
			index: prog.index ?? null,
			total: prog.total ?? null,
		});
	const pdpUrl = resolveTrendyolPdpUrl(entry.url, entry);
	let reviewsUrl = buildTrendyolReviewsUrl(pdpUrl, entry);
	report('pdp_open', 'Ürün sayfası açılıyor…');
	const pdpTabId = await withTabRetry(() => createInactiveTab(pdpUrl), {
		maxAttempts: 6,
		baseDelayMs: 120,
	});
	let revTabId = null;
	startPdpProgressPoll(pdpTabId, prog);
	try {
		report('pdp_load', 'Ürün sayfası yükleniyor…');
		await waitForTabComplete(pdpTabId, 28000);
		report('pdp_wait', 'Ürün sayfası hazırlanıyor…');
		await sleep(skipReviews ? 1500 : 2500);
		report('pdp_extract', 'Ürün verisi çıkarılıyor…');
		const extractOpts = {
			mode: 'pdp',
			skipReviews,
			fetchFollowerApi: !skipReviews,
			fetchStoreApi: !skipReviews,
			pdpWaitMs: skipReviews ? 10000 : 15000,
			pdpPollMs: 400,
		};
		let pdp = await withTabRetry(
			() => executeTrendyolExtractInTab(pdpTabId, extractOpts),
			{ maxAttempts: 4, baseDelayMs: 150 },
		);
		const needsRetry =
			!pdp?.product?.price ||
			!(pdp?.merchant?.name || pdp?.product?.merchant?.name);
		if (needsRetry) {
			report('pdp_retry', 'Fiyat/satıcı eksik — sayfa yeniden okunuyor…');
			await sleep(skipReviews ? 1500 : 3000);
			pdp = await withTabRetry(
				() =>
					executeTrendyolExtractInTab(pdpTabId, {
						...extractOpts,
						pdpWaitMs: skipReviews ? 12000 : 18000,
					}),
				{ maxAttempts: skipReviews ? 1 : 2, baseDelayMs: 200 },
			);
		}
		const product = pdp.product || {};
		const merchant = pdp.merchant || product.merchant || null;
		const contentId = pdp.contentId || product.contentId || null;
		const savedPdpUrl = (merchantId) =>
			resolveTrendyolPdpUrl(product.url || pdpUrl, {
				merchantId: merchantId ?? merchant?.id ?? entry.merchantId,
				boutiqueId: entry.boutiqueId,
			});

		if (skipReviews) {
			report('pdp_done', 'Ürün verisi alındı');
			const ratingSummary = pdp.ratingSummary || product.ratingSummary || null;
			return {
				ok: true,
				item: {
					linkId: entry.linkId,
					platform: 'trendyol',
					contentId,
					url: savedPdpUrl(),
					sku: product.sku || contentId,
					barcode: product.barcode,
					title: product.title,
					brand: product.brand,
					price: product.price,
					currency: product.currency,
					availability: product.availability,
					categoryPath: product.categoryPath,
					imageUrl: product.imageUrl,
					attributes: product.attributes,
					merchant,
					merchantId: merchant?.id ?? null,
					merchantName: merchant?.name ?? null,
					ratingSummary,
					aiReviewSummary: null,
					reviews: [],
					rawProductJson: {
						schemaVersion: 'trendyol-pdp-auto-1',
						scrapedAt: new Date().toISOString(),
						sourceUrl: pdpUrl,
						skipReviews: true,
						pdp,
					},
				},
			};
		}

		reviewsUrl = buildTrendyolReviewsUrl(pdpUrl, {
			...entry,
			merchantId: merchant?.id ?? entry.merchantId,
			merchant,
		});
		report('reviews_open', 'Yorumlar sayfası açılıyor…');
		revTabId = await withTabRetry(() => createInactiveTab(reviewsUrl), {
			maxAttempts: 6,
			baseDelayMs: 120,
		});
		report('reviews_load', 'Yorumlar sayfası yükleniyor…');
		await waitForTabComplete(revTabId, 32000);
		await sleep(900);
		const noReviewsOnPage = await tabHasNoReviewsEmptyState(revTabId);
		if (!noReviewsOnPage) await sleep(3600);
		const reviewMerchantId =
			merchant?.id != null && Number.isFinite(Number(merchant.id))
				? Math.trunc(Number(merchant.id))
				: entry.merchantId != null && Number.isFinite(Number(entry.merchantId))
					? Math.trunc(Number(entry.merchantId))
					: null;
		report(
			noReviewsOnPage ? 'reviews_none' : 'reviews_extract',
			noReviewsOnPage ? 'Henüz yorum yok' : 'Yorumlar ve AI özeti çekiliyor…',
		);
		startReviewProgressPoll(revTabId, {
			url: entry.url || prog.url || '',
			index: prog.index ?? null,
			total: prog.total ?? null,
		});
		let rev;
		try {
			rev = await withTabRetry(
				() =>
					executeTrendyolExtractInTab(revTabId, {
						mode: 'reviews',
						contentId: pdp.contentId || product.contentId,
						merchantId: reviewMerchantId,
						fetchReviewsApi: !noReviewsOnPage,
						fetchFollowerApi: !noReviewsOnPage,
						fetchStoreApi: !noReviewsOnPage,
						skipAiSummary: noReviewsOnPage,
						reviewsWaitMs: noReviewsOnPage ? 2000 : 16000,
						reviewsPollMs: noReviewsOnPage ? 200 : 400,
						pageSize: 20,
						maxPages: 500,
						pageDelayMs: 150,
					}),
				{ maxAttempts: 3, baseDelayMs: 200 },
			);
		} finally {
			stopReviewProgressPoll();
		}

		const mergedMerchant = mergeTrendyolMerchants(merchant, rev.merchant);
		const mergedRating = mergeTrendyolRatingSummary(
			pdp.ratingSummary || product.ratingSummary,
			rev.ratingSummary,
		);
		const resolvedContentId = contentId || rev.contentId || null;
		const item = {
			linkId: entry.linkId,
			platform: 'trendyol',
			contentId: resolvedContentId,
			url: savedPdpUrl(mergedMerchant?.id),
			sku: product.sku || resolvedContentId,
			barcode: product.barcode,
			title: product.title,
			brand: product.brand,
			price: product.price,
			currency: product.currency,
			availability: product.availability,
			categoryPath: product.categoryPath,
			imageUrl: product.imageUrl,
			attributes: product.attributes,
			merchant: mergedMerchant,
			merchantId: mergedMerchant?.id ?? null,
			merchantName: mergedMerchant?.name ?? null,
			ratingSummary: mergedRating,
			aiReviewSummary: rev.aiReviewSummary || null,
			reviews: rev.reviews || [],
			rawProductJson: {
				schemaVersion: 'trendyol-full-1',
				scrapedAt: new Date().toISOString(),
				sourceUrl: pdpUrl,
				reviewsUrl,
				reviewsMeta: rev.reviewsMeta || null,
				pdp,
				reviewsPage: rev,
			},
		};
		report('done', 'Tüm veriler alındı');
		return { ok: true, item };
	} finally {
		stopPdpProgressPoll();
		stopReviewProgressPoll();
		if (revTabId != null) {
			await withTabRetry(() => closeTabSafe(revTabId), {
				maxAttempts: 6,
				baseDelayMs: 120,
			}).catch(() => {});
		}
		await withTabRetry(() => closeTabSafe(pdpTabId), {
			maxAttempts: 6,
			baseDelayMs: 120,
		}).catch(() => {});
	}
}

async function scrapeProductPdpViaTab(entry, options) {
	const scrapeMode = resolveScrapeMode(options);
	if (scrapeMode === 'reviews_only') {
		if (!isTrendyolProductUrl(entry.url)) {
			throw new Error('Sadece yorum modu şu an yalnızca Trendyol ürün linkleri için desteklenir.');
		}
		return scrapeTrendyolReviewsOnlyViaTab(entry, options);
	}
	if (isTrendyolPdpUrl(entry.url) || isTrendyolProductUrl(entry.url)) {
		return scrapeTrendyolProductViaTab(entry, options);
	}
	const prog = options?.progress && typeof options.progress === 'object' ? options.progress : {};
	const report = (phase, message) =>
		emitScrapeProgress({
			phase,
			message,
			url: entry.url || prog.url || '',
			index: prog.index ?? null,
			total: prog.total ?? null,
		});
	report('page_open', 'Ürün sayfası açılıyor…');
	const tabId = await withTabRetry(() => createInactiveTab(entry.url), {
		maxAttempts: 6,
		baseDelayMs: 120,
	});
	try {
		report('page_load', 'Sayfa yükleniyor…');
		await waitForTabComplete(tabId, 25000);
		report('page_extract', 'Ürün verisi çıkarılıyor…');
		const item = await withTabRetry(() => executeExtractInTab(tabId), {
			maxAttempts: 4,
			baseDelayMs: 120,
		});
		return {
			ok: true,
			item: {
				...item,
				linkId: entry.linkId,
				platform: String(entry.platform || item.platform || '').trim().toLowerCase() || 'trendyol',
			},
		};
	} finally {
		await withTabRetry(() => closeTabSafe(tabId), {
			maxAttempts: 6,
			baseDelayMs: 120,
		}).catch(() => {
			/* ignore close errors */
		});
	}
}

function isAkakceHost(hostname) {
	const h = String(hostname || '')
		.toLowerCase()
		.replace(/^www\./, '');
	return h === 'akakce.com' || h.endsWith('.akakce.com');
}

function isAkakceProductUrl(url) {
	return /akakce\.com/i.test(String(url || '')) && /,\d+\.html/i.test(String(url || ''));
}

function detectDestinationPlatformFromUrl(urlString) {
	try {
		const host = new URL(urlString).hostname.replace(/^www\./i, '').toLowerCase();
		if (host === 'trendyol.com' || host.endsWith('.trendyol.com') || host.endsWith('.trendyol.com.tr')) {
			return 'trendyol';
		}
		if (host === 'n11.com' || host.endsWith('.n11.com')) return 'n11';
		if (host === 'hepsiburada.com' || host.endsWith('.hepsiburada.com')) return 'hepsiburada';
		if (host === 'amazon.com.tr' || host.endsWith('.amazon.com.tr')) return 'amazon';
		if (host === 'idefix.com' || host.endsWith('.idefix.com')) return 'idefix';
		if (host === 'pazarama.com' || host.endsWith('.pazarama.com')) return 'pazarama';
		if (host === 'pttavm.com' || host.endsWith('.pttavm.com')) return 'pttavm';
		return 'other';
	} catch {
		return 'other';
	}
}

function detectPlatformFromShopName(shopName) {
	const n = String(shopName || '').toLowerCase();
	if (!n) return null;
	if (n.includes('trendyol')) return 'trendyol';
	if (n.includes('hepsiburada') || n.includes('hepsi burada')) return 'hepsiburada';
	if (n.includes('n11')) return 'n11';
	if (n.includes('amazon')) return 'amazon';
	if (n.includes('idefix')) return 'idefix';
	if (n.includes('pazarama')) return 'pazarama';
	if (n.includes('pttavm') || n.includes('ptt avm')) return 'pttavm';
	return null;
}

/** Akakçe scrape — yalnızca n11, Trendyol, Hepsiburada hedef linkleri çözülür. */
const AKAKCE_TARGET_PLATFORMS = new Set(['n11', 'trendyol', 'hepsiburada']);

function akakcePlatformFromOffer(offer) {
	const fromShop =
		detectPlatformFromShopName(offer?.shopName) || detectPlatformFromShopName(offer?.shopLabel);
	if (fromShop && AKAKCE_TARGET_PLATFORMS.has(fromShop)) return fromShop;
	return null;
}

function isAkakceTargetOffer(offer) {
	if (!offer) return false;
	if (offer.platform && AKAKCE_TARGET_PLATFORMS.has(offer.platform)) return true;
	return akakcePlatformFromOffer(offer) != null;
}

function finalizeAkakceScrapedOfferPlatform(offer) {
	let platform =
		offer.platform && AKAKCE_TARGET_PLATFORMS.has(offer.platform)
			? offer.platform
			: akakcePlatformFromOffer(offer);
	if (!platform && offer.destinationUrl) {
		const fromUrl = detectDestinationPlatformFromUrl(offer.destinationUrl);
		if (AKAKCE_TARGET_PLATFORMS.has(fromUrl)) platform = fromUrl;
	}
	return platform && AKAKCE_TARGET_PLATFORMS.has(platform) ? platform : null;
}

function akakceRedirectHostHint(offer) {
	const platform = akakcePlatformFromOffer(offer);
	if (platform === 'n11') return 'n11.com';
	if (platform === 'pttavm') return 'pttavm.com';
	if (platform === 'trendyol') return 'trendyol.com';
	if (platform === 'hepsiburada') return 'hepsiburada.com';
	if (platform === 'amazon') return 'amazon.com.tr';
	if (platform === 'idefix') return 'idefix.com';
	if (platform === 'pazarama') return 'pazarama.com';
	return '';
}

/** Kayıt öncesi hedef URL — utm_* ve hash temizlenir */
function sanitizeDestinationUrl(urlString) {
	const raw = String(urlString || '').trim();
	if (!raw || /akakce\.com/i.test(raw)) return null;
	try {
		const u = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
		if (isAkakceHost(u.hostname)) return null;
		u.hash = '';
		u.hostname = u.hostname.toLowerCase();
		if (u.pathname.length > 1) u.pathname = u.pathname.replace(/\/+$/, '');
		const params = [...u.searchParams.entries()].filter(
			([key]) => !key.toLowerCase().startsWith('utm_'),
		);
		u.search = '';
		for (const [key, val] of params) u.searchParams.append(key, val);
		return u.href;
	} catch {
		return null;
	}
}

/** MV3 service worker uzun taramada uyumasın */
function startScrapeKeepAlive() {
	const tick = () => {
		try {
			chrome.runtime.getPlatformInfo(() => {});
		} catch {
			/* ignore */
		}
	};
	tick();
	return setInterval(tick, 20000);
}

function enrichAkakceOfferParams(params) {
	const f = params.get('f');
	if (!f) return;
	try {
		const decoded = decodeURIComponent(f);
		const qi = decoded.indexOf('?');
		if (qi < 0) return;
		const fp = new URLSearchParams(decoded.slice(qi + 1));
		if (!params.has('v') && fp.get('vd')) params.set('v', fp.get('vd'));
		if (!params.has('p') && fp.get('pr')) params.set('p', fp.get('pr'));
		if (!params.has('g') && fp.get('pg')) params.set('g', fp.get('pg'));
	} catch {
		/* ignore */
	}
}

function canonicalizeAkakceOfferUrl(offerUrl) {
	try {
		const u = new URL(String(offerUrl || '').trim());
		if (!isAkakceHost(u.hostname)) return null;
		const path = (u.pathname || '/').replace(/\/+$/, '') || '/';
		if (path !== '/c') return null;
		const params = new URLSearchParams(u.search);
		enrichAkakceOfferParams(params);
		if (!params.get('v') || !params.get('p')) return null;
		const sorted = new URLSearchParams();
		[...params.entries()]
			.sort(([a], [b]) => a.localeCompare(b))
			.forEach(([key, val]) => sorted.append(key, val));
		return `https://www.akakce.com/c/?${sorted.toString()}`;
	} catch {
		return null;
	}
}

function akakceIntermediateRedirectUrl(offerUrl) {
	try {
		const canon = canonicalizeAkakceOfferUrl(offerUrl) || offerUrl;
		const u = new URL(canon);
		const f = u.searchParams.get('f');
		if (!f) return null;
		const decoded = decodeURIComponent(f);
		if (!decoded.startsWith('/')) return null;
		return `https://www.akakce.com${decoded}`;
	} catch {
		return null;
	}
}

const AKAKCE_PTAVM_VENDOR_ID = '11281';

function isPttavmAkakceOffer(offerUrl) {
	try {
		const canon = canonicalizeAkakceOfferUrl(offerUrl) || offerUrl;
		return new URL(canon).searchParams.get('v') === AKAKCE_PTAVM_VENDOR_ID;
	} catch {
		return false;
	}
}

function extractPgFromAkakceOfferUrl(offerUrl) {
	try {
		const u = new URL(canonicalizeAkakceOfferUrl(offerUrl) || offerUrl);
		const g = u.searchParams.get('g');
		if (g) return g;
		const f = u.searchParams.get('f');
		if (!f) return null;
		const decoded = decodeURIComponent(f);
		const qi = decoded.indexOf('?');
		if (qi < 0) return null;
		return new URLSearchParams(decoded.slice(qi + 1)).get('pg');
	} catch {
		return null;
	}
}

/** Pttavm: Akakçe pg → https://www.pttavm.com/item/{pg} (redirect çözülemezse yedek) */
function buildPttavmItemUrlFromOffer(offerUrl) {
	if (!isPttavmAkakceOffer(offerUrl)) return null;
	const pg = extractPgFromAkakceOfferUrl(offerUrl);
	if (!pg || !/^\d+$/.test(pg)) return null;
	return `https://www.pttavm.com/item/${pg}`;
}

function extractDestinationFromAkakceHref(href) {
	try {
		const u = new URL(href);
		if (!isAkakceHost(u.hostname)) {
			return /^https?:\/\//i.test(href) ? href : null;
		}
		const r = u.searchParams.get('r');
		if (r) {
			const decoded = decodeURIComponent(r);
			if (/^https?:\/\//i.test(decoded)) {
				const destHost = new URL(decoded).hostname;
				if (!isAkakceHost(destHost)) return decoded;
			}
		}
		return null;
	} catch {
		return null;
	}
}

function destinationFromProbedHref(href) {
	if (!href) return null;
	const embedded = extractDestinationFromAkakceHref(href);
	if (embedded) return sanitizeDestinationUrl(embedded);
	try {
		const host = new URL(href).hostname;
		if (!isAkakceHost(host)) return sanitizeDestinationUrl(href);
	} catch {
		/* ignore */
	}
	return null;
}

async function probeTabDestination(tabId, hostHint) {
	const results = await chrome.scripting.executeScript({
		target: { tabId },
		func: (hint) => {
			const href = location.href;
			try {
				const u = new URL(href);
				const r = u.searchParams.get('r');
				if (r) {
					const decoded = decodeURIComponent(r);
					if (/^https?:\/\//i.test(decoded)) return decoded;
				}
			} catch {
				/* ignore */
			}
			const meta = document.querySelector('meta[http-equiv="refresh" i]');
			if (meta) {
				const content = meta.getAttribute('content') || '';
				const m = content.match(/url=([^;]+)/i);
				if (m && m[1]) return m[1].trim();
			}
			const anchors = document.querySelectorAll('a[href^="http"]');
			for (let i = 0; i < anchors.length; i++) {
				const h = anchors[i].href;
				if (h && !/akakce\.com/i.test(h)) return h;
			}
			if (hint) {
				const re = new RegExp(
					`https?:\\/\\/(?:www\\.)?${hint}[a-z0-9\\-._~:/?#\\[\\]@!$&'()*+,;=%]+`,
					'i',
				);
				const found = document.documentElement.innerHTML.match(re);
				if (found && found[0]) return found[0];
			}
			return href;
		},
		args: [hostHint || ''],
	});
	return results && results[0] ? results[0].result : null;
}

async function waitForDestinationOnTab(tabId, timeoutMs) {
	return new Promise((resolve) => {
		let settled = false;
		const timer = setTimeout(() => finish(null), timeoutMs);

		function finish(url) {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			chrome.tabs.onUpdated.removeListener(onUpdated);
			resolve(url);
		}

		function onUpdated(id, changeInfo, tab) {
			if (id !== tabId) return;
			const href = (changeInfo.url || tab?.url || '').trim();
			if (!href) return;
			if (changeInfo.status && changeInfo.status !== 'complete' && !changeInfo.url) return;
			const dest = destinationFromProbedHref(href);
			if (dest) finish(dest);
		}

		chrome.tabs.onUpdated.addListener(onUpdated);
		chrome.tabs.get(tabId, (tab) => {
			if (chrome.runtime.lastError) return;
			if (tab?.url) onUpdated(tabId, { status: 'complete', url: tab.url }, tab);
		});
	});
}

async function resolveAkakceOfferRedirect(offerUrl, options) {
	const timeoutMs =
		typeof options?.timeoutMs === 'number' && options.timeoutMs > 0 ? options.timeoutMs : 36000;
	const hostHint = String(options?.hostHint || '').trim();
	const canonical = canonicalizeAkakceOfferUrl(offerUrl);
	if (!canonical) return null;

	const isPttavm = isPttavmAkakceOffer(canonical);
	const pttavmFallback = buildPttavmItemUrlFromOffer(canonical);
	const intermediate = akakceIntermediateRedirectUrl(canonical);
	const openFirst = isPttavm && intermediate ? intermediate : canonical;
	const probeHint = hostHint || (isPttavm ? 'pttavm.com' : '');

	const tabId = await withTabRetry(
		() => createInactiveTab(openFirst, { active: isPttavm }),
		{ maxAttempts: 5, baseDelayMs: 120 },
	);
	try {
		const waitMs = isPttavm ? Math.min(timeoutMs, 28000) : Math.min(timeoutMs, 22000);
		await waitForTabComplete(tabId, waitMs);
		await sleep(isPttavm ? 2500 : 800);

		let dest = await waitForDestinationOnTab(tabId, isPttavm ? 14000 : 9000);
		if (!dest) {
			dest = destinationFromProbedHref(await probeTabDestination(tabId, probeHint));
		}

		if (!dest && openFirst !== canonical) {
			await chrome.tabs.update(tabId, { url: canonical });
			await waitForTabComplete(tabId, waitMs);
			await sleep(isPttavm ? 2000 : 800);
			dest = await waitForDestinationOnTab(tabId, isPttavm ? 12000 : 9000);
			if (!dest) {
				dest = destinationFromProbedHref(await probeTabDestination(tabId, probeHint));
			}
		}

		if (!dest && intermediate && openFirst === canonical) {
			await chrome.tabs.update(tabId, { url: intermediate });
			await waitForTabComplete(tabId, waitMs);
			await sleep(isPttavm ? 2500 : 1500);
			dest = await waitForDestinationOnTab(tabId, isPttavm ? 14000 : 12000);
			if (!dest) {
				dest = destinationFromProbedHref(await probeTabDestination(tabId, probeHint));
			}
		}

		if (!dest && pttavmFallback) return sanitizeDestinationUrl(pttavmFallback);
		return dest;
	} finally {
		await withTabRetry(() => closeTabSafe(tabId), { maxAttempts: 5, baseDelayMs: 120 }).catch(() => {});
		await sleep(350);
	}
}

async function scrapeAkakceProductViaTab(url, options) {
	const pageUrl = String(url || '').trim();
	if (!isAkakceProductUrl(pageUrl)) {
		return { ok: false, error: 'Geçerli bir Akakçe ürün detay URL gerekli (,ID.html).' };
	}

	emitScrapeProgress({ phase: 'page_open', message: 'Akakçe sayfası açılıyor…', url: pageUrl });
	const keepAlive = startScrapeKeepAlive();
	let tabId;
	try {
		tabId = await withTabRetry(() => createInactiveTab(pageUrl), {
			maxAttempts: 6,
			baseDelayMs: 120,
		});
	} catch (err) {
		clearInterval(keepAlive);
		throw err;
	}
	try {
		emitScrapeProgress({ phase: 'page_load', message: 'Sayfa yükleniyor…', url: pageUrl });
		await waitForTabComplete(tabId, 35000);
		await sleep(1500);
		emitScrapeProgress({ phase: 'page_expand', message: 'Tüm satıcı listesi yükleniyor…', url: pageUrl });
		await chrome.scripting.executeScript({
			target: { tabId },
			world: 'MAIN',
			func: async () => {
				const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
				for (let i = 0; i < 6; i++) {
					window.scrollTo(0, document.body.scrollHeight);
					await sleepMs(500);
				}
				const patterns = [/tümünü göster/i, /tüm fiyat/i, /daha fazla/i];
				document.querySelectorAll('a, button, span').forEach((el) => {
					const t = String(el.textContent || '')
						.replace(/\s+/g, ' ')
						.trim();
					if (!t || t.length > 40) return;
					if (!patterns.some((re) => re.test(t))) return;
					try {
						el.click();
					} catch {
						/* ignore */
					}
				});
				await sleepMs(2000);
				for (let j = 0; j < 4; j++) {
					window.scrollTo(0, document.body.scrollHeight);
					await sleepMs(400);
				}
			},
		});
		await sleep(800);
		emitScrapeProgress({ phase: 'page_wait_pl', message: 'Satıcı listesi (ul#PL) bekleniyor…', url: pageUrl });
		const plWaitDeadline = Date.now() + 20000;
		while (Date.now() < plWaitDeadline) {
			const waitRes = await chrome.scripting.executeScript({
				target: { tabId },
				func: () => {
					const pl = document.getElementById('PL');
					if (!pl) return { hasPl: false, itemCount: 0, offerLinks: 0 };
					const items = pl.querySelectorAll('li');
					let offerLinks = 0;
					items.forEach((li) => {
						const a = li.querySelector('a.iC, a[href*="/c/?"], a[href*="?v="]');
						if (!a) return;
						const h = a.getAttribute('href') || '';
						if (/\bv=\d+/i.test(h) && /\bp=\d+/i.test(h)) offerLinks += 1;
					});
					return { hasPl: true, itemCount: items.length, offerLinks };
				},
			});
			const st = waitRes && waitRes[0] ? waitRes[0].result : null;
			if (st?.offerLinks > 0) break;
			await sleep(600);
		}
		emitScrapeProgress({ phase: 'page_extract', message: 'Ürün özellikleri ve teklifler alınıyor…', url: pageUrl });
		await chrome.scripting.executeScript({
			target: { tabId },
			world: 'MAIN',
			files: ['lib/akakce-page-extract.js'],
		});
		const results = await chrome.scripting.executeScript({
			target: { tabId },
			world: 'MAIN',
			func: () => {
				if (typeof window.__ahtapotExtractAkakcePage !== 'function') {
					return { ok: false, error: 'Akakçe extract yüklenemedi.' };
				}
				return window.__ahtapotExtractAkakcePage();
			},
		});
		const payload = results && results[0] ? results[0].result : null;
		if (!payload || !payload.ok) {
			return payload || { ok: false, error: 'Akakçe sayfasından veri çıkarılamadı.' };
		}

		const offers = Array.isArray(payload.offers) ? payload.offers : [];
		if (!offers.length) {
			return {
				ok: false,
				error:
					'Satıcı teklifi bulunamadı. Sayfada /c/? satıcı linkleri yok veya liste henüz açılmadı (Cloudflare / Tümünü göster).',
			};
		}

		const targetOffers = offers.filter(isAkakceTargetOffer);
		if (!targetOffers.length) {
			return {
				ok: false,
				error:
					'n11, Trendyol veya Hepsiburada teklifi bulunamadı. Diğer satıcılar bu akışta atlanır.',
			};
		}

		const resolveRedirects = options?.resolveRedirects !== false;
		if (resolveRedirects && targetOffers.length) {
			let redirectDone = 0;
			for (let i = 0; i < targetOffers.length; i++) {
				const offer = targetOffers[i];
				if (!offer?.akakceOfferUrl) continue;
				const canonOfferUrl = canonicalizeAkakceOfferUrl(offer.akakceOfferUrl);
				if (!canonOfferUrl) continue;
				offer.akakceOfferUrl = canonOfferUrl;
				const fromShop = akakcePlatformFromOffer(offer);
				if (fromShop) offer.platform = fromShop;

				redirectDone += 1;
				emitScrapeProgress({
					phase: 'redirect',
					message: `Hedef link ${redirectDone}/${targetOffers.length} (n11/TY/HB)…`,
					url: pageUrl,
					index: redirectDone,
					total: targetOffers.length,
				});
				const dest = await resolveAkakceOfferRedirect(canonOfferUrl, {
					hostHint: akakceRedirectHostHint(offer),
				});
				offer.destinationUrl = dest;
				offer.platform = finalizeAkakceScrapedOfferPlatform(offer);
			}
		} else if (targetOffers.length) {
			for (let i = 0; i < targetOffers.length; i++) {
				const offer = targetOffers[i];
				if (!offer) continue;
				offer.platform = finalizeAkakceScrapedOfferPlatform(offer);
			}
		}

		const offersToSave = targetOffers.filter((o) => finalizeAkakceScrapedOfferPlatform(o));
		if (!offersToSave.length) {
			return {
				ok: false,
				error: 'Hedef platform linki çözülemedi (yalnızca n11, Trendyol, Hepsiburada).',
			};
		}

		emitScrapeProgress({ phase: 'import', message: 'Veritabanına kaydediliyor…', url: pageUrl });
		const importRes = await fetch(panelApiUrl('/akakce/products/import'), {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({
				product: payload.product,
				offers: offersToSave,
				rawJson: payload.rawJson,
			}),
		});
		const data = await importRes.json().catch(() => ({}));
		if (!importRes.ok || !data.ok) {
			return {
				ok: false,
				error: data.error || `Import başarısız (HTTP ${importRes.status})`,
			};
		}
		emitScrapeProgress({ phase: 'done', message: 'Akakçe ürünü kaydedildi.', url: pageUrl });
		return { ok: true, data, product: payload.product, offers };
	} finally {
		clearInterval(keepAlive);
		await withTabRetry(() => closeTabSafe(tabId), { maxAttempts: 6, baseDelayMs: 120 }).catch(() => {});
		await sleep(400);
	}
}

const hbSearchExtractInjectedTabIds = new Set();

function buildHepsiburadaSearchUrl(barcode) {
	return `https://www.hepsiburada.com/ara?q=${encodeURIComponent(String(barcode || '').trim())}`;
}

function normalizeHepsiburadaProductUrl(href) {
	const raw = String(href || '').trim();
	if (!raw) return null;
	try {
		if (/^https?:\/\//i.test(raw)) return new URL(raw).href.split('?')[0];
		return new URL(raw, 'https://www.hepsiburada.com').href.split('?')[0];
	} catch {
		return null;
	}
}

function isValidHepsiburadaBarcode(value) {
	return /^\d{8,14}$/.test(String(value || '').trim());
}

async function ensureHepsiburadaSearchExtract(tabId) {
	if (hbSearchExtractInjectedTabIds.has(tabId)) return;
	await chrome.scripting.executeScript({
		target: { tabId },
		world: 'MAIN',
		files: ['lib/hepsiburada-search-extract.js'],
	});
	hbSearchExtractInjectedTabIds.add(tabId);
}

async function readHepsiburadaSearchProductFromTab(tabId) {
	await ensureHepsiburadaSearchExtract(tabId);
	const results = await chrome.scripting.executeScript({
		target: { tabId },
		world: 'MAIN',
		func: () =>
			typeof extractFirstHepsiburadaSearchProduct === 'function'
				? extractFirstHepsiburadaSearchProduct()
				: null,
	});
	return results && results[0] ? results[0].result : null;
}

async function waitForHepsiburadaSearchProduct(tabId, timeoutMs) {
	const deadline = Date.now() + timeoutMs;
	while (Date.now() < deadline) {
		const row = await readHepsiburadaSearchProductFromTab(tabId);
		if (row && row.href) return row;
		await sleep(900);
	}
	return null;
}

async function resolveHepsiburadaBarcodeViaTab(barcode, ctx) {
	const code = String(barcode || '').trim();
	if (!isValidHepsiburadaBarcode(code)) {
		return { ok: false, barcode: code, error: 'Geçersiz barkod (8–14 rakam).' };
	}

	const searchUrl = buildHepsiburadaSearchUrl(code);
	emitScrapeProgress({
		phase: 'page_open',
		message: `Arama açılıyor: ${code}`,
		url: searchUrl,
		index: ctx?.index ?? null,
		total: ctx?.total ?? null,
	});

	const tabId = await withTabRetry(() => createInactiveTab(searchUrl), {
		maxAttempts: 6,
		baseDelayMs: 120,
	});

	try {
		emitScrapeProgress({
			phase: 'page_load',
			message: 'Arama sayfası yükleniyor…',
			url: searchUrl,
			index: ctx?.index ?? null,
			total: ctx?.total ?? null,
		});
		await waitForTabComplete(tabId, 35000);
		await sleep(2200);

		emitScrapeProgress({
			phase: 'search',
			message: 'İlk ürün kartı aranıyor…',
			url: searchUrl,
			index: ctx?.index ?? null,
			total: ctx?.total ?? null,
		});
		const product = await waitForHepsiburadaSearchProduct(tabId, 28000);
		if (!product?.href) {
			return {
				ok: false,
				barcode: code,
				searchUrl,
				error: 'Arama sonucunda ürün kartı bulunamadı.',
			};
		}

		const productUrl = normalizeHepsiburadaProductUrl(product.href);
		if (!productUrl) {
			return {
				ok: false,
				barcode: code,
				searchUrl,
				error: 'Ürün linki çözülemedi.',
			};
		}

		emitScrapeProgress({
			phase: 'pdp_open',
			message: 'Ürün sayfasına gidiliyor…',
			url: productUrl,
			index: ctx?.index ?? null,
			total: ctx?.total ?? null,
		});
		await chrome.tabs.update(tabId, { url: productUrl });
		await waitForTabComplete(tabId, 35000);
		await sleep(1500);

		return {
			ok: true,
			barcode: code,
			searchUrl,
			productUrl,
			title: product.title || null,
		};
	} finally {
		hbSearchExtractInjectedTabIds.delete(tabId);
		await withTabRetry(() => closeTabSafe(tabId), { maxAttempts: 6, baseDelayMs: 120 }).catch(() => {});
		await sleep(400);
	}
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
	if (!message || !message.type) return;

	if (message.type === 'kg-hepsiburada-barcode-batch') {
		const barcodesIn = Array.isArray(message.barcodes) ? message.barcodes : [];
		(async () => {
			const barcodes = [];
			const seen = new Set();
			for (let i = 0; i < barcodesIn.length; i++) {
				const code = String(barcodesIn[i] || '').trim();
				if (!code || seen.has(code)) continue;
				seen.add(code);
				barcodes.push(code);
			}
			const total = barcodes.length;
			if (!total) {
				sendResponse({ ok: false, error: 'Geçerli barkod bulunamadı.' });
				return;
			}

			const results = [];
			let okCount = 0;
			let failCount = 0;

			for (let i = 0; i < barcodes.length; i++) {
				const barcode = barcodes[i];
				emitScrapeProgress({
					phase: 'batch',
					message: `Barkod ${i + 1}/${total}: ${barcode}`,
					index: i + 1,
					total,
				});
				try {
					const row = await resolveHepsiburadaBarcodeViaTab(barcode, {
						index: i + 1,
						total,
					});
					results.push(row);
					if (row?.ok) okCount += 1;
					else failCount += 1;
				} catch (err) {
					failCount += 1;
					results.push({
						ok: false,
						barcode,
						error: err && err.message ? err.message : 'Hepsiburada tarama hatası',
					});
				}
				if (i < barcodes.length - 1) await sleep(600);
			}

			emitScrapeProgress({
				phase: 'done',
				message: `Bitti — ${okCount} ürün bulundu, ${failCount} hata.`,
			});
			sendResponse({
				ok: failCount < total,
				okCount,
				failCount,
				total,
				results,
			});
		})();
		return true;
	}

	if (message.type === 'kg-scrape-akakce-pdp') {
		const url = String(message.url || '').trim();
		const resolveRedirects = message.resolveRedirects !== false;
		(async () => {
			try {
				const result = await scrapeAkakceProductViaTab(url, { resolveRedirects });
				sendResponse(result);
			} catch (err) {
				sendResponse({
					ok: false,
					error: err && err.message ? err.message : 'Akakçe tarama hatası',
				});
			}
		})();
		return true;
	}

	if (message.type === 'kg-scrape-akakce-pdp-batch') {
		const urlsIn = Array.isArray(message.urls) ? message.urls : [];
		const resolveRedirects = message.resolveRedirects !== false;
		(async () => {
			const results = [];
			let saved = 0;
			let failed = 0;
			const urls = [];
			const seen = new Set();
			for (let i = 0; i < urlsIn.length; i++) {
				const u = String(urlsIn[i] || '').trim();
				if (!u || seen.has(u)) continue;
				seen.add(u);
				urls.push(u);
			}
			const total = urls.length;
			if (!total) {
				sendResponse({ ok: false, error: 'Geçerli Akakçe URL bulunamadı.' });
				return;
			}
			for (let i = 0; i < urls.length; i++) {
				const url = urls[i];
				emitScrapeProgress({
					phase: 'batch',
					message: `Toplu çekim ${i + 1}/${total}…`,
					url,
					index: i + 1,
					total,
				});
				try {
					const row = await scrapeAkakceProductViaTab(url, { resolveRedirects });
					if (row?.ok) {
						saved += 1;
						results.push({ url, ok: true, offersSaved: row?.data?.offersSaved });
					} else {
						failed += 1;
						results.push({ url, ok: false, error: row?.error || 'Tarama başarısız.' });
					}
				} catch (err) {
					failed += 1;
					results.push({
						url,
						ok: false,
						error: err && err.message ? err.message : 'Akakçe tarama hatası',
					});
				}
				if (i < urls.length - 1) await sleep(600);
			}
			emitScrapeProgress({
				phase: 'done',
				message: `Toplu çekim bitti — ${saved} kayıt, ${failed} hata.`,
			});
			sendResponse({
				ok: failed < total,
				saved,
				failed,
				total,
				results,
			});
		})();
		return true;
	}

	if (message.type === 'ahtapot-open-tab') {
		const url = message.url;
		const active = message.active === true;
		if (typeof url !== 'string' || !url.trim()) {
			sendResponse({ ok: false, reason: 'bad-url' });
			return true;
		}
		chrome.tabs.create({ url: url.trim(), active: active }, function (tab) {
			if (chrome.runtime.lastError) {
				sendResponse({ ok: false, error: chrome.runtime.lastError.message });
			} else {
				sendResponse({ ok: true, tabId: tab && tab.id });
			}
		});
		return true;
	}

	if (message.type === 'dc-close-current-tab') {
		const tabId = sender && sender.tab ? sender.tab.id : null;
		if (tabId == null) {
			sendResponse({ ok: false, reason: 'no-sender-tab' });
			return true;
		}
		chrome.tabs.remove(tabId, function () {
			if (chrome.runtime.lastError) {
				sendResponse({ ok: false, error: chrome.runtime.lastError.message });
			} else {
				sendResponse({ ok: true });
			}
		});
		return true;
	}

	if (message.type === 'kg-get-pending-links') {
		const limitRaw = Number(message.limit);
		const limit = Number.isFinite(limitRaw) ? Math.max(1, Math.min(200, Math.floor(limitRaw))) : 50;
		const platforms = Array.isArray(message.platforms)
			? message.platforms
					.map((x) => String(x || '').trim().toLowerCase())
					.filter((x) => x === 'trendyol' || x === 'n11' || x === 'hepsiburada' || x === 'amazon')
			: [];
		const platformParam = platforms.length ? platforms.join(',') : 'trendyol,n11,hepsiburada,amazon';
		const endpoint = `${panelApiUrl('/links/pending')}?limit=${limit}&platforms=${encodeURIComponent(platformParam)}`;
		fetch(endpoint, { method: 'GET' })
			.then(async (res) => {
				if (!res.ok) {
					const text = await res.text().catch(() => '');
					sendResponse({
						ok: false,
						error: `Link listesi alınamadı (HTTP ${res.status})`,
						detail: text,
					});
					return;
				}
				const data = await res.json().catch(() => ({}));
				sendResponse({ ok: true, data });
			})
			.catch((err) => {
				sendResponse({
					ok: false,
					error: err && err.message ? err.message : 'Background fetch hatası',
				});
			});
		return true;
	}

	if (message.type === 'kg-get-missing-reviews') {
		const limitRaw = Number(message.limit);
		const limit = Number.isFinite(limitRaw) ? Math.max(1, Math.min(200, Math.floor(limitRaw))) : 50;
		const platform = String(message.platform || 'trendyol').trim().toLowerCase() || 'trendyol';
		const qs = `limit=${limit}&platform=${encodeURIComponent(platform)}`;
		const endpoints = [
			`${panelApiUrl('/scraped-products/missing-reviews')}?${qs}`,
			`${panelApiUrl('/scraped-products/reviews-missing')}?${qs}`,
			`${panelApiUrl('/scraped-products')}?missingReviews=1&${qs}`,
		];
		(async () => {
			let lastError = 'Yorumu boş ürün listesi alınamadı.';
			let lastDetail = '';
			for (let i = 0; i < endpoints.length; i++) {
				try {
					const res = await fetch(endpoints[i], { method: 'GET' });
					const data = await res.json().catch(() => ({}));
					if (res.ok && data.ok === true) {
						sendResponse({ ok: true, data });
						return;
					}
					lastDetail = data.error || (await res.text().catch(() => '')) || lastDetail;
					lastError = `Yorumu boş ürün listesi alınamadı (HTTP ${res.status})`;
					if (res.status !== 400 && res.status !== 404) break;
				} catch (err) {
					lastError = err && err.message ? err.message : 'Background fetch hatası';
				}
			}
			sendResponse({
				ok: false,
				error:
					lastError +
					' Panel API’yi yeniden başlatın: terminalde npm run api (port 8787).',
				detail: lastDetail,
			});
		})();
		return true;
	}

	if (message.type === 'kg-patch-product-reviews') {
		const productId = String(message.productId || '').trim();
		const item = message.item && typeof message.item === 'object' ? message.item : null;
		if (!productId || !item) {
			sendResponse({ ok: false, error: 'productId ve item gerekli.' });
			return true;
		}
		fetch(panelApiUrl(`/scraped-products/${encodeURIComponent(productId)}/reviews`), {
			method: 'PATCH',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ item }),
		})
			.then(async (res) => {
				const data = await res.json().catch(() => ({}));
				if (!res.ok || !data.ok) {
					const errText =
						typeof data.error === 'string' && data.error.trim()
							? data.error.trim()
							: `Yorum güncellenemedi (HTTP ${res.status})`;
					sendResponse({
						ok: false,
						error: errText,
					});
					return;
				}
				sendResponse({ ok: true, data });
			})
			.catch((err) => {
				sendResponse({
					ok: false,
					error: err && err.message ? err.message : 'Yorum güncelleme hatası',
				});
			});
		return true;
	}

	function isIso88591Text(value) {
		const s = String(value || '');
		for (let i = 0; i < s.length; i++) {
			if (s.charCodeAt(i) > 255) return false;
		}
		return true;
	}

	async function buildTrendyolCookieHeader() {
		try {
			const cookies = await chrome.cookies.getAll({ domain: '.trendyol.com' });
			if (!cookies.length) return '';
			return cookies
				.filter((c) => isIso88591Text(c.name) && isIso88591Text(c.value))
				.map((c) => `${c.name}=${c.value}`)
				.join('; ');
		} catch {
			return '';
		}
	}

	if (message.type === 'kg-ty-discovery-fetch') {
		const url = String(message.url || '').trim();
		if (!/^https:\/\/apigw\.trendyol\.com\//i.test(url)) {
			sendResponse({ ok: false, error: 'Geçersiz Trendyol API URL.' });
			return true;
		}
		(async () => {
			try {
				const cookieHeader = await buildTrendyolCookieHeader();
				const headers = {
					Accept: 'application/json, text/plain, */*',
					Origin: 'https://www.trendyol.com',
					Referer: 'https://www.trendyol.com/',
				};
				if (cookieHeader) headers.Cookie = cookieHeader;
				let res = null;
				let text = '';
				for (let attempt = 1; attempt <= 5; attempt++) {
					res = await fetch(url, { method: 'GET', headers, cache: 'no-store' });
					if (res.status !== 429 || attempt >= 5) break;
					const retryAfter = res.headers.get('Retry-After');
					let waitMs = Math.min(45000, 4000 * Math.pow(2, attempt - 1));
					if (retryAfter) {
						const secs = parseInt(retryAfter, 10);
						if (Number.isFinite(secs) && secs > 0) waitMs = Math.max(waitMs, secs * 1000);
					}
					await sleep(waitMs);
				}
				text = await res.text();
				let json = null;
				try {
					json = JSON.parse(text);
				} catch {
					json = null;
				}
				if (!res.ok) {
					sendResponse({
						ok: false,
						status: res.status,
						error: `HTTP ${res.status}`,
					});
					return;
				}
				if (json == null) {
					sendResponse({ ok: false, error: 'JSON parse hatası' });
					return;
				}
				sendResponse({ ok: true, json });
			} catch (err) {
				sendResponse({
					ok: false,
					error: err && err.message ? err.message : 'Trendyol API fetch hatası',
				});
			}
		})();
		return true;
	}

	if (message.type === 'kg-hb-fetch-products-page') {
		const categoryId = String(message.categoryId || '').trim();
		const pageRaw = Number(message.page);
		const sizeRaw = Number(message.size);
		const page = Number.isFinite(pageRaw) && pageRaw > 0 ? Math.floor(pageRaw) : 1;
		const size = Number.isFinite(sizeRaw) && sizeRaw > 0 ? Math.min(72, Math.floor(sizeRaw)) : 36;
		if (!/^\d+$/.test(categoryId)) {
			sendResponse({ ok: false, error: 'Geçersiz categoryId.' });
			return true;
		}
		const endpoint =
			'https://blackgate.hepsiburada.com/moriaapi/api/product?' +
			`filter=${encodeURIComponent(`categoryId:${categoryId}`)}` +
			`&isBot=false&page=${page}&pageType=Category&size=${size}`;

		fetch(endpoint, { method: 'GET' })
			.then(async (res) => {
				const body = await res.json().catch(() => null);
				if (!res.ok) {
					sendResponse({
						ok: false,
						status: res.status,
						error: `HB fetch başarısız (HTTP ${res.status})`,
						body,
					});
					return;
				}
				sendResponse({ ok: true, status: res.status, body });
			})
			.catch((err) => {
				sendResponse({
					ok: false,
					error: err && err.message ? err.message : 'HB fetch hatası',
				});
			});
		return true;
	}

	if (message.type === 'kg-scrape-trendyol-pdp-tabs') {
		const links = Array.isArray(message.links) ? message.links : [];
		const scrapeOptions =
			message.scrapeOptions && typeof message.scrapeOptions === 'object'
				? message.scrapeOptions
				: {};
		(async () => {
			const results = await scrapeQueueEntriesWithConcurrency(links, scrapeOptions);
			sendResponse({ ok: true, results });
		})().catch((err) => {
			sendResponse({
				ok: false,
				error: err && err.message ? err.message : 'Sekmeli scrape akışı başarısız',
			});
		});
		return true;
	}

	if (message.type === 'ahtapot-crawl-seller-profiles') {
		const entries = Array.isArray(message.entries) ? message.entries : [];
		const tabConcurrency = resolveTabConcurrency({
			tabConcurrency: message.tabConcurrency,
		});
		const delayMsRaw = Number(message.delayMs);
		const delayMs =
			Number.isFinite(delayMsRaw) && delayMsRaw >= 0
				? Math.min(5000, Math.floor(delayMsRaw))
				: tabConcurrency > 1
					? 0
					: 800;
		(async () => {
			const results = await scrapeSellerProfileEntriesWithConcurrency(entries, {
				tabConcurrency,
				delayMs,
			});
			sendResponse({ ok: true, results, tabConcurrency });
		})().catch((err) => {
			sendResponse({
				ok: false,
				error: err && err.message ? err.message : 'Satıcı profili taraması başarısız',
			});
		});
		return true;
	}

	if (message.type === 'ahtapot-refresh-scraped-product') {
		const productId = String(message.productId || '').trim();
		const url = String(message.url || '').trim();
		const platform = String(message.platform || '').trim().toLowerCase() || null;
		const linkIdRaw = message.linkId;
		const linkId = linkIdRaw != null && Number.isFinite(Number(linkIdRaw)) ? Number(linkIdRaw) : null;
		if (!productId || !url) {
			sendResponse({ ok: false, error: 'productId ve url gerekli.' });
			return true;
		}
		(async () => {
			try {
				const scraped = await scrapeProductPdpViaTab({ url, linkId, platform });
				if (!scraped?.ok || !scraped.item) {
					sendResponse({
						ok: false,
						error: scraped?.error || 'Sayfa ziyaret edildi ancak veri çıkarılamadı.',
					});
					return;
				}
				const putRes = await fetch(
					panelApiUrl(`/scraped-products/${encodeURIComponent(productId)}`),
					{
						method: 'PUT',
						headers: { 'Content-Type': 'application/json' },
						body: JSON.stringify({
							item: {
								...scraped.item,
								linkId: linkId ?? scraped.item.linkId ?? null,
							},
						}),
					},
				);
				const putData = await putRes.json().catch(() => ({}));
				if (!putRes.ok || !putData.ok) {
					sendResponse({
						ok: false,
						error: putData.error || `Kayıt güncellenemedi (HTTP ${putRes.status})`,
					});
					return;
				}
				sendResponse({ ok: true, product: putData.product });
			} catch (err) {
				sendResponse({
					ok: false,
					error: err && err.message ? err.message : 'Güncelleme başarısız.',
				});
			}
		})();
		return true;
	}

	if (message.type === 'kg-mark-product-links-status') {
		const items = Array.isArray(message.items) ? message.items : [];
		fetch(panelApiUrl('/product-links/mark-status'), {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ items }),
		})
			.then(async (res) => {
				const data = await res.json().catch(() => ({}));
				if (!res.ok || !data.ok) {
					sendResponse({
						ok: false,
						error: data.error || `Durum güncellenemedi (HTTP ${res.status})`,
					});
					return;
				}
				sendResponse({ ok: true, data });
			})
			.catch((err) => {
				sendResponse({
					ok: false,
					error: err && err.message ? err.message : 'Durum güncelleme hatası',
				});
			});
		return true;
	}

	if (message.type === 'kg-import-scraped-products') {
		const items = Array.isArray(message.items) ? message.items : [];
		fetch(panelApiUrl('/scraped-products/import'), {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ items }),
		})
			.then(async (res) => {
				if (!res.ok) {
					const text = await res.text().catch(() => '');
					sendResponse({
						ok: false,
						error: `Import başarısız (HTTP ${res.status})`,
						detail: text,
					});
					return;
				}
				const data = await res.json().catch(() => ({}));
				sendResponse({ ok: true, data });
			})
			.catch((err) => {
				sendResponse({
					ok: false,
					error: err && err.message ? err.message : 'Import fetch hatası',
				});
			});
		return true;
	}

	if (message.type !== 'dc-download-text') {
		return;
	}
	const filename = sanitizeDownloadFilename(message.filename);
	const text = message.text;
	if (typeof text !== 'string') {
		sendResponse({ ok: false });
		return true;
	}

	const dataUrl = utf8TextToDataUrlBase64(text);
	if (!dataUrl) {
		sendResponse({ ok: false, tooLarge: true });
		return true;
	}

	chrome.downloads.download(
		{
			url: dataUrl,
			filename: filename,
			saveAs: false,
		},
		function (downloadId) {
			if (chrome.runtime.lastError) {
				sendResponse({ ok: false, error: chrome.runtime.lastError.message });
			} else {
				sendResponse({ ok: true, downloadId: downloadId });
			}
		},
	);
	return true;
});

chrome.runtime.onInstalled.addListener((details) => {
	if (details.reason === 'install') {
		console.info('[Ahtapot] Kuruldu');
	} else if (details.reason === 'update') {
		console.info('[Ahtapot] Güncellendi:', chrome.runtime.getManifest().version);
	}
});

/**
 * @param {string | undefined} url
 */
function isSupportedPageUrl(url) {
	if (!url) return false;
	try {
		const u = new URL(url);
		if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
		const h = u.hostname.toLowerCase();
		if (h === 'trendyol.com' || h === 'trendyol.com.tr') return true;
		if (h.endsWith('.trendyol.com') || h.endsWith('.trendyol.com.tr')) return true;
		if (h === 'hepsiburada.com' || h.endsWith('.hepsiburada.com')) return true;
		if (h === 'amazon.com.tr' || h.endsWith('.amazon.com.tr')) return true;
		if (h === 'epey.com' || h.endsWith('.epey.com')) return true;
		if (h === 'akakce.com' || h.endsWith('.akakce.com')) return true;
		return false;
	} catch {
		return false;
	}
}

const CONTENT_SCRIPTS = [
	'lib/extension-download.js',
	'lib/link-sanitize.js',
	'content/trendyol-telefon-mapper.js',
	'link-crawler-api.js',
	'content.js',
];

/**
 * @param {number} tabId
 */
function injectContent(tabId) {
	chrome.scripting.executeScript({ target: { tabId }, files: CONTENT_SCRIPTS }).catch(() => {
		/* sekme kapalı, chrome://, izin yok vb. */
	});
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
	if (!tab?.url || !isSupportedPageUrl(tab.url)) return;
	if (changeInfo.status === 'complete' || changeInfo.url != null) {
		injectContent(tabId);
	}
});
