(function () {
	function readRunnerParams() {
		var src = '';
		if (document.currentScript && document.currentScript.src) src = document.currentScript.src;
		if (!src) {
			var nodes = document.getElementsByTagName('script');
			for (var i = nodes.length - 1; i >= 0; i--) {
				var s = nodes[i].src || '';
				if (s.indexOf('page-trendyol-api-runner.js') !== -1) {
					src = s;
					break;
				}
			}
		}
		if (!src) return { pm: '', seed: '', resume: '', maxLinks: '4500' };
		try {
			var u = new URL(src);
			return {
				pm: u.searchParams.get('pm') || '',
				seed: u.searchParams.get('seed') || '',
				resume: u.searchParams.get('resume') || '',
				maxLinks: u.searchParams.get('maxLinks') || '4500',
			};
		} catch (e) {
			return { pm: '', seed: '', resume: '', maxLinks: '4500' };
		}
	}

	var ABSOLUTE_CRAWL_MAX = 4500;
	var cfg = readRunnerParams();
	var PM = cfg.pm;
	var seedStr = cfg.seed || '';
	var MAX_CRAWL_LINKS = parseInt(cfg.maxLinks || String(ABSOLUTE_CRAWL_MAX), 10);
	if (!Number.isFinite(MAX_CRAWL_LINKS) || MAX_CRAWL_LINKS < 1) MAX_CRAWL_LINKS = ABSOLUTE_CRAWL_MAX;
	if (MAX_CRAWL_LINKS > ABSOLUTE_CRAWL_MAX) MAX_CRAWL_LINKS = ABSOLUTE_CRAWL_MAX;
	if (!PM) return;

	var S = 'data-crawler-ty-api-direct';
	var BASE = 'https://apigw.trendyol.com/discovery-sfint-search-service/api/search/products';
	var CK_SESSION = 'ahtapot_lc_ckpt';
	var MIN_SAFE_LINK_COUNT = 100;
	var MAX_FETCH_RETRY = 6;
	var MAX_STALL_PAGES = 3;
	var GAP_MIN_MS = 700;
	var GAP_MAX_MS = 5000;
	var GAP_STEP_UP_MS = 600;
	var GAP_STEP_DOWN_MS = 120;
	var PROXY_FETCH_TIMEOUT_MS = 45000;

	var PAGE_ORIGIN = (function () {
		try {
			if (typeof location !== 'undefined' && location.origin) {
				return location.origin.replace(/\/$/, '');
			}
		} catch (e) {}
		return 'https://www.trendyol.com';
	})();

	function readResumePayload() {
		if (cfg.resume !== '1') return null;
		try {
			var raw = sessionStorage.getItem(CK_SESSION);
			if (!raw) return null;
			return JSON.parse(raw);
		} catch (e) {
			return null;
		}
	}

	function walk(o, set) {
		if (!o || typeof o !== 'object') return;
		if (Array.isArray(o)) {
			for (var i = 0; i < o.length; i++) walk(o[i], set);
			return;
		}
		if (typeof o.url === 'string') {
			var path = o.url.trim();
			if (!path) return;
			if (path.charAt(0) !== '/') path = '/' + path;
			if (/-p-\d+/.test(path)) {
				var clean = path.split('?')[0];
				set.add(PAGE_ORIGIN + clean);
			}
		}
		for (var k in o) walk(o[k], set);
	}

	function pageUrlCount(j) {
		var t = new Set();
		walk(j, t);
		return t.size;
	}

	function pickState(j) {
		var r = j && (j.result || j.searchResult || j.data);
		if (!r || typeof r !== 'object') r = j;
		if (!r || typeof r !== 'object') return {};
		var off = r.offset;
		if (off === undefined) off = r.nextOffset;
		if (off === undefined) off = r.widgetOffset;
		var op = r.offsetParameters;
		if (op === undefined) op = r.offsetParameter;
		return { offset: off, offsetParameters: op };
	}

	function sleep(ms) {
		return new Promise(function (resolve) {
			setTimeout(resolve, ms);
		});
	}

	function shouldRetryHttp(status) {
		return status === 429 || status >= 500;
	}

	function parseRetryAfterMs(res) {
		if (!res || !res.headers || !res.headers.get) return null;
		var raw = res.headers.get('Retry-After');
		if (!raw) return null;
		var secs = parseInt(raw, 10);
		if (Number.isFinite(secs) && secs > 0) return secs * 1000;
		var when = Date.parse(raw);
		if (Number.isFinite(when)) return Math.max(0, when - Date.now());
		return null;
	}

	function retryDelayMs(status, attempt, retryAfterMs) {
		var base;
		if (status === 429) {
			base = Math.min(45000, 3000 * Math.pow(2, attempt - 1));
		} else {
			base = Math.min(10000, 450 * Math.pow(2, attempt - 1));
		}
		if (retryAfterMs != null && retryAfterMs > base) return retryAfterMs;
		return base;
	}

	function shouldTryProxy(err) {
		if (!err) return true;
		if (err.kind === 'exception') return true;
		if (err.kind === 'http' && shouldRetryHttp(err.status)) return true;
		return false;
	}

	function trimLinksToMax(set) {
		if (set.size <= MAX_CRAWL_LINKS) return set;
		return new Set(Array.from(set).slice(0, MAX_CRAWL_LINKS));
	}

	function nextGapMs(throttleMs, hadIssue) {
		var next = throttleMs;
		if (hadIssue) next = Math.min(GAP_MAX_MS, next + GAP_STEP_UP_MS);
		else next = Math.max(GAP_MIN_MS, next - GAP_STEP_DOWN_MS);
		return {
			sleepMs: next + Math.floor(Math.random() * 100),
			throttleMs: next,
		};
	}

	function iso88591HeaderValue(value) {
		var s = String(value || '');
		try {
			for (var i = 0; i < s.length; i++) {
				if (s.charCodeAt(i) > 255) return encodeURI(s);
			}
		} catch (e) {}
		return s;
	}

	function fetchHeaders() {
		var referer = PAGE_ORIGIN + '/';
		try {
			if (typeof location !== 'undefined' && location.href) referer = location.href.split('#')[0];
		} catch (e) {}
		return {
			Accept: 'application/json, text/plain, */*',
			Referer: iso88591HeaderValue(referer),
		};
	}

	function fetchViaExtensionProxy(url) {
		return new Promise(function (resolve) {
			var requestId = 'pf_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
			var settled = false;
			function finish(payload) {
				if (settled) return;
				settled = true;
				window.removeEventListener('message', onMsg);
				clearTimeout(timer);
				resolve(payload || { ok: false, error: { kind: 'exception', message: 'Proxy yanıt yok' } });
			}
			function onMsg(ev) {
				if (ev.source !== window) return;
				var d = ev.data;
				if (!d || d.source !== S || d.phase !== 'proxy-fetch-result' || d.requestId !== requestId) return;
				finish(d);
			}
			window.addEventListener('message', onMsg);
			var timer = setTimeout(function () {
				finish({ ok: false, error: { kind: 'exception', message: 'Proxy fetch zaman aşımı' } });
			}, PROXY_FETCH_TIMEOUT_MS);
			window.postMessage({ source: S, phase: 'proxy-fetch', requestId: requestId, url: url }, '*');
		});
	}

	async function fetchJsonOnce(url) {
		var res = await fetch(url, { credentials: 'include', headers: fetchHeaders(), cache: 'no-store' });
		if (!res.ok) {
			return {
				ok: false,
				error: { kind: 'http', status: res.status },
				retryAfterMs: parseRetryAfterMs(res),
			};
		}
		try {
			return { ok: true, json: await res.json() };
		} catch (parseErr) {
			return {
				ok: false,
				error: {
					kind: 'json',
					message: String(parseErr && parseErr.message ? parseErr.message : parseErr),
				},
			};
		}
	}

	async function fetchJsonWithRetry(url) {
		var lastErr = null;
		var attempts = 0;
		for (var attempt = 1; attempt <= MAX_FETCH_RETRY; attempt++) {
			attempts = attempt;
			try {
				var direct = await fetchJsonOnce(url);
				if (direct.ok) return { ok: true, json: direct.json, attempts: attempt };
				lastErr = direct.error || { kind: 'http', status: 0 };
				if (lastErr.kind === 'http' && !shouldRetryHttp(lastErr.status)) {
					break;
				}
				if (attempt < MAX_FETCH_RETRY) {
					await sleep(retryDelayMs(lastErr.status, attempt, direct.retryAfterMs));
				}
			} catch (netErr) {
				lastErr = {
					kind: 'exception',
					message: String(netErr && netErr.message ? netErr.message : netErr),
				};
				if (attempt < MAX_FETCH_RETRY) {
					await sleep(retryDelayMs(0, attempt, null));
				}
			}
		}
		if (shouldTryProxy(lastErr)) {
			try {
				var proxied = await fetchViaExtensionProxy(url);
				if (proxied && proxied.ok && proxied.json) {
					return { ok: true, json: proxied.json, attempts: attempts + 1 };
				}
				if (proxied) {
					lastErr = {
						kind: proxied.status ? 'http' : 'exception',
						status: proxied.status,
						message:
							typeof proxied.error === 'string'
								? proxied.error
								: proxied.error && proxied.error.message
									? proxied.error.message
									: 'Proxy hatası',
					};
				}
			} catch (proxyErr) {
				lastErr = {
					kind: 'exception',
					message: String(proxyErr && proxyErr.message ? proxyErr.message : proxyErr),
				};
			}
		}
		return { ok: false, error: lastErr || { kind: 'exception', message: 'Bilinmeyen hata' }, attempts: attempts };
	}

	function urlsFromSet(all) {
		return Array.from(trimLinksToMax(all));
	}

	/** Sonraki istek için: bir sonraki pi ve güncel offset (başarılı yanıttan sonra). */
	function emitCheckpoint(nextPi, off, offParams, all) {
		all = trimLinksToMax(all);
		window.postMessage(
			{
				source: S,
				phase: 'checkpoint',
				pathModel: PM,
				seed: seedStr,
				nextPi: nextPi,
				offset: off,
				offsetParameters: offParams,
				urls: urlsFromSet(all),
				count: all.size,
			},
			'*',
		);
	}

	/** İstek çökünce aynı pi/offset ile tekrar denemek için. */
	function emitRetryCheckpoint(retryPi, off, offParams, all) {
		all = trimLinksToMax(all);
		window.postMessage(
			{
				source: S,
				phase: 'checkpoint',
				pathModel: PM,
				seed: seedStr,
				nextPi: retryPi,
				offset: off,
				offsetParameters: offParams,
				urls: urlsFromSet(all),
				count: all.size,
				retrySamePage: true,
			},
			'*',
		);
	}

	async function run() {
		var all = new Set();
		var pi = 1;
		var offset = null;
		var offsetParameters = null;
		var guard = 0;
		var stallPages = 0;
		var throttleMs = GAP_MIN_MS;

		var resume = readResumePayload();
		if (resume && Array.isArray(resume.urls)) {
			for (var ri = 0; ri < resume.urls.length; ri++) {
				if (typeof resume.urls[ri] === 'string') all.add(resume.urls[ri]);
			}
			if (all.size > MAX_CRAWL_LINKS) all = trimLinksToMax(all);
			if (resume.nextPi != null && !isNaN(Number(resume.nextPi))) pi = Number(resume.nextPi);
			if (resume.offset !== undefined) offset = resume.offset;
			if (resume.offsetParameters !== undefined) offsetParameters = resume.offsetParameters;
		}

		try {
			while (guard++ < 500) {
				var reqPi = pi;
				var reqOffset = offset;
				var reqOffParams = offsetParameters;

				var q = new URLSearchParams(seedStr);
				q.set('pathModel', PM);
				q.set('channelId', '1');
				q.set('storefrontId', '1');
				q.set('culture', 'tr-TR');
				q.set('pi', String(reqPi));
				if (reqOffset != null && reqOffset !== '') q.set('offset', String(reqOffset));
				if (reqOffParams) q.set('offsetParameters', String(reqOffParams));

				var reqUrl = BASE + '?' + q.toString();
				var fetched = await fetchJsonWithRetry(reqUrl);
				var hadIssue = !fetched.ok || (fetched.attempts != null && fetched.attempts > 1);
				if (!fetched.ok) {
					var err = fetched.error || {};
					emitRetryCheckpoint(reqPi, reqOffset, reqOffParams, all);
					if (all.size >= MIN_SAFE_LINK_COUNT || all.size >= MAX_CRAWL_LINKS) {
						break;
					}
					if (all.size > 0) {
						window.postMessage(
							{
								source: S,
								phase: 'done',
								urls: Array.from(all).sort(),
								partial: true,
								stoppedReason: err.kind || 'http',
								httpStatus: err.status,
								exceptionMessage: err.message,
							},
							'*',
						);
						return;
					}
					var errMsg =
						err.status === 429
							? 'HTTP 429 — Trendyol rate limit (çok hızlı istek)'
							: err.message ||
								(err.status != null ? 'HTTP ' + err.status : 'Ağ hatası (rate limit olabilir)');
					window.postMessage(
						{
							source: S,
							phase: 'error',
							status: err.status,
							canResume: true,
							message: errMsg,
						},
						'*',
					);
					return;
				}

				var j = fetched.json;

				var before = all.size;
				walk(j, all);
				if (all.size > MAX_CRAWL_LINKS) all = trimLinksToMax(all);
				window.postMessage({ source: S, phase: 'progress', count: all.size, pi: reqPi }, '*');

				if (all.size >= MAX_CRAWL_LINKS) break;

				var nPage = pageUrlCount(j);
				if (nPage === 0) break;
				if (all.size === before && reqPi > 1) {
					stallPages++;
					if (stallPages >= MAX_STALL_PAGES) break;
				} else {
					stallPages = 0;
				}

				var st = pickState(j);
				if (st.offset !== undefined && st.offset !== null) offset = st.offset;
				if (st.offsetParameters) offsetParameters = st.offsetParameters;

				emitCheckpoint(reqPi + 1, offset, offsetParameters, all);
				pi++;
				var gap = nextGapMs(throttleMs, hadIssue);
				throttleMs = gap.throttleMs;
				if (gap.sleepMs > 0) await sleep(gap.sleepMs);
			}
		} catch (e) {
			if (all.size > 0) {
				window.postMessage(
					{
						source: S,
						phase: 'done',
						urls: Array.from(all).sort(),
						partial: true,
						stoppedReason: 'exception',
						exceptionMessage: String(e && e.message ? e.message : e),
					},
					'*',
				);
				return;
			}
			window.postMessage(
				{ source: S, phase: 'error', canResume: false, message: String(e && e.message ? e.message : e) },
				'*',
			);
			return;
		}
		try {
			sessionStorage.removeItem(CK_SESSION);
		} catch (e2) {}
		all = trimLinksToMax(all);
		window.postMessage(
			{
				source: S,
				phase: 'done',
				urls: Array.from(all).sort(),
				partial: false,
				cappedAt: all.size >= MAX_CRAWL_LINKS ? MAX_CRAWL_LINKS : null,
			},
			'*',
		);
	}

	run();
})();
