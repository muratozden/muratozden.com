/**
 * Data Crawler’daki «API Crawler» akışı — Trendyol discovery API + sayfa dünyası runner.
 * globalThis.ahtapotOpenLinkCrawler(modalTitleEl, modalBodyEl, onClose)
 */
(function () {
	'use strict';

	const PANEL_API_BASE = 'https://ahtapot.datascraper.net/api';
	function panelApiUrl(path) {
		const p = path.startsWith('/') ? path : `/${path}`;
		return `${PANEL_API_BASE}${p}`;
	}

	function sleep(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}

	const EXT_CONTEXT_INVALIDATED_TR =
		"Extension bağlamı sona erdi. Extension'ı yenilediyseniz bu sekmeyi yenileyin (F5), sonra Auto Scraping'i tekrar deneyin.";

	function isExtensionContextInvalidatedError(err) {
		const msg = String(err?.message || err || '').toLowerCase();
		return msg.includes('extension context invalidated') || msg.includes('context invalidated');
	}

	function normalizeRuntimeError(err) {
		if (isExtensionContextInvalidatedError(err)) {
			return new Error(EXT_CONTEXT_INVALIDATED_TR);
		}
		return err instanceof Error ? err : new Error(String(err));
	}

	function isExtensionRuntimeAlive() {
		try {
			return Boolean(chrome?.runtime?.id);
		} catch {
			return false;
		}
	}

	function sendRuntimeMessage(message) {
		if (!isExtensionRuntimeAlive()) {
			return Promise.reject(new Error(EXT_CONTEXT_INVALIDATED_TR));
		}
		if (!chrome?.runtime || typeof chrome.runtime.sendMessage !== 'function') {
			return Promise.reject(new Error('Chrome runtime erişimi yok.'));
		}
		return new Promise((resolve, reject) => {
			try {
				chrome.runtime.sendMessage(message, (response) => {
					if (chrome.runtime.lastError) {
						reject(normalizeRuntimeError(new Error(chrome.runtime.lastError.message)));
						return;
					}
					resolve(response);
				});
			} catch (err) {
				reject(normalizeRuntimeError(err));
			}
		});
	}

	const MSG_API_DIRECT = 'data-crawler-ty-api-direct';
	const API_PRODUCTS_BASE =
		'https://apigw.trendyol.com/discovery-sfint-search-service/api/search/products';

	/** Sayfa runner (MAIN) → uzantı üzerinden apigw fetch yedek köprüsü */
	window.addEventListener('message', (ev) => {
		if (ev.source !== window) return;
		const d = ev.data;
		if (!d || d.source !== MSG_API_DIRECT || d.phase !== 'proxy-fetch' || !d.requestId) return;
		const reply = (payload) => {
			window.postMessage(
				{
					source: MSG_API_DIRECT,
					phase: 'proxy-fetch-result',
					requestId: d.requestId,
					...payload,
				},
				'*',
			);
		};
		if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
			reply({ ok: false, error: 'Uzantı köprüsü kullanılamıyor.' });
			return;
		}
		chrome.runtime.sendMessage({ type: 'kg-ty-discovery-fetch', url: d.url }, (resp) => {
			const err = chrome.runtime.lastError;
			if (err) {
				reply({ ok: false, error: err.message || 'Background yanıt vermedi.' });
				return;
			}
			reply(resp || { ok: false, error: 'Boş yanıt.' });
		});
	});
	const PAGE_SCRIPT_API_RUNNER = 'page-trendyol-api-runner.js';

	/** Liste tam çekilebilir sayım aralığı (Data Crawler ile aynı). */
	const RESULT_COUNT_MIN = 1200;
	/** Trendyol prc/API tek parçada güvenle taranabilir üst sınır */
	const RESULT_COUNT_MAX = 4500;
	const CRAWL_LINK_MAX = RESULT_COUNT_MAX;
	/** NextPage sonrası otomatik modal / prc ayarı (localStorage). */
	const LS_AFTER_NEXTPAGE = 'dc_ty_after_nextpage';
	const SESSION_PRC_AUTOTUNE_ITR = 'dc_ty_prc_autotune_i';
	const PRC_AUTOTUNE_MAX = 20;
	const SESSION_PRC_AUTOTUNE_BEST = 'dc_ty_prc_autotune_best';
	const LS_NEXTPAGE_AUTOSTOP = 'dc_ty_nextpage_autostop';
	const AFTER_NEXTPAGE_TTL_MS = 300000;

	const LS_AUTO_CRAWLER_TY = 'dc_ty_auto_crawler';
	const TY_AUTO_START_DELAY_MS = 650;
	const TY_AUTO_NEXTPAGE_DELAY_MS = 1800;

	/** Hepsiburada kategori listesi — hedef 750–1500 ürün / fiyat dilimi */
	const HB_RESULT_COUNT_MIN = 750;
	const HB_RESULT_COUNT_MAX = 1500;
	const HB_CRAWL_LINK_MAX = 1500;
	const LS_AFTER_NEXTPAGE_HB = 'dc_hb_after_nextpage';
	const SESSION_HB_FIYAT_AUTOTUNE_ITR = 'dc_hb_fiyat_autotune_i';
	const SESSION_HB_FIYAT_AUTOTUNE_BEST = 'dc_hb_fiyat_autotune_best';
	const LS_NEXTPAGE_AUTOSTOP_HB = 'dc_hb_nextpage_autostop';
	const LS_AUTO_CRAWLER_HB = 'dc_hb_auto_crawler';
	const LS_HB_FORCE_AUTO_START = 'dc_hb_force_auto_start';
	const SESSION_HB_LC_CATEGORY_URL = 'dc_hb_lc_category_url';
	const SESSION_HB_LAST_FIYAT_BOUNDS = 'dc_hb_last_fiyat_bounds';
	const SESSION_HB_PENDING_FIYAT_BOUNDS = 'dc_hb_pending_fiyat_bounds';
	const HB_AUTO_START_DELAY_MS = 650;
	const HB_AUTO_NEXTPAGE_DELAY_MS = 2200;
	const HB_FIYAT_AUTOTUNE_MAX = 20;

	/** chrome.storage — sekme kapansa bile yarım tarama */
	const LC_CHECKPOINT_STORAGE_KEY = 'ahtapot_lc_checkpoint_v1';
	const LC_CKPT_SESSION = 'ahtapot_lc_ckpt';

	/** @type {{ onApiMessage: (ev: MessageEvent) => void } | null} */
	let apiSession = null;

	/** Açık Link Crawler modal ui (zamanlayıcı iptali için). */
	let activeLcUi = null;

	function isLcUiActive(ui) {
		return activeLcUi === ui;
	}

	function pathModelFromLocation() {
		let p = (location.pathname || '').replace(/^\/+|\/+$/g, '');
		if (!p) return '';
		const q = p.indexOf('?');
		if (q !== -1) p = p.slice(0, q);
		return p;
	}

	function apiSeedQueryFromLocation() {
		const drop = new Set(['pi', 'offset', 'offsetparameters']);
		const usp = new URLSearchParams(location.search);
		const out = new URLSearchParams();
		usp.forEach((v, k) => {
			if (drop.has(k.toLowerCase())) return;
			out.append(k, v);
		});
		return out.toString();
	}

	/** [data-testid="result-count-info"] veya .result-count-info — örn. 4.759+ Ürün → 4759. */
	function parseResultCountFromDom() {
		const el =
			document.querySelector('[data-testid="result-count-info"]') ||
			document.querySelector('.result-count-info');
		if (!el) return null;
		const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
		const m = t.match(/([\d.]+)/);
		if (!m) return null;
		const digits = m[1].replace(/\./g, '');
		const n = parseInt(digits, 10);
		return Number.isFinite(n) ? n : null;
	}

	function canCrawlListCompletely(n) {
		return typeof n === 'number' && n >= RESULT_COUNT_MIN && n <= RESULT_COUNT_MAX;
	}

	/** API taraması başlamadan önce DOM’daki liste bu sınırı aşmamalı. */
	function isListWithinCrawlLimit(n) {
		return typeof n === 'number' && n >= 1 && n <= RESULT_COUNT_MAX;
	}

	function resolveCrawlLinkMax(domCount) {
		if (domCount != null && domCount > 0) return Math.min(CRAWL_LINK_MAX, domCount);
		return CRAWL_LINK_MAX;
	}

	function trimUrlListToCrawlMax(urls) {
		if (!Array.isArray(urls)) return [];
		if (urls.length <= CRAWL_LINK_MAX) return urls;
		return urls.slice(0, CRAWL_LINK_MAX);
	}

	function waitForDomResultCount(deadlineMs) {
		return new Promise((resolve) => {
			const deadline = Date.now() + deadlineMs;
			function tick() {
				const n = parseResultCountFromDom();
				if (n != null) {
					resolve(n);
					return;
				}
				if (Date.now() > deadline) {
					resolve(null);
					return;
				}
				setTimeout(tick, 350);
			}
			tick();
		});
	}

	function clearNextPageAutostop() {
		try {
			localStorage.removeItem(LS_NEXTPAGE_AUTOSTOP);
		} catch {
			/* ignore */
		}
	}

	function stopPrcAutotuneFlow() {
		clearAfterNextPageFlag();
		clearPrcAutotuneItr();
		clearPrcAutotuneBestCandidate();
		try {
			localStorage.setItem(LS_NEXTPAGE_AUTOSTOP, '1');
		} catch {
			/* ignore */
		}
	}

	function applyInitialPrcForOversizedList() {
		clearNextPageAutostop();
		setAfterNextPageFlag();
		clearPrcAutotuneItr();
		clearPrcAutotuneBestCandidate();
		replaceLocationKeepingQueryPrc(1, 100);
	}

	function shouldResetToInitialPrc() {
		if (getPrcBoundsFromLocation()) return false;
		const n = parseResultCountFromDom();
		return n != null && n > RESULT_COUNT_MAX;
	}

	function failPrcAutotuneWithoutReset() {
		if (shouldResetToInitialPrc()) {
			applyInitialPrcForOversizedList();
			return;
		}
		stopPrcAutotuneFlow();
	}

	function scheduleModalWhenWithinCrawlLimit() {
		const n = parseResultCountFromDom();
		if (n === 0) {
			stopPrcAutotuneFlow();
			return false;
		}
		if (n != null && n > RESULT_COUNT_MAX) return false;
		if (n === null && getPrcBoundsFromLocation()) {
			stopPrcAutotuneFlow();
			return false;
		}
		clearNextPageAutostop();
		scheduleAutoOpenAhtapotModalAfterNextPage();
		return true;
	}

	function readPrcAutotuneItr() {
		try {
			const v = parseInt(sessionStorage.getItem(SESSION_PRC_AUTOTUNE_ITR) || '0', 10);
			return Number.isFinite(v) && v >= 0 ? v : 0;
		} catch {
			return 0;
		}
	}

	function writePrcAutotuneItr(n) {
		try {
			sessionStorage.setItem(SESSION_PRC_AUTOTUNE_ITR, String(n));
		} catch {
			/* ignore */
		}
	}

	function clearPrcAutotuneItr() {
		try {
			sessionStorage.removeItem(SESSION_PRC_AUTOTUNE_ITR);
		} catch {
			/* ignore */
		}
	}

	function getResultCountDistanceFromTarget(n) {
		if (!Number.isFinite(n)) return Number.POSITIVE_INFINITY;
		if (n < RESULT_COUNT_MIN) return RESULT_COUNT_MIN - n;
		if (n > RESULT_COUNT_MAX) return n - RESULT_COUNT_MAX;
		return 0;
	}

	function readPrcAutotuneBestCandidate() {
		try {
			const raw = sessionStorage.getItem(SESSION_PRC_AUTOTUNE_BEST);
			if (!raw) return null;
			const parsed = JSON.parse(raw);
			if (
				!parsed ||
				!Number.isFinite(parsed.min) ||
				!Number.isFinite(parsed.max) ||
				parsed.max < parsed.min ||
				!Number.isFinite(parsed.count) ||
				!Number.isFinite(parsed.distance)
			) {
				return null;
			}
			return {
				min: parsed.min,
				max: parsed.max,
				count: parsed.count,
				distance: parsed.distance,
			};
		} catch {
			return null;
		}
	}

	function writePrcAutotuneBestCandidate(bounds, count) {
		if (
			!bounds ||
			!Number.isFinite(bounds.min) ||
			!Number.isFinite(bounds.max) ||
			bounds.max < bounds.min ||
			!Number.isFinite(count)
		) {
			return;
		}
		const next = {
			min: bounds.min,
			max: bounds.max,
			count: count,
			distance: getResultCountDistanceFromTarget(count),
		};
		try {
			const cur = readPrcAutotuneBestCandidate();
			if (
				cur &&
				(cur.distance < next.distance ||
					(cur.distance === next.distance &&
						((cur.max - cur.min < next.max - next.min) ||
							(cur.max - cur.min === next.max - next.min && cur.min <= next.min))))
			) {
				return;
			}
			sessionStorage.setItem(
				SESSION_PRC_AUTOTUNE_BEST,
				JSON.stringify(next),
			);
		} catch {
			/* ignore */
		}
	}

	function clearPrcAutotuneBestCandidate() {
		try {
			sessionStorage.removeItem(SESSION_PRC_AUTOTUNE_BEST);
		} catch {
			/* ignore */
		}
	}

	/**
	 * Ürün sayısı hedef dışındayken bir sonraki prc aralığı (daralt / genişlet).
	 * @param {number} min
	 * @param {number} max
	 * @param {number|null} n
	 */
	function computeNextPrcBounds(min, max, n) {
		const width = max - min;
		if (!Number.isFinite(min) || !Number.isFinite(max) || width < 1) return null;

		if (n != null && n > RESULT_COUNT_MAX) {
			let step = Math.max(5, Math.min(120, Math.ceil(width * 0.22)));
			if (width < 20) step = Math.max(1, Math.floor(width / 2));
			let newMax = max - step;
			if (newMax <= min + 3) newMax = min + Math.max(4, Math.min(width - 1, 25));
			if (newMax <= min || newMax >= max) return null;
			return { min: min, max: newMax };
		}

		if (n != null && n >= 1 && n < RESULT_COUNT_MIN) {
			const gap = RESULT_COUNT_MIN - n;
			const step = Math.max(30, Math.min(150, Math.max(5, Math.ceil(gap / 12))));
			const newMax = max + step;
			if (newMax <= max) return null;
			return { min: min, max: newMax };
		}

		// n === 0: bu fiyat aralığında ürün yok — genişletme / başa dönme yok
		return null;
	}

	function replaceLocationKeepingQueryPrc(min, max) {
		const usp = new URLSearchParams(location.search);
		usp.set('prc', min + '-' + max);
		const q = usp.toString();
		const url = location.origin + location.pathname + (q ? '?' + q : '') + (location.hash || '');
		location.replace(url);
	}

	function restoreBestPrcAndReload(currentBounds) {
		const best = readPrcAutotuneBestCandidate();
		if (!best || best.count === 0) return false;
		if (
			currentBounds &&
			best.min === currentBounds.min &&
			best.max === currentBounds.max
		) {
			return false;
		}
		clearPrcAutotuneItr();
		clearPrcAutotuneBestCandidate();
		setAfterNextPageFlag();
		replaceLocationKeepingQueryPrc(best.min, best.max);
		return true;
	}

	function setAfterNextPageFlag() {
		try {
			localStorage.setItem(LS_AFTER_NEXTPAGE, String(Date.now()));
		} catch {
			/* ignore */
		}
	}

	function getAfterNextPageFlag() {
		try {
			const raw = localStorage.getItem(LS_AFTER_NEXTPAGE);
			if (!raw) return false;
			const t = parseInt(raw, 10);
			if (!Number.isFinite(t) || Date.now() - t > AFTER_NEXTPAGE_TTL_MS) {
				localStorage.removeItem(LS_AFTER_NEXTPAGE);
				return false;
			}
			return true;
		} catch {
			return false;
		}
	}

	function clearAfterNextPageFlag() {
		try {
			localStorage.removeItem(LS_AFTER_NEXTPAGE);
		} catch {
			/* ignore */
		}
	}

	function isNextPageAutostop() {
		try {
			return localStorage.getItem(LS_NEXTPAGE_AUTOSTOP) === '1';
		} catch {
			return false;
		}
	}

	/** Adres çubuğundaki prc=alt-üst (örn. 1011-1100). */
	function getPrcBoundsFromLocation() {
		const usp = new URLSearchParams(location.search);
		const raw = usp.get('prc');
		if (!raw) return null;
		const m = String(raw).trim().match(/^(\d+)\s*-\s*(\d+)$/);
		if (!m) return null;
		const lo = parseInt(m[1], 10);
		const hi = parseInt(m[2], 10);
		if (!Number.isFinite(lo) || !Number.isFinite(hi)) return null;
		return { min: lo, max: hi };
	}

	/** prc: eski üst +1 … eski üst +50; yeni sekmede aç; NextPage akışı için bayrak. */
	function navigateToNextPrcPage() {
		const b = getPrcBoundsFromLocation();
		if (!b) return;
		clearNextPageAutostop();
		clearPrcAutotuneItr();
		clearPrcAutotuneBestCandidate();
		const newMin = b.max + 1;
		const newMax = b.max + 50;
		const usp = new URLSearchParams(location.search);
		usp.set('prc', newMin + '-' + newMax);
		const q = usp.toString();
		const path = location.pathname + (q ? '?' + q : '') + (location.hash || '');
		const url = location.origin + path;
		if (!isNextPageAutostop()) setAfterNextPageFlag();
		if (typeof globalThis.ahtapotOpenUrlInBackgroundTab === 'function') {
			globalThis.ahtapotOpenUrlInBackgroundTab(url);
		} else {
			window.open(url, '_blank', 'noopener,noreferrer');
		}
	}

	function isTyAutoCrawlerEnabled() {
		try {
			return localStorage.getItem(LS_AUTO_CRAWLER_TY) === '1';
		} catch {
			return false;
		}
	}

	function setTyAutoCrawlerEnabled(on) {
		try {
			localStorage.setItem(LS_AUTO_CRAWLER_TY, on ? '1' : '0');
		} catch {
			/* ignore */
		}
	}

	function requestCloseCurrentTab() {
		try {
			if (!chrome || !chrome.runtime || typeof chrome.runtime.sendMessage !== 'function') return;
			chrome.runtime.sendMessage({ type: 'dc-close-current-tab' }, () => {
				/* ignore response */
			});
		} catch {
			/* ignore */
		}
	}

	/**
	 * @param {{
	 *   _tyAutoStartTimer?: ReturnType<typeof setTimeout> | null;
	 *   _tyAutoNextTimer?: ReturnType<typeof setTimeout> | null;
	 * }} ui
	 */
	function clearTyAutoTimers(ui) {
		if (!ui) return;
		if (ui._tyAutoStartTimer != null) {
			clearTimeout(ui._tyAutoStartTimer);
			ui._tyAutoStartTimer = null;
		}
		if (ui._tyAutoNextTimer != null) {
			clearTimeout(ui._tyAutoNextTimer);
			ui._tyAutoNextTimer = null;
		}
	}

	function createApiNextPageButton() {
		const btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'kg-lc-btn kg-lc-btn--ghost';
		btn.textContent = 'NextPage';
		btn.addEventListener('click', () => navigateToNextPrcPage());
		return btn;
	}

	/**
	 * @param {{
	 *   actionsEl: HTMLElement;
	 * }} ui
	 * @param {HTMLElement} [parentEl]
	 */
	function appendApiNextPageIfPrc(ui, parentEl) {
		if (!getPrcBoundsFromLocation()) return;
		(parentEl || ui.actionsEl).appendChild(createApiNextPageButton());
	}

	/**
	 * @param {{
	 *   statusEl: HTMLElement;
	 *   actionsEl: HTMLElement;
	 *   previewEl: HTMLElement;
	 *   onClose: () => void;
	 *   _tyAutoStartTimer?: ReturnType<typeof setTimeout> | null;
	 *   _tyAutoNextTimer?: ReturnType<typeof setTimeout> | null;
	 * }} ui
	 * @param {HTMLElement} parentEl
	 */
	function appendTyAutoCrawlerCheckbox(ui, parentEl) {
		const wrap = document.createElement('label');
		wrap.className = 'kg-lc-auto-crawler';
		const cb = document.createElement('input');
		cb.type = 'checkbox';
		cb.checked = isTyAutoCrawlerEnabled();
		cb.addEventListener('change', function () {
			setTyAutoCrawlerEnabled(cb.checked);
			if (!cb.checked) {
				clearTyAutoTimers(ui);
				return;
			}
			if (!isLcUiActive(ui)) return;
			const primary = ui.actionsEl.querySelector('.kg-lc-btn--primary');
			const label = primary ? primary.textContent.trim() : '';
			if (label === 'Başlat') {
				const pm = pathModelFromLocation();
				if (pm) scheduleTyAutoStartIfEnabled(ui, pm, null);
			} else if (label === 'TXT indir') {
				scheduleTyAutoNextPageIfEnabled(ui);
			}
		});
		const textCol = document.createElement('span');
		textCol.className = 'kg-lc-auto-crawler-text';
		const title = document.createElement('span');
		title.className = 'kg-lc-auto-crawler-title';
		title.textContent = 'Auto Crawler';
		const sub = document.createElement('span');
		sub.className = 'kg-lc-auto-crawler-sub';
		sub.textContent = 'API Başlat + NextPage (prc ile) otomatik';
		textCol.append(title, sub);
		wrap.append(cb, textCol);
		parentEl.appendChild(wrap);
	}

	/**
	 * @param {{
	 *   _tyAutoStartTimer?: ReturnType<typeof setTimeout> | null;
	 *   _tyAutoNextTimer?: ReturnType<typeof setTimeout> | null;
	 * }} ui
	 * @param {string} pathModel
	 */
	function scheduleTyAutoStartIfEnabled(ui, pathModel, resumePayload) {
		clearTyAutoTimers(ui);
		if (!isTyAutoCrawlerEnabled() || !pathModel) return;
		ui._tyAutoStartTimer = setTimeout(function () {
			ui._tyAutoStartTimer = null;
			if (!isLcUiActive(ui)) return;
			void tryAutoStartOrTunePrc(ui, pathModel, resumePayload || null);
		}, TY_AUTO_START_DELAY_MS);
	}

	/**
	 * Auto Crawler: 4500 üstü listede API başlatma — önce prc daralt.
	 * @param {object | null} resumePayload
	 */
	async function tryAutoStartOrTunePrc(ui, pathModel, resumePayload) {
		const seed = apiSeedQueryFromLocation();

		if (resumePayload && Array.isArray(resumePayload.urls) && resumePayload.urls.length > 0) {
			const trimmed = trimUrlListToCrawlMax(resumePayload.urls);
			startApiFetch(
				ui,
				pathModel,
				seed,
				trimmed.length < resumePayload.urls.length ? { ...resumePayload, urls: trimmed } : resumePayload,
			);
			return;
		}

		let n = parseResultCountFromDom();
		if (n == null) {
			ui.statusEl.textContent = 'Auto Crawler: ürün sayısı okunuyor…';
			n = await waitForDomResultCount(22000);
		}

		if (n === 0) {
			const prc = getPrcBoundsFromLocation();
			const prcNote = prc ? ` <code>prc=${prc.min}-${prc.max}</code>` : '';
			ui.statusEl.innerHTML =
				'<p class="kg-lc-p">Bu fiyat aralığında ürün bulunamadı' +
				prcNote +
				'. Auto Crawler durduruldu; başka bir <code>prc</code> deneyin veya NextPage ile devam edin.</p>';
			stopPrcAutotuneFlow();
			return;
		}

		if (n != null && n > RESULT_COUNT_MAX) {
			ui.statusEl.innerHTML =
				'<p class="kg-lc-p">Liste <strong>' +
				escapeHtml(String(n)) +
				'</strong> ürün — Auto Crawler en fazla <strong>' +
				RESULT_COUNT_MAX +
				'</strong> ile başlar. <code>prc</code> aralığı ayarlanıyor…</p>';
			if (!getPrcBoundsFromLocation()) {
				applyInitialPrcForOversizedList();
				return;
			}
			setAfterNextPageFlag();
			runPrcAutotuneThenScheduleAhtapotModal();
			return;
		}

		clearNextPageAutostop();
		startApiFetch(ui, pathModel, seed, null);
	}

	/**
	 * @param {{
	 *   onClose: () => void;
	 *   _tyAutoNextTimer?: ReturnType<typeof setTimeout> | null;
	 * }} ui
	 */
	function scheduleTyAutoNextPageIfEnabled(ui) {
		if (ui._tyAutoNextTimer != null) {
			clearTimeout(ui._tyAutoNextTimer);
			ui._tyAutoNextTimer = null;
		}
		if (!isTyAutoCrawlerEnabled() || !getPrcBoundsFromLocation()) return;
		ui._tyAutoNextTimer = setTimeout(function () {
			ui._tyAutoNextTimer = null;
			if (!isLcUiActive(ui)) return;
			navigateToNextPrcPage();
			requestCloseCurrentTab();
			ui.onClose();
		}, TY_AUTO_NEXTPAGE_DELAY_MS);
	}

	/**
	 * NextPage ile yeni sekmede geldikten sonra: pathModel varsa
	 * Link Crawler giriş ekranını otomatik açar.
	 */
	function scheduleAutoOpenAhtapotModalAfterNextPage() {
		if (isNextPageAutostop()) return;
		if (!getAfterNextPageFlag()) return;

		const deadline = Date.now() + 16000;

		function clearFlag() {
			clearAfterNextPageFlag();
		}

		function tick() {
			if (isNextPageAutostop()) {
				clearFlag();
				return;
			}
			const pm = pathModelFromLocation();
			if (pm) {
				clearFlag();
				if (typeof globalThis.ahtapotLcAutoShowIntro === 'function') {
					globalThis.ahtapotLcAutoShowIntro();
				}
				return;
			}
			if (Date.now() > deadline) {
				clearFlag();
				return;
			}
			setTimeout(tick, 350);
		}

		tick();
	}

	/**
	 * NextPage sonrası sayfa yüklemesinde: ürün sayısına göre prc daralt/genişlet veya modal aç.
	 * Data Crawler `runPrcAutotuneThenScheduleModal` ile aynı mantık.
	 */
	function runPrcAutotuneThenScheduleAhtapotModal() {
		if (isNextPageAutostop()) {
			clearAfterNextPageFlag();
			clearPrcAutotuneItr();
			clearPrcAutotuneBestCandidate();
			return;
		}
		if (!getAfterNextPageFlag()) return;

		if (!getPrcBoundsFromLocation()) {
			const n0 = parseResultCountFromDom();
			if (n0 != null && n0 > RESULT_COUNT_MAX) {
				applyInitialPrcForOversizedList();
				return;
			}
			scheduleModalWhenWithinCrawlLimit();
			return;
		}

		const deadline = Date.now() + 24000;

		function tick() {
			if (isNextPageAutostop()) {
				clearAfterNextPageFlag();
				clearPrcAutotuneItr();
				clearPrcAutotuneBestCandidate();
				return;
			}
			const b = getPrcBoundsFromLocation();
			if (!b) {
				clearPrcAutotuneItr();
				clearPrcAutotuneBestCandidate();
				scheduleModalWhenWithinCrawlLimit();
				return;
			}

			const n = parseResultCountFromDom();
			if (n != null && n > 0) writePrcAutotuneBestCandidate(b, n);

			if (n === 0) {
				stopPrcAutotuneFlow();
				return;
			}

			if (canCrawlListCompletely(n) || isListWithinCrawlLimit(n)) {
				clearPrcAutotuneItr();
				clearPrcAutotuneBestCandidate();
				scheduleModalWhenWithinCrawlLimit();
				return;
			}

			if (n != null) {
				const itr = readPrcAutotuneItr();
				if (itr >= PRC_AUTOTUNE_MAX) {
					const best = readPrcAutotuneBestCandidate();
					if (best && isListWithinCrawlLimit(best.count) && restoreBestPrcAndReload(b)) return;
					if (restoreBestPrcAndReload(b)) return;
					if (!scheduleModalWhenWithinCrawlLimit()) {
						failPrcAutotuneWithoutReset();
					}
					return;
				}
				const next = computeNextPrcBounds(b.min, b.max, n);
				if (!next || (next.min === b.min && next.max === b.max)) {
					const best = readPrcAutotuneBestCandidate();
					if (best && isListWithinCrawlLimit(best.count) && restoreBestPrcAndReload(b)) return;
					if (restoreBestPrcAndReload(b)) return;
					if (!scheduleModalWhenWithinCrawlLimit()) {
						failPrcAutotuneWithoutReset();
					}
					return;
				}
				writePrcAutotuneItr(itr + 1);
				setAfterNextPageFlag();
				replaceLocationKeepingQueryPrc(next.min, next.max);
				return;
			}

			if (Date.now() > deadline) {
				const best = readPrcAutotuneBestCandidate();
				if (best && isListWithinCrawlLimit(best.count) && restoreBestPrcAndReload(b)) return;
				if (restoreBestPrcAndReload(b)) return;
				if (!scheduleModalWhenWithinCrawlLimit()) {
					failPrcAutotuneWithoutReset();
				}
				return;
			}
			setTimeout(tick, 380);
		}

		tick();
	}

	function injectPageScriptSrc(fullUrl) {
		const s = document.createElement('script');
		s.async = false;
		s.src = fullUrl;
		s.onload = () => s.remove();
		(document.documentElement || document.head).appendChild(s);
	}

	/**
	 * @param {object | null} resumePayload chrome.storage’dan; sayfa runner sessionStorage okur
	 */
	function injectApiPageFetchAll(pathModel, seedQuery, resumePayload) {
		try {
			sessionStorage.removeItem(LC_CKPT_SESSION);
		} catch {
			/* ignore */
		}
		if (resumePayload && Array.isArray(resumePayload.urls)) {
			try {
				const urls = trimUrlListToCrawlMax(resumePayload.urls);
				sessionStorage.setItem(
					LC_CKPT_SESSION,
					JSON.stringify({
						urls: urls,
						nextPi: resumePayload.nextPi,
						offset: resumePayload.offset,
						offsetParameters: resumePayload.offsetParameters,
					}),
				);
			} catch (e) {
				console.warn('[Ahtapot] checkpoint sessionStorage dolu veya yazılamadı', e);
			}
		}
		const maxLinks = resolveCrawlLinkMax(parseResultCountFromDom());
		let u = chrome.runtime.getURL(PAGE_SCRIPT_API_RUNNER) + '?pm=' + encodeURIComponent(pathModel);
		if (seedQuery) u += '&seed=' + encodeURIComponent(seedQuery);
		if (resumePayload) u += '&resume=1';
		u += '&maxLinks=' + encodeURIComponent(String(maxLinks));
		injectPageScriptSrc(u);
	}

	/**
	 * @param {object} d checkpoint mesajı
	 */
	async function persistCheckpoint(d) {
		if (!d || !d.pathModel || !Array.isArray(d.urls)) return;
		const urls = trimUrlListToCrawlMax(d.urls);
		try {
			await chrome.storage.local.set({
				[LC_CHECKPOINT_STORAGE_KEY]: {
					pathModel: d.pathModel,
					seed: d.seed || '',
					nextPi: d.nextPi,
					offset: d.offset,
					offsetParameters: d.offsetParameters,
					urls: urls,
					count: urls.length,
					updatedAt: Date.now(),
					locationHref: (location.href || '').split('#')[0],
				},
			});
		} catch (e) {
			console.warn('[Ahtapot] checkpoint kaydedilemedi', e);
		}
	}

	async function clearPersistedCheckpoint() {
		try {
			await chrome.storage.local.remove(LC_CHECKPOINT_STORAGE_KEY);
		} catch {
			/* ignore */
		}
	}

	async function loadPersistedCheckpoint() {
		try {
			const x = await chrome.storage.local.get(LC_CHECKPOINT_STORAGE_KEY);
			return x[LC_CHECKPOINT_STORAGE_KEY] || null;
		} catch {
			return null;
		}
	}

	function checkpointMatchesCurrentPage(ck) {
		if (!ck || !ck.pathModel) return false;
		return ck.pathModel === pathModelFromLocation() && (ck.seed || '') === apiSeedQueryFromLocation();
	}

	function clearApiSession() {
		if (!apiSession) return;
		window.removeEventListener('message', apiSession.onApiMessage);
		apiSession = null;
	}

	function isAllowedTrendyolOrigin(o) {
		return (
			o === 'https://www.trendyol.com' ||
			o === 'https://trendyol.com' ||
			o === 'https://www.trendyol.com.tr' ||
			o === 'https://trendyol.com.tr'
		);
	}

	function downloadTxt(lines, filename) {
		const san =
			typeof globalThis.ahtapotSanitizeTrendyolLines === 'function'
				? globalThis.ahtapotSanitizeTrendyolLines(lines)
				: { lines: lines, stats: null };
		const text = san.lines.join('\n');
		const fn = filename || 'ahtapot-trendyol-urunler-' + Date.now() + '.txt';
		if (typeof globalThis.ahtapotExtensionDownloadText === 'function') {
			globalThis.ahtapotExtensionDownloadText(text, fn);
		} else {
			const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
			const url = URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = fn;
			a.rel = 'noopener';
			(document.body || document.documentElement).appendChild(a);
			a.click();
			a.remove();
			URL.revokeObjectURL(url);
		}
	}

	/** Data Crawler trendyol-app.js ile aynı — zaten sanitize edilmiş satırlar. */
	function downloadCleanTxtLines(lines, filename) {
		const text = lines.join('\n');
		const fn = filename || 'ahtapot-birlesik-' + Date.now() + '.txt';
		if (typeof globalThis.ahtapotExtensionDownloadText === 'function') {
			globalThis.ahtapotExtensionDownloadText(text, fn);
		} else {
			const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
			const url = URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = fn;
			a.rel = 'noopener';
			(document.body || document.documentElement).appendChild(a);
			a.click();
			a.remove();
			URL.revokeObjectURL(url);
		}
	}

	/** @type {{ name: string; text: string }[]} */
	let lcTxtMergeBuffers = [];

	/**
	 * @param {{
	 *   mergeDropEl: HTMLElement;
	 *   mergeFileEl: HTMLInputElement;
	 *   mergeFileWrapEl: HTMLElement;
	 *   mergeFileListEl: HTMLElement;
	 *   mergeStatusEl: HTMLElement;
	 *   mergeActionsEl: HTMLElement;
	 *   _txtMergeBtn?: HTMLButtonElement | null;
	 *   _txtMergeWired?: boolean;
	 * }} ui
	 */
	function clearLcTxtMergeUi(ui) {
		lcTxtMergeBuffers = [];
		if (ui.mergeFileListEl) ui.mergeFileListEl.innerHTML = '';
		if (ui.mergeFileWrapEl) ui.mergeFileWrapEl.hidden = true;
		if (ui.mergeFileEl) ui.mergeFileEl.value = '';
		if (ui.mergeDropEl) ui.mergeDropEl.classList.remove('kg-drag');
		if (ui._txtMergeBtn) ui._txtMergeBtn.disabled = true;
	}

	function refreshLcTxtMergeFileList(ui) {
		const ul = ui.mergeFileListEl;
		ul.innerHTML = '';
		if (!lcTxtMergeBuffers.length) {
			ui.mergeFileWrapEl.hidden = true;
			if (ui._txtMergeBtn) ui._txtMergeBtn.disabled = true;
			return;
		}
		ui.mergeFileWrapEl.hidden = false;
		for (let i = 0; i < lcTxtMergeBuffers.length; i++) {
			const li = document.createElement('li');
			li.textContent = lcTxtMergeBuffers[i].name;
			ul.appendChild(li);
		}
		if (ui._txtMergeBtn) ui._txtMergeBtn.disabled = false;
	}

	function filterLcTxtFiles(fileList) {
		return Array.from(fileList).filter(
			(f) => f.type === 'text/plain' || /\.txt$/i.test(f.name),
		);
	}

	function readLcFileAsText(file) {
		return new Promise((resolve, reject) => {
			const r = new FileReader();
			r.onload = () => resolve(String(r.result || ''));
			r.onerror = () => reject(r.error);
			r.readAsText(file, 'UTF-8');
		});
	}

	/**
	 * @param {{
	 *   mergeDropEl: HTMLElement;
	 *   mergeFileEl: HTMLInputElement;
	 *   mergeFileWrapEl: HTMLElement;
	 *   mergeFileListEl: HTMLElement;
	 *   mergeStatusEl: HTMLElement;
	 *   mergeActionsEl: HTMLElement;
	 *   _txtMergeBtn?: HTMLButtonElement | null;
	 *   _txtMergeWired?: boolean;
	 * }} ui
	 */
	async function addLcTxtMergeFiles(ui, fileList) {
		const files = filterLcTxtFiles(fileList);
		for (let i = 0; i < files.length; i++) {
			try {
				const text = await readLcFileAsText(files[i]);
				lcTxtMergeBuffers.push({ name: files[i].name, text });
			} catch {
				/* atla */
			}
		}
		refreshLcTxtMergeFileList(ui);
		if (lcTxtMergeBuffers.length) {
			ui.mergeStatusEl.textContent =
				lcTxtMergeBuffers.length +
				' dosya eklendi. «Birleştir ve indir» ile URL’ler doğrulanır ve mükerrerler temizlenir.';
		}
	}

	/**
	 * @param {{
	 *   mergeDropEl: HTMLElement;
	 *   mergeFileEl: HTMLInputElement;
	 *   mergeFileWrapEl: HTMLElement;
	 *   mergeFileListEl: HTMLElement;
	 *   mergeStatusEl: HTMLElement;
	 *   mergeActionsEl: HTMLElement;
	 *   _txtMergeBtn?: HTMLButtonElement | null;
	 *   _txtMergeWired?: boolean;
	 * }} ui
	 */
	function wireLcTxtMergeColumn(ui) {
		ui.mergeActionsEl.innerHTML = '';
		const mergeBtn = document.createElement('button');
		mergeBtn.type = 'button';
		mergeBtn.className = 'kg-lc-btn kg-lc-btn--primary';
		mergeBtn.textContent = 'Birleştir ve indir';
		mergeBtn.disabled = true;
		mergeBtn.addEventListener('click', () => {
			if (!lcTxtMergeBuffers.length) return;
			const combined = lcTxtMergeBuffers.map((x) => x.text).join('\n');
			const san =
				typeof globalThis.ahtapotSanitizeUrlLines === 'function'
					? globalThis.ahtapotSanitizeUrlLines(combined)
					: { lines: [], stats: { scanned: 0, kept: 0, invalid: 0, duplicate: 0 } };
			const st = san.stats;
			ui.mergeStatusEl.textContent =
				lcTxtMergeBuffers.length +
				' dosya birleştirildi · Taranan satır: ' +
				st.scanned +
				' · Geçerli benzersiz: ' +
				st.kept +
				' · Geçersiz: ' +
				st.invalid +
				' · Tekrar: ' +
				st.duplicate;
			downloadCleanTxtLines(san.lines, 'ahtapot-birlesik-' + Date.now() + '.txt');
		});
		const clearBtn = document.createElement('button');
		clearBtn.type = 'button';
		clearBtn.className = 'kg-lc-btn kg-lc-btn--ghost';
		clearBtn.textContent = 'Listeyi sıfırla';
		clearBtn.addEventListener('click', () => {
			lcTxtMergeBuffers = [];
			refreshLcTxtMergeFileList(ui);
			ui.mergeStatusEl.textContent = 'Liste boşaltıldı. Yeni dosya ekleyebilirsiniz.';
		});
		ui.mergeActionsEl.append(mergeBtn, clearBtn);
		ui._txtMergeBtn = mergeBtn;

		if (!ui._txtMergeWired) {
			ui._txtMergeWired = true;
			lcTxtMergeBuffers = [];
			const drop = ui.mergeDropEl;
			const input = ui.mergeFileEl;
			drop.addEventListener('click', () => input.click());
			drop.addEventListener('keydown', (e) => {
				if (e.key === 'Enter' || e.key === ' ') {
					e.preventDefault();
					input.click();
				}
			});
			input.addEventListener('change', () => {
				if (input.files && input.files.length) {
					void addLcTxtMergeFiles(ui, input.files);
					input.value = '';
				}
			});
			['dragenter', 'dragover'].forEach((type) => {
				drop.addEventListener(type, (e) => {
					e.preventDefault();
					e.dataTransfer.dropEffect = 'copy';
					drop.classList.add('kg-drag');
				});
			});
			drop.addEventListener('dragleave', (e) => {
				if (!drop.contains(e.relatedTarget)) drop.classList.remove('kg-drag');
			});
			drop.addEventListener('drop', (e) => {
				e.preventDefault();
				drop.classList.remove('kg-drag');
				if (e.dataTransfer.files && e.dataTransfer.files.length) {
					void addLcTxtMergeFiles(ui, e.dataTransfer.files);
				}
			});
		}
		refreshLcTxtMergeFileList(ui);
		ui.mergeStatusEl.textContent =
			'TXT dosyalarını kutuya sürükleyip bırakın veya tıklayarak seçin. Birden fazla dosya tek listede birleştirilir; geçersiz satırlar ve tekrar eden Trendyol ürün linkleri ayıklanır.';
	}

	/**
	 * @param {string} s
	 */
	function escapeHtml(s) {
		return String(s)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	/**
	 * @param {{
	 *   statusEl: HTMLElement;
	 *   actionsEl: HTMLElement;
	 *   previewEl: HTMLElement;
	 *   onClose: () => void;
	 * }} ui
	 */
	async function renderIntro(ui) {
		clearTyAutoTimers(ui);
		clearApiSession();
		const pm = pathModelFromLocation();
		ui.statusEl.innerHTML = '';
		ui.actionsEl.innerHTML = '';
		ui.previewEl.hidden = true;
		ui.previewEl.textContent = '';

		let saved = null;
		try {
			saved = await loadPersistedCheckpoint();
		} catch {
			saved = null;
		}
		const resumeOk = Boolean(saved && checkpointMatchesCurrentPage(saved));

		if (!pm) {
			ui.statusEl.innerHTML =
				'<p class="kg-lc-p">Bu sayfa yolundan <strong>pathModel</strong> çıkarılamadı. Kategori veya arama listesi sayfasında olun (ör. <code class="kg-lc-code">/sr</code> veya kategori yolu).</p>';
			const close = document.createElement('button');
			close.type = 'button';
			close.className = 'kg-lc-btn kg-lc-btn--ghost';
			close.textContent = 'Kapat';
			close.addEventListener('click', () => ui.onClose());
			ui.actionsEl.appendChild(close);
			return;
		}

		const seed = apiSeedQueryFromLocation();
		const seedNote = seed
			? '<br><br>Adres çubuğundaki filtreler API’ye aktarılır (<code>wb</code>, <code>wc</code>, …); sayfadaki <code>pi</code> yok sayılır, tarama <code>pi=1</code>’den başlar.'
			: '';

		const n = parseResultCountFromDom();
		const prcBounds = getPrcBoundsFromLocation();
		let countBlock = n != null ? `<br><br>Liste ürün sayısı (DOM): <strong>${n}</strong>` : '';
		if (n === 0 && prcBounds) {
			countBlock +=
				'<br><br><strong>Bu <code>prc=' +
				prcBounds.min +
				'-' +
				prcBounds.max +
				'</code> aralığında ürün yok.</strong> Auto Crawler bu parçada durur; başka aralık veya NextPage kullanın.';
		}

		let resumeHtml = '';
		if (resumeOk && saved) {
			const t = saved.updatedAt ? new Date(saved.updatedAt).toLocaleString('tr-TR') : '';
			resumeHtml =
				'<div class="kg-lc-resume-banner"><p class="kg-lc-resume-p"><strong>Yarım kalan tarama</strong> · ' +
				escapeHtml(String(saved.count ?? saved.urls?.length ?? 0)) +
				' benzersiz link · sonraki istek <code class="kg-lc-code">pi≥' +
				escapeHtml(String(saved.nextPi ?? '?')) +
				'</code>' +
				(t ? ' · kayıt: ' + escapeHtml(t) : '') +
				'</p><p class="kg-lc-resume-hint">Ağ veya sunucu hatasında konum otomatik kaydedilir; «Kaldığı yerden devam et» ile aynı liste ve sayfadan devam edilir.</p></div>';
		}

		ui.statusEl.innerHTML =
			resumeHtml +
			'<p class="kg-lc-p">pathModel: <code class="kg-lc-code">' +
			escapeHtml(pm) +
			'</code>' +
			seedNote +
			countBlock +
			'</p><p class="kg-lc-p kg-lc-p--muted">İstek tabanı: <code class="kg-lc-code kg-lc-code--sm">' +
			escapeHtml(API_PRODUCTS_BASE) +
			'</code> · JSON içindeki ürün <code>url</code> alanları (içinde <code>-p-</code>) toplanır; sayfalama offset ile devam eder.</p>' +
			'<p class="kg-lc-p kg-lc-p--muted"><em>Auto Crawler</em> açıksa «Başlat» kısa gecikmeyle kendiliğinden çalışır; tarama bittikten sonra adreste <code>prc=…</code> varsa «NextPage» yeni sekmede açılır. Durdurmak için kutuyu kaldırın.</p>';

		if (resumeOk && saved) {
			const resumeRow = document.createElement('div');
			resumeRow.className = 'kg-lc-resume-actions';
			const btnResume = document.createElement('button');
			btnResume.type = 'button';
			btnResume.className = 'kg-lc-btn kg-lc-btn--primary';
			btnResume.textContent = 'Kaldığı yerden devam et';
			btnResume.addEventListener('click', () => startApiFetch(ui, pm, seed, saved));
			const btnClear = document.createElement('button');
			btnClear.type = 'button';
			btnClear.className = 'kg-lc-btn kg-lc-btn--ghost';
			btnClear.textContent = 'Kaydı sil, sıfırdan';
			btnClear.addEventListener('click', async () => {
				await clearPersistedCheckpoint();
				await renderIntro(ui);
			});
			resumeRow.append(btnResume, btnClear);
			ui.actionsEl.appendChild(resumeRow);
		}

		const autoRow = document.createElement('div');
		autoRow.className = 'kg-lc-auto-panel';
		appendTyAutoCrawlerCheckbox(ui, autoRow);
		ui.actionsEl.appendChild(autoRow);

		const btnRow = document.createElement('div');
		btnRow.className = 'kg-lc-actions-row';
		const start = document.createElement('button');
		start.type = 'button';
		start.className = 'kg-lc-btn kg-lc-btn--primary';
		start.textContent = resumeOk ? 'Sıfırdan başlat' : 'Başlat';
		start.addEventListener('click', async () => {
			if (resumeOk) await clearPersistedCheckpoint();
			startApiFetch(ui, pm, seed, null);
		});
		btnRow.appendChild(start);
		appendApiNextPageIfPrc(ui, btnRow);
		ui.actionsEl.appendChild(btnRow);

		if (n !== 0 && !isNextPageAutostop()) {
			scheduleTyAutoStartIfEnabled(ui, pm, resumeOk ? saved : null);
		}
	}

	/**
	 * @param {{
	 *   statusEl: HTMLElement;
	 *   actionsEl: HTMLElement;
	 *   previewEl: HTMLElement;
	 *   onClose: () => void;
	 * }} ui
	 * @param {string} pathModel
	 * @param {string} seedQuery
	 * @param {object | null} resumePayload chrome.storage kaydı veya null
	 */
	function startApiFetch(ui, pathModel, seedQuery, resumePayload) {
		if (resumePayload && Array.isArray(resumePayload.urls)) {
			const trimmed = trimUrlListToCrawlMax(resumePayload.urls);
			if (trimmed.length < resumePayload.urls.length) {
				resumePayload = { ...resumePayload, urls: trimmed };
			}
		}
		clearTyAutoTimers(ui);
		clearApiSession();
		ui.previewEl.hidden = true;
		ui.statusEl.textContent = resumePayload ? 'Kaldığınız yerden devam ediliyor…' : 'İstekler gönderiliyor…';
		ui.actionsEl.innerHTML = '';

		const crawlAutoRow = document.createElement('div');
		crawlAutoRow.className = 'kg-lc-auto-panel';
		appendTyAutoCrawlerCheckbox(ui, crawlAutoRow);
		ui.actionsEl.appendChild(crawlAutoRow);

		const crawlBtnRow = document.createElement('div');
		crawlBtnRow.className = 'kg-lc-actions-row';
		appendApiNextPageIfPrc(ui, crawlBtnRow);
		ui.actionsEl.appendChild(crawlBtnRow);

		function onApiMessage(ev) {
			if (ev.source !== window) return;
			if (!isAllowedTrendyolOrigin(ev.origin || '')) return;
			const d = ev.data;
			if (!d || d.source !== MSG_API_DIRECT) return;

			if (d.phase === 'checkpoint') {
				void persistCheckpoint(d);
				return;
			}
			if (d.phase === 'progress') {
				ui.statusEl.innerHTML = `pi=<strong>${escapeHtml(String(d.pi))}</strong> · toplam <strong>${escapeHtml(String(d.count))}</strong> benzersiz link`;
				return;
			}
			if (d.phase === 'error') {
				clearApiSession();
				const canResume = Boolean(d.canResume);
				const is429 =
					d.status === 429 || /(?:^|\s)429(?:\s|$)/.test(String(d.message || ''));
				const errLine = is429
					? 'İstek kesildi: Trendyol rate limit (HTTP 429) — API çok sık çağrıldı.'
					: 'İstek kesildi: ' +
						(d.message
							? String(d.message)
							: d.status != null
								? 'HTTP ' + d.status
								: 'Bilinmeyen hata');
				const resumeHint = is429
					? '2–5 dakika bekleyin, Trendyol sekmesini yenileyin, sonra «Kaldığı yerden devam et» ile aynı sayfadan tekrar deneyin. Paralel tarama veya Auto Crawler açık başka sekmeler varsa kapatın.'
					: canResume
						? 'İlerleme kaydedildi; «Kaldığı yerden devam et» ile aynı sayfadan tekrar deneyebilirsiniz.'
						: '';
				ui.statusEl.innerHTML =
					'<p class="kg-lc-p">' +
					escapeHtml(errLine) +
					'</p>' +
					(resumeHint
						? '<p class="kg-lc-p kg-lc-p--muted">' + escapeHtml(resumeHint) + '</p>'
						: '');
				ui.actionsEl.innerHTML = '';
				const errAutoRow = document.createElement('div');
				errAutoRow.className = 'kg-lc-auto-panel';
				appendTyAutoCrawlerCheckbox(ui, errAutoRow);
				ui.actionsEl.appendChild(errAutoRow);
				const errBtnRow = document.createElement('div');
				errBtnRow.className = 'kg-lc-actions-row';
				if (canResume) {
					const cont = document.createElement('button');
					cont.type = 'button';
					cont.className = 'kg-lc-btn kg-lc-btn--primary';
					cont.textContent = 'Kaldığı yerden devam et';
					cont.addEventListener('click', async () => {
						const ck = await loadPersistedCheckpoint();
						if (ck && checkpointMatchesCurrentPage(ck)) {
							startApiFetch(ui, pathModel, seedQuery || '', ck);
						} else {
							startApiFetch(ui, pathModel, seedQuery || '', null);
						}
					});
					errBtnRow.appendChild(cont);
				}
				const again = document.createElement('button');
				again.type = 'button';
				again.className = 'kg-lc-btn kg-lc-btn--ghost';
				again.textContent = 'Panele dön';
				again.addEventListener('click', () => void renderIntro(ui));
				errBtnRow.appendChild(again);
				appendApiNextPageIfPrc(ui, errBtnRow);
				ui.actionsEl.appendChild(errBtnRow);
				scheduleTyAutoNextPageIfEnabled(ui);
				return;
			}
			if (d.phase === 'done' && Array.isArray(d.urls)) {
				clearApiSession();
				void finishApi(
					ui,
					d.urls,
					{
						partial: !!d.partial,
						stoppedReason: d.stoppedReason,
						httpStatus: d.httpStatus,
						exceptionMessage: d.exceptionMessage,
						cappedAt: d.cappedAt != null ? Number(d.cappedAt) : null,
					},
					pathModel,
					seedQuery || '',
				);
			}
		}

		window.addEventListener('message', onApiMessage);
		apiSession = { onApiMessage };
		injectApiPageFetchAll(pathModel, seedQuery || '', resumePayload || null);
	}

	/**
	 * @param {{
	 *   statusEl: HTMLElement;
	 *   actionsEl: HTMLElement;
	 *   previewEl: HTMLElement;
	 *   onClose: () => void;
	 * }} ui
	 * @param {string[]} list
	 * @param {{ partial?: boolean }} options
	 * @param {string} pathModel
	 * @param {string} seedQuery
	 */
	async function finishApi(ui, list, options, pathModel, seedQuery) {
		list = trimUrlListToCrawlMax(list);
		const partial = options && options.partial;
		const n = list.length;
		if (partial && n > 0) {
			const why =
				options && options.stoppedReason === 'http'
					? ' (HTTP ' + (options.httpStatus != null ? options.httpStatus : '') + ')'
					: options && options.stoppedReason === 'json'
						? ' (JSON)'
						: options && options.stoppedReason === 'exception' && options.exceptionMessage
							? ' (' + String(options.exceptionMessage).slice(0, 120) + ')'
							: '';
			ui.statusEl.textContent =
				'İşlem kesildi' +
				why +
				'; şu ana kadar toplanan: ' +
				n +
				' link. TXT indirildi. İsterseniz kayıttan devam edin.';
		} else if (partial && n === 0) {
			ui.statusEl.textContent = 'İşlem kesildi (hata); henüz link yok.';
		} else if (n > 0) {
			const capNote =
				options?.cappedAt != null
					? ` (liste üst sınırı: ${options.cappedAt.toLocaleString('tr-TR')})`
					: '';
			ui.statusEl.textContent =
				'İşlem tamamlandı: ' + n + ' ürün linki' + capNote + '. TXT otomatik indirildi.';
		} else {
			ui.statusEl.textContent =
				'İşlem tamamlandı: bu aşamada JSON’da ürün url’si yok (liste sonu veya boş yanıt).';
		}
		ui.previewEl.hidden = false;
		ui.previewEl.textContent = list.slice(0, 50).join('\n') + (list.length > 50 ? '\n…' : '');
		ui.actionsEl.innerHTML = '';
		const finAutoRow = document.createElement('div');
		finAutoRow.className = 'kg-lc-auto-panel';
		appendTyAutoCrawlerCheckbox(ui, finAutoRow);
		ui.actionsEl.appendChild(finAutoRow);
		const finBtnRow = document.createElement('div');
		finBtnRow.className = 'kg-lc-actions-row';
		const dl = document.createElement('button');
		dl.type = 'button';
		dl.className = 'kg-lc-btn kg-lc-btn--primary';
		dl.textContent = 'TXT indir';
		dl.addEventListener('click', () => downloadTxt(list));
		const again = document.createElement('button');
		again.type = 'button';
		again.className = 'kg-lc-btn kg-lc-btn--ghost';
		again.textContent = 'Yeniden';
		again.addEventListener('click', () => void renderIntro(ui));
		finBtnRow.append(dl, again);
		appendApiNextPageIfPrc(ui, finBtnRow);
		ui.actionsEl.appendChild(finBtnRow);

		if (n > 0) {
			const name = 'ahtapot-trendyol-urunler-' + Date.now() + '.txt';
			requestAnimationFrame(function () {
				downloadTxt(list, name);
			});
		}

		if (!partial) {
			await clearPersistedCheckpoint();
		} else if (n > 0) {
			try {
				const cur = await loadPersistedCheckpoint();
				if (cur && cur.pathModel === pathModel && (cur.seed || '') === seedQuery) {
					await chrome.storage.local.set({
						[LC_CHECKPOINT_STORAGE_KEY]: {
							...cur,
							urls: list,
							count: list.length,
							updatedAt: Date.now(),
						},
					});
				} else {
					await persistCheckpoint({
						pathModel,
						seed: seedQuery,
						urls: list,
						count: list.length,
						nextPi: 1,
						offset: null,
						offsetParameters: null,
					});
				}
			} catch (e) {
				console.warn('[Ahtapot] partial checkpoint güncellenemedi', e);
			}
		}

		scheduleTyAutoNextPageIfEnabled(ui);
	}

	function parseHbTotalProductCountFromHtml(html) {
		const blob =
			html != null
				? String(html)
				: [
						document.documentElement?.innerHTML || '',
						...Array.from(document.querySelectorAll('script:not([src])')).map(
							(s) => s.textContent || '',
						),
					].join('\n');
		if (!blob.includes('totalProductCount')) return null;
		const m = blob.match(/"totalProductCount"\s*:\s*(\d+)/);
		if (!m) return null;
		const n = parseInt(m[1], 10);
		return Number.isFinite(n) ? n : null;
	}

	function parseHbCountFromText(text) {
		const t = String(text || '').replace(/\s+/g, ' ').trim();
		const m = t.match(/([\d.]+)\s*\+?\s*(?:[Uu]rün|[Ss]onuç|[Uu]rünler)/);
		if (!m) return null;
		const digits = m[1].replace(/\./g, '');
		const n = parseInt(digits, 10);
		return Number.isFinite(n) ? n : null;
	}

	/** Hepsiburada kategori listesi ürün sayısı — önce sayfa JSON, sonra DOM. */
	function parseHbResultCountFromDom() {
		const fromJson = parseHbTotalProductCountFromHtml();
		if (fromJson != null) return fromJson;

		const selectors = [
			'[data-test-id="total-product-count"]',
			'[data-test-id="product-count"]',
			'.totalProductCount',
			'.productListContent-header-desc',
			'[class*="totalCount"]',
			'[class*="resultCount"]',
		];
		for (let i = 0; i < selectors.length; i++) {
			const el = document.querySelector(selectors[i]);
			if (!el) continue;
			const n = parseHbCountFromText(el.textContent);
			if (n != null) return n;
		}
		const bodyText = document.body?.innerText || '';
		const m = bodyText.match(/([\d.]+)\s*\+?\s*[Uu]rün/);
		if (m) {
			const digits = m[1].replace(/\./g, '');
			const n = parseInt(digits, 10);
			if (Number.isFinite(n)) return n;
		}
		return null;
	}

	function waitForHbDomResultCount(deadlineMs) {
		return new Promise((resolve) => {
			const deadline = Date.now() + deadlineMs;
			function tick() {
				const n = parseHbResultCountFromDom();
				if (n != null) {
					resolve(n);
					return;
				}
				if (Date.now() > deadline) {
					resolve(null);
					return;
				}
				setTimeout(tick, 350);
			}
			tick();
		});
	}

	function isHbListWithinCrawlLimit(n) {
		return typeof n === 'number' && n >= HB_RESULT_COUNT_MIN && n <= HB_RESULT_COUNT_MAX;
	}

	function canHbCrawlListCompletely(n) {
		return isHbListWithinCrawlLimit(n);
	}

	function hbNextFiyatWindowWidth(bounds) {
		const width = bounds.max - bounds.min + 1;
		return Math.max(50, Math.min(2500, width));
	}

	function trimHbUrlListToMax(urls) {
		if (!Array.isArray(urls)) return [];
		if (urls.length <= HB_CRAWL_LINK_MAX) return urls;
		return urls.slice(0, HB_CRAWL_LINK_MAX);
	}

	function parseHbCategoryId(input) {
		const text = String(input || '').trim();
		if (!text) return null;
		const fromUrl = text.match(/-c-(\d+)/i);
		if (fromUrl) return fromUrl[1];
		try {
			const u = new URL(text);
			const f = u.searchParams.get('filter');
			const fromFilter = String(f || '').match(/categoryId:(\d+)/i);
			if (fromFilter) return fromFilter[1];
		} catch {
			/* ignore */
		}
		return null;
	}

	function normalizeHbProductUrl(rawUrl) {
		const raw = String(rawUrl || '').trim();
		if (!raw) return null;
		try {
			const absolute = new URL(raw, 'https://www.hepsiburada.com');
			const host = absolute.hostname.replace(/^www\./i, '').toLowerCase();
			if (host !== 'hepsiburada.com') return null;
			if (!/-p[m]?-[a-z0-9]+/i.test(absolute.pathname)) return null;
			absolute.hash = '';
			return absolute.toString();
		} catch {
			return null;
		}
	}

	function setHbFiyatFilterInParams(usp, min, max) {
		let filtreler = usp.get('filtreler') || '';
		const fiyatPart = `fiyat:${min}-${max}`;
		if (/fiyat:\d+-\d+/i.test(filtreler)) {
			filtreler = filtreler.replace(/fiyat:\d+-\d+/gi, fiyatPart);
		} else if (filtreler.trim()) {
			filtreler = `${filtreler.trim()};${fiyatPart}`;
		} else {
			filtreler = fiyatPart;
		}
		usp.set('filtreler', filtreler);
	}

	function parseHbFiyatBoundsFromString(str) {
		let decoded = String(str || '');
		try {
			decoded = decodeURIComponent(decoded);
		} catch {
			/* ignore */
		}
		const m = decoded.match(/fiyat:(\d+)\s*-\s*(\d+)/i);
		if (!m) return null;
		const min = parseInt(m[1], 10);
		const max = parseInt(m[2], 10);
		if (!Number.isFinite(min) || !Number.isFinite(max) || max < min) return null;
		return { min, max };
	}

	function parseHbAppliedFiyatFromPageState(html) {
		const blob =
			html != null
				? String(html)
				: [
						document.documentElement?.innerHTML || '',
						...Array.from(document.querySelectorAll('script:not([src])')).map(
							(s) => s.textContent || '',
						),
					].join('\n');
		const patterns = [
			/"filtreler"\s*:\s*"fiyat:(\d+)-(\d+)"/i,
			/"filter"\s*:\s*"fiyat:(\d+)-(\d+)"/i,
			/"selectedFilters"\s*:\s*\[[^\]]*"fiyat:(\d+)-(\d+)"/i,
			/"priceFilter"\s*:\s*\{[^}]*"min"\s*:\s*(\d+)[^}]*"max"\s*:\s*(\d+)/i,
			/"minPrice"\s*:\s*(\d+)\s*,\s*"maxPrice"\s*:\s*(\d+)/i,
		];
		for (let i = 0; i < patterns.length; i++) {
			const m = blob.match(patterns[i]);
			if (!m) continue;
			const min = parseInt(m[1], 10);
			const max = parseInt(m[2], 10);
			if (Number.isFinite(min) && Number.isFinite(max) && max >= min) {
				return { min, max };
			}
		}
		return null;
	}

	function rememberHbPendingFiyatBounds(bounds) {
		if (!bounds) return;
		try {
			sessionStorage.setItem(SESSION_HB_PENDING_FIYAT_BOUNDS, JSON.stringify(bounds));
		} catch {
			/* ignore */
		}
	}

	function readHbPendingFiyatBounds() {
		try {
			const raw = sessionStorage.getItem(SESSION_HB_PENDING_FIYAT_BOUNDS);
			if (!raw) return null;
			const parsed = JSON.parse(raw);
			if (
				parsed &&
				Number.isFinite(parsed.min) &&
				Number.isFinite(parsed.max) &&
				parsed.max >= parsed.min
			) {
				return parsed;
			}
		} catch {
			/* ignore */
		}
		return null;
	}

	function clearHbPendingFiyatBounds() {
		try {
			sessionStorage.removeItem(SESSION_HB_PENDING_FIYAT_BOUNDS);
		} catch {
			/* ignore */
		}
	}

	function getHbFiyatBoundsFromUrlOnly() {
		const fromHref = parseHbFiyatBoundsFromString(location.href);
		if (fromHref) return fromHref;
		const usp = new URLSearchParams(location.search);
		return parseHbFiyatBoundsFromString(usp.get('filtreler') || '');
	}

	function getHbFiyatBoundsFromLocation() {
		const fromUrl = getHbFiyatBoundsFromUrlOnly();
		if (fromUrl) {
			rememberHbFiyatBounds(fromUrl);
			return fromUrl;
		}
		const fromState = parseHbAppliedFiyatFromPageState();
		if (fromState) {
			rememberHbFiyatBounds(fromState);
			return fromState;
		}
		return null;
	}

	function getHbFiyatBoundsForNavigation() {
		const fromUrl = getHbFiyatBoundsFromUrlOnly();
		if (fromUrl) return fromUrl;
		const pending = readHbPendingFiyatBounds();
		if (pending) return pending;
		try {
			const raw = sessionStorage.getItem(SESSION_HB_LAST_FIYAT_BOUNDS);
			if (!raw) return null;
			const parsed = JSON.parse(raw);
			if (
				parsed &&
				Number.isFinite(parsed.min) &&
				Number.isFinite(parsed.max) &&
				parsed.max >= parsed.min
			) {
				return parsed;
			}
		} catch {
			/* ignore */
		}
		return null;
	}

	function rememberHbFiyatBounds(bounds) {
		if (!bounds) return;
		try {
			sessionStorage.setItem(SESSION_HB_LAST_FIYAT_BOUNDS, JSON.stringify(bounds));
		} catch {
			/* ignore */
		}
	}

	function rememberHbCategoryUrl(url) {
		const u = String(url || '').split('#')[0].trim();
		if (!u) return;
		try {
			sessionStorage.setItem(SESSION_HB_LC_CATEGORY_URL, u);
		} catch {
			/* ignore */
		}
	}

	function readHbCategoryUrl() {
		try {
			const u = sessionStorage.getItem(SESSION_HB_LC_CATEGORY_URL);
			return u ? String(u).split('#')[0] : '';
		} catch {
			return '';
		}
	}

	function getHbFiyatBoundsCached() {
		const live = getHbFiyatBoundsFromLocation();
		if (live) return live;
		try {
			const raw = sessionStorage.getItem(SESSION_HB_LAST_FIYAT_BOUNDS);
			if (!raw) return null;
			const parsed = JSON.parse(raw);
			if (
				parsed &&
				Number.isFinite(parsed.min) &&
				Number.isFinite(parsed.max) &&
				parsed.max >= parsed.min
			) {
				return parsed;
			}
		} catch {
			/* ignore */
		}
		return null;
	}

	function buildHbUrlWithFiyat(href, min, max) {
		const u = new URL(String(href || location.href).split('#')[0]);
		const parts = [];
		u.searchParams.forEach((val, key) => {
			if (key === 'filtreler' || key === 'sayfa') return;
			parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(val)}`);
		});
		parts.push(`filtreler=fiyat:${min}-${max}`);
		return `${u.origin}${u.pathname}?${parts.join('&')}`;
	}

	function hbUrlsMatchFiyat(a, b) {
		if (!a || !b) return false;
		const pa = parseHbFiyatBoundsFromString(a);
		const pb = parseHbFiyatBoundsFromString(b);
		return !!(pa && pb && pa.min === pb.min && pa.max === pb.max);
	}

	/** NextPage sonrası sayfa state URL ile uyumlu değilse tam yenileme. */
	function ensureHbPendingFiyatOnPage() {
		const pending = readHbPendingFiyatBounds();
		if (!pending || !getHbAfterNextPageFlag()) return false;

		const urlBounds = getHbFiyatBoundsFromUrlOnly();
		const applied = parseHbAppliedFiyatFromPageState();
		const urlOk =
			urlBounds &&
			urlBounds.min === pending.min &&
			urlBounds.max === pending.max;
		const appliedOk =
			applied &&
			applied.min === pending.min &&
			applied.max === pending.max;

		if (urlOk && appliedOk) {
			clearHbPendingFiyatBounds();
			rememberHbFiyatBounds(pending);
			rememberHbCategoryUrl(location.href.split('#')[0]);
			return false;
		}

		const target = buildHbUrlWithFiyat(
			readHbCategoryUrl() || location.href,
			pending.min,
			pending.max,
		);
		const current = location.href.split('#')[0];
		if (current !== target && !hbUrlsMatchFiyat(current, target)) {
			location.replace(target);
			return true;
		}

		if (urlOk && !appliedOk) {
			location.reload();
			return true;
		}

		return false;
	}

	function consumeHbForceAutoStart() {
		try {
			if (localStorage.getItem(LS_HB_FORCE_AUTO_START) !== '1') return false;
			localStorage.removeItem(LS_HB_FORCE_AUTO_START);
			return isHbAutoCrawlerEnabled();
		} catch {
			return false;
		}
	}

	function setHbForceAutoStartPending() {
		if (!isHbAutoCrawlerEnabled()) return;
		try {
			localStorage.setItem(LS_HB_FORCE_AUTO_START, '1');
		} catch {
			/* ignore */
		}
	}

	function replaceLocationKeepingQueryHbFiyat(min, max) {
		const base = readHbCategoryUrl() || location.href;
		const url = buildHbUrlWithFiyat(base, min, max);
		rememberHbCategoryUrl(url);
		location.replace(url);
	}

	function navigateHbFiyatForAutotune(min, max) {
		setHbAfterNextPageFlag();
		setHbForceAutoStartPending();
		replaceLocationKeepingQueryHbFiyat(min, max);
	}

	function setHbAfterNextPageFlag() {
		try {
			localStorage.setItem(LS_AFTER_NEXTPAGE_HB, String(Date.now()));
		} catch {
			/* ignore */
		}
	}

	function getHbAfterNextPageFlag() {
		try {
			const raw = localStorage.getItem(LS_AFTER_NEXTPAGE_HB);
			if (!raw) return false;
			const t = parseInt(raw, 10);
			if (!Number.isFinite(t) || Date.now() - t > AFTER_NEXTPAGE_TTL_MS) {
				localStorage.removeItem(LS_AFTER_NEXTPAGE_HB);
				return false;
			}
			return true;
		} catch {
			return false;
		}
	}

	function clearHbAfterNextPageFlag() {
		try {
			localStorage.removeItem(LS_AFTER_NEXTPAGE_HB);
		} catch {
			/* ignore */
		}
	}

	function isHbNextPageAutostop() {
		try {
			return localStorage.getItem(LS_NEXTPAGE_AUTOSTOP_HB) === '1';
		} catch {
			return false;
		}
	}

	function clearHbNextPageAutostop() {
		try {
			localStorage.removeItem(LS_NEXTPAGE_AUTOSTOP_HB);
		} catch {
			/* ignore */
		}
	}

	function stopHbFiyatAutotuneFlow() {
		clearHbAfterNextPageFlag();
		clearHbFiyatAutotuneItr();
		clearHbFiyatAutotuneBestCandidate();
		try {
			localStorage.setItem(LS_NEXTPAGE_AUTOSTOP_HB, '1');
		} catch {
			/* ignore */
		}
	}

	function applyInitialHbFiyatForOversizedList() {
		clearHbNextPageAutostop();
		clearHbFiyatAutotuneItr();
		clearHbFiyatAutotuneBestCandidate();
		navigateHbFiyatForAutotune(1, 100);
	}

	function readHbFiyatAutotuneItr() {
		try {
			const v = parseInt(sessionStorage.getItem(SESSION_HB_FIYAT_AUTOTUNE_ITR) || '0', 10);
			return Number.isFinite(v) && v >= 0 ? v : 0;
		} catch {
			return 0;
		}
	}

	function writeHbFiyatAutotuneItr(n) {
		try {
			sessionStorage.setItem(SESSION_HB_FIYAT_AUTOTUNE_ITR, String(n));
		} catch {
			/* ignore */
		}
	}

	function clearHbFiyatAutotuneItr() {
		try {
			sessionStorage.removeItem(SESSION_HB_FIYAT_AUTOTUNE_ITR);
		} catch {
			/* ignore */
		}
	}

	function getHbResultCountDistanceFromTarget(n) {
		if (!Number.isFinite(n)) return Number.POSITIVE_INFINITY;
		if (n < HB_RESULT_COUNT_MIN) return HB_RESULT_COUNT_MIN - n;
		if (n > HB_RESULT_COUNT_MAX) return n - HB_RESULT_COUNT_MAX;
		return 0;
	}

	function readHbFiyatAutotuneBestCandidate() {
		try {
			const raw = sessionStorage.getItem(SESSION_HB_FIYAT_AUTOTUNE_BEST);
			if (!raw) return null;
			const parsed = JSON.parse(raw);
			if (
				!parsed ||
				!Number.isFinite(parsed.min) ||
				!Number.isFinite(parsed.max) ||
				parsed.max < parsed.min ||
				!Number.isFinite(parsed.count)
			) {
				return null;
			}
			return parsed;
		} catch {
			return null;
		}
	}

	function writeHbFiyatAutotuneBestCandidate(bounds, count) {
		if (
			!bounds ||
			!Number.isFinite(bounds.min) ||
			!Number.isFinite(bounds.max) ||
			bounds.max < bounds.min ||
			!Number.isFinite(count)
		) {
			return;
		}
		const next = {
			min: bounds.min,
			max: bounds.max,
			count,
			distance: getHbResultCountDistanceFromTarget(count),
		};
		try {
			const cur = readHbFiyatAutotuneBestCandidate();
			if (cur && cur.distance < next.distance) return;
			sessionStorage.setItem(SESSION_HB_FIYAT_AUTOTUNE_BEST, JSON.stringify(next));
		} catch {
			/* ignore */
		}
	}

	function clearHbFiyatAutotuneBestCandidate() {
		try {
			sessionStorage.removeItem(SESSION_HB_FIYAT_AUTOTUNE_BEST);
		} catch {
			/* ignore */
		}
	}

	function computeNextHbFiyatBounds(min, max, n) {
		const width = max - min;
		if (!Number.isFinite(min) || !Number.isFinite(max) || width < 1) return null;

		if (n != null && n > HB_RESULT_COUNT_MAX) {
			let step = Math.max(10, Math.min(250, Math.ceil(width * 0.18)));
			if (width < 30) step = Math.max(2, Math.floor(width / 3));
			let newMax = max - step;
			if (newMax <= min + 5) newMax = min + Math.max(8, Math.min(width - 1, 40));
			if (newMax <= min || newMax >= max) return null;
			return { min, max: newMax };
		}

		if (n != null && n >= 1 && n < HB_RESULT_COUNT_MIN) {
			const gap = HB_RESULT_COUNT_MIN - n;
			const step = Math.max(40, Math.min(500, Math.max(10, Math.ceil(gap / 6))));
			const newMax = max + step;
			if (newMax <= max) return null;
			return { min, max: newMax };
		}

		return null;
	}

	function restoreBestHbFiyatAndReload(currentBounds) {
		const best = readHbFiyatAutotuneBestCandidate();
		if (!best || best.count === 0) return false;
		if (
			currentBounds &&
			best.min === currentBounds.min &&
			best.max === currentBounds.max
		) {
			return false;
		}
		clearHbFiyatAutotuneItr();
		clearHbFiyatAutotuneBestCandidate();
		navigateHbFiyatForAutotune(best.min, best.max);
		return true;
	}

	function navigateToNextHbFiyatPage(options) {
		const b = getHbFiyatBoundsForNavigation();
		if (!b) return;
		clearHbNextPageAutostop();
		clearHbFiyatAutotuneItr();
		clearHbFiyatAutotuneBestCandidate();
		const newMin = b.max + 1;
		const newMax = b.max + hbNextFiyatWindowWidth(b);
		const nextBounds = { min: newMin, max: newMax };
		const base =
			readHbCategoryUrl() ||
			`${location.origin}${location.pathname}${location.search || ''}`.split('#')[0];
		const url = buildHbUrlWithFiyat(base, newMin, newMax);
		rememberHbFiyatBounds(nextBounds);
		rememberHbPendingFiyatBounds(nextBounds);
		rememberHbCategoryUrl(url);
		if (!isHbNextPageAutostop()) {
			setHbAfterNextPageFlag();
			setHbForceAutoStartPending();
		}
		const sameTab = options?.sameTab === true || isHbAutoCrawlerEnabled();
		if (sameTab) {
			location.replace(url);
			return;
		}
		if (typeof globalThis.ahtapotOpenUrlInBackgroundTab === 'function') {
			globalThis.ahtapotOpenUrlInBackgroundTab(url);
		} else {
			window.open(url, '_blank', 'noopener,noreferrer');
		}
	}

	function isHbAutoCrawlerEnabled() {
		try {
			return localStorage.getItem(LS_AUTO_CRAWLER_HB) === '1';
		} catch {
			return false;
		}
	}

	function setHbAutoCrawlerEnabled(on) {
		try {
			localStorage.setItem(LS_AUTO_CRAWLER_HB, on ? '1' : '0');
		} catch {
			/* ignore */
		}
	}

	function clearHbAutoTimers(ui) {
		if (!ui) return;
		if (ui._hbAutoStartTimer != null) {
			clearTimeout(ui._hbAutoStartTimer);
			ui._hbAutoStartTimer = null;
		}
		if (ui._hbAutoNextTimer != null) {
			clearTimeout(ui._hbAutoNextTimer);
			ui._hbAutoNextTimer = null;
		}
	}

	function createHbNextPageButton() {
		const btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'kg-lc-btn kg-lc-btn--ghost';
		btn.textContent = 'NextPage';
		btn.addEventListener('click', () => navigateToNextHbFiyatPage());
		return btn;
	}

	function appendHbNextPageIfFiyat(ui, parentEl) {
		if (!getHbFiyatBoundsForNavigation()) return;
		(parentEl || ui.actionsEl).appendChild(createHbNextPageButton());
	}

	function appendHbAutoCrawlerCheckbox(ui, parentEl) {
		const wrap = document.createElement('label');
		wrap.className = 'kg-lc-auto-crawler';
		const cb = document.createElement('input');
		cb.type = 'checkbox';
		cb.checked = isHbAutoCrawlerEnabled();
		cb.addEventListener('change', function () {
			setHbAutoCrawlerEnabled(cb.checked);
			if (!cb.checked) {
				clearHbAutoTimers(ui);
				return;
			}
			if (!isLcUiActive(ui)) return;
			const primary = ui.actionsEl.querySelector('.kg-lc-btn--primary');
			const label = primary ? primary.textContent.trim() : '';
			if (label === 'Başlat') {
				scheduleHbAutoStartIfEnabled(ui);
			} else if (label === 'TXT indir') {
				scheduleHbAutoNextPageIfEnabled(ui);
			}
		});
		const textCol = document.createElement('span');
		textCol.className = 'kg-lc-auto-crawler-text';
		const title = document.createElement('span');
		title.className = 'kg-lc-auto-crawler-title';
		title.textContent = 'Auto Crawler';
		const sub = document.createElement('span');
		sub.className = 'kg-lc-auto-crawler-sub';
		sub.textContent = 'Başlat + NextPage otomatik · fiyat dilimi hedefi 750–1500 ürün';
		textCol.append(title, sub);
		wrap.append(cb, textCol);
		parentEl.appendChild(wrap);
	}

	function scheduleHbAutoStartIfEnabled(ui) {
		clearHbAutoTimers(ui);
		if (!isHbAutoCrawlerEnabled()) return;
		ui._hbAutoStartTimer = setTimeout(function () {
			ui._hbAutoStartTimer = null;
			if (!isLcUiActive(ui)) return;
			void tryAutoStartOrTuneHbFiyat(ui);
		}, HB_AUTO_START_DELAY_MS);
	}

	function invokeHbLinkFetchFromUi(ui) {
		if (ui && typeof ui.startLinkFetch === 'function') {
			void ui.startLinkFetch();
			return true;
		}
		return false;
	}

	async function tryAutoStartOrTuneHbFiyat(ui) {
		const forceAuto = consumeHbForceAutoStart();
		let n = parseHbResultCountFromDom();
		if (n == null) {
			ui.statusEl.textContent = 'Auto Crawler: ürün sayısı okunuyor…';
			n = await waitForHbDomResultCount(forceAuto ? 28000 : 22000);
		}

		if (n != null && isHbListWithinCrawlLimit(n)) {
			clearHbNextPageAutostop();
			clearHbAfterNextPageFlag();
			if (invokeHbLinkFetchFromUi(ui)) return;
		}

		if (n === 0) {
			const fiyat = getHbFiyatBoundsCached();
			const fiyatNote = fiyat ? ` <code>fiyat:${fiyat.min}-${fiyat.max}</code>` : '';
			ui.statusEl.innerHTML =
				'<p class="kg-lc-p">Bu fiyat aralığında ürün bulunamadı' +
				fiyatNote +
				'. Auto Crawler durduruldu; başka aralık veya NextPage kullanın.</p>';
			stopHbFiyatAutotuneFlow();
			return;
		}

		if (n != null && n > HB_RESULT_COUNT_MAX) {
			ui.statusEl.innerHTML =
				'<p class="kg-lc-p">Liste <strong>' +
				escapeHtml(String(n)) +
				'</strong> ürün — hedef en fazla <strong>' +
				HB_RESULT_COUNT_MAX +
				'</strong>. Fiyat aralığı daraltılıyor…</p>';
			if (!getHbFiyatBoundsCached()) {
				applyInitialHbFiyatForOversizedList();
				return;
			}
			setHbAfterNextPageFlag();
			runHbFiyatAutotuneThenScheduleAhtapotModal();
			return;
		}

		if (n != null && n >= 1 && n < HB_RESULT_COUNT_MIN) {
			ui.statusEl.innerHTML =
				'<p class="kg-lc-p">Liste <strong>' +
				escapeHtml(String(n)) +
				'</strong> ürün — hedef en az <strong>' +
				HB_RESULT_COUNT_MIN +
				'</strong>. Fiyat aralığı genişletiliyor…</p>';
			if (!getHbFiyatBoundsCached()) {
				ui.statusEl.innerHTML =
					'<p class="kg-lc-p">Fiyat filtresi yok; önce <code>filtreler=fiyat:…</code> ekleyin veya çok büyük listeyi daraltın.</p>';
				return;
			}
			setHbAfterNextPageFlag();
			runHbFiyatAutotuneThenScheduleAhtapotModal();
			return;
		}

		clearHbNextPageAutostop();
		if (invokeHbLinkFetchFromUi(ui)) return;
		ui.statusEl.innerHTML =
			'<p class="kg-lc-p">Auto Crawler: tarama başlatılamadı — <strong>Başlat</strong> düğmesine tıklayın.</p>';
	}

	function scheduleHbAutoNextPageIfEnabled(ui) {
		if (ui._hbAutoNextTimer != null) {
			clearTimeout(ui._hbAutoNextTimer);
			ui._hbAutoNextTimer = null;
		}
		if (!isHbAutoCrawlerEnabled() || !getHbFiyatBoundsForNavigation()) return;
		ui._hbAutoNextTimer = setTimeout(function () {
			ui._hbAutoNextTimer = null;
			if (!isLcUiActive(ui)) return;
			rememberHbCategoryUrl(readHbCategoryUrl() || location.href.split('#')[0]);
			ui.onClose();
			navigateToNextHbFiyatPage({ sameTab: true });
		}, HB_AUTO_NEXTPAGE_DELAY_MS);
	}

	function scheduleHbModalWhenWithinCrawlLimit() {
		const n = parseHbResultCountFromDom();
		if (n === 0) {
			stopHbFiyatAutotuneFlow();
			return false;
		}
		if (n == null || !isHbListWithinCrawlLimit(n)) return false;
		clearHbNextPageAutostop();
		setHbForceAutoStartPending();
		scheduleAutoOpenHbLinkCrawlerModalAfterNextPage();
		return true;
	}

	function scheduleAutoOpenHbLinkCrawlerModalAfterNextPage() {
		if (isHbNextPageAutostop()) return;
		if (!getHbAfterNextPageFlag()) return;

		const deadline = Date.now() + 20000;

		function clearFlag() {
			clearHbAfterNextPageFlag();
		}

		function tick() {
			if (isHbNextPageAutostop()) {
				clearFlag();
				return;
			}
			if (!/-c-\d+/i.test(location.pathname || '')) {
				if (Date.now() > deadline) {
					clearFlag();
					return;
				}
				setTimeout(tick, 350);
				return;
			}
			const n = parseHbResultCountFromDom();
			if (n === 0) {
				stopHbFiyatAutotuneFlow();
				clearFlag();
				return;
			}
			if (n == null && Date.now() < deadline) {
				setTimeout(tick, 350);
				return;
			}
			if (n == null || !isHbListWithinCrawlLimit(n)) {
				if (Date.now() < deadline) {
					setTimeout(tick, 350);
					return;
				}
				clearFlag();
				setHbAfterNextPageFlag();
				runHbFiyatAutotuneThenScheduleAhtapotModal();
				return;
			}
			clearFlag();
			clearHbNextPageAutostop();
			setHbForceAutoStartPending();
			if (typeof globalThis.ahtapotLcAutoShowIntro === 'function') {
				globalThis.ahtapotLcAutoShowIntro();
			}
		}

		tick();
	}

	function runHbFiyatAutotuneThenScheduleAhtapotModal() {
		if (isHbNextPageAutostop()) {
			clearHbAfterNextPageFlag();
			clearHbFiyatAutotuneItr();
			clearHbFiyatAutotuneBestCandidate();
			clearHbPendingFiyatBounds();
			return;
		}
		if (!getHbAfterNextPageFlag()) return;

		if (ensureHbPendingFiyatOnPage()) return;

		const nQuick = parseHbResultCountFromDom();
		if (nQuick != null && nQuick > 0 && isHbListWithinCrawlLimit(nQuick)) {
			clearHbFiyatAutotuneItr();
			clearHbFiyatAutotuneBestCandidate();
			scheduleHbModalWhenWithinCrawlLimit();
			return;
		}

		if (!getHbFiyatBoundsFromLocation()) {
			const n0 = parseHbResultCountFromDom();
			if (n0 != null && n0 > HB_RESULT_COUNT_MAX) {
				applyInitialHbFiyatForOversizedList();
				return;
			}
			scheduleHbModalWhenWithinCrawlLimit();
			return;
		}

		const deadline = Date.now() + 24000;

		function tick() {
			if (isHbNextPageAutostop()) {
				clearHbAfterNextPageFlag();
				clearHbFiyatAutotuneItr();
				clearHbFiyatAutotuneBestCandidate();
				return;
			}
			const b = getHbFiyatBoundsFromLocation();
			if (!b) {
				clearHbFiyatAutotuneItr();
				clearHbFiyatAutotuneBestCandidate();
				scheduleHbModalWhenWithinCrawlLimit();
				return;
			}

			const n = parseHbResultCountFromDom();
			if (n != null && n > 0) writeHbFiyatAutotuneBestCandidate(b, n);

			if (n === 0) {
				stopHbFiyatAutotuneFlow();
				return;
			}

			if (canHbCrawlListCompletely(n)) {
				clearHbFiyatAutotuneItr();
				clearHbFiyatAutotuneBestCandidate();
				scheduleHbModalWhenWithinCrawlLimit();
				return;
			}

			if (n != null) {
				const itr = readHbFiyatAutotuneItr();
				if (itr >= HB_FIYAT_AUTOTUNE_MAX) {
					if (restoreBestHbFiyatAndReload(b)) return;
					if (!scheduleHbModalWhenWithinCrawlLimit()) stopHbFiyatAutotuneFlow();
					return;
				}
				const next = computeNextHbFiyatBounds(b.min, b.max, n);
				if (!next || (next.min === b.min && next.max === b.max)) {
					if (restoreBestHbFiyatAndReload(b)) return;
					if (!scheduleHbModalWhenWithinCrawlLimit()) stopHbFiyatAutotuneFlow();
					return;
				}
				writeHbFiyatAutotuneItr(itr + 1);
				navigateHbFiyatForAutotune(next.min, next.max);
				return;
			}

			if (Date.now() > deadline) {
				if (restoreBestHbFiyatAndReload(b)) return;
				if (!scheduleHbModalWhenWithinCrawlLimit()) stopHbFiyatAutotuneFlow();
				return;
			}
			setTimeout(tick, 380);
		}

		tick();
	}

	function buildHbCategoryPageUrl(rawUrl, page) {
		const u = new URL(String(rawUrl || '').trim());
		if (page <= 1) u.searchParams.delete('sayfa');
		else u.searchParams.set('sayfa', String(page));
		return u.toString();
	}

	function collectHbLinksFromDocument(doc) {
		const seen = new Set();
		const strictSelector =
			'ul.productListContent-frGrtf5XrVXRwJ05HUfU.productListContent-rEYj2_8SETJUeqNhyzSm .productCard-module_productCardRoot__Yf7qs > a[href]';
		const fallbackSelector = '.productCard-module_productCardRoot__Yf7qs > a[href]';
		const cardSelector = 'article[class*="productCard"] a[href*="-p-"]';
		const anchors = [
			...Array.from(doc.querySelectorAll(strictSelector)),
			...Array.from(doc.querySelectorAll(fallbackSelector)),
			...Array.from(doc.querySelectorAll(cardSelector)),
		];
		for (let i = 0; i < anchors.length; i++) {
			const href = anchors[i]?.getAttribute?.('href');
			const normalized = normalizeHbProductUrl(href);
			if (normalized) seen.add(normalized);
		}
		return Array.from(seen);
	}

	async function fetchHbCategoryLinks(categoryUrl, onProgress) {
		const seen = new Set();
		let page = 1;
		let fetchedPages = 0;
		const maxPages = 400;
		let stopReason = 'Bitti';
		const visitedUrls = new Set();

		while (page <= maxPages && seen.size < HB_CRAWL_LINK_MAX) {
			const pageUrl = buildHbCategoryPageUrl(categoryUrl, page);
			if (onProgress) onProgress(`Sayfa ${page} çekiliyor…`);
			let html = '';
			let finalUrl = pageUrl;
			try {
				const res = await fetch(pageUrl, { credentials: 'include', redirect: 'follow', cache: 'no-store' });
				if (!res.ok) {
					stopReason = `HTTP ${res.status} (sayfa ${page})`;
					break;
				}
				finalUrl = res.url || pageUrl;
				if (visitedUrls.has(finalUrl)) {
					stopReason = `Liste sonu / redirect (sayfa ${page})`;
					break;
				}
				visitedUrls.add(finalUrl);
				html = await res.text();
			} catch (error) {
				stopReason =
					seen.size > 0
						? `Sayfa ${page} alınamadı (${error instanceof Error ? error.message : String(error)}). Kısmi sonuç.`
						: `Fetch hatası (sayfa ${page}): ${error instanceof Error ? error.message : String(error)}`;
				break;
			}

			const doc = new DOMParser().parseFromString(html, 'text/html');
			const linksOnPage = collectHbLinksFromDocument(doc);
			const before = seen.size;
			for (let i = 0; i < linksOnPage.length; i++) {
				if (seen.size >= HB_CRAWL_LINK_MAX) break;
				seen.add(linksOnPage[i]);
			}
			fetchedPages += 1;
			const added = seen.size - before;
			if (onProgress) {
				onProgress(`Sayfa ${page}: +${added} link, toplam ${seen.size} link`);
			}
			if (seen.size >= HB_CRAWL_LINK_MAX) {
				stopReason = `Üst sınır (${HB_CRAWL_LINK_MAX})`;
				break;
			}
			if (linksOnPage.length === 0 || added === 0) {
				stopReason = `Yeni link yok (sayfa ${page})`;
				break;
			}
			page += 1;
			await epeySleep(260);
		}

		return {
			links: trimHbUrlListToMax(Array.from(seen).sort()),
			fetchedPages,
			stopReason,
		};
	}

	/**
	 * @param {HTMLElement} modalTitleEl
	 * @param {HTMLElement} modalBodyEl
	 * @param {() => void} onClose
	 */
	function ahtapotOpenHepsiburadaLinkCrawler(modalTitleEl, modalBodyEl, onClose) {
		clearApiSession();
		modalTitleEl.textContent = 'Link Crawler';
		modalBodyEl.innerHTML = `
			<div class="kg-lc">
				<div class="kg-lc-status" id="kg-hb-lc-status"></div>
				<div class="kg-lc-actions" id="kg-hb-lc-actions"></div>
				<pre class="kg-lc-preview" id="kg-hb-lc-preview" hidden></pre>
			</div>
		`;

		const statusEl = modalBodyEl.querySelector('#kg-hb-lc-status');
		const actionsEl = modalBodyEl.querySelector('#kg-hb-lc-actions');
		const previewEl = modalBodyEl.querySelector('#kg-hb-lc-preview');
		if (!statusEl || !actionsEl || !previewEl) return;

		const ui = {
			statusEl,
			actionsEl,
			previewEl,
			onClose,
			_hbAutoStartTimer: null,
			_hbAutoNextTimer: null,
			_hbRunning: false,
			_hbLastLinks: [],
		};
		activeLcUi = ui;
		globalThis.ahtapotLcCleanup = () => {
			ui._hbRunning = false;
			clearHbAutoTimers(activeLcUi);
			activeLcUi = null;
		};

		function getCategoryUrlFromLocation() {
			return (location.href || '').split('#')[0];
		}

		function isValidHbCategoryUrl(url) {
			return (
				/^https?:\/\/(www\.)?hepsiburada\.com\//i.test(url) &&
				/-c-\d+/i.test(url) &&
				parseHbCategoryId(url)
			);
		}

		async function finishHb(list, options) {
			list = trimHbUrlListToMax(list);
			ui._hbLastLinks = list;
			const partial = options && options.partial;
			const stopReason = options?.stopReason || '';
			const n = list.length;
			rememberHbCategoryUrl(getCategoryUrlFromLocation());
			const bounds = getHbFiyatBoundsCached();
			if (bounds) rememberHbFiyatBounds(bounds);
			if (partial && n > 0) {
				statusEl.textContent =
					'İşlem kesildi; şu ana kadar toplanan: ' + n + ' link. ' + stopReason;
			} else if (n > 0) {
				statusEl.textContent =
					'İşlem tamamlandı: ' +
					n +
					' ürün linki (en fazla ' +
					HB_CRAWL_LINK_MAX +
					'). ' +
					stopReason +
					' TXT indiriliyor…';
			} else {
				statusEl.textContent = 'Bu aralıkta link bulunamadı. ' + stopReason;
			}
			previewEl.hidden = false;
			previewEl.textContent = list.slice(0, 50).join('\n') + (list.length > 50 ? '\n…' : '');
			actionsEl.innerHTML = '';

			const finAutoRow = document.createElement('div');
			finAutoRow.className = 'kg-lc-auto-panel';
			appendHbAutoCrawlerCheckbox(ui, finAutoRow);
			actionsEl.appendChild(finAutoRow);

			const finBtnRow = document.createElement('div');
			finBtnRow.className = 'kg-lc-actions-row';
			const dl = document.createElement('button');
			dl.type = 'button';
			dl.className = 'kg-lc-btn kg-lc-btn--primary';
			dl.textContent = 'TXT indir';
			dl.addEventListener('click', () => {
				if (!list.length) return;
				void hepsiburadaDownloadLinksTxt(list.join('\n'));
			});
			const again = document.createElement('button');
			again.type = 'button';
			again.className = 'kg-lc-btn kg-lc-btn--ghost';
			again.textContent = 'Yeniden';
			again.addEventListener('click', () => void renderHbIntro());
			const close = document.createElement('button');
			close.type = 'button';
			close.className = 'kg-lc-btn kg-lc-btn--ghost';
			close.textContent = 'Kapat';
			close.addEventListener('click', () => onClose());
			finBtnRow.append(dl, again, close);
			appendHbNextPageIfFiyat(ui, finBtnRow);
			actionsEl.appendChild(finBtnRow);

			if (n > 0) {
				const downloaded = await hepsiburadaDownloadLinksTxt(list.join('\n'));
				if (downloaded) {
					statusEl.textContent =
						'İşlem tamamlandı: ' +
						n +
						' ürün linki (en fazla ' +
						HB_CRAWL_LINK_MAX +
						'). ' +
						stopReason +
						' TXT otomatik indirildi.';
				} else {
					statusEl.textContent =
						'İşlem tamamlandı: ' +
						n +
						' ürün linki. ' +
						stopReason +
						' TXT indirilemedi — «TXT indir» düğmesini kullanın.';
				}
			}
			scheduleHbAutoNextPageIfEnabled(ui);
		}

		function getHbCategoryUrlForFetch() {
			const bounds = getHbFiyatBoundsForNavigation() || getHbFiyatBoundsCached();
			const base = readHbCategoryUrl() || getCategoryUrlFromLocation();
			if (bounds) return buildHbUrlWithFiyat(base, bounds.min, bounds.max);
			return getCategoryUrlFromLocation();
		}

		async function startHbLinkFetch() {
			if (ui._hbRunning) return;
			const categoryUrl = getHbCategoryUrlForFetch();
			if (!isValidHbCategoryUrl(categoryUrl)) {
				statusEl.innerHTML =
					'<p class="kg-lc-p">Geçerli bir Hepsiburada kategori URL’si gerekli (<code>-c-ID</code>). Örn: <code class="kg-lc-code">…/sobalar-isiticilar-c-8001872?filtreler=fiyat:3601-4800</code></p>';
				return;
			}
			rememberHbCategoryUrl(categoryUrl);
			const bounds = getHbFiyatBoundsCached();
			if (bounds) rememberHbFiyatBounds(bounds);

			let n = parseHbResultCountFromDom();
			if (n == null) n = await waitForHbDomResultCount(8000);
			if (n === 0) {
				statusEl.innerHTML =
					'<p class="kg-lc-p">Bu fiyat aralığında ürün yok. NextPage veya farklı <code>filtreler=fiyat:…</code> deneyin.</p>';
				return;
			}
			if (n != null && n > HB_RESULT_COUNT_MAX) {
				statusEl.innerHTML =
					'<p class="kg-lc-p">Liste <strong>' +
					escapeHtml(String(n)) +
					'</strong> ürün — hedef en fazla <strong>' +
					HB_RESULT_COUNT_MAX +
					'</strong>. Auto Crawler fiyat aralığını daraltır.</p>';
				return;
			}
			if (n != null && n >= 1 && n < HB_RESULT_COUNT_MIN) {
				statusEl.innerHTML =
					'<p class="kg-lc-p">Liste <strong>' +
					escapeHtml(String(n)) +
					'</strong> ürün — hedef en az <strong>' +
					HB_RESULT_COUNT_MIN +
					'</strong>. Auto Crawler fiyat aralığını genişletir.</p>';
				return;
			}

			clearHbAutoTimers(ui);
			ui._hbRunning = true;
			previewEl.hidden = true;
			statusEl.textContent = 'Linkler toplanıyor…';
			actionsEl.innerHTML = '';

			const crawlAutoRow = document.createElement('div');
			crawlAutoRow.className = 'kg-lc-auto-panel';
			appendHbAutoCrawlerCheckbox(ui, crawlAutoRow);
			actionsEl.appendChild(crawlAutoRow);

			const crawlBtnRow = document.createElement('div');
			crawlBtnRow.className = 'kg-lc-actions-row';
			appendHbNextPageIfFiyat(ui, crawlBtnRow);
			actionsEl.appendChild(crawlBtnRow);

			try {
				const result = await fetchHbCategoryLinks(categoryUrl, (msg) => {
					statusEl.textContent = msg;
				});
				await finishHb(result.links, { stopReason: result.stopReason });
			} catch (error) {
				statusEl.textContent =
					'Link toplama hatası: ' + (error instanceof Error ? error.message : String(error));
				void renderHbIntro();
			} finally {
				ui._hbRunning = false;
			}
		}
		ui.startLinkFetch = () => void startHbLinkFetch();

		function renderHbIntro() {
			clearHbAutoTimers(ui);
			statusEl.innerHTML = '';
			actionsEl.innerHTML = '';
			previewEl.hidden = true;
			previewEl.textContent = '';

			const categoryUrl = getCategoryUrlFromLocation();
			rememberHbCategoryUrl(categoryUrl);
			const boundsLive = getHbFiyatBoundsCached();
			if (boundsLive) rememberHbFiyatBounds(boundsLive);
			if (!isValidHbCategoryUrl(categoryUrl)) {
				statusEl.innerHTML =
					'<p class="kg-lc-p">Hepsiburada kategori listesi sayfasında olun (<code>-c-ID</code> içeren URL).</p>';
				const close = document.createElement('button');
				close.type = 'button';
				close.className = 'kg-lc-btn kg-lc-btn--ghost';
				close.textContent = 'Kapat';
				close.addEventListener('click', () => onClose());
				actionsEl.appendChild(close);
				return;
			}

			const n = parseHbResultCountFromDom();
			const fiyatBounds = getHbFiyatBoundsCached();
			let countBlock = n != null ? `<br><br>Liste ürün sayısı (DOM): <strong>${n}</strong>` : '';
			if (n != null && n > 0 && n < HB_RESULT_COUNT_MIN) {
				countBlock += `<br><br>Hedef: <strong>${HB_RESULT_COUNT_MIN}–${HB_RESULT_COUNT_MAX}</strong> ürün — Auto Crawler fiyat üst sınırını genişletir.`;
			} else if (n != null && n > HB_RESULT_COUNT_MAX) {
				countBlock += `<br><br>Hedef: <strong>${HB_RESULT_COUNT_MIN}–${HB_RESULT_COUNT_MAX}</strong> ürün — Auto Crawler fiyat aralığını daraltır.`;
			} else if (n != null && isHbListWithinCrawlLimit(n)) {
				countBlock += `<br><br>Hedef aralıkta (<strong>${HB_RESULT_COUNT_MIN}–${HB_RESULT_COUNT_MAX}</strong> ürün).`;
			}
			if (n === 0 && fiyatBounds) {
				countBlock +=
					'<br><br><strong>Bu <code>fiyat:' +
					fiyatBounds.min +
					'-' +
					fiyatBounds.max +
					'</code> aralığında ürün yok.</strong> Auto Crawler durur; NextPage veya başka aralık kullanın.';
			}

			const fiyatNote = fiyatBounds
				? `<br><br>Fiyat filtresi: <code class="kg-lc-code">filtreler=fiyat:${fiyatBounds.min}-${fiyatBounds.max}</code>`
				: '<br><br>Fiyat filtresi yok — çok büyük listelerde Auto Crawler <code>fiyat:1-100</code> ile başlar.';

			statusEl.innerHTML =
				'<p class="kg-lc-p">Kategori: <code class="kg-lc-code">' +
				escapeHtml(categoryUrl.split('?')[0]) +
				'</code>' +
				fiyatNote +
				countBlock +
				'</p><p class="kg-lc-p kg-lc-p--muted">Fiyat dilimi hedefi: <strong>' +
				HB_RESULT_COUNT_MIN +
				'–' +
				HB_RESULT_COUNT_MAX +
				'</strong> ürün (<code>filtreler=fiyat:min-max</code> autotune ile ayarlanır). En fazla <strong>' +
				HB_CRAWL_LINK_MAX +
				'</strong> link toplanır. <em>Auto Crawler</em> açıksa uygun aralıkta otomatik başlar; bitince <code>NextPage</code> bir sonraki fiyat dilimine geçer.</p>';

			const autoRow = document.createElement('div');
			autoRow.className = 'kg-lc-auto-panel';
			appendHbAutoCrawlerCheckbox(ui, autoRow);
			actionsEl.appendChild(autoRow);

			const btnRow = document.createElement('div');
			btnRow.className = 'kg-lc-actions-row';
			const start = document.createElement('button');
			start.type = 'button';
			start.className = 'kg-lc-btn kg-lc-btn--primary';
			start.textContent = 'Başlat';
			start.addEventListener('click', () => void startHbLinkFetch());
			btnRow.appendChild(start);
			appendHbNextPageIfFiyat(ui, btnRow);
			const close = document.createElement('button');
			close.type = 'button';
			close.className = 'kg-lc-btn kg-lc-btn--ghost';
			close.textContent = 'Kapat';
			close.addEventListener('click', () => onClose());
			btnRow.appendChild(close);
			actionsEl.appendChild(btnRow);

			const forceAutoPending = (() => {
				try {
					return localStorage.getItem(LS_HB_FORCE_AUTO_START) === '1';
				} catch {
					return false;
				}
			})();

			if (
				!isHbNextPageAutostop() &&
				(forceAutoPending || n !== 0 || (n != null && isHbListWithinCrawlLimit(n)))
			) {
				scheduleHbAutoStartIfEnabled(ui);
			}
		}

		void renderHbIntro();
	}

	/**
	 * @param {HTMLElement} modalTitleEl
	 * @param {HTMLElement} modalBodyEl
	 * @param {() => void} onClose
	 */
	function ahtapotOpenAmazonLinkCrawler(modalTitleEl, modalBodyEl, onClose) {
		clearApiSession();
		activeLcUi = null;
		modalTitleEl.textContent = 'Link Crawler';
		modalBodyEl.innerHTML = `
			<div class="kg-epey-modal" role="region" aria-label="Amazon Link Crawler">
				<p class="kg-epey-help">Kategori/listing URL'sinden <code>div.s-search-results a.a-link-normal</code> linkleri toplanır ve <code>page=2,3...</code> ile tüm sayfalar gezilir.</p>
				<input id="kg-amz-category-url" class="kg-epey-input" type="text" placeholder="https://www.amazon.com.tr/s?..." />
				<div id="kg-amz-link-status" class="kg-epey-status">Hazır</div>
				<div class="kg-epey-actions">
					<button type="button" class="kg-lc-btn kg-lc-btn--primary" id="kg-amz-link-run">Toplamayı başlat</button>
					<button type="button" class="kg-lc-btn kg-lc-btn--ghost" id="kg-amz-link-download">TXT indir</button>
					<button type="button" class="kg-lc-btn kg-lc-btn--ghost" id="kg-amz-link-clear">Temizle</button>
					<button type="button" class="kg-lc-btn kg-lc-btn--ghost" id="kg-amz-link-close">Kapat</button>
				</div>
			</div>
		`;

		const categoryUrlEl = modalBodyEl.querySelector('#kg-amz-category-url');
		const statusEl = modalBodyEl.querySelector('#kg-amz-link-status');
		const runBtn = modalBodyEl.querySelector('#kg-amz-link-run');
		const downloadBtn = modalBodyEl.querySelector('#kg-amz-link-download');
		const clearBtn = modalBodyEl.querySelector('#kg-amz-link-clear');
		const closeBtn = modalBodyEl.querySelector('#kg-amz-link-close');
		if (!categoryUrlEl || !statusEl || !runBtn || !downloadBtn || !clearBtn || !closeBtn) return;

		function normalizeAmazonProductUrl(rawUrl, baseUrl) {
			const raw = String(rawUrl || '').trim();
			if (!raw) return null;
			try {
				const absolute = new URL(raw, baseUrl || location.href);
				const host = absolute.hostname.replace(/^www\./i, '').toLowerCase();
				if (host !== 'amazon.com.tr') return null;
				absolute.hash = '';
				if (!/\/dp\/[A-Z0-9]{10}|\/gp\/product\/[A-Z0-9]{10}/i.test(absolute.pathname)) {
					return null;
				}
				absolute.search = '';
				return absolute.toString();
			} catch {
				return null;
			}
		}

		function buildAmazonCategoryPageUrl(rawUrl, page) {
			const u = new URL(String(rawUrl || '').trim());
			if (page <= 1) u.searchParams.delete('page');
			else u.searchParams.set('page', String(page));
			return u.toString();
		}

		function collectAmazonLinksFromDocument(doc, baseUrl) {
			const seen = new Set();
			const anchors = Array.from(doc.querySelectorAll('div.s-search-results a.a-link-normal[href]'));
			for (let i = 0; i < anchors.length; i++) {
				const href = anchors[i]?.getAttribute?.('href');
				const normalized = normalizeAmazonProductUrl(href, baseUrl);
				if (normalized) seen.add(normalized);
			}
			return Array.from(seen);
		}

		let running = false;
		let lastCollectedLinksText = '';
		closeBtn.addEventListener('click', () => onClose());
		clearBtn.addEventListener('click', () => {
			if (running) return;
			lastCollectedLinksText = '';
			statusEl.textContent = 'Temizlendi.';
		});
		downloadBtn.addEventListener('click', () => {
			const ok = amazonDownloadLinksTxt(lastCollectedLinksText);
			if (!ok) {
				statusEl.textContent = 'İndirilecek link yok.';
				return;
			}
			statusEl.textContent = 'TXT indirildi.';
		});

		categoryUrlEl.value = location.href || '';

		runBtn.addEventListener('click', async () => {
			if (running) return;
			const categoryUrl = String(categoryUrlEl.value || '').trim();
			if (!/^https?:\/\/(www\.)?amazon\.com\.tr\/s\?/i.test(categoryUrl)) {
				statusEl.textContent = 'Kategori URL geçersiz. Örn: https://www.amazon.com.tr/s?...';
				return;
			}
			running = true;
			runBtn.disabled = true;
			try {
				const seen = new Set();
				let page = 1;
				let fetchedPages = 0;
				const maxPages = 400;
				let stopReason = 'Bitti';
				const visitedUrls = new Set();

				while (page <= maxPages) {
					const pageUrl = buildAmazonCategoryPageUrl(categoryUrl, page);
					statusEl.textContent = `Sayfa ${page} çekiliyor...`;
					let html = '';
					let finalUrl = pageUrl;
					try {
						const res = await fetch(pageUrl, { credentials: 'include', redirect: 'follow', cache: 'no-store' });
						if (!res.ok) {
							stopReason = `HTTP ${res.status} (sayfa ${page})`;
							break;
						}
						finalUrl = res.url || pageUrl;
						if (visitedUrls.has(finalUrl)) {
							stopReason = `Liste sonu / redirect (sayfa ${page})`;
							break;
						}
						visitedUrls.add(finalUrl);
						html = await res.text();
					} catch (error) {
						if (seen.size > 0) {
							stopReason =
								`Sayfa ${page} alınamadı (${
									error instanceof Error ? error.message : String(error)
								}). Kısmi sonuçlarla tamamlandı.`;
						} else {
							stopReason = `Fetch hatası (sayfa ${page}): ${
								error instanceof Error ? error.message : String(error)
							}`;
						}
						break;
					}

					const doc = new DOMParser().parseFromString(html, 'text/html');
					const linksOnPage = collectAmazonLinksFromDocument(doc, finalUrl);
					const before = seen.size;
					for (let i = 0; i < linksOnPage.length; i++) seen.add(linksOnPage[i]);
					fetchedPages += 1;
					const added = seen.size - before;
					statusEl.textContent = `Sayfa ${page}: +${added} link, toplam ${seen.size} link`;
					if (linksOnPage.length === 0 || added === 0) {
						stopReason = `Yeni link yok (sayfa ${page})`;
						break;
					}
					page += 1;
					await epeySleep(260);
				}

				const links = Array.from(seen).sort();
				lastCollectedLinksText = links.join('\n');
				statusEl.textContent =
					`Tamamlandı: ${links.length} link, ${fetchedPages} sayfa. ${stopReason}`;
				if (links.length) amazonDownloadLinksTxt(lastCollectedLinksText);
			} catch (error) {
				statusEl.textContent =
					'Link toplama hatası: ' + (error instanceof Error ? error.message : String(error));
			} finally {
				running = false;
				runBtn.disabled = false;
			}
		});

		globalThis.ahtapotLcCleanup = () => {
			running = false;
		};
	}

	/**
	 * @param {HTMLElement} modalTitleEl
	 * @param {HTMLElement} modalBodyEl
	 * @param {() => void} onClose
	 */
	function ahtapotOpenLinkCrawler(modalTitleEl, modalBodyEl, onClose) {
		const host = (location.hostname || '').toLowerCase();
		if (host === 'hepsiburada.com' || host.endsWith('.hepsiburada.com')) {
			ahtapotOpenHepsiburadaLinkCrawler(modalTitleEl, modalBodyEl, onClose);
			return;
		}
		if (host === 'amazon.com.tr' || host.endsWith('.amazon.com.tr')) {
			ahtapotOpenAmazonLinkCrawler(modalTitleEl, modalBodyEl, onClose);
			return;
		}
		clearApiSession();
		modalTitleEl.textContent = 'Link Crawler';
		modalBodyEl.innerHTML = `
			<div class="kg-lc">
				<div class="kg-lc-status" id="kg-lc-status"></div>
				<div class="kg-lc-actions" id="kg-lc-actions"></div>
				<pre class="kg-lc-preview" id="kg-lc-preview" hidden></pre>
			</div>
		`;
		const statusEl = modalBodyEl.querySelector('#kg-lc-status');
		const actionsEl = modalBodyEl.querySelector('#kg-lc-actions');
		const previewEl = modalBodyEl.querySelector('#kg-lc-preview');
		if (!statusEl || !actionsEl || !previewEl) return;

		const ui = {
			statusEl,
			actionsEl,
			previewEl,
			onClose,
			_tyAutoStartTimer: null,
			_tyAutoNextTimer: null,
		};
		activeLcUi = ui;
		globalThis.ahtapotLcCleanup = () => {
			clearApiSession();
			clearTyAutoTimers(activeLcUi);
			activeLcUi = null;
		};
		void renderIntro(ui).catch((e) => console.error('[Ahtapot] Link Crawler intro', e));
	}

	/**
	 * 2. özellik — Data Crawler’daki TXT Birleştir; ayrı modal.
	 * @param {HTMLElement} modalTitleEl
	 * @param {HTMLElement} modalBodyEl
	 * @param {() => void} onClose
	 */
	function ahtapotOpenTxtBirlestir(modalTitleEl, modalBodyEl, onClose) {
		clearApiSession();
		activeLcUi = null;
		lcTxtMergeBuffers = [];
		modalTitleEl.textContent = 'TXT Birleştir';
		modalBodyEl.innerHTML = `
			<div class="kg-txt-modal" role="region" aria-label="TXT Birleştir">
				<p class="kg-txt-modal-lead">Birden fazla TXT dosyasındaki linkleri tek listede birleştirir. Tüm domainler desteklenir; geçersiz satırlar ve mükerrer URL’ler ayıklanır.</p>
				<div class="kg-txt-drop" id="kg-txt-drop" tabindex="0" role="button" aria-label="TXT dosyalarını sürükleyin veya seçin">
					Dosyaları sürükleyip bırakın<br /><span class="kg-lc-txt-drop-sub">veya tıklayarak seçin (.txt)</span>
				</div>
				<input type="file" id="kg-txt-file" accept=".txt,text/plain" multiple hidden />
				<div class="kg-txt-file-wrap" id="kg-txt-file-wrap" hidden>
					<div class="kg-txt-file-label">Seçilen dosyalar</div>
					<ul class="kg-txt-file-list" id="kg-txt-file-list"></ul>
				</div>
				<p class="kg-lc-txt-merge-status" id="kg-txt-merge-status"></p>
				<div class="kg-lc-txt-merge-actions" id="kg-txt-merge-actions"></div>
			</div>
		`;
		const mergeDropEl = modalBodyEl.querySelector('#kg-txt-drop');
		const mergeFileEl = modalBodyEl.querySelector('#kg-txt-file');
		const mergeFileWrapEl = modalBodyEl.querySelector('#kg-txt-file-wrap');
		const mergeFileListEl = modalBodyEl.querySelector('#kg-txt-file-list');
		const mergeStatusEl = modalBodyEl.querySelector('#kg-txt-merge-status');
		const mergeActionsEl = modalBodyEl.querySelector('#kg-txt-merge-actions');
		if (
			!mergeDropEl ||
			!mergeFileEl ||
			!mergeFileWrapEl ||
			!mergeFileListEl ||
			!mergeStatusEl ||
			!mergeActionsEl
		) {
			return;
		}

		const mergeUi = {
			mergeDropEl,
			mergeFileEl,
			mergeFileWrapEl,
			mergeFileListEl,
			mergeStatusEl,
			mergeActionsEl,
			_txtMergeBtn: null,
			_txtMergeWired: false,
		};
		wireLcTxtMergeColumn(mergeUi);
		globalThis.ahtapotLcCleanup = () => {
			clearLcTxtMergeUi(mergeUi);
		};
	}

	function isSupportedProductPdpUrl(url) {
		try {
			const parsed = new URL(url);
			const host = parsed.hostname.toLowerCase();
			if (host === 'www.trendyol.com' || host === 'trendyol.com') {
				return /-p-\d+/i.test(parsed.pathname);
			}
			if (host === 'www.n11.com' || host === 'n11.com') {
				return /\/urun\//i.test(parsed.pathname);
			}
			if (host === 'www.hepsiburada.com' || host === 'hepsiburada.com') {
				return /-p[m]?-[a-z0-9]+/i.test(parsed.pathname) || /\/p\//i.test(parsed.pathname);
			}
			if (host === 'www.amazon.com.tr' || host === 'amazon.com.tr') {
				return /\/dp\/[a-z0-9]{10}/i.test(parsed.pathname) || /\/gp\/product\/[a-z0-9]{10}/i.test(parsed.pathname);
			}
			return false;
		} catch {
			return false;
		}
	}

	function parseProductCrawlerUrlLines(text) {
		return String(text || '')
			.split(/\r?\n/)
			.map((x) => x.trim())
			.filter(Boolean)
			.filter(isSupportedProductPdpUrl);
	}

	function detectProductPlatform(url) {
		try {
			const parsed = new URL(url);
			const host = parsed.hostname.toLowerCase();
			if (host === 'www.n11.com' || host === 'n11.com') return 'n11';
			if (host === 'www.hepsiburada.com' || host === 'hepsiburada.com') return 'hepsiburada';
			if (host === 'www.trendyol.com' || host === 'trendyol.com') return 'trendyol';
			if (host === 'www.amazon.com.tr' || host === 'amazon.com.tr') return 'amazon';
		} catch {
			/* ignore */
		}
		return null;
	}

	function detectCurrentPlatformForQueue() {
		const host = String(location.hostname || '').toLowerCase();
		if (host === 'www.n11.com' || host === 'n11.com' || host.endsWith('.n11.com')) return 'n11';
		if (host === 'www.hepsiburada.com' || host === 'hepsiburada.com' || host.endsWith('.hepsiburada.com')) return 'hepsiburada';
		if (host === 'www.amazon.com.tr' || host === 'amazon.com.tr' || host.endsWith('.amazon.com.tr')) return 'amazon';
		if (host === 'www.trendyol.com' || host === 'trendyol.com' || host.endsWith('.trendyol.com') || host.endsWith('.trendyol.com.tr')) {
			return 'trendyol';
		}
		return null;
	}

	function pickFirstNonEmpty(values) {
		for (let i = 0; i < values.length; i++) {
			const v = values[i];
			if (typeof v === 'string' && v.trim()) return v.trim();
		}
		return null;
	}

	function numberOrNull(value) {
		if (typeof value === 'number' && Number.isFinite(value)) return value;
		if (typeof value === 'string') {
			const cleaned = value.replace(/[^\d.,-]/g, '').replace(/\./g, '').replace(',', '.');
			const n = Number(cleaned);
			return Number.isFinite(n) ? n : null;
		}
		return null;
	}

	function extractTrendyolPriceRaw(priceNode) {
		if (priceNode == null) return null;
		if (typeof priceNode === 'number' && Number.isFinite(priceNode)) return priceNode;
		if (typeof priceNode === 'string') return numberOrNull(priceNode);
		if (typeof priceNode !== 'object') return null;
		const candidates = [
			priceNode.sellingPrice?.value,
			priceNode.discountedPrice?.value,
			priceNode.couponApplicablePrice?.value,
			priceNode.discountedPriceAfterNoLimitPromotions?.value,
			priceNode.tyPlusCouponApplicablePrice?.value,
			priceNode.price,
			priceNode.lowPrice,
			priceNode.value,
		];
		for (let i = 0; i < candidates.length; i++) {
			const v = candidates[i];
			if (v == null) continue;
			const n = typeof v === 'number' ? (Number.isFinite(v) ? v : null) : numberOrNull(v);
			if (n != null) return n;
		}
		return null;
	}

	function normalizeTrendyolPrice(raw, currency) {
		const n = extractTrendyolPriceRaw(raw);
		if (n == null) return null;
		const cur = String(currency || 'TRY').toUpperCase();
		if (cur !== 'TRY') return n;
		if (!Number.isInteger(n)) return Math.round(n * 100) / 100;
		if (n >= 1000) return n / 100;
		return n;
	}

	function normalizeImageUrl(image) {
		function fixN11Placeholder(url) {
			return String(url || '').replace('/{0}/', '/320/');
		}
		if (!image) return null;
		if (typeof image === 'string') {
			const fixed = fixN11Placeholder(image).trim();
			return fixed || null;
		}
		if (Array.isArray(image)) return normalizeImageUrl(image[0]);
		if (typeof image === 'object') {
			const raw = pickFirstNonEmpty([image.url, image.contentUrl, image.thumbnailUrl]);
			return raw ? fixN11Placeholder(raw) : null;
		}
		return null;
	}

	function parseJsonLdNodesFromHtml(html) {
		const parser = new DOMParser();
		const doc = parser.parseFromString(html, 'text/html');
		const scripts = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));
		const nodes = [];
		for (let i = 0; i < scripts.length; i++) {
			const text = String(scripts[i].textContent || '').trim();
			if (!text) continue;
			try {
				const parsed = JSON.parse(text);
				if (Array.isArray(parsed)) {
					for (let j = 0; j < parsed.length; j++) nodes.push(parsed[j]);
				} else {
					nodes.push(parsed);
				}
			} catch {
				/* ignore invalid script */
			}
		}
		return { doc, nodes };
	}

	function parseNextDataProduct(doc) {
		const el = doc.querySelector('#__NEXT_DATA__');
		if (!el) return null;
		const raw = String(el.textContent || '').trim();
		if (!raw) return null;
		try {
			const parsed = JSON.parse(raw);
			const product = parsed?.props?.pageProps?.product;
			if (!product || typeof product !== 'object') return null;
			const brand =
				typeof product.brand?.name === 'string'
					? product.brand.name
					: typeof product.brandName === 'string'
						? product.brandName
						: null;
			const categoryPath = Array.isArray(product.categories)
				? product.categories
						.map((x) => (typeof x?.name === 'string' ? x.name.trim() : ''))
						.filter(Boolean)
				: null;
			const attributes = Array.isArray(product.attributes)
				? product.attributes
						.map((x) => {
							const name = pickFirstNonEmpty([x?.key?.name, x?.attribute?.name, x?.name]);
							const value = pickFirstNonEmpty([x?.value?.name, x?.value, x?.displayValue]);
							if (!name || !value) return null;
							return { name, value };
						})
						.filter(Boolean)
				: [];
			const firstVariant = Array.isArray(product.variants) ? product.variants[0] : null;
			const barcode = pickFirstNonEmpty([
				product.barcode,
				firstVariant?.barcode,
				product?.sellerSku,
			]);
			return {
				url: pickFirstNonEmpty([product.url]),
				sku: pickFirstNonEmpty([product.id ? String(product.id) : null, product.sku]),
				barcode,
				title: pickFirstNonEmpty([product.name]),
				brand,
				price: normalizeTrendyolPrice(product?.price, product?.price?.currency ?? 'TRY'),
				currency: pickFirstNonEmpty([product?.price?.currency, 'TRY']),
				availability:
					product?.stock > 0 || product?.hasStock === true
						? 'https://schema.org/InStock'
						: product?.stock === 0
							? 'https://schema.org/OutOfStock'
							: null,
				categoryPath: categoryPath && categoryPath.length ? categoryPath : null,
				imageUrl: normalizeImageUrl(product.images),
				attributes,
				rawProductJson: {
					schemaVersion: 'api-json-scraping-next-data-1',
					source: '__NEXT_DATA__',
					product,
				},
			};
		} catch {
			return null;
		}
	}

	function flattenJsonLdNodes(nodes) {
		const out = [];
		function walk(node) {
			if (!node || typeof node !== 'object') return;
			out.push(node);
			if (Array.isArray(node['@graph'])) {
				for (let i = 0; i < node['@graph'].length; i++) walk(node['@graph'][i]);
			}
		}
		for (let i = 0; i < nodes.length; i++) walk(nodes[i]);
		return out;
	}

	function hasType(node, target) {
		const t = node && node['@type'];
		if (typeof t === 'string') return t.toLowerCase() === target;
		if (Array.isArray(t)) return t.some((x) => String(x || '').toLowerCase() === target);
		return false;
	}

	function pickProductAndWebPage(nodes) {
		const flat = flattenJsonLdNodes(nodes);
		let product = null;
		let webPage = null;
		for (let i = 0; i < flat.length; i++) {
			const item = flat[i];
			if (!product && (hasType(item, 'product') || hasType(item, 'productgroup'))) product = item;
			if (!webPage && hasType(item, 'webpage')) webPage = item;
			if (product && webPage) break;
		}
		return { product, webPage };
	}

	function extractCategoryPathFromBreadcrumb(breadcrumb) {
		if (!breadcrumb || typeof breadcrumb !== 'object') return null;
		const list = Array.isArray(breadcrumb.itemListElement) ? breadcrumb.itemListElement : [];
		const names = [];
		for (let i = 0; i < list.length; i++) {
			const item = list[i];
			const name =
				typeof item?.name === 'string'
					? item.name
					: typeof item?.item?.name === 'string'
						? item.item.name
						: null;
			if (name && name.trim()) names.push(name.trim());
		}
		return names.length ? names : null;
	}

	function normalizeAttributes(additionalProperty) {
		const list = Array.isArray(additionalProperty) ? additionalProperty : [];
		const out = [];
		for (let i = 0; i < list.length; i++) {
			const row = list[i] || {};
			const name = pickFirstNonEmpty([row.name]);
			const value = pickFirstNonEmpty([row.value, row.unitText]);
			if (!name || !value) continue;
			out.push({ name, value });
		}
		return out;
	}

	function mapApiJsonPayload(url, html) {
		const parsed = parseJsonLdNodesFromHtml(html);
		const picked = pickProductAndWebPage(parsed.nodes);
		if (!picked.product) {
			const nextDataMapped = parseNextDataProduct(parsed.doc);
			if (nextDataMapped) {
				return {
					linkId: null,
					url: pickFirstNonEmpty([nextDataMapped.url, url]),
					sku: nextDataMapped.sku,
					barcode: nextDataMapped.barcode,
					title: nextDataMapped.title,
					brand: nextDataMapped.brand,
					price: nextDataMapped.price,
					currency: nextDataMapped.currency,
					availability: nextDataMapped.availability,
					categoryPath: nextDataMapped.categoryPath,
					imageUrl: nextDataMapped.imageUrl,
					attributes: nextDataMapped.attributes,
					rawProductJson: {
						...nextDataMapped.rawProductJson,
						sourceUrl: url,
						scrapedAt: new Date().toISOString(),
					},
				};
			}
			throw new Error('JSON-LD Product verisi bulunamadı (muhtemel bot/redirect).');
		}
		const product = picked.product;
		const webPage = picked.webPage;
		const offers = product.offers && typeof product.offers === 'object' ? product.offers : {};
		const brand =
			typeof product.brand === 'string'
				? product.brand
				: typeof product.brand?.name === 'string'
					? product.brand.name
					: null;
		const skuFromUrl = (() => {
			const m = String(url).match(/-p-(\d+)/i);
			return m ? m[1] : null;
		})();
		const categoryPath =
			extractCategoryPathFromBreadcrumb(webPage?.breadcrumb) ||
			extractCategoryPathFromBreadcrumb(product?.breadcrumb);
		const domMeta = extractTrendyolDomMeta(parsed.doc, url);
		return {
			linkId: null,
			url: pickFirstNonEmpty([product.url, product['@id'], webPage?.url, url]),
			sku: pickFirstNonEmpty([product.sku, skuFromUrl]),
			barcode: pickFirstNonEmpty([product.gtin13, product.gtin14, product.gtin, product.mpn]),
			title: pickFirstNonEmpty([product.name, webPage?.name, parsed.doc.querySelector('title')?.textContent]),
			brand: pickFirstNonEmpty([brand]),
			price: normalizeTrendyolPrice(offers, pickFirstNonEmpty([offers.priceCurrency, 'TRY'])),
			currency: pickFirstNonEmpty([offers.priceCurrency, 'TRY']),
			availability: pickFirstNonEmpty([offers.availability]),
			categoryPath,
			imageUrl: normalizeImageUrl(
				pickFirstNonEmpty([
					product.image,
					webPage?.primaryImageOfPage,
					domMeta.image,
					domMeta.images?.[0],
				]),
			),
			attributes: normalizeAttributes(product.additionalProperty),
			rawProductJson: {
				schemaVersion: 'api-json-scraping-1',
				sourceUrl: url,
				scrapedAt: new Date().toISOString(),
				product,
				webPage: webPage || null,
			},
		};
	}

	function formatScrapeErrorMessage(value, fallback) {
		const fb = fallback || 'Bilinmeyen hata';
		if (value == null || value === '') return fb;
		if (typeof value === 'string') return value;
		if (value instanceof Error) {
			const m = value.message;
			if (m && m !== '[object Object]') return m;
		}
		if (typeof value === 'object') {
			if (typeof value.error === 'string' && value.error.trim()) return value.error.trim();
			if (
				typeof value.message === 'string' &&
				value.message.trim() &&
				value.message !== '[object Object]'
			) {
				return value.message.trim();
			}
			try {
				const s = JSON.stringify(value);
				if (s && s !== '{}') return s.length > 320 ? `${s.slice(0, 317)}…` : s;
			} catch {
				/* ignore */
			}
		}
		const s = String(value);
		return s === '[object Object]' ? fb : s;
	}

	function panelResponseErrorMessage(response, fallback) {
		return (
			formatScrapeErrorMessage(response?.error, '') ||
			formatScrapeErrorMessage(response?.detail, '') ||
			fallback ||
			'İstek başarısız'
		);
	}

	function buildErrorSummary(errors) {
		if (!errors || !errors.length) return '';
		const counts = new Map();
		for (let i = 0; i < errors.length; i++) {
			const msg = formatScrapeErrorMessage(errors[i]?.message, 'Bilinmeyen hata').trim();
			counts.set(msg, (counts.get(msg) || 0) + 1);
		}
		const lines = Array.from(counts.entries())
			.sort((a, b) => b[1] - a[1])
			.slice(0, 3)
			.map(([msg, count]) => `${count}x ${msg}`);
		return lines.join(' | ');
	}

	async function markProductLinkStatuses(items) {
		if (!Array.isArray(items) || !items.length) return { updated: 0 };
		if (!isExtensionRuntimeAlive()) return { updated: 0 };
		const response = await sendRuntimeMessage({ type: 'kg-mark-product-links-status', items });
		if (!response || response.ok !== true) {
			throw new Error(response?.error || 'Link durumu güncellenemedi.');
		}
		return response.data || {};
	}

	function buildFailedLinkStatusUpdates(links, errors) {
		if (!Array.isArray(links) || !Array.isArray(errors) || !errors.length) return [];
		const byUrl = new Map();
		for (let i = 0; i < links.length; i++) {
			const row = links[i];
			const linkId = Number(row?.linkId);
			const url = typeof row?.url === 'string' ? row.url.trim() : '';
			if (Number.isFinite(linkId) && url) byUrl.set(url, linkId);
		}
		const out = [];
		const seen = new Set();
		for (let i = 0; i < errors.length; i++) {
			const url = typeof errors[i]?.url === 'string' ? errors[i].url.trim() : '';
			const linkId = byUrl.get(url);
			if (!Number.isFinite(linkId) || seen.has(linkId)) continue;
			seen.add(linkId);
			out.push({ id: linkId, status: 'failed' });
		}
		return out;
	}

	async function postApiJsonScrapingItems(items) {
		const response = await sendRuntimeMessage({ type: 'kg-import-scraped-products', items });
		if (!response || response.ok !== true) {
			throw new Error(panelResponseErrorMessage(response, 'Import başarısız.'));
		}
		return response.data || {};
	}

	async function patchProductReviews(productId, item) {
		const response = await sendRuntimeMessage({
			type: 'kg-patch-product-reviews',
			productId,
			item,
		});
		if (!response || response.ok !== true) {
			const msg = panelResponseErrorMessage(response, 'Yorum güncellenemedi.');
			if (/reviews_fetched_at|column.*does not exist/i.test(msg)) {
				throw new Error(
					`${msg} — Veritabanı migration gerekli: npm run db:migrate:reviews sonra npm run api`,
				);
			}
			throw new Error(msg);
		}
		return response.data || {};
	}

	async function fetchProductsMissingReviews(limit) {
		const safeLimit = Number.isFinite(limit) ? Math.max(1, Math.min(200, Math.floor(limit))) : 50;
		const response = await sendRuntimeMessage({
			type: 'kg-get-missing-reviews',
			limit: safeLimit,
			platform: 'trendyol',
		});
		if (!response || response.ok !== true) {
			const detail =
				response?.detail && typeof response.detail === 'string'
					? response.detail
					: response?.detail?.error
						? String(response.detail.error)
						: '';
			const base = response?.error || 'Yorumu boş ürünler alınamadı.';
			throw new Error(detail && !base.includes(detail) ? `${base} (${detail})` : base);
		}
		const body = response.data || {};
		const rows = Array.isArray(body?.products) ? body.products : [];
		return rows
			.map((row) => {
				const productId = String(row?.id || '').trim();
				const url = typeof row?.url === 'string' ? row.url.trim() : '';
				if (!productId || !url || !isTrendyolProductUrlForReviews(url)) return null;
				const linkIdRaw = row?.linkId ?? row?.link_id;
				const linkId = linkIdRaw != null ? Number(linkIdRaw) : null;
				const contentId =
					row?.contentId != null && String(row.contentId).trim()
						? String(row.contentId).trim()
						: row?.content_id != null && String(row.content_id).trim()
							? String(row.content_id).trim()
							: null;
				const merchantIdRaw = row?.merchantId ?? row?.merchant_id;
				const merchantId =
					merchantIdRaw != null && Number.isFinite(Number(merchantIdRaw))
						? Math.trunc(Number(merchantIdRaw))
						: null;
				return {
					productId,
					linkId: Number.isFinite(linkId) ? linkId : null,
					url,
					contentId,
					merchantId,
					platform: 'trendyol',
				};
			})
			.filter(Boolean);
	}

	function isTrendyolProductUrlForReviews(url) {
		try {
			const u = new URL(url);
			if (!u.hostname.toLowerCase().includes('trendyol.com')) return false;
			return /-p-\d+/i.test(u.pathname);
		} catch {
			return false;
		}
	}

	function dedupeReviewQueueLinks(links) {
		const seen = new Set();
		const out = [];
		for (let i = 0; i < links.length; i++) {
			const link = links[i];
			const key = link?.productId ? String(link.productId) : link?.url ? String(link.url) : '';
			if (!key || seen.has(key)) continue;
			seen.add(key);
			out.push(link);
		}
		return out;
	}

	/** API claim çalışmasa bile kuyruktan düşsün diye hemen işaretle. */
	async function claimReviewQueueProducts(links) {
		if (!Array.isArray(links) || !links.length) {
			return { claimed: 0, failed: 0 };
		}
		let claimed = 0;
		let failed = 0;
		await Promise.all(
			links.map(async (link) => {
				const productId = link?.productId ? String(link.productId).trim() : '';
				if (!productId) {
					failed += 1;
					return;
				}
				try {
					await patchProductReviews(productId, {
						platform: 'trendyol',
						url: link.url,
						contentId: link.contentId || undefined,
						merchantId: link.merchantId ?? undefined,
						markReviewsChecked: true,
						preserveReviews: true,
					});
					claimed += 1;
				} catch {
					failed += 1;
				}
			}),
		);
		return { claimed, failed };
	}

	async function fetchScrapeQueue(limit, scrapeMode) {
		if (scrapeMode === 'reviews_only') {
			const links = dedupeReviewQueueLinks(await fetchProductsMissingReviews(limit));
			if (links.length) {
				const claim = await claimReviewQueueProducts(links);
				if (claim.claimed < 1 && claim.failed > 0) {
					throw new Error(
						'Kuyruk işaretlenemedi — npm run db:migrate:reviews ve npm run api (yeniden başlat) gerekli.',
					);
				}
			}
			return links;
		}
		return fetchPendingProductLinks(limit, { allPlatforms: true });
	}

	async function fetchPendingProductLinks(limit, options) {
		const safeLimit = Number.isFinite(limit) ? Math.max(1, Math.min(200, Math.floor(limit))) : 50;
		const allPlatforms = options && options.allPlatforms === true;
		const queuePlatform = allPlatforms ? null : detectCurrentPlatformForQueue();
		const response = await sendRuntimeMessage({
			type: 'kg-get-pending-links',
			limit: safeLimit,
			platforms: queuePlatform ? [queuePlatform] : ['trendyol', 'n11', 'hepsiburada', 'amazon'],
		});
		if (!response || response.ok !== true) {
			throw new Error(response?.error || 'Pending linkler alınamadı.');
		}
		const body = response.data || {};
		const rows = Array.isArray(body?.links) ? body.links : [];
		return rows
			.map((row) => {
				const linkId = Number(row?.id);
				const rawUrl = row?.original_url ?? row?.originalUrl ?? row?.normalized_url ?? row?.normalizedUrl;
				const url = typeof rawUrl === 'string' ? rawUrl.trim() : '';
				if (!Number.isFinite(linkId) || !url || !isSupportedProductPdpUrl(url)) return null;
				return {
					linkId,
					url,
					platform: String(row?.platform || '').trim().toLowerCase() || null,
				};
			})
			.filter(Boolean);
	}

	function watchScrapeProgress(onStatus) {
		if (!chrome?.runtime?.onMessage || typeof onStatus !== 'function') {
			return () => {};
		}
		const listener = (msg) => {
			if (msg?.type === 'kg-scrape-progress' && msg.message) {
				onStatus(msg);
			}
		};
		chrome.runtime.onMessage.addListener(listener);
		return () => chrome.runtime.onMessage.removeListener(listener);
	}

	async function scrapeLinksViaTabs(links, options) {
		if (!Array.isArray(links) || links.length === 0) return [];
		const scrapeOptions =
			options && options.scrapeOptions && typeof options.scrapeOptions === 'object'
				? options.scrapeOptions
				: null;
		const timeoutMs =
			options && Number.isFinite(Number(options.timeoutMs)) ? Number(options.timeoutMs) : 0;
		const onScrapeProgress =
			options && typeof options.onScrapeProgress === 'function' ? options.onScrapeProgress : null;
		const unwatch = onScrapeProgress ? watchScrapeProgress(onScrapeProgress) : () => {};
		try {
			const sendScrape = () =>
				sendRuntimeMessage({
					type: 'kg-scrape-trendyol-pdp-tabs',
					links,
					...(scrapeOptions ? { scrapeOptions } : {}),
				}).then((response) => {
					if (!response || response.ok !== true) {
						throw new Error(response?.error || 'Sekmeli scrape başarısız.');
					}
					return response;
				});
			const data =
				timeoutMs > 0
					? await Promise.race([
							sendScrape(),
							new Promise((_, reject) => {
								setTimeout(
									() =>
										reject(
											new Error(
												`Scrape zaman aşımı (${Math.round(timeoutMs / 1000)} sn)`,
											),
										),
									timeoutMs,
								);
							}),
						])
					: await sendScrape();
			return Array.isArray(data?.results) ? data.results : [];
		} finally {
			unwatch();
		}
	}

	/**
	 * Her linki sırayla scrape eder; başarılı olanları hemen veritabanına yazar (Auto Scraping).
	 * @param {Array<{linkId:number,url:string,platform?:string|null}>} links
	 * @param {{ onProgress?: (info: { index: number, total: number, phase: string, url: string }) => void, shouldStop?: () => boolean }} [options]
	 */
	function scrapeModeLabel(mode) {
		if (mode === 'product_only') return 'Sadece ürün bilgileri';
		if (mode === 'reviews_only') return 'Sadece yorumlar';
		return 'Ürün + yorumlar';
	}

	function readApiJsonScrapeMode(modalBodyEl) {
		const checked = modalBodyEl?.querySelector('input[name="kg-scrape-collect-mode"]:checked');
		const mode = checked?.value;
		if (mode === 'product_only' || mode === 'product_and_reviews' || mode === 'reviews_only') {
			return mode;
		}
		return 'product_and_reviews';
	}

	function readApiJsonTabConcurrency(modalBodyEl) {
		const raw = Number(modalBodyEl?.querySelector('#kg-scrape-tab-concurrency')?.value);
		if (!Number.isFinite(raw)) return 1;
		return Math.max(1, Math.min(10, Math.floor(raw)));
	}

	function tabConcurrencyLabel(n) {
		return `${n} sekme`;
	}

	function buildApiJsonScrapeOptions(modalBodyEl) {
		return {
			scrapeMode: readApiJsonScrapeMode(modalBodyEl),
			tabConcurrency: readApiJsonTabConcurrency(modalBodyEl),
		};
	}

	function shouldMarkReviewsAsChecked(item) {
		const raw = item?.rawProductJson;
		return raw?.schemaVersion === 'trendyol-reviews-only-1';
	}

	async function applyScrapeResultToDb(link, row, options) {
		const isReviewsOnly = options?.scrapeMode === 'reviews_only';
		const result = { savedCount: 0, parsedCount: 0, errors: [] };
		if (row.ok && row.item) {
			result.parsedCount = 1;
			try {
				if (isReviewsOnly) {
					const productId = link.productId || row.item.scrapedProductId;
					const reviewList = Array.isArray(row.item.reviews) ? row.item.reviews : [];
					if (!productId) {
						result.errors.push({ url: link.url, message: 'Ürün kimliği eksik.' });
					} else if (reviewList.length < 1) {
						if (shouldMarkReviewsAsChecked(row.item)) {
							await patchProductReviews(productId, {
								...row.item,
								reviews: [],
								markReviewsChecked: true,
							});
							result.savedCount = 1;
						} else {
							result.errors.push({
								url: link.url,
								message: 'Yorum sonucu kaydedilemedi (geçersiz scrape çıktısı).',
							});
						}
					} else {
						await patchProductReviews(productId, row.item);
						result.savedCount = 1;
					}
				} else {
					const imp = await postApiJsonScrapingItems([row.item]);
					const saved = Number(imp.savedCount ?? 0);
					result.savedCount = saved;
					if (saved < 1) {
						result.errors.push({
							url: link.url,
							message: 'Veritabanına yazılamadı.',
						});
						if (Number.isFinite(link.linkId)) {
							await markProductLinkStatuses([{ id: link.linkId, status: 'failed' }]).catch(
								() => {},
							);
						}
					}
				}
			} catch (err) {
				result.errors.push({
					url: link.url,
					message: formatScrapeErrorMessage(err, 'Kayıt hatası'),
				});
				if (!isReviewsOnly && Number.isFinite(link.linkId)) {
					await markProductLinkStatuses([{ id: link.linkId, status: 'failed' }]).catch(() => {});
				}
			}
		} else {
			result.errors.push({
				url: row.url || link.url,
				message: formatScrapeErrorMessage(row.error, 'Sekme scrape hatası'),
			});
			if (!isReviewsOnly && Number.isFinite(link.linkId)) {
				await markProductLinkStatuses([{ id: link.linkId, status: 'failed' }]).catch(() => {});
			}
		}
		return result;
	}

	async function scrapeAndImportLinksIncrementally(links, options) {
		const errors = [];
		let savedCount = 0;
		let parsedCount = 0;
		let processedCount = 0;
		const total = Array.isArray(links) ? links.length : 0;
		const onProgress = options && typeof options.onProgress === 'function' ? options.onProgress : null;
		const shouldStop = options && typeof options.shouldStop === 'function' ? options.shouldStop : () => false;
		const scrapeOptions =
			options && options.scrapeOptions && typeof options.scrapeOptions === 'object'
				? options.scrapeOptions
				: { scrapeMode: 'product_and_reviews', tabConcurrency: 1 };
		const isReviewsOnly = scrapeOptions.scrapeMode === 'reviews_only';
		const tabConcurrency = Math.max(
			1,
			Math.min(10, Number(scrapeOptions.tabConcurrency) || 1),
		);
		const tabsPrefix =
			tabConcurrency > 1 ? `${tabConcurrencyLabel(tabConcurrency)} · ` : '';

		for (let start = 0; start < total; start += tabConcurrency) {
			if (shouldStop()) break;
			const chunk = links.slice(start, start + tabConcurrency);
			const chunkEnd = start + chunk.length;
			let liveStatus = isReviewsOnly ? 'Yorumlar çekiliyor…' : 'Ürün verisi çekiliyor…';
			const scrapeStarted = Date.now();

			const reportChunkProgress = (extra) => {
				const elapsedSec = Math.floor((Date.now() - scrapeStarted) / 1000);
				const activeUrl = chunk[0]?.url || '';
				onProgress?.({
					index: chunkEnd,
					total,
					phase: 'scrape',
					url: activeUrl,
					elapsedSec,
					statusMessage: `${tabsPrefix}${liveStatus}${extra || ''}${
						elapsedSec > 0 && !liveStatus.includes('sn') ? ` (${elapsedSec} sn)` : ''
					}`,
				});
			};

			reportChunkProgress(
				chunk.length > 1 ? ` · ${start + 1}–${chunkEnd}/${total}` : ` · ${chunkEnd}/${total}`,
			);
			const tickScrape = setInterval(() => reportChunkProgress(''), 1000);

			let tabResults = [];
			try {
				tabResults = await scrapeLinksViaTabs(chunk, {
					scrapeOptions,
					timeoutMs: 360000,
					onScrapeProgress: (msg) => {
						liveStatus = msg.message || liveStatus;
						const msgUrl = msg.url || '';
						const matchIdx = chunk.findIndex((l) => l.url === msgUrl);
						const pos =
							matchIdx >= 0 ? start + matchIdx + 1 : chunkEnd;
						onProgress?.({
							index: pos,
							total,
							phase: 'scrape',
							url: msgUrl || chunk[0]?.url || '',
							elapsedSec: Math.floor((Date.now() - scrapeStarted) / 1000),
							statusMessage: `${tabsPrefix}${liveStatus}`,
						});
					},
				});
			} catch (err) {
				for (let ci = 0; ci < chunk.length; ci++) {
					errors.push({
						url: chunk[ci].url,
						message: formatScrapeErrorMessage(err, 'Sekme scrape hatası'),
					});
					if (!isReviewsOnly && Number.isFinite(chunk[ci].linkId)) {
						await markProductLinkStatuses([{ id: chunk[ci].linkId, status: 'failed' }]).catch(
							() => {},
						);
					}
					processedCount += 1;
				}
				clearInterval(tickScrape);
				continue;
			} finally {
				clearInterval(tickScrape);
			}

			for (let ci = 0; ci < chunk.length; ci++) {
				const link = chunk[ci];
				const index = start + ci + 1;
				const row = tabResults[ci] || {};
				onProgress?.({
					index,
					total,
					phase: 'save',
					url: link.url,
					statusMessage: isReviewsOnly ? 'Yorumlar kaydediliyor…' : 'Veritabanına kaydediliyor…',
				});
				const applied = await applyScrapeResultToDb(link, row, scrapeOptions);
				savedCount += applied.savedCount;
				parsedCount += applied.parsedCount;
				if (applied.errors.length) errors.push(...applied.errors);
				processedCount += 1;
			}
		}

		return { savedCount, parsedCount, processedCount, errors };
	}

	function downloadProductCrawlerJson(batch) {
		const okItems = Array.isArray(batch?.ok) ? batch.ok : [];
		const errorItems = Array.isArray(batch?.errors) ? batch.errors : [];
		if (!batch || (!okItems.length && !errorItems.length)) return;
		const payload = {
			schemaVersion: 'dc-trendyol-product-batch-1',
			generatedAt: batch.generatedAt,
			source: 'trendyol-product-crawler',
			items: okItems,
			errors: errorItems,
		};
		const blob = new Blob([JSON.stringify(payload, null, 2)], {
			type: 'application/json;charset=utf-8',
		});
		const objectUrl = URL.createObjectURL(blob);
		const a = document.createElement('a');
		a.href = objectUrl;
		a.download = `ahtapot-trendyol-products-${Date.now()}.json`;
		a.rel = 'noopener';
		(document.body || document.documentElement).appendChild(a);
		a.click();
		a.remove();
		setTimeout(() => URL.revokeObjectURL(objectUrl), 15000);
	}

	let kgXlsxLoadPromise = null;
	function ensureXlsxLoaded() {
		if (globalThis.XLSX) return Promise.resolve(globalThis.XLSX);
		if (kgXlsxLoadPromise) return kgXlsxLoadPromise;
		kgXlsxLoadPromise = new Promise((resolve, reject) => {
			const script = document.createElement('script');
			script.src = 'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';
			script.async = true;
			script.onload = () => {
				if (globalThis.XLSX) resolve(globalThis.XLSX);
				else reject(new Error('XLSX kutuphanesi yuklenemedi.'));
			};
			script.onerror = () => reject(new Error('XLSX kutuphanesi indirilemedi.'));
			(document.head || document.documentElement).appendChild(script);
		});
		return kgXlsxLoadPromise;
	}

	async function downloadProductCrawlerExcel(batch) {
		const okItems = Array.isArray(batch?.ok) ? batch.ok : [];
		const errorItems = Array.isArray(batch?.errors) ? batch.errors : [];
		if (!batch || (!okItems.length && !errorItems.length)) return;
		const rows = [];
		for (let i = 0; i < okItems.length; i++) {
			rows.push({
				Link: okItems[i]?.sourceUrl || '',
				Title: okItems[i]?.title || '',
				Kategori: okItems[i]?.category || '',
			});
		}
		for (let j = 0; j < errorItems.length; j++) {
			rows.push({
				Link: errorItems[j]?.url || '',
				Title: errorItems[j]?.title || '',
				Kategori: '',
			});
		}
		try {
			const XLSX = await ensureXlsxLoaded();
			const wb = XLSX.utils.book_new();
			const ws = XLSX.utils.json_to_sheet(rows, { header: ['Link', 'Title', 'Kategori'] });
			XLSX.utils.book_append_sheet(wb, ws, 'Products');
			XLSX.writeFile(wb, `ahtapot-trendyol-products-${Date.now()}.xlsx`);
		} catch {
			const blob = buildMinimalXlsxBlob(rows);
			downloadBlobAsFile(blob, `ahtapot-trendyol-products-${Date.now()}.xlsx`);
		}
	}

	function downloadBlobAsFile(blob, filename) {
		const objectUrl = URL.createObjectURL(blob);
		const a = document.createElement('a');
		a.href = objectUrl;
		a.download = filename;
		a.rel = 'noopener';
		(document.body || document.documentElement).appendChild(a);
		a.click();
		a.remove();
		setTimeout(() => URL.revokeObjectURL(objectUrl), 15000);
	}

	function buildMinimalXlsxBlob(rows) {
		const xmlEscape = (value) =>
			String(value ?? '')
				.replace(/&/g, '&amp;')
				.replace(/</g, '&lt;')
				.replace(/>/g, '&gt;')
				.replace(/"/g, '&quot;')
				.replace(/'/g, '&apos;');
		const colName = (index) => {
			let n = index;
			let s = '';
			while (n >= 0) {
				s = String.fromCharCode((n % 26) + 65) + s;
				n = Math.floor(n / 26) - 1;
			}
			return s;
		};
		const table = [['Link', 'Title', 'Kategori']];
		for (let i = 0; i < rows.length; i++) {
			table.push([rows[i]?.Link || '', rows[i]?.Title || '', rows[i]?.Kategori || '']);
		}
		let sheetRows = '';
		for (let r = 0; r < table.length; r++) {
			sheetRows += `<row r="${r + 1}">`;
			for (let c = 0; c < table[r].length; c++) {
				sheetRows += `<c r="${colName(c)}${r + 1}" t="inlineStr"><is><t>${xmlEscape(table[r][c])}</t></is></c>`;
			}
			sheetRows += '</row>';
		}
		const files = [
			{
				name: '[Content_Types].xml',
				content:
					'<?xml version="1.0" encoding="UTF-8"?>' +
					'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
					'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
					'<Default Extension="xml" ContentType="application/xml"/>' +
					'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
					'<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' +
					'</Types>',
			},
			{
				name: '_rels/.rels',
				content:
					'<?xml version="1.0" encoding="UTF-8"?>' +
					'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
					'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
					'</Relationships>',
			},
			{
				name: 'xl/workbook.xml',
				content:
					'<?xml version="1.0" encoding="UTF-8"?>' +
					'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
					'<sheets><sheet name="Products" sheetId="1" r:id="rId1"/></sheets>' +
					'</workbook>',
			},
			{
				name: 'xl/_rels/workbook.xml.rels',
				content:
					'<?xml version="1.0" encoding="UTF-8"?>' +
					'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
					'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>' +
					'</Relationships>',
			},
			{
				name: 'xl/worksheets/sheet1.xml',
				content:
					'<?xml version="1.0" encoding="UTF-8"?>' +
					'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
					`<sheetData>${sheetRows}</sheetData>` +
					'</worksheet>',
			},
		];
		return zipStoredFiles(files);
	}

	function zipStoredFiles(files) {
		const enc = new TextEncoder();
		const crcTable = new Uint32Array(256).map((_, n) => {
			let c = n;
			for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
			return c >>> 0;
		});
		const crc32 = (bytes) => {
			let c = 0xffffffff;
			for (let i = 0; i < bytes.length; i++) c = crcTable[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
			return (c ^ 0xffffffff) >>> 0;
		};
		const chunks = [];
		const central = [];
		let offset = 0;
		const u16 = (v) => new Uint8Array([v & 255, (v >>> 8) & 255]);
		const u32 = (v) => new Uint8Array([v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]);
		for (let i = 0; i < files.length; i++) {
			const name = enc.encode(files[i].name);
			const data = enc.encode(files[i].content);
			const crc = crc32(data);
			const local = new Uint8Array([
				...u32(0x04034b50),
				...u16(20),
				...u16(0),
				...u16(0),
				...u16(0),
				...u16(0),
				...u32(crc),
				...u32(data.length),
				...u32(data.length),
				...u16(name.length),
				...u16(0),
			]);
			chunks.push(local, name, data);
			const cdh = new Uint8Array([
				...u32(0x02014b50),
				...u16(20),
				...u16(20),
				...u16(0),
				...u16(0),
				...u16(0),
				...u16(0),
				...u32(crc),
				...u32(data.length),
				...u32(data.length),
				...u16(name.length),
				...u16(0),
				...u16(0),
				...u16(0),
				...u16(0),
				...u32(0),
				...u32(offset),
			]);
			central.push(cdh, name);
			offset += local.length + name.length + data.length;
		}
		const centralSize = central.reduce((n, p) => n + p.length, 0);
		const end = new Uint8Array([
			...u32(0x06054b50),
			...u16(0),
			...u16(0),
			...u16(files.length),
			...u16(files.length),
			...u32(centralSize),
			...u32(offset),
			...u16(0),
		]);
		return new Blob([...chunks, ...central, end], {
			type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		});
	}

	function extractTrendyolPreviewFromHtml(html, fallbackUrl) {
		function extractContentUrlsFromDoc(doc) {
			const urls = [];
			const seen = new Set();
			const pushUrl = (value) => {
				const u = String(value || '').trim();
				if (!u || !/^https?:\/\//i.test(u) || seen.has(u)) return;
				seen.add(u);
				urls.push(u);
			};
			const scripts = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));
			for (let i = 0; i < scripts.length; i++) {
				const raw = String(scripts[i].textContent || '').trim();
				if (!raw) continue;
				try {
					const parsed = JSON.parse(raw);
					const walk = (node) => {
						if (!node) return;
						if (Array.isArray(node)) {
							for (let j = 0; j < node.length; j++) walk(node[j]);
							return;
						}
						if (typeof node !== 'object') return;
						if (Array.isArray(node.contentUrl)) {
							for (let k = 0; k < node.contentUrl.length; k++) pushUrl(node.contentUrl[k]);
						}
						if (typeof node.url === 'string') pushUrl(node.url);
						if (typeof node.image === 'string') pushUrl(node.image);
						if (Array.isArray(node.image)) {
							for (let m = 0; m < node.image.length; m++) walk(node.image[m]);
						} else if (node.image && typeof node.image === 'object') {
							walk(node.image);
						}
					};
					walk(parsed);
				} catch {
					/* ignore invalid script */
				}
			}
			if (urls.length) return urls;
			const match = html.match(/"contentUrl"\s*:\s*(\[[^\]]+\])/);
			if (!match || !match[1]) return [];
			try {
				const arr = JSON.parse(match[1]);
				if (!Array.isArray(arr)) return [];
				for (let i = 0; i < arr.length; i++) pushUrl(arr[i]);
			} catch {
				/* ignore parse */
			}
			return urls;
		}
		try {
			const doc = new DOMParser().parseFromString(html, 'text/html');
			const title =
				(doc.querySelector('meta[property="og:title"]')?.getAttribute('content') || '').trim() ||
				(doc.querySelector('meta[name="twitter:title"]')?.getAttribute('content') || '').trim() ||
				(doc.querySelector('h1')?.textContent || '').trim() ||
				(doc.querySelector('title')?.textContent || '').trim() ||
				fallbackUrl ||
				'';
			const image =
				(doc.querySelector('meta[property="og:image"]')?.getAttribute('content') || '').trim() ||
				(doc.querySelector('meta[name="twitter:image"]')?.getAttribute('content') || '').trim() ||
				'';
			const images = extractContentUrlsFromDoc(doc);
			return { title, image, images };
		} catch {
			return { title: fallbackUrl || '', image: '', images: [] };
		}
	}

	function extractN11StateProductFromHtml(html, fallbackUrl) {
		function normalizeAttrText(value) {
			return String(value || '')
				.replace(/\s+/g, ' ')
				.replace(/^[:\-\s]+|[:\-\s]+$/g, '')
				.trim();
		}
		function extractN11AttributesFromDoc(doc) {
			const out = [];
			const seen = new Set();
			const rows = Array.from(
				doc.querySelectorAll(
					'#productAttributes .unf-prop-list-item, #productAttributes .catalogAttributeItem, #productAttributes li',
				),
			);
			for (let i = 0; i < rows.length; i++) {
				const row = rows[i];
				let name = normalizeAttrText(
					row.querySelector('.unf-prop-list-title, .attrKey, dt, span:first-child')?.textContent || '',
				);
				let value = normalizeAttrText(
					row.querySelector('.unf-prop-list-prop, .attrValue, dd, span:last-child')?.textContent || '',
				);
				if ((!name || !value) && row.childElementCount === 0) {
					const text = normalizeAttrText(row.textContent || '');
					const idx = text.indexOf(':');
					if (idx > 0) {
						name = normalizeAttrText(text.slice(0, idx));
						value = normalizeAttrText(text.slice(idx + 1));
					}
				}
				if (!name || !value || name === value) continue;
				const key = `${name}::${value}`;
				if (seen.has(key)) continue;
				seen.add(key);
				out.push({ name, value });
			}
			return out;
		}
		function extractN11AttributesFromFeatureTable(doc) {
			const out = [];
			const seen = new Set();
			const rows = Array.from(
				doc.querySelectorAll(
					'table#attr-table tr, #attr-table tr, table.product-features tr, .product-features-table tr, #productDescription table tr',
				),
			);
			for (let i = 0; i < rows.length; i++) {
				const row = rows[i];
				const name = normalizeAttrText(
					row.querySelector('th, td.attr-name, td.key, td:first-child, .attr-name')?.textContent || '',
				);
				const value = normalizeAttrText(
					row.querySelector('td.attr-value, td.value, td:last-child, .attr-value')?.textContent || '',
				);
				if (!name || !value || name === value) continue;
				const key = `${name}::${value}`;
				if (seen.has(key)) continue;
				seen.add(key);
				out.push({ name, value });
			}
			return out;
		}
		function extractN11AttributesFromDescriptionText(text) {
			const out = [];
			const seen = new Set();
			const blockedCssKeys = new Set([
				'font-size',
				'color',
				'padding',
				'padding-bottom',
				'padding-top',
				'padding-left',
				'padding-right',
				'margin',
				'margin-bottom',
				'margin-top',
				'margin-left',
				'margin-right',
				'line-height',
				'font-family',
				'background',
				'border',
				'border-radius',
				'max-width',
				'height',
				'width',
				'display',
				'position',
				'overflow',
				'text-align',
			]);
			function shouldSkipCssNoise(name, value) {
				const n = String(name || '').toLowerCase().trim();
				const v = String(value || '').toLowerCase().trim();
				if (!n || !v) return true;
				if (blockedCssKeys.has(n)) return true;
				if (n.includes('{') || n.includes('}') || n.includes('.')) return true;
				if (/^\.|^#|^\@|^\*/.test(n)) return true;
				if (/(px|em|rem|vh|vw|%|rgb\(|rgba\(|#(?:[0-9a-f]{3}|[0-9a-f]{6}))/i.test(v) && blockedCssKeys.has(n)) {
					return true;
				}
				if (/^[a-z\-]+\s*\{?/i.test(n) && /;/.test(v)) return true;
				return false;
			}
			const lines = String(text || '')
				.replace(/&nbsp;/gi, ' ')
				.replace(/<br\s*\/?>/gi, '\n')
				.replace(/<\/p>/gi, '\n')
				.replace(/<\/li>/gi, '\n')
				.replace(/<[^>]+>/g, ' ')
				.split(/\r?\n+/)
				.map((x) => normalizeAttrText(x))
				.filter(Boolean);
			for (let i = 0; i < lines.length; i++) {
				const line = lines[i];
				const idx = line.indexOf(':');
				if (idx <= 0) continue;
				const name = normalizeAttrText(line.slice(0, idx));
				const value = normalizeAttrText(line.slice(idx + 1));
				if (shouldSkipCssNoise(name, value)) continue;
				if (!name || !value || name === value) continue;
				const key = `${name}::${value}`;
				if (seen.has(key)) continue;
				seen.add(key);
				out.push({ name, value });
			}
			return out;
		}
		if (!html || typeof html !== 'string') return null;
		const keyIdx = html.indexOf('"product":');
		if (keyIdx === -1) return null;
		const braceStart = html.indexOf('{', keyIdx);
		if (braceStart === -1) return null;
		let depth = 0;
		let inString = false;
		let escaped = false;
		let end = -1;
		for (let i = braceStart; i < html.length; i++) {
			const ch = html[i];
			if (inString) {
				if (escaped) escaped = false;
				else if (ch === '\\') escaped = true;
				else if (ch === '"') inString = false;
				continue;
			}
			if (ch === '"') {
				inString = true;
				continue;
			}
			if (ch === '{') depth++;
			else if (ch === '}') {
				depth--;
				if (depth === 0) {
					end = i;
					break;
				}
			}
		}
		if (end === -1) return null;
		try {
			const product = JSON.parse(html.slice(braceStart, end + 1));
			const breadcrumb = Array.isArray(product?.breadcrumb)
				? product.breadcrumb
						.map((x) => (typeof x?.name === 'string' ? x.name.trim() : ''))
						.filter(Boolean)
				: [];
			const attrsFromState = Array.isArray(product?.productAttributes)
				? product.productAttributes
						.map((x) => {
							const name = typeof x?.key === 'string' ? x.key.trim() : '';
							const value = typeof x?.value === 'string' ? x.value.trim() : '';
							if (!name || !value) return null;
							return { name, value };
						})
						.filter(Boolean)
				: [];
			const doc = new DOMParser().parseFromString(html, 'text/html');
			const attrsFromDom = extractN11AttributesFromDoc(doc);
			const attrsFromTable = extractN11AttributesFromFeatureTable(doc);
			const attrsFromDescription = extractN11AttributesFromDescriptionText(
				product?.description || product?.catalogDescription || '',
			);
			const attrs = [];
			const seen = new Set();
			for (const group of [attrsFromDom, attrsFromTable, attrsFromDescription, attrsFromState]) {
				for (let i = 0; i < group.length; i++) {
					const row = group[i];
					const key = `${row.name}::${row.value}`;
					if (seen.has(key)) continue;
					seen.add(key);
					attrs.push(row);
				}
			}
			const imagePath = Array.isArray(product?.images) ? product.images[0]?.path : null;
			const barcode =
				typeof product?.gtin8 === 'string' && product.gtin8.trim()
					? product.gtin8.trim()
					: typeof product?.barcode === 'string' && product.barcode.trim()
						? product.barcode.trim()
						: typeof product?.defaultGtin === 'string' && product.defaultGtin.trim()
							? product.defaultGtin.trim()
							: Array.isArray(product?.skus) && typeof product.skus[0]?.gtin === 'string'
								? product.skus[0].gtin.trim()
								: null;
			return {
				title: product?.title || fallbackUrl || '',
				brand: product?.productBrand || null,
				price: typeof product?.priceFloat === 'number' ? product.priceFloat : null,
				currency: 'TRY',
				categoryPath: breadcrumb,
				imageUrl: typeof imagePath === 'string' ? imagePath.replace('/{0}/', '/320/') : null,
				attributes: attrs,
				barcode,
				rawProductJson: {
					schemaVersion: 'n11-product-crawler-1',
					sourceUrl: fallbackUrl,
					product,
				},
			};
		} catch {
			return null;
		}
	}

	/**
	 * 3. özellik — Data Crawler Product Crawler entegrasyonu (Trendyol PDP -> JSON batch).
	 * @param {HTMLElement} modalTitleEl
	 * @param {HTMLElement} modalBodyEl
	 * @param {() => void} onClose
	 */
	function ahtapotOpenProductCrawler(modalTitleEl, modalBodyEl, onClose) {
		clearApiSession();
		activeLcUi = null;
		modalTitleEl.textContent = 'Product Crawler';
		modalBodyEl.innerHTML = `
			<div class="kg-product-modal" role="region" aria-label="Product Crawler">
				<p class="kg-product-modal-lead">Her satira bir <strong>Trendyol</strong> veya <strong>n11</strong> PDP linki girin. Trendyol icin Akilli Saat/Cep Telefonu mapper kullanilir; n11 icin sayfa state'inden urun verisi cikartilir.</p>
				<textarea class="kg-product-input" id="kg-product-urls" rows="10" placeholder="https://www.trendyol.com/...-p-123456789 veya https://www.n11.com/urun/..." spellcheck="false"></textarea>
				<p class="kg-product-status" id="kg-product-status"></p>
				<div class="kg-lc-txt-merge-actions" id="kg-product-actions"></div>
			</div>
		`;

		const urlsEl = modalBodyEl.querySelector('#kg-product-urls');
		const statusEl = modalBodyEl.querySelector('#kg-product-status');
		const actionsEl = modalBodyEl.querySelector('#kg-product-actions');
		if (!urlsEl || !statusEl || !actionsEl) return;

		/** @type {{ ok: any[]; errors: {url: string; message: string}[]; generatedAt: string } | null} */
		let batch = null;

		const runBtn = document.createElement('button');
		runBtn.type = 'button';
		runBtn.className = 'kg-lc-btn kg-lc-btn--primary';
		runBtn.textContent = 'Çalıştır';
		const downloadBtn = document.createElement('button');
		downloadBtn.type = 'button';
		downloadBtn.className = 'kg-lc-btn kg-lc-btn--primary';
		downloadBtn.textContent = 'JSON indir';
		downloadBtn.disabled = true;
		const excelBtn = document.createElement('button');
		excelBtn.type = 'button';
		excelBtn.className = 'kg-lc-btn kg-lc-btn--primary';
		excelBtn.textContent = 'Excel indir';
		excelBtn.disabled = true;
		const closeBtn = document.createElement('button');
		closeBtn.type = 'button';
		closeBtn.className = 'kg-lc-btn kg-lc-btn--ghost';
		closeBtn.textContent = 'Kapat';
		closeBtn.addEventListener('click', () => onClose());
		actionsEl.append(runBtn, downloadBtn, excelBtn, closeBtn);

		runBtn.addEventListener('click', async () => {
			const lines = parseProductCrawlerUrlLines(urlsEl.value);
			if (!lines.length) {
				statusEl.innerHTML =
					'Gecerli URL yok. Her satir Trendyol PDP (<code>...-p-</code>) veya n11 PDP (<code>/urun/</code>) formatinda olmali.';
				batch = null;
				downloadBtn.disabled = true;
				excelBtn.disabled = true;
				return;
			}
			if (typeof globalThis.dcLoadTelefonTemplate !== 'function') {
				statusEl.textContent = 'Telefon şablonu yükleyici bulunamadı.';
				return;
			}
			if (typeof globalThis.dcLoadAkilliSaatTemplate !== 'function') {
				statusEl.textContent = 'Akıllı saat şablonu yükleyici bulunamadı.';
				return;
			}
			if (typeof globalThis.dcDetectTrendyolCategoryFromHtml !== 'function') {
				statusEl.textContent = 'Kategori algılayıcı bulunamadı.';
				return;
			}
			if (typeof globalThis.dcMapTrendyolHtmlToTelefon !== 'function') {
				statusEl.textContent = 'Product mapper bulunamadı.';
				return;
			}

			const ok = [];
			const errors = [];
			downloadBtn.disabled = true;
			excelBtn.disabled = true;
			for (let i = 0; i < lines.length; i++) {
				const url = lines[i];
				let preview = { title: '', image: '', images: [] };
				statusEl.textContent = 'İşleniyor ' + (i + 1) + '/' + lines.length + '...';
				try {
					const res = await fetch(url, { credentials: 'include', redirect: 'follow' });
					if (!res.ok) throw new Error('HTTP ' + res.status);
					const html = await res.text();
					preview = extractTrendyolPreviewFromHtml(html, url);
					const platform = detectProductPlatform(url);
					if (platform === 'n11') {
						const n11Data = extractN11StateProductFromHtml(html, url);
						if (!n11Data) {
							throw new Error('n11 urun state verisi bulunamadi.');
						}
						ok.push({
							sourceUrl: url,
							category: Array.isArray(n11Data.categoryPath)
								? n11Data.categoryPath.join(' > ')
								: null,
							title: n11Data.title || preview.title || null,
							image: n11Data.imageUrl || preview.image || null,
							images: Array.isArray(preview.images) ? preview.images : [],
							product: n11Data,
						});
						continue;
					}
					const category = globalThis.dcDetectTrendyolCategoryFromHtml(html);
					if (!category) {
						const trail =
							typeof globalThis.dcExtractTrendyolBreadcrumbTrail === 'function'
								? globalThis.dcExtractTrendyolBreadcrumbTrail(html)
								: [];
						const normalizedTrail =
							trail.length && /^trendyol$/i.test(String(trail[0] || '').trim())
								? trail.slice(1)
								: trail;
						throw new Error(
							normalizedTrail.length ? normalizedTrail.join(' > ') : 'Kategori tespit edilemedi.',
						);
					}
					const template =
						category === 'akilli-saat'
							? await globalThis.dcLoadAkilliSaatTemplate()
							: await globalThis.dcLoadTelefonTemplate();
					const product = globalThis.dcMapTrendyolHtmlToTelefon(html, url, template);
					ok.push({
						sourceUrl: url,
						category,
						title: preview.title || null,
						image: preview.image || null,
						images: Array.isArray(preview.images) ? preview.images : [],
						product,
					});
				} catch (err) {
					errors.push({
						url,
						title: preview.title || '',
						image: preview.image || '',
						images: Array.isArray(preview.images) ? preview.images : [],
						message: err && err.message ? err.message : String(err),
					});
				}
			}

			batch = {
				ok,
				errors,
				generatedAt: new Date().toISOString(),
			};
			statusEl.innerHTML =
				'Bitti: <strong>' +
				ok.length +
				'</strong> ürün işlendi' +
				(errors.length ? ', <strong>' + errors.length + '</strong> hata' : '') +
				'.';
			downloadBtn.disabled = ok.length === 0 && errors.length === 0;
			excelBtn.disabled = ok.length === 0 && errors.length === 0;
		});

		downloadBtn.addEventListener('click', () => downloadProductCrawlerJson(batch));
		excelBtn.addEventListener('click', async () => {
			try {
				await downloadProductCrawlerExcel(batch);
			} catch (error) {
				statusEl.textContent =
					(error && error.message) || 'Excel dosyasi olusturulamadi.';
			}
		});
		globalThis.ahtapotLcCleanup = () => {
			batch = null;
		};
	}

	function ahtapotOpenApiJsonScraping(modalTitleEl, modalBodyEl, onClose) {
		clearApiSession();
		activeLcUi = null;
		modalTitleEl.textContent = 'API JSON Scraping';
		modalBodyEl.innerHTML = `
			<div class="kg-product-modal" role="region" aria-label="API JSON Scraping">
				<p class="kg-product-modal-lead">Ürün modları: <code>/api/links/pending</code> kuyruğu (<strong>Trendyol, n11, Hepsiburada, Amazon</strong>). <strong>Sadece yorum topla</strong>: veritabanında <code>reviews</code> alanı boş olan Trendyol kayıtları (<code>/api/scraped-products/missing-reviews</code>). Panelde <code>npm run api</code> ve <code>npm run dev</code> çalışır olmalı.</p>
				<fieldset class="kg-scrape-mode-fieldset" id="kg-scrape-collect-mode-wrap">
					<legend class="kg-product-modal-lead">Ne toplansın?</legend>
					<label class="kg-scrape-mode-option">
						<input type="radio" name="kg-scrape-collect-mode" value="product_only" />
						<span>Sadece ürün bilgilerini topla</span>
					</label>
					<label class="kg-scrape-mode-option">
						<input type="radio" name="kg-scrape-collect-mode" value="product_and_reviews" checked />
						<span>Ürün bilgileri + yorum topla</span>
					</label>
					<label class="kg-scrape-mode-option">
						<input type="radio" name="kg-scrape-collect-mode" value="reviews_only" />
						<span>Sadece yorum topla <span class="kg-scrape-mode-hint">(yorumu boş ve henüz taranmamış Trendyol ürünleri; yorumsuz ürünler bir kez işaretlenir)</span></span>
					</label>
				</fieldset>
				<label class="kg-product-modal-lead" for="kg-scrape-tab-concurrency">Eşzamanlı sekme</label>
				<select class="kg-product-input kg-scrape-tab-select" id="kg-scrape-tab-concurrency" aria-label="Eşzamanlı sekme sayısı">
					<option value="1" selected>1 sekme</option>
					<option value="2">2 sekme</option>
					<option value="3">3 sekme</option>
					<option value="4">4 sekme</option>
					<option value="5">5 sekme</option>
					<option value="6">6 sekme</option>
					<option value="7">7 sekme</option>
					<option value="8">8 sekme</option>
					<option value="9">9 sekme</option>
					<option value="10">10 sekme</option>
				</select>
				<p class="kg-scrape-mode-hint kg-scrape-tab-hint">Aynı anda birden fazla ürün taranır (tüm toplama modlarında geçerli). Daha fazla sekme daha hızlıdır; Trendyol limitine takılma riski artar.</p>
				<label class="kg-product-modal-lead" for="kg-api-json-limit">Tur başına link (Auto Scraping: <strong>Dur</strong>’a basana kadar tüm kuyruk işlenir)</label>
				<input class="kg-product-input" id="kg-api-json-limit" type="number" min="1" max="200" value="200" />
				<p class="kg-product-status" id="kg-api-json-status"></p>
				<div class="kg-lc-txt-merge-actions" id="kg-api-json-actions"></div>
			</div>
		`;

		const limitEl = modalBodyEl.querySelector('#kg-api-json-limit');
		const scrapeModeWrapEl = modalBodyEl.querySelector('#kg-scrape-collect-mode-wrap');
		const tabConcurrencyEl = modalBodyEl.querySelector('#kg-scrape-tab-concurrency');
		const statusEl = modalBodyEl.querySelector('#kg-api-json-status');
		const actionsEl = modalBodyEl.querySelector('#kg-api-json-actions');
		if (!limitEl || !statusEl || !actionsEl || !scrapeModeWrapEl || !tabConcurrencyEl) return;

		const runBtn = document.createElement('button');
		runBtn.type = 'button';
		runBtn.className = 'kg-lc-btn kg-lc-btn--primary';
		runBtn.textContent = 'Çalıştır ve Kaydet';
		const autoBtn = document.createElement('button');
		autoBtn.type = 'button';
		autoBtn.className = 'kg-lc-btn kg-lc-btn--primary';
		autoBtn.textContent = 'Auto Scraping';
		const stopBtn = document.createElement('button');
		stopBtn.type = 'button';
		stopBtn.className = 'kg-lc-btn kg-lc-btn--ghost';
		stopBtn.textContent = 'Dur';
		stopBtn.disabled = true;
		const closeBtn = document.createElement('button');
		closeBtn.type = 'button';
		closeBtn.className = 'kg-lc-btn kg-lc-btn--ghost';
		closeBtn.textContent = 'Kapat';
		closeBtn.addEventListener('click', () => onClose());
		actionsEl.append(runBtn, autoBtn, stopBtn, closeBtn);

		let autoRunning = false;
		let stopRequested = false;

		function setRunningState(running) {
			autoRunning = running;
			runBtn.disabled = running;
			autoBtn.disabled = running;
			stopBtn.disabled = !running;
			limitEl.disabled = running;
			tabConcurrencyEl.disabled = running;
			scrapeModeWrapEl.querySelectorAll('input[name="kg-scrape-collect-mode"]').forEach((el) => {
				el.disabled = running;
			});
		}

		stopBtn.addEventListener('click', () => {
			if (!autoRunning) return;
			stopRequested = true;
			stopBtn.disabled = true;
			statusEl.textContent =
				'Dur isteği alındı. Aktif parti tamamlanıp kuyruğa kaydedildikten sonra duracak...';
		});

		runBtn.addEventListener('click', async () => {
			const limit = Number(limitEl.value || 50);
			const scrapeOptions = buildApiJsonScrapeOptions(modalBodyEl);
			const isReviewsOnly = scrapeOptions.scrapeMode === 'reviews_only';
			let links = [];
			try {
				statusEl.textContent = isReviewsOnly
					? 'Yorumu boş ürünler alınıyor…'
					: 'Link listesi alınıyor…';
				links = await fetchScrapeQueue(limit, scrapeOptions.scrapeMode);
			} catch (err) {
				statusEl.textContent =
					err && err.message ? err.message : 'Liste alınırken hata oluştu.';
				return;
			}

			if (!links.length) {
				statusEl.innerHTML = isReviewsOnly
					? 'Veritabanında <strong>yorumu boş</strong> Trendyol ürünü bulunamadı.'
					: 'İşlenecek <strong>pending</strong> link bulunamadı.';
				return;
			}

			runBtn.disabled = true;
			const errors = [];
			try {
				if (isReviewsOnly) {
					const incremental = await scrapeAndImportLinksIncrementally(links, {
						scrapeOptions,
						onProgress: (info) => {
							const sec =
								info.elapsedSec != null && info.elapsedSec > 0 ? ` · ${info.elapsedSec} sn` : '';
							statusEl.textContent = `${info.index}/${info.total}${sec} — ${
								info.statusMessage || 'İşleniyor…'
							}`;
						},
					});
					errors.push(...incremental.errors);
					statusEl.innerHTML =
						'Bitti: <strong>' +
						links.length +
						'</strong> üründen <strong>' +
						incremental.parsedCount +
						'</strong> yorum çekildi, <strong>' +
						incremental.savedCount +
						'</strong> kayıt güncellendi' +
						(errors.length ? ', <strong>' + errors.length + '</strong> hata.' : '.');
				} else {
					const okItems = [];
					statusEl.textContent = `${scrapeModeLabel(scrapeOptions.scrapeMode)} çekiliyor…`;
					const tabResults = await scrapeLinksViaTabs(links, {
						scrapeOptions,
						onScrapeProgress: (msg) => {
							const idx =
								msg.index != null ? `${msg.index}/${msg.total || links.length} · ` : '';
							statusEl.textContent = `${idx}${msg.message}`;
						},
					}).catch((err) => {
						errors.push({
							url: 'background-tab-scraper',
							message: err && err.message ? err.message : String(err),
						});
						return [];
					});
					for (let i = 0; i < tabResults.length; i++) {
						const row = tabResults[i] || {};
						if (row.ok && row.item) {
							okItems.push(row.item);
						} else {
							errors.push({
								url: row.url || links[i]?.url || '-',
								message: row.error || 'Sekme scrape hatası',
							});
						}
					}
					let importResult = { savedCount: 0, failedCount: 0 };
					if (okItems.length) {
						importResult = await postApiJsonScrapingItems(okItems);
					}
					const failedUpdates = buildFailedLinkStatusUpdates(links, errors);
					if (failedUpdates.length) {
						await markProductLinkStatuses(failedUpdates).catch(() => {});
					}
					const errorSummary = buildErrorSummary(errors);
					statusEl.innerHTML =
						'Bitti: <strong>' +
						links.length +
						'</strong> pending linkten <strong>' +
						okItems.length +
						'</strong> URL parse edildi, <strong>' +
						String(importResult.savedCount ?? 0) +
						'</strong> kayıt veritabanına yazıldı' +
						(errors.length ? ', <strong>' + errors.length + '</strong> URL hata verdi (failed).' : '.') +
						(errorSummary
							? '<br><span style="opacity:.9">Hata özeti: ' +
								errorSummary.replace(/</g, '&lt;') +
								'</span>'
							: '');
				}
			} catch (err) {
				errors.push({
					url: isReviewsOnly ? 'reviews-patch' : panelApiUrl('/scraped-products/import'),
					message: err && err.message ? err.message : String(err),
				});
				statusEl.textContent = 'Kayıt sırasında hata oluştu: ' + (err?.message || String(err));
			} finally {
				runBtn.disabled = false;
			}
		});

		autoBtn.addEventListener('click', async () => {
			if (autoRunning) return;
			if (!isExtensionRuntimeAlive()) {
				statusEl.textContent = EXT_CONTEXT_INVALIDATED_TR;
				return;
			}
			stopRequested = false;
			setRunningState(true);
			const queuePlatform = detectCurrentPlatformForQueue();
			const limitRaw = Number(limitEl.value || 50);
			const safeLimit = Number.isFinite(limitRaw) ? Math.max(1, Math.min(200, Math.floor(limitRaw))) : 50;
			const batchLimit = queuePlatform === 'hepsiburada' ? Math.min(safeLimit, 15) : safeLimit;
			let cycle = 0;
			let totalProcessed = 0;
			let totalSaved = 0;
			let totalFailed = 0;
			const sessionSeenProductIds = new Set();
			const scrapeOptions = buildApiJsonScrapeOptions(modalBodyEl);
			const isReviewsOnly = scrapeOptions.scrapeMode === 'reviews_only';
			const collectLabel = scrapeModeLabel(scrapeOptions.scrapeMode);
			const IDLE_POLL_MS = 8000;
			const tabsLabel = tabConcurrencyLabel(scrapeOptions.tabConcurrency || 1);
			statusEl.innerHTML =
				`Auto Scraping başladı · mod: <strong>${collectLabel}</strong> · <strong>${tabsLabel}</strong> · tur başına en fazla <strong>${batchLimit}</strong> · ` +
				(isReviewsOnly
					? 'Kaynak: veritabanında yorumu boş Trendyol ürünleri (eşzamanlı sekme destekli) · '
					: scrapeOptions.scrapeMode === 'product_and_reviews'
						? 'Trendyol’da ürün + yorum (ürün başına birkaç dk sürebilir) · '
						: '') +
				`<strong>Dur</strong>’a basana kadar devam eder (liste bitince bekler, yeniden dener).`;
			try {
				while (true) {
					if (stopRequested) break;
					cycle += 1;
					let links = [];
					try {
						statusEl.textContent = isReviewsOnly
							? `Auto Scraping · Tur ${cycle}: yorumu boş ürünler alınıyor…`
							: `Auto Scraping · Tur ${cycle}: pending liste alınıyor…`;
						links = await fetchScrapeQueue(batchLimit, scrapeOptions.scrapeMode);
					} catch (err) {
						const errMsg = err && err.message ? err.message : String(err);
						if (isExtensionContextInvalidatedError(err)) {
							statusEl.textContent = errMsg;
							break;
						}
						statusEl.textContent = isReviewsOnly
							? `Auto Scraping · Tur ${cycle}: liste alınamadı, 8 sn sonra tekrar…`
							: `Auto Scraping · Tur ${cycle}: pending liste alınamadı, 8 sn sonra tekrar…`;
						if (stopRequested) break;
						await sleep(IDLE_POLL_MS);
						continue;
					}
					if (isReviewsOnly && links.length) {
						const fresh = [];
						for (let li = 0; li < links.length; li++) {
							const pid = links[li]?.productId ? String(links[li].productId) : '';
							if (pid && sessionSeenProductIds.has(pid)) continue;
							if (pid) sessionSeenProductIds.add(pid);
							fresh.push(links[li]);
						}
						if (!fresh.length) {
							statusEl.innerHTML =
								`Auto Scraping · Tur ${cycle}: API aynı ürünleri döndürüyor (kuyruk ilerlemiyor).<br>` +
								`Terminalde çalışan <strong>npm run api</strong> sürecini durdurup yeniden başlatın, ardından uzantıyı yenileyin.`;
							if (stopRequested) break;
							await sleep(IDLE_POLL_MS);
							continue;
						}
						links = fresh;
					}
					if (!links.length) {
						if (stopRequested) break;
						statusEl.innerHTML = isReviewsOnly
							? `Auto Scraping · Bekleniyor… yorumu boş ürün yok, 8 sn sonra tekrar kontrol.<br>` +
								`<strong>Dur</strong> ile durdurun · Güncellenen: <strong>${totalSaved}</strong> · ` +
								`işlenen: <strong>${totalProcessed}</strong> · hata: <strong>${totalFailed}</strong>`
							: `Auto Scraping · Bekleniyor… şu an pending link yok, 8 sn sonra tekrar kontrol.<br>` +
								`<strong>Dur</strong> ile durdurun · Toplam kayıt: <strong>${totalSaved}</strong> · ` +
								`işlenen: <strong>${totalProcessed}</strong> · hata: <strong>${totalFailed}</strong>`;
						const waitEnd = Date.now() + IDLE_POLL_MS;
						while (Date.now() < waitEnd) {
							if (stopRequested) break;
							await sleep(400);
						}
						continue;
					}

					const incremental = await scrapeAndImportLinksIncrementally(links, {
						scrapeOptions,
						shouldStop: () => stopRequested,
						onProgress: (info) => {
							const shortUrl =
								info.url.length > 56 ? info.url.slice(0, 53) + '…' : info.url;
							const sec =
								info.elapsedSec != null && info.elapsedSec > 0 ? ` · ${info.elapsedSec} sn` : '';
							const step =
								info.statusMessage ||
								(info.phase === 'save'
									? 'Kaydediliyor…'
									: scrapeOptions.scrapeMode === 'product_only'
										? info.elapsedSec > 45
											? 'Ürün verisi çekiliyor…'
											: 'İşleniyor…'
										: scrapeOptions.scrapeMode === 'reviews_only'
											? info.elapsedSec > 90
												? 'Yorumlar çekiliyor (uzun sürebilir)…'
												: info.elapsedSec > 30
													? 'Yorumlar çekiliyor…'
													: 'İşleniyor…'
											: info.elapsedSec > 90
												? 'Yorumlar çekiliyor (uzun sürebilir)…'
												: info.elapsedSec > 45
													? 'Hâlâ çekiliyor…'
													: 'İşleniyor…');
							statusEl.textContent =
								`Auto Scraping · Tur ${cycle}: ${info.index}/${info.total}${sec} — ${step}`;
						},
					});

					const cycleErrors = incremental.errors;
					totalProcessed += incremental.processedCount;
					totalSaved += incremental.savedCount;
					totalFailed += cycleErrors.length;

					statusEl.innerHTML =
						`Auto Scraping · Tur ${cycle} tamamlandı.<br>` +
						`Bu tur: link <strong>${links.length}</strong>, parse <strong>${incremental.parsedCount}</strong>, kayıt <strong>${incremental.savedCount}</strong>, hata <strong>${cycleErrors.length}</strong><br>` +
						`Toplam: işlenen <strong>${totalProcessed}</strong>, kaydedilen <strong>${totalSaved}</strong>, hatalı URL <strong>${totalFailed}</strong>`;

					if (stopRequested) break;
				}
				if (stopRequested) {
					statusEl.innerHTML =
						`<strong>Auto Scraping durduruldu</strong> (Dur).<br>` +
						`Toplam işlenen: <strong>${totalProcessed}</strong> · ` +
						`Kaydedilen: <strong>${totalSaved}</strong> · ` +
						`Hatalı URL: <strong>${totalFailed}</strong>`;
				}
			} catch (err) {
				statusEl.textContent =
					'Auto Scraping hatası: ' + (err && err.message ? err.message : String(err));
			} finally {
				setRunningState(false);
				stopRequested = false;
			}
		});
	}

	function epeyGetUrls(rawInput) {
		return String(rawInput || '')
			.split(/\r?\n|,/g)
			.map((url) => url.trim())
			.filter((url) => /^https?:\/\/(www\.)?epey\.com\/.+/i.test(url));
	}

	function epeyCleanText(value) {
		return (value || '').replace(/\s+/g, ' ').trim();
	}

	function epeyExtractValueParts(li) {
		const valueContainer = li.querySelector('span.cell.cs1') || li.querySelector('span.cell');
		if (!valueContainer) return [];
		const firstLevelSpans = Array.from(valueContainer.querySelectorAll(':scope > span'));
		const rawValues =
			firstLevelSpans.length > 0
				? firstLevelSpans.map((span) => epeyCleanText(span.textContent))
				: [epeyCleanText(valueContainer.textContent)];
		const uniqueValues = [];
		rawValues.forEach((value) => {
			if (!value) return;
			if (!uniqueValues.includes(value)) uniqueValues.push(value);
		});
		return uniqueValues;
	}

	function epeyParseProductHtml(html, url) {
		const parser = new DOMParser();
		const doc = parser.parseFromString(html, 'text/html');
		const h1Title = epeyCleanText(doc.querySelector('h1')?.textContent);
		const title =
			h1Title || doc.querySelector('meta[property="og:title"]')?.getAttribute('content') || '';
		const canonicalUrl = doc.querySelector('link[rel="canonical"]')?.getAttribute('href') || url;
		const attributes = {};
		const groups = doc.querySelectorAll('#ozellikler #grup');
		groups.forEach((group) => {
			const groupName = epeyCleanText(group.querySelector('h3 span')?.textContent) || 'GENEL';
			const groupAttributes = {};
			group.querySelectorAll('ul.grup > li').forEach((li) => {
				const key = epeyCleanText(li.querySelector('strong#cell')?.textContent);
				if (!key) return;
				const values = epeyExtractValueParts(li);
				if (values.length === 0) groupAttributes[key] = '';
				else if (values.length === 1) groupAttributes[key] = values[0];
				else groupAttributes[key] = values;
			});
			if (Object.keys(groupAttributes).length > 0) {
				attributes[groupName] = groupAttributes;
			}
		});
		return { url, canonicalUrl, h1: h1Title, title, attributes };
	}

	async function epeyCrawlProduct(url) {
		const response = await fetch(url, { credentials: 'include' });
		if (!response.ok) throw new Error(`HTTP ${response.status}`);
		const html = await response.text();
		return epeyParseProductHtml(html, url);
	}

	function epeySanitizeFileName(value) {
		const normalized = String(value || 'epey-data')
			.replace(/ı/g, 'i')
			.replace(/İ/g, 'I')
			.replace(/ş/g, 's')
			.replace(/Ş/g, 'S')
			.replace(/ğ/g, 'g')
			.replace(/Ğ/g, 'G')
			.replace(/ü/g, 'u')
			.replace(/Ü/g, 'U')
			.replace(/ö/g, 'o')
			.replace(/Ö/g, 'O')
			.replace(/ç/g, 'c')
			.replace(/Ç/g, 'C')
			.normalize('NFD')
			.toLowerCase();
		return (
			normalized
				.replace(/[\u0300-\u036f]/g, '')
				.replace(/[^a-z0-9]+/g, '-')
				.replace(/^-+|-+$/g, '')
				.slice(0, 80) || 'epey-data'
		);
	}

	function epeyDownloadPayload(payload) {
		const firstProduct = Array.isArray(payload?.data)
			? payload.data.find((item) => item && !item.error)
			: null;
		const fileName = `${epeySanitizeFileName(firstProduct?.h1 || firstProduct?.title || 'epey-data')}.json`;
		const blob = new Blob([JSON.stringify(payload, null, 2)], {
			type: 'application/json;charset=utf-8',
		});
		const objectUrl = URL.createObjectURL(blob);
		const anchor = document.createElement('a');
		anchor.href = objectUrl;
		anchor.download = fileName;
		anchor.rel = 'noopener';
		(document.body || document.documentElement).appendChild(anchor);
		anchor.click();
		anchor.remove();
		URL.revokeObjectURL(objectUrl);
	}

	function epeySleep(ms) {
		return new Promise((resolve) => {
			window.setTimeout(resolve, ms);
		});
	}

	async function epeyFetchPageDocument(url) {
		const response = await fetch(url, { credentials: 'include', redirect: 'follow' });
		if (!response.ok) {
			return {
				ok: false,
				status: response.status,
				finalUrl: response.url || url,
				doc: null,
			};
		}
		const html = await response.text();
		const parser = new DOMParser();
		const doc = parser.parseFromString(html, 'text/html');
		return {
			ok: true,
			doc,
			status: response.status,
			finalUrl: response.url || url,
		};
	}

	function epeyToAbsoluteUrl(href, baseUrl) {
		if (!href) return null;
		const trimmedHref = String(href).trim();
		if (
			trimmedHref === '#' ||
			/^javascript:/i.test(trimmedHref) ||
			/^void\(0\)$/i.test(trimmedHref)
		) {
			return null;
		}
		try {
			return new URL(trimmedHref, baseUrl).toString();
		} catch {
			return null;
		}
	}

	function epeyCollectListingProductLinks(doc, currentUrl) {
		const out = new Set();
		const anchors = Array.from(doc.querySelectorAll('div.listele a.urunadi[href]'));
		anchors.forEach((anchor) => {
			const absolute = epeyToAbsoluteUrl(anchor.getAttribute('href'), currentUrl);
			if (absolute && /^https?:\/\/(www\.)?epey\.com\/.+/i.test(absolute)) out.add(absolute);
		});
		return Array.from(out);
	}

	function epeyBuildTwoLinkTarget(page, firstPageUrl, secondPageUrl) {
		if (page === 1) return firstPageUrl;
		if (page === 2) return secondPageUrl;
		const u = new URL(secondPageUrl);
		const segments = u.pathname.split('/').filter(Boolean);
		if (segments.length > 0 && /^\d+$/.test(segments[segments.length - 1])) {
			segments[segments.length - 1] = String(page);
		} else {
			segments.push(String(page));
		}
		u.pathname = `/${segments.join('/')}/`;
		return u.toString();
	}

	async function epeyCollectAllPaginationLinks(firstPageUrl, secondPageUrl, onProgress) {
		const MAX_PAGES = 250;
		const allLinks = new Set();
		const visitedFinalUrls = new Set();
		let pagesVisited = 0;
		let stopReason = 'Pagination bitti.';

		for (let page = 1; page <= MAX_PAGES; page += 1) {
			const pageUrl = epeyBuildTwoLinkTarget(page, firstPageUrl, secondPageUrl);
			onProgress(`Sayfa ${page} taranıyor: ${pageUrl}`);
			const pageResult = await epeyFetchPageDocument(pageUrl);
			if (!pageResult.ok) {
				stopReason = `Sayfa ${page} durdu (HTTP ${pageResult.status}).`;
				break;
			}
			if (visitedFinalUrls.has(pageResult.finalUrl)) {
				stopReason = `Sayfa ${page} durdu (redirect/list sonu).`;
				break;
			}
			visitedFinalUrls.add(pageResult.finalUrl);
			pagesVisited += 1;
			const links = epeyCollectListingProductLinks(pageResult.doc, pageResult.finalUrl);
			links.forEach((link) => allLinks.add(link));
			onProgress(`Sayfa ${page}: ${links.length} link, toplam ${allLinks.size} link`);
			if (!links.length) {
				stopReason = `Sayfa ${page} durdu (ürün linki yok).`;
				break;
			}
			await epeySleep(180);
		}

		return {
			links: Array.from(allLinks),
			pagesVisited,
			stopReason,
		};
	}

	function epeyDownloadLinksTxt(text) {
		const content = String(text || '').trim();
		if (!content) return false;
		const filename = `ahtapot-epey-links-${Date.now()}.txt`;
		if (typeof globalThis.ahtapotExtensionDownloadText === 'function') {
			globalThis.ahtapotExtensionDownloadText(content, filename);
			return true;
		}
		const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
		const objectUrl = URL.createObjectURL(blob);
		const anchor = document.createElement('a');
		anchor.href = objectUrl;
		anchor.download = filename;
		anchor.rel = 'noopener';
		(document.body || document.documentElement).appendChild(anchor);
		anchor.click();
		anchor.remove();
		URL.revokeObjectURL(objectUrl);
		return true;
	}

	async function hepsiburadaDownloadLinksTxt(text) {
		const content = String(text || '').trim();
		if (!content) return false;
		const filename = `ahtapot-hepsiburada-links-${Date.now()}.txt`;
		if (typeof globalThis.ahtapotExtensionDownloadText === 'function') {
			const ret = globalThis.ahtapotExtensionDownloadText(content, filename);
			if (ret && typeof ret.then === 'function') return ret;
			return true;
		}
		const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
		const objectUrl = URL.createObjectURL(blob);
		const anchor = document.createElement('a');
		anchor.href = objectUrl;
		anchor.download = filename;
		anchor.rel = 'noopener';
		(document.body || document.documentElement).appendChild(anchor);
		anchor.click();
		anchor.remove();
		URL.revokeObjectURL(objectUrl);
		return true;
	}

	function amazonDownloadLinksTxt(text) {
		const content = String(text || '').trim();
		if (!content) return false;
		const filename = `ahtapot-amazon-links-${Date.now()}.txt`;
		if (typeof globalThis.ahtapotExtensionDownloadText === 'function') {
			globalThis.ahtapotExtensionDownloadText(content, filename);
			return true;
		}
		const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
		const objectUrl = URL.createObjectURL(blob);
		const anchor = document.createElement('a');
		anchor.href = objectUrl;
		anchor.download = filename;
		anchor.rel = 'noopener';
		(document.body || document.documentElement).appendChild(anchor);
		anchor.click();
		anchor.remove();
		URL.revokeObjectURL(objectUrl);
		return true;
	}

	/**
	 * Epey 1. Özellik — Attr Crawler.
	 * @param {HTMLElement} modalTitleEl
	 * @param {HTMLElement} modalBodyEl
	 * @param {() => void} onClose
	 */
	function ahtapotOpenEpeyAttrCrawler(modalTitleEl, modalBodyEl, onClose) {
		clearApiSession();
		activeLcUi = null;
		modalTitleEl.textContent = 'Epey Attr Crawler';
		modalBodyEl.innerHTML = `
			<div class="kg-epey-modal" role="region" aria-label="Epey Attr Crawler">
				<p class="kg-epey-help">Her satıra bir epey.com ürün URL'si girin. Her URL için başlık ve özellik grupları JSON'a çıkarılır.</p>
				<textarea id="kg-epey-input" class="kg-epey-input" placeholder="https://www.epey.com/akilli-telefonlar/xiaomi-15-ultra.html"></textarea>
				<div class="kg-epey-actions" id="kg-epey-actions"></div>
				<div id="kg-epey-status" class="kg-epey-status">Hazır</div>
			</div>
		`;
		const inputEl = modalBodyEl.querySelector('#kg-epey-input');
		const actionsEl = modalBodyEl.querySelector('#kg-epey-actions');
		const statusEl = modalBodyEl.querySelector('#kg-epey-status');
		if (!inputEl || !actionsEl || !statusEl) return;

		/** @type {any | null} */
		let lastPayload = null;
		let running = false;

		const startButton = document.createElement('button');
		startButton.type = 'button';
		startButton.className = 'kg-lc-btn kg-lc-btn--primary';
		startButton.textContent = 'Taramayı başlat';
		const downloadButton = document.createElement('button');
		downloadButton.type = 'button';
		downloadButton.className = 'kg-lc-btn kg-lc-btn--ghost';
		downloadButton.textContent = 'Sonucu indir';
		const closeButton = document.createElement('button');
		closeButton.type = 'button';
		closeButton.className = 'kg-lc-btn kg-lc-btn--ghost';
		closeButton.textContent = 'Kapat';
		closeButton.addEventListener('click', () => onClose());
		actionsEl.append(startButton, downloadButton, closeButton);

		downloadButton.addEventListener('click', () => {
			if (!lastPayload) {
				statusEl.textContent = 'Önce bir tarama sonucu üretin.';
				return;
			}
			epeyDownloadPayload(lastPayload);
			statusEl.textContent = 'Son JSON indirildi.';
		});

		startButton.addEventListener('click', async () => {
			if (running) return;
			const urls = epeyGetUrls(inputEl.value);
			if (!urls.length) {
				statusEl.textContent = 'En az bir geçerli epey.com URL girin.';
				return;
			}
			running = true;
			startButton.disabled = true;
			const results = [];
			for (let i = 0; i < urls.length; i += 1) {
				const url = urls[i];
				statusEl.textContent = `(${i + 1}/${urls.length}) İndiriliyor: ${url}`;
				try {
					const product = await epeyCrawlProduct(url);
					results.push(product);
					statusEl.textContent = `(${i + 1}/${urls.length}) Ayrıştırıldı: ${product.title || url}`;
				} catch (error) {
					const message = error instanceof Error ? error.message : String(error);
					results.push({ url, error: message });
					statusEl.textContent = `(${i + 1}/${urls.length}) Hata: ${message}`;
				}
				await epeySleep(250);
			}
			const payload = {
				generatedAt: new Date().toISOString(),
				source: 'epey.com',
				total: urls.length,
				successCount: results.filter((item) => !item.error).length,
				data: results,
			};
			lastPayload = payload;
			epeyDownloadPayload(payload);
			statusEl.textContent = 'Bitti. JSON indirildi.';
			running = false;
			startButton.disabled = false;
		});

		globalThis.ahtapotLcCleanup = () => {
			running = false;
		};
	}

	/**
	 * Epey 2. Özellik hazırlık modalı — detayları kullanıcı akışına göre eklenecek.
	 * @param {HTMLElement} modalTitleEl
	 * @param {HTMLElement} modalBodyEl
	 * @param {() => void} onClose
	 */
	function ahtapotOpenEpeyLinkCrawler(modalTitleEl, modalBodyEl, onClose) {
		clearApiSession();
		activeLcUi = null;
		modalTitleEl.textContent = 'Link Crawler';
		modalBodyEl.innerHTML = `
			<div class="kg-epey-modal" role="region" aria-label="Epey Link Crawler">
				<p class="kg-epey-help">Aynı kutuda ilk iki satıra liste URL'lerini girin. 1. satır sayfa 1, 2. satır sayfa 2 kabul edilir; sonra 2. satır şablonundan <code>/3, /4...</code> otomatik üretilir.</p>
				<textarea id="kg-epey-link-seeds" class="kg-epey-input" rows="3" placeholder="1. satır (sayfa 1): https://www.epey.com/akilli-telefonlar/xiaomi/
2. satır (sayfa 2): https://www.epey.com/akilli-telefonlar/xiaomi/2"></textarea>
				<textarea id="kg-epey-link-output" class="kg-epey-input kg-epey-link-output" placeholder="Toplanan ürün linkleri burada listelenecek..." spellcheck="false"></textarea>
				<div id="kg-epey-link-status" class="kg-epey-status">Hazır</div>
				<div class="kg-epey-actions">
					<button type="button" class="kg-lc-btn kg-lc-btn--primary" id="kg-epey-link-run">Toplamayı başlat</button>
					<button type="button" class="kg-lc-btn kg-lc-btn--ghost" id="kg-epey-link-download-txt">TXT indir</button>
					<button type="button" class="kg-lc-btn kg-lc-btn--ghost" id="kg-epey-link-clear">Temizle</button>
					<button type="button" class="kg-lc-btn kg-lc-btn--ghost" id="kg-epey-link-close">Kapat</button>
				</div>
			</div>
		`;
		const seedsEl = modalBodyEl.querySelector('#kg-epey-link-seeds');
		const outputEl = modalBodyEl.querySelector('#kg-epey-link-output');
		const statusEl = modalBodyEl.querySelector('#kg-epey-link-status');
		const runBtn = modalBodyEl.querySelector('#kg-epey-link-run');
		const downloadTxtBtn = modalBodyEl.querySelector('#kg-epey-link-download-txt');
		const clearBtn = modalBodyEl.querySelector('#kg-epey-link-clear');
		const closeBtn = modalBodyEl.querySelector('#kg-epey-link-close');
		if (!seedsEl || !outputEl || !statusEl || !runBtn || !downloadTxtBtn || !clearBtn || !closeBtn)
			return;

		let running = false;

		closeBtn.addEventListener('click', () => onClose());
		clearBtn.addEventListener('click', () => {
			if (running) return;
			outputEl.value = '';
			statusEl.textContent = 'Temizlendi.';
		});
		downloadTxtBtn.addEventListener('click', () => {
			const ok = epeyDownloadLinksTxt(outputEl.value);
			if (!ok) {
				statusEl.textContent = 'İndirilecek link yok.';
				return;
			}
			statusEl.textContent = 'TXT indirildi.';
		});

		runBtn.addEventListener('click', async () => {
			if (running) return;
			const lines = String(seedsEl.value || '')
				.split(/\r?\n/)
				.map((x) => x.trim())
				.filter(Boolean);
			const seed1 = lines[0] || '';
			const seed2 = lines[1] || '';
			if (
				!/^https?:\/\/(www\.)?epey\.com\/.+/i.test(seed1) ||
				!/^https?:\/\/(www\.)?epey\.com\/.+/i.test(seed2)
			) {
				statusEl.textContent =
					'Tek kutuda 1. ve 2. satıra geçerli epey.com liste URL adreslerini girin.';
				return;
			}
			running = true;
			runBtn.disabled = true;
			try {
				const collected = await epeyCollectAllPaginationLinks(seed1, seed2, (msg) => {
					statusEl.textContent = msg;
				});
				outputEl.value = collected.links.join('\n');
				statusEl.textContent =
					`Bitti: ${collected.links.length} link, ${collected.pagesVisited} sayfa. ` +
					collected.stopReason;
			} catch (error) {
				statusEl.textContent =
					'Link toplama hatası: ' +
					(error instanceof Error ? error.message : String(error));
			}
			running = false;
			runBtn.disabled = false;
		});

		globalThis.ahtapotLcCleanup = () => {
			running = false;
		};
	}

	globalThis.ahtapotOpenLinkCrawler = ahtapotOpenLinkCrawler;
	globalThis.ahtapotOpenTxtBirlestir = ahtapotOpenTxtBirlestir;
	globalThis.ahtapotOpenProductCrawler = ahtapotOpenProductCrawler;
	globalThis.ahtapotOpenApiJsonScraping = ahtapotOpenApiJsonScraping;
	globalThis.ahtapotOpenEpeyAttrCrawler = ahtapotOpenEpeyAttrCrawler;
	globalThis.ahtapotOpenEpeyLinkCrawler = ahtapotOpenEpeyLinkCrawler;
	globalThis.ahtapotLcCleanup = null;
	function runPostNextPageFlowForCurrentSite() {
		const host = (location.hostname || '').toLowerCase();
		if (host === 'hepsiburada.com' || host.endsWith('.hepsiburada.com')) {
			runHbFiyatAutotuneThenScheduleAhtapotModal();
			return;
		}
		runPrcAutotuneThenScheduleAhtapotModal();
	}

	globalThis.ahtapotLcRunPostNextPageFlow = runPostNextPageFlowForCurrentSite;
})();
