/**
 * Trendyol PDP HTML → ürün şablonu (JSON-LD Product + additionalProperty + gömülü "barcode" JSON).
 * Şablonlar: telefon-template.json (cep telefonu), akilli-saat-template.json (breadcrumb’da Akıllı Saat).
 * globalThis: dcLoadTelefonTemplate(), dcLoadAkilliSaatTemplate(), dcDetectTrendyolCategoryFromHtml(html),
 *   dcMapTrendyolHtmlToTelefon(html, pageUrl, templateDoc)
 */
(function () {
  'use strict';

  let _templateCache = null;
  let _akilliSaatTemplateCache = null;

  function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function loadTemplateJson() {
    if (_templateCache) return Promise.resolve(deepClone(_templateCache));
    const u = chrome.runtime.getURL('content/telefon-template.json');
    return fetch(u)
      .then(function (r) {
        if (!r.ok) throw new Error('telefon-template.json ' + r.status);
        return r.json();
      })
      .then(function (t) {
        _templateCache = t;
        return deepClone(t);
      });
  }

  globalThis.dcLoadTelefonTemplate = loadTemplateJson;

  function loadAkilliSaatTemplateJson() {
    if (_akilliSaatTemplateCache) return Promise.resolve(deepClone(_akilliSaatTemplateCache));
    const u = chrome.runtime.getURL('content/akilli-saat-template.json');
    return fetch(u)
      .then(function (r) {
        if (!r.ok) throw new Error('akilli-saat-template.json ' + r.status);
        return r.json();
      })
      .then(function (t) {
        _akilliSaatTemplateCache = t;
        return deepClone(t);
      });
  }

  globalThis.dcLoadAkilliSaatTemplate = loadAkilliSaatTemplateJson;

  function extractProductLdFromHtml(html) {
    var doc = new DOMParser().parseFromString(html, 'text/html');
    var nodes = doc.querySelectorAll('script[type="application/ld+json"]');
    for (var i = 0; i < nodes.length; i++) {
      try {
        var raw = (nodes[i].textContent || '').trim();
        if (!raw) continue;
        var data = JSON.parse(raw);
        if (data && data['@type'] === 'Product') return data;
        if (Array.isArray(data)) {
          for (var j = 0; j < data.length; j++) {
            if (data[j] && data[j]['@type'] === 'Product') return data[j];
          }
        }
      } catch (e) {
        /* continue */
      }
    }
    return null;
  }

  /**
   * PDP galeri: .carousel-viewport içindeki img[src] (ör. dsmcdn).
   * Sıra korunur, aynı src tekil tutulur.
   */
  function extractCarouselMediaFromHtml(html) {
    var doc = new DOMParser().parseFromString(html, 'text/html');
    var vp =
      doc.querySelector('.carousel-viewport') ||
      doc.querySelector('.product-image-gallery-viewport') ||
      doc.querySelector('[class*="carousel-viewport"]');
    if (!vp) return [];
    var imgs = vp.querySelectorAll('img[src]');
    var out = [];
    var seen = Object.create(null);
    for (var i = 0; i < imgs.length; i++) {
      var el = imgs[i];
      var src = el.getAttribute('src');
      if (!src) continue;
      src = String(src).trim();
      if (src.indexOf('http') !== 0) continue;
      if (seen[src]) continue;
      seen[src] = true;
      out.push({
        url: src,
        altTr: el.getAttribute('alt') || null,
      });
    }
    return out;
  }

  function ensureGallerySlot(doc, index) {
    while (doc.media.gallery.length <= index) {
      var n = doc.media.gallery.length;
      doc.media.gallery.push({
        url: null,
        kind: 'gallery',
        sortOrder: n,
        widthPx: null,
        heightPx: null,
        altTr: null,
      });
    }
  }

  /**
   * JSON-LD image: string | string[] | { contentUrl: string[] } | ImageObject[].
   */
  function collectProductImageUrls(product) {
    var img = product && product.image;
    if (!img) return [];
    if (typeof img === 'string') {
      return img.indexOf('http') === 0 ? [img] : [];
    }
    if (Array.isArray(img)) {
      var out = [];
      for (var a = 0; a < img.length; a++) {
        var x = img[a];
        if (typeof x === 'string' && x.indexOf('http') === 0) {
          out.push(x);
        } else if (x && typeof x === 'object' && Array.isArray(x.contentUrl)) {
          for (var b = 0; b < x.contentUrl.length; b++) {
            var u = x.contentUrl[b];
            if (typeof u === 'string' && u.indexOf('http') === 0) out.push(u);
          }
        }
      }
      return out;
    }
    if (typeof img === 'object' && Array.isArray(img.contentUrl)) {
      var urls = [];
      for (var c = 0; c < img.contentUrl.length; c++) {
        var u2 = img.contentUrl[c];
        if (typeof u2 === 'string' && u2.indexOf('http') === 0) urls.push(u2);
      }
      return urls;
    }
    return [];
  }

  /**
   * Gömülü JSON parçası: "contentUrl": [ "https://...", ... ] (köşeli parantez eşleştirme).
   */
  /**
   * Trendyol PDP: ürün state’i HTML içinde JSON olarak gömülü; çoğu sayfada
   * "barcode":"6902176157936" benzeri alan vardır (JSON-LD’de yoktur).
   * İlk geçerli eşleşmeyi döner; çoklu varyantta genelde aynı barkod tekrarlanır.
   */
  function extractTrendyolEmbeddedBarcode(html) {
    if (!html || typeof html !== 'string') return null;
    var re = /"barcode"\s*:\s*"([0-9]{8,14})"/g;
    var m;
    while ((m = re.exec(html)) !== null) {
      var d = m[1];
      if (d && /^[0-9]+$/.test(d)) return d;
    }
    return null;
  }

  function extractContentUrlArrayFromHtml(html) {
    var key = '"contentUrl"';
    var idx = html.indexOf(key);
    if (idx === -1) return [];
    var start = html.indexOf('[', idx);
    if (start === -1) return [];
    var depth = 0;
    for (var i = start; i < html.length; i++) {
      var ch = html.charAt(i);
      if (ch === '[') depth++;
      else if (ch === ']') {
        depth--;
        if (depth === 0) {
          try {
            var arr = JSON.parse(html.slice(start, i + 1));
            if (!Array.isArray(arr)) return [];
            return arr.filter(function (u) {
              return typeof u === 'string' && u.indexOf('http') === 0;
            });
          } catch (e) {
            return [];
          }
        }
      }
    }
    return [];
  }

  /** Galeri + primaryImageUrl (carousel veya contentUrl listesi için). */
  function applyCarouselMediaToDoc(doc, items) {
    if (!items || !items.length) return;
    if (!doc.media || typeof doc.media !== 'object') doc.media = {};
    doc.media.contentUrl = items
      .map(function (x) {
        return x && typeof x.url === 'string' ? x.url.trim() : '';
      })
      .filter(function (u) {
        return u.indexOf('http') === 0;
      });
    doc.media.primaryImageUrl = items[0].url;
    for (var i = 0; i < items.length; i++) {
      ensureGallerySlot(doc, i);
      doc.media.gallery[i].url = items[i].url;
      doc.media.gallery[i].kind = i === 0 ? 'hero' : 'gallery';
      doc.media.gallery[i].sortOrder = i;
      doc.media.gallery[i].altTr = items[i].altTr;
    }
  }

  function productIdFromTrendyolUrl(url) {
    if (!url) return null;
    var m = String(url).match(/-p-(\d+)(?:\?|#|$|\/)/);
    return m ? m[1] : null;
  }

  /** JSON-LD / &nbsp; (U+00A0) ve benzeri ayırıcıları normal boşluğa çevirir (çıktı JSON). */
  function normalizePlatformWhitespace(s) {
    if (s == null) return '';
    return String(s)
      .replace(/\u00A0/g, ' ')
      .replace(/[\u202F\u2007\uFEFF\u2009\u200A]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function brandName(brand) {
    if (!brand) return null;
    if (typeof brand === 'string') return normalizePlatformWhitespace(brand) || null;
    if (typeof brand === 'object' && brand.name)
      return normalizePlatformWhitespace(String(brand.name)) || null;
    return null;
  }

  function varYok(v) {
    if (v == null) return null;
    var t = normalizePlatformWhitespace(String(v)).toLowerCase();
    if (t === 'var') return true;
    if (t === 'yok') return false;
    return null;
  }

  function parseIntGb(s) {
    if (!s) return null;
    var m = String(s).match(/(\d+)\s*GB/i);
    return m ? parseInt(m[1], 10) : null;
  }

  function parseWarrantyMonths(s) {
    if (!s) return null;
    var t = String(s).trim();
    var y = t.match(/(\d+)\s*[Yy]ıl/i);
    if (y) return parseInt(y[1], 10) * 12;
    var mo = t.match(/(\d+)\s*[Aa]y/i);
    if (mo) return parseInt(mo[1], 10);
    return null;
  }

  function parseHz(s) {
    if (!s) return null;
    var m = String(s).match(/(\d+(?:[.,]\d+)?)\s*Hz/i);
    return m ? parseFloat(m[1].replace(',', '.')) : null;
  }

  function propsMapFromProduct(product) {
    var out = {};
    var list = product && product.additionalProperty;
    if (!Array.isArray(list)) return out;
    for (var i = 0; i < list.length; i++) {
      var p = list[i];
      if (!p || typeof p.name !== 'string') continue;
      var name = normalizePlatformWhitespace(p.name);
      if (!name) continue;
      var valRaw = p.unitText != null ? p.unitText : p.value;
      var val = valRaw != null ? normalizePlatformWhitespace(String(valRaw)) : '';
      out[name] = val;
    }
    return out;
  }

  function applyPropsToTelefon(doc, props) {
    function g(k) {
      return props[k];
    }

    var gt = g('Garanti Tipi');
    if (gt) doc.warrantyCompliance.warrantyCoverageLabelTr = gt;

    var gs = g('Garanti Süresi');
    if (gs) {
      var mo = parseWarrantyMonths(gs);
      if (mo != null) doc.warrantyCompliance.warrantyMonths = mo;
    }

    var dh = g('Dahili Hafıza');
    if (dh) {
      var gb = parseIntGb(dh);
      if (gb != null) doc.performance.storageGb = gb;
    }

    var ram = g('RAM Kapasitesi');
    if (ram) {
      var rg = parseIntGb(ram);
      if (rg != null) doc.performance.ramGb = rg;
    }

    var os = g('İşletim Sistemi');
    if (os) {
      doc.software.osFamily = os;
      doc.software.osName = os;
    }

    if (g('Ekran Boyutu')) doc.display.sizeInchMarketingLabelTr = g('Ekran Boyutu');
    if (g('Ekran Boyut Aralığı')) doc.display.sizeInchRangeLabel = g('Ekran Boyut Aralığı');

    if (g('Ekran Çözünürlüğü')) doc.display.resolutionLabel = g('Ekran Çözünürlüğü');
    if (g('Ekran Teknolojisi')) doc.display.displayTechnology = g('Ekran Teknolojisi');

    var panel = g('Görüntü Teknolojisi') || g('Ekran Cinsi');
    if (panel) doc.display.panelType = panel;

    var hz = parseHz(g('Ekran Yenileme Hızı'));
    if (hz != null) doc.display.refreshRateHz = hz;

    var touch = varYok(g('Dokunmatik Ekran'));
    if (touch != null) doc.display.touchscreen = touch;

    if (g('Mobil Bağlantı Hızı')) doc.connectivity.cellularGeneration = g('Mobil Bağlantı Hızı');

    var vcall = varYok(g('Görüntülü Konuşma'));
    if (vcall != null) doc.connectivity.videoCallSupported = vcall;

    var nfc = varYok(g('NFC'));
    if (nfc != null) doc.connectivity.nfc = nfc;

    var dual = varYok(g('Çift Hat'));
    if (dual != null) doc.connectivity.dualSimStandby = dual;

    var fp = varYok(g('Parmak İzi Okuyucu'));
    if (fp != null) doc.sensorsSecurity.fingerprintReader = fp;

    var face = varYok(g('Yüz Tanıma'));
    if (face != null) doc.sensorsSecurity.faceRecognitionSecure = face;

    var radio = varYok(g('Radio'));
    if (radio != null) doc.connectivity.fmRadio = radio;

    if (g('Kulaklık Girişi')) doc.physical.headphoneJack = g('Kulaklık Girişi');
    if (g('Şarj Girişi')) doc.physical.usbPortType = g('Şarj Girişi');

    var rearN = parseInt(g('Arka Kamera Sayısı'), 10);
    if (Number.isFinite(rearN)) doc.camerasRear.cameraCount = rearN;

    var frontN = parseInt(g('Ön Kamera Sayısı'), 10);
    if (Number.isFinite(frontN)) doc.camerasFront.cameraCount = frontN;

    if (g('Ana Kamera Çözünürlük Aralığı'))
      doc.camerasRear.rearCameraResolutionRangeLabel = g('Ana Kamera Çözünürlük Aralığı');
    if (g('Kamera Çözünürlüğü')) doc.camerasRear.rearCameraResolutionLabel = g('Kamera Çözünürlüğü');
    if (g('Ön Kamera Çözünürlüğü'))
      doc.camerasFront.frontCameraResolutionLabel = g('Ön Kamera Çözünürlüğü');
    if (g('Ön Kamera Çözünürlük Aralığı'))
      doc.camerasFront.frontCameraResolutionRangeLabel = g('Ön Kamera Çözünürlük Aralığı');
    if (g('Video Kayıt Çözünürlüğü'))
      doc.camerasRear.rearVideoMaxResolution = g('Video Kayıt Çözünürlüğü');

    if (g('Pil Gücü (mAh)')) doc.battery.capacityRangeLabel = g('Pil Gücü (mAh)');
    if (g('Batarya Kapasitesi Aralığı'))
      doc.battery.capacityRangeLabel = g('Batarya Kapasitesi Aralığı');

    var wc = varYok(g('Kablosuz Şarj'));
    if (wc != null) doc.battery.wirelessChargingSupported = wc;
    var sh = g('Şarj Hızı');
    if (sh) doc.battery.chargingSpeedLabel = sh;
    else if (wc === true) doc.battery.chargingSpeedLabel = 'Kablosuz şarj: Var';

    var water = varYok(g('Suya/Toza Dayanıklılık'));
    if (water === true) {
      doc.physical.waterResistance = 'Var';
      doc.physical.dustResistance = 'Var';
    }

    if (g('CPU Aralık')) doc.performance.cpuClockRangeLabel = g('CPU Aralık');

    if (g('Cep Telefonu Modeli')) doc.identity.modelName = g('Cep Telefonu Modeli');

    var men = g('Menşei');
    if (men) {
      doc.identity.countryOfOrigin = men;
      doc.identity.countryOfOriginCode = men.length <= 3 ? men.toUpperCase() : null;
    }

    if (g('Tamir Edilebilirlik'))
      doc.sustainabilityRepair.repairabilityNotesTr = g('Tamir Edilebilirlik');

    var ai = varYok(g('Yapay Zeka'));
    if (ai === true) doc.performance.aiFeaturesLabel = 'Var';

    if (g('Renk')) doc.identity.colorName = g('Renk');

    var barkod =
      g('Barkod') ||
      g('Barkod Numarası') ||
      g('Ürün Barkodu') ||
      g('Barcode');
    if (barkod) {
      var bc = normalizePlatformWhitespace(barkod).replace(/\D/g, '');
      if (bc.length >= 8 && bc.length <= 14) doc.identity.barcode = bc;
    }
  }

  /**
   * Barkod ↔ GTIN: gömülü barkod veya JSON-LD GTIN tek kaynak olabilir; çıktıda ikisi de dolu kalsın.
   */
  function syncBarcodeGtinEan(doc) {
    if (!doc.identity) return;
    var gRaw = doc.identity.gtin;
    var g = gRaw != null ? String(gRaw).replace(/\D/g, '') : '';
    if (!doc.identity.barcode && g.length >= 8 && g.length <= 14) doc.identity.barcode = g;

    var b = doc.identity.barcode;
    if (!b) return;
    var d = String(b).replace(/\D/g, '');
    if (d.length < 8 || d.length > 14) return;
    if (!doc.identity.gtin) doc.identity.gtin = d;
    if (!doc.identity.ean && d.length === 13) doc.identity.ean = d;
  }

  function fillFromJsonLd(doc, product, pageUrl) {
    doc.identity.commercialName = normalizePlatformWhitespace(product.name) || null;
    var b = brandName(product.brand);
    if (b) {
      doc.identity.brand = b;
      doc.identity.brandNormalized = b.toLowerCase().replace(/\s+/g, '');
    }
    if (product.color) doc.identity.colorName = normalizePlatformWhitespace(product.color) || null;
    if (product.sku != null) doc.identity.sku = normalizePlatformWhitespace(String(product.sku)) || null;
    if (product.gtin) doc.identity.gtin = normalizePlatformWhitespace(String(product.gtin)) || null;
    if (product.gtin13) doc.identity.gtin = normalizePlatformWhitespace(String(product.gtin13)) || null;
    if (product.mpn) doc.identity.mpn = normalizePlatformWhitespace(String(product.mpn)) || null;
    if (product.barcode != null && typeof product.barcode === 'string') {
      var bcs = normalizePlatformWhitespace(String(product.barcode)).replace(/\D/g, '');
      if (bcs.length >= 8 && bcs.length <= 14) doc.identity.barcode = bcs;
    }

    if (product.aggregateRating && typeof product.aggregateRating === 'object') {
      var ar = product.aggregateRating;
      if (ar.ratingValue != null) doc.aggregateRating.ratingValue = ar.ratingValue;
      var rc = ar.reviewCount != null ? ar.reviewCount : ar.ratingCount;
      if (rc != null) doc.aggregateRating.reviewCount = rc;
    }

    if (Array.isArray(product.isRelatedTo)) {
      doc.isRelatedTo = product.isRelatedTo
        .filter(function (x) {
          return typeof x === 'string';
        })
        .map(function (x) {
          return normalizePlatformWhitespace(x);
        })
        .filter(function (x) {
          return x.length > 0;
        });
    }

    var offers = product.offers;
    if (offers && typeof offers === 'object') {
      var av = offers.availability;
      if (av && String(av).indexOf('InStock') !== -1) doc.stock.inStock = true;
      else if (av && String(av).indexOf('OutOfStock') !== -1) doc.stock.inStock = false;

      var priceAmt =
        offers.price != null ? parseFloat(String(offers.price).replace(',', '.')) : null;
      var pid = productIdFromTrendyolUrl(pageUrl);
      doc.marketplaceMeta.platformIds.trendyol = {
        canonical: pageUrl,
        productId: pid,
        title: normalizePlatformWhitespace(product.name) || null,
        shipment: null,
        ratingValue: doc.aggregateRating.ratingValue,
        reviewCount: doc.aggregateRating.reviewCount,
        offers: [
          {
            sellerName: 'Trendyol',
            storeUrl: null,
            listingUrl: offers.url || pageUrl,
            price: {
              amount: Number.isFinite(priceAmt) ? priceAmt : null,
              currency: offers.priceCurrency || 'TRY',
              displayTr:
                offers.price != null
                  ? normalizePlatformWhitespace(
                      String(offers.price).replace('.', ',') + ' ' + (offers.priceCurrency || 'TRY')
                    ) || null
                  : null,
            },
            stock: {
              inStock: doc.stock.inStock,
              quantity: null,
              statusLabelTr: null,
              lastCheckedAt: null,
            },
            collectedAt: new Date().toISOString(),
          },
        ],
      };
    } else {
      doc.marketplaceMeta.platformIds.trendyol = {
        canonical: pageUrl,
        productId: productIdFromTrendyolUrl(pageUrl),
        title: normalizePlatformWhitespace(product.name) || null,
        shipment: null,
        ratingValue: doc.aggregateRating.ratingValue,
        reviewCount: doc.aggregateRating.reviewCount,
        offers: [],
      };
    }

    doc.marketplaceMeta.lastSyncedAt = new Date().toISOString();
    doc.marketplaceMeta.sourceLocale = 'tr-TR';
  }

  function trendyolBreadcrumbAnchors(doc) {
    var list = doc.querySelectorAll('ul.breadcrumb-list li a[href]');
    if (!list.length) {
      list = doc.querySelectorAll('.breadcrumb-list a[href], [class*="breadcrumb-list"] a[href]');
    }
    return list;
  }

  function normalizedBreadcrumbTrailFromDoc(doc) {
    var list = trendyolBreadcrumbAnchors(doc);
    var texts = [];
    for (var i = 0; i < list.length; i++) {
      var item = normalizePlatformWhitespace(list[i].textContent || '');
      if (item) texts.push(item);
    }
    if (texts.length && /^trendyol$/i.test(String(texts[0] || '').trim())) {
      texts = texts.slice(1);
    }
    return texts;
  }

  function applyCategoryHierarchyFromTrail(doc, trail) {
    if (!doc || typeof doc !== 'object') return;
    var levels = Array.isArray(trail)
      ? trail.filter(function (x) {
          return typeof x === 'string' && x.trim().length > 0;
        })
      : [];
    doc.categoryPath = levels;
    doc.categoryPathText = levels.length ? levels.join(' > ') : null;
    doc.categoryL1 = levels[0] || null;
    doc.categoryL2 = levels[1] || null;
    doc.categoryL3 = levels[2] || null;
    doc.categoryL4 = levels[3] || null;
    doc.categoryL5 = levels[4] || null;
    doc.categoryL6 = levels[5] || null;
    doc.categoryL7 = levels[6] || null;
    doc.categoryL8 = levels[7] || null;
  }

  globalThis.dcExtractTrendyolBreadcrumbTrail = function (html) {
    var doc = new DOMParser().parseFromString(html, 'text/html');
    return normalizedBreadcrumbTrailFromDoc(doc);
  };

  /**
   * PDP breadcrumb: Akıllı Saat → akilli-saat; Cep Telefonu → cep-telefonu.
   * Önce href (akilli-saat-x-c…), sonra metin (Akıllı Saat).
   */
  globalThis.dcDetectTrendyolCategoryFromHtml = function (html) {
    var doc = new DOMParser().parseFromString(html, 'text/html');
    var list = trendyolBreadcrumbAnchors(doc);
    var hrefs = [];
    var texts = [];
    for (var i = 0; i < list.length; i++) {
      hrefs.push((list[i].getAttribute('href') || '').toLowerCase());
      texts.push(normalizePlatformWhitespace(list[i].textContent || ''));
    }
    for (var h = 0; h < hrefs.length; h++) {
      if (hrefs[h].indexOf('akilli-saat') !== -1) return 'akilli-saat';
    }
    for (var c = 0; c < hrefs.length; c++) {
      if (hrefs[c].indexOf('cep-telefonu') !== -1 || hrefs[c].indexOf('cep-telefon') !== -1) {
        return 'cep-telefonu';
      }
    }
    for (var t = 0; t < texts.length; t++) {
      if (/akıllı\s*saat|akilli\s*saat/i.test(texts[t])) return 'akilli-saat';
    }
    for (var u = 0; u < texts.length; u++) {
      if (/cep\s*telefonu|cep\s*telefon/i.test(texts[u])) return 'cep-telefonu';
    }
    return null;
  };

  globalThis.dcMapTrendyolHtmlToTelefon = function (html, pageUrl, templateDoc) {
    var product = extractProductLdFromHtml(html);
    if (!product) {
      throw new Error('JSON-LD Product bulunamadı');
    }
    var doc = templateDoc;
    var props = propsMapFromProduct(product);
    var breadcrumbTrail = globalThis.dcExtractTrendyolBreadcrumbTrail(html);

    fillFromJsonLd(doc, product, pageUrl);
    applyCategoryHierarchyFromTrail(doc, breadcrumbTrail);
    applyPropsToTelefon(doc, props);

    if (!doc.identity.barcode) {
      var emb = extractTrendyolEmbeddedBarcode(html);
      if (emb) doc.identity.barcode = emb;
    }
    syncBarcodeGtinEan(doc);

    var imageUrls = collectProductImageUrls(product);
    if (!imageUrls.length) {
      imageUrls = extractContentUrlArrayFromHtml(html);
    }
    if (imageUrls.length) {
      applyCarouselMediaToDoc(
        doc,
        imageUrls.map(function (u) {
          return { url: u, altTr: null };
        })
      );
    } else {
      var carouselMedia = extractCarouselMediaFromHtml(html);
      if (carouselMedia.length) {
        applyCarouselMediaToDoc(doc, carouselMedia);
      }
    }

    var pairs = Object.keys(props).map(function (k) {
      return { source: 'trendyol', key: k, value: props[k] };
    });
    doc.rawPlatformAttributes = pairs;

    return doc;
  };
})();
