const ROOT_ID = 'ahtapot-ui-root';
const DOCK_POS_KEY = 'ahtapot_dock_position_v1';

/** @type {null | (() => boolean)} */
let tryCloseModal = null;

/** @type {boolean} */
let uiMounting = false;

/** content.css yüklenemezse görünürlük için minimal kurallar */
const FALLBACK_CSS = `
:host { display: block; pointer-events: none; }
* { box-sizing: border-box; }
.kg-dock {
  position: fixed; top: 16px; right: 16px; z-index: 2147483647;
  display: flex; flex-direction: column; width: min(280px, calc(100vw - 32px));
  font-family: system-ui, sans-serif; pointer-events: auto;
}
.kg-modal-host { position: fixed; inset: 0; z-index: 2147483647; display: none; align-items: center; justify-content: center;
  padding: 24px; background: rgba(15,23,42,0.55); pointer-events: auto; }
.kg-modal-host[data-open="true"] { display: flex; }
.kg-group[data-open="false"] .kg-group-body { display: none; }
.kg-drag-handle {
  cursor: move; user-select: none;
  font-size: 11px; letter-spacing: .04em;
  color: #64748b; margin: 0 0 6px;
  background: rgba(255,255,255,.96); border: 1px solid #e2e8f0;
  border-radius: 8px; padding: 4px 8px; width: fit-content;
}
`;

function resolveMenu() {
	const host = (location.hostname || '').toLowerCase();
	if (host === 'epey.com' || host.endsWith('.epey.com')) {
		return {
			groupTitle: 'CRAWL & SCRAPING',
			items: [
				{ id: 'epey-attr-crawler', label: 'Attribute Crawler', tone: 'blue' },
				{ id: 'epey-link-crawler', label: 'Link Crawler', tone: 'grey' },
			],
		};
	}
	return {
		groupTitle: 'CRAWL & SCRAPING',
		items: [
			{ id: 'link-crawler', label: 'Link Crawler', tone: 'blue' },
			{ id: 'txt-birlestir', label: 'TXT Birleştir', tone: 'grey' },
			{ id: 'product-crawler', label: 'Product Crawler', tone: 'grey' },
			{ id: 'api-json-scraping', label: 'API JSON Scraping', tone: 'grey' },
			{ id: 'seller-data-crawler', label: 'Seller Data Crawler', tone: 'grey' },
		],
	};
}

const MENU = resolveMenu();

function runModalCleanup() {
	try {
		globalThis.ahtapotLcCleanup?.();
	} catch {
		/* ignore */
	}
	globalThis.ahtapotLcCleanup = null;
}

function buildShadowHtml() {
	const itemsHtml = MENU.items.map(
		(it) =>
			`<button type="button" class="kg-sub kg-sub--${it.tone}" data-kg-action="${escapeAttr(it.id)}" data-kg-label="${escapeAttr(it.label)}">${escapeHtml(it.label)}</button>`,
	).join('');

	return `
		<div class="kg-dock" part="dock">
			<div class="kg-drag-handle" id="kg-drag-handle" title="Surukleyip konumlandir">AHTAPOT</div>
			<div class="kg-group" data-open="true" part="group">
				<button type="button" class="kg-group-head" id="kg-group-toggle" aria-expanded="true" aria-controls="kg-group-panel">
					<span>${escapeHtml(MENU.groupTitle)}</span>
					<span class="kg-chevron" aria-hidden="true"></span>
				</button>
				<div class="kg-group-body" id="kg-group-panel" role="region" aria-label="${escapeAttr(MENU.groupTitle)}">
					${itemsHtml}
				</div>
			</div>
		</div>
		<div class="kg-modal-host" id="kg-modal-host" data-open="false" aria-hidden="true">
			<div class="kg-modal" role="dialog" aria-modal="true" aria-labelledby="kg-modal-title">
				<div class="kg-modal-head">
					<span id="kg-modal-title"></span>
					<button type="button" class="kg-modal-close" id="kg-modal-close" title="Kapat">&times;</button>
				</div>
				<div class="kg-modal-body" id="kg-modal-body"></div>
			</div>
		</div>
	`;
}

/**
 * @param {string} s
 */
function escapeHtml(s) {
	return s
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;');
}

/**
 * @param {string} s
 */
function escapeAttr(s) {
	return escapeHtml(s);
}

function readDockPosition() {
	return new Promise((resolve) => {
		try {
			chrome.storage.local.get(DOCK_POS_KEY, (res) => {
				resolve(res?.[DOCK_POS_KEY] || null);
			});
		} catch {
			resolve(null);
		}
	});
}

function writeDockPosition(pos) {
	try {
		chrome.storage.local.set({ [DOCK_POS_KEY]: pos });
	} catch {
		/* ignore */
	}
}

async function ensureUi() {
	if (document.getElementById(ROOT_ID) || uiMounting) return;
	uiMounting = true;

	try {
		let cssText = '';
		try {
			const res = await fetch(chrome.runtime.getURL('content.css'));
			if (res.ok) cssText = await res.text();
		} catch (e) {
			console.warn('[Ahtapot] content.css fetch başarısız', e);
		}

		if (document.getElementById(ROOT_ID)) return;

		const host = document.createElement('div');
		host.id = ROOT_ID;
		host.setAttribute('data-ahtapot-extension', 'true');

		const shadow = host.attachShadow({ mode: 'closed' });
		const style = document.createElement('style');
		style.textContent = cssText.trim() ? cssText : FALLBACK_CSS;
		shadow.appendChild(style);
		const tpl = document.createElement('template');
		tpl.innerHTML = buildShadowHtml().trim();
		shadow.appendChild(tpl.content.cloneNode(true));

		const group = shadow.querySelector('.kg-group');
		const dock = shadow.querySelector('.kg-dock');
		const dragHandle = shadow.getElementById('kg-drag-handle');
		const toggle = shadow.getElementById('kg-group-toggle');
		const modalHost = shadow.getElementById('kg-modal-host');
		const modalTitle = shadow.getElementById('kg-modal-title');
		const modalBody = shadow.getElementById('kg-modal-body');
		const modalClose = shadow.getElementById('kg-modal-close');

		function setGroupOpen(open) {
			if (!group || !toggle) return;
			group.setAttribute('data-open', open ? 'true' : 'false');
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		}

		toggle?.addEventListener('click', () => {
			const open = group?.getAttribute('data-open') !== 'false';
			setGroupOpen(!open);
		});

		function clampDockPosition(x, y) {
			const w = dock?.offsetWidth || 280;
			const h = dock?.offsetHeight || 180;
			const maxX = Math.max(8, window.innerWidth - w - 8);
			const maxY = Math.max(8, window.innerHeight - h - 8);
			return {
				x: Math.min(Math.max(8, x), maxX),
				y: Math.min(Math.max(8, y), maxY),
			};
		}

		async function applySavedDockPosition() {
			if (!dock) return;
			const saved = await readDockPosition();
			if (!saved || !Number.isFinite(saved.x) || !Number.isFinite(saved.y)) return;
			const next = clampDockPosition(saved.x, saved.y);
			dock.style.left = `${next.x}px`;
			dock.style.top = `${next.y}px`;
			dock.style.right = 'auto';
		}

		function enableDockDrag() {
			if (!dock || !dragHandle) return;
			let dragging = false;
			let offsetX = 0;
			let offsetY = 0;

			dragHandle.addEventListener('pointerdown', (ev) => {
				dragging = true;
				dragHandle.setPointerCapture(ev.pointerId);
				const rect = dock.getBoundingClientRect();
				offsetX = ev.clientX - rect.left;
				offsetY = ev.clientY - rect.top;
				ev.preventDefault();
			});

			dragHandle.addEventListener('pointermove', (ev) => {
				if (!dragging) return;
				const next = clampDockPosition(ev.clientX - offsetX, ev.clientY - offsetY);
				dock.style.left = `${next.x}px`;
				dock.style.top = `${next.y}px`;
				dock.style.right = 'auto';
			});

			function stopDrag(ev) {
				if (!dragging) return;
				dragging = false;
				try {
					dragHandle.releasePointerCapture(ev.pointerId);
				} catch {
					/* ignore */
				}
				const rect = dock.getBoundingClientRect();
				writeDockPosition({ x: Math.round(rect.left), y: Math.round(rect.top) });
			}

			dragHandle.addEventListener('pointerup', stopDrag);
			dragHandle.addEventListener('pointercancel', stopDrag);
		}

		function openModal(title, bodyHtml) {
			if (!modalHost || !modalTitle || !modalBody) return;
			modalTitle.textContent = title;
			modalBody.innerHTML = bodyHtml;
			modalHost.setAttribute('data-open', 'true');
			modalHost.setAttribute('aria-hidden', 'false');
		}

		function closeModal() {
			try {
				globalThis.ahtapotLcCleanup?.();
			} catch {
				/* ignore */
			}
			globalThis.ahtapotLcCleanup = null;
			if (!modalHost || !modalBody) return;
			modalHost.setAttribute('data-open', 'false');
			modalHost.setAttribute('aria-hidden', 'true');
			modalBody.innerHTML = '';
		}

		/** @returns {boolean} true if a modal was open and closed */
		function tryCloseModalFromEscape() {
			if (!modalHost || modalHost.getAttribute('data-open') !== 'true') return false;
			closeModal();
			return true;
		}

		tryCloseModal = tryCloseModalFromEscape;

		for (const btn of shadow.querySelectorAll('.kg-sub[data-kg-action]')) {
			btn.addEventListener('click', (e) => {
				e.preventDefault();
				const action = btn.getAttribute('data-kg-action') || '';
				if (action === 'link-crawler') {
					if (!modalHost || !modalTitle || !modalBody) return;
					runModalCleanup();
					modalTitle.textContent = 'Link Crawler';
					modalBody.innerHTML = '';
					modalHost.setAttribute('data-open', 'true');
					modalHost.setAttribute('aria-hidden', 'false');
					if (typeof globalThis.ahtapotOpenLinkCrawler === 'function') {
						globalThis.ahtapotOpenLinkCrawler(modalTitle, modalBody, closeModal);
					} else {
						modalBody.innerHTML =
							'<p class="kg-lc-p">Link Crawler modülü yüklenemedi. Uzantıyı yenileyin.</p>';
					}
					return;
				}
				if (action === 'txt-birlestir') {
					if (!modalHost || !modalTitle || !modalBody) return;
					runModalCleanup();
					modalTitle.textContent = 'TXT Birleştir';
					modalBody.innerHTML = '';
					modalHost.setAttribute('data-open', 'true');
					modalHost.setAttribute('aria-hidden', 'false');
					if (typeof globalThis.ahtapotOpenTxtBirlestir === 'function') {
						globalThis.ahtapotOpenTxtBirlestir(modalTitle, modalBody, closeModal);
					} else {
						modalBody.innerHTML =
							'<p class="kg-lc-p">TXT Birleştir modülü yüklenemedi. Uzantıyı yenileyin.</p>';
					}
					return;
				}
				if (action === 'product-crawler') {
					if (!modalHost || !modalTitle || !modalBody) return;
					runModalCleanup();
					modalTitle.textContent = 'Product Crawler';
					modalBody.innerHTML = '';
					modalHost.setAttribute('data-open', 'true');
					modalHost.setAttribute('aria-hidden', 'false');
					if (typeof globalThis.ahtapotOpenProductCrawler === 'function') {
						globalThis.ahtapotOpenProductCrawler(modalTitle, modalBody, closeModal);
					} else {
						modalBody.innerHTML =
							'<p class="kg-lc-p">Product Crawler modülü yüklenemedi. Uzantıyı yenileyin.</p>';
					}
					return;
				}
				if (action === 'api-json-scraping') {
					if (!modalHost || !modalTitle || !modalBody) return;
					runModalCleanup();
					modalTitle.textContent = 'API JSON Scraping';
					modalBody.innerHTML = '';
					modalHost.setAttribute('data-open', 'true');
					modalHost.setAttribute('aria-hidden', 'false');
					if (typeof globalThis.ahtapotOpenApiJsonScraping === 'function') {
						globalThis.ahtapotOpenApiJsonScraping(modalTitle, modalBody, closeModal);
					} else {
						modalBody.innerHTML =
							'<p class="kg-lc-p">API JSON Scraping modülü yüklenemedi. Uzantıyı yenileyin.</p>';
					}
					return;
				}
				if (action === 'seller-data-crawler') {
					if (!modalHost || !modalTitle || !modalBody) return;
					runModalCleanup();
					modalTitle.textContent = 'Seller Data Crawler';
					modalBody.innerHTML = '';
					modalHost.setAttribute('data-open', 'true');
					modalHost.setAttribute('aria-hidden', 'false');
					if (typeof globalThis.ahtapotOpenSellerDataCrawler === 'function') {
						globalThis.ahtapotOpenSellerDataCrawler(modalTitle, modalBody, closeModal);
					} else {
						modalBody.innerHTML =
							'<p class="kg-lc-p">Seller Data Crawler modülü yüklenemedi. Uzantıyı yenileyin.</p>';
					}
					return;
				}
				if (action === 'epey-attr-crawler') {
					if (!modalHost || !modalTitle || !modalBody) return;
					runModalCleanup();
					modalTitle.textContent = 'Epey Attr Crawler';
					modalBody.innerHTML = '';
					modalHost.setAttribute('data-open', 'true');
					modalHost.setAttribute('aria-hidden', 'false');
					if (typeof globalThis.ahtapotOpenEpeyAttrCrawler === 'function') {
						globalThis.ahtapotOpenEpeyAttrCrawler(modalTitle, modalBody, closeModal);
					} else {
						modalBody.innerHTML =
							'<p class="kg-lc-p">Epey Attr Crawler modülü yüklenemedi. Uzantıyı yenileyin.</p>';
					}
					return;
				}
				if (action === 'epey-link-crawler') {
					if (!modalHost || !modalTitle || !modalBody) return;
					runModalCleanup();
					modalTitle.textContent = 'Link Crawler';
					modalBody.innerHTML = '';
					modalHost.setAttribute('data-open', 'true');
					modalHost.setAttribute('aria-hidden', 'false');
					if (typeof globalThis.ahtapotOpenEpeyLinkCrawler === 'function') {
						globalThis.ahtapotOpenEpeyLinkCrawler(modalTitle, modalBody, closeModal);
					} else {
						modalBody.innerHTML =
							'<p class="kg-lc-p">Link Crawler modülü yüklenemedi. Uzantıyı yenileyin.</p>';
					}
					return;
				}
				const label = btn.getAttribute('data-kg-label') ?? btn.textContent ?? '';
				openModal(label, '<p>Detaylar yakında eklenecek.</p>');
			});
		}

		modalClose?.addEventListener('click', closeModal);
		modalHost?.addEventListener('click', (e) => {
			if (e.target === modalHost) closeModal();
		});

		const mountParent = document.documentElement;
		mountParent.appendChild(host);
		enableDockDrag();
		void applySavedDockPosition();

		globalThis.ahtapotLcAutoShowIntro = function () {
			if (!modalHost || !modalTitle || !modalBody) return;
			runModalCleanup();
			modalTitle.textContent = 'Link Crawler';
			modalBody.innerHTML = '';
			modalHost.setAttribute('data-open', 'true');
			modalHost.setAttribute('aria-hidden', 'false');
			if (typeof globalThis.ahtapotOpenLinkCrawler === 'function') {
				globalThis.ahtapotOpenLinkCrawler(modalTitle, modalBody, closeModal);
			}
		};

		if (typeof globalThis.ahtapotLcRunPostNextPageFlow === 'function') {
			try {
				globalThis.ahtapotLcRunPostNextPageFlow();
			} catch (e) {
				console.warn('[Ahtapot] NextPage / prc sonrası akış', e);
			}
		}
	} catch (e) {
		console.error('[Ahtapot] UI mount hatası', e);
	} finally {
		uiMounting = false;
	}
}

function initOnce() {
	if (globalThis.__ahtapotInitOnce) return;
	globalThis.__ahtapotInitOnce = true;

	if (typeof window !== 'undefined') {
		window.addEventListener(
			'keydown',
			(e) => {
				if (e.key !== 'Escape' || !tryCloseModal) return;
				if (tryCloseModal()) e.preventDefault();
			},
			true,
		);
	}

	const observer = new MutationObserver(() => {
		if (!document.getElementById(ROOT_ID)) void ensureUi();
	});
	observer.observe(document.documentElement, { childList: true, subtree: true });
}

initOnce();
void ensureUi().catch((e) => {
	console.error('[Ahtapot] UI oluşturulamadı', e);
});
