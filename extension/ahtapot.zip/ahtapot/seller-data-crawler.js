/**
 * Seller Data Crawler — DB'deki Trendyol satıcılarını otomatik dolaşır.
 * globalThis.ahtapotOpenSellerDataCrawler(modalTitleEl, modalBodyEl, onClose)
 */
(function initSellerDataCrawler() {
	const PANEL_API_BASE = 'https://ahtapot.datascraper.net/api';
	function panelApiUrl(path) {
		const p = path.startsWith('/') ? path : `/${path}`;
		return `${PANEL_API_BASE}${p}`;
	}

	function formatCount(n) {
		const num = Number(n);
		if (!Number.isFinite(num)) return '—';
		return new Intl.NumberFormat('tr-TR').format(num);
	}

	function readSellerTabConcurrency(modalBodyEl) {
		const raw = Number(modalBodyEl?.querySelector('#kg-seller-crawl-tab-concurrency')?.value);
		if (!Number.isFinite(raw)) return 1;
		return Math.max(1, Math.min(30, Math.floor(raw)));
	}

	function sellerTabConcurrencyLabel(n) {
		return `${n} satıcı`;
	}

	function merchantToCrawlEntry(m) {
		const merchantId = m?.merchantId != null ? Number(m.merchantId) : null;
		if (!Number.isFinite(merchantId) || merchantId <= 0) return null;
		return {
			merchantId,
			name: m.name || null,
			storeUrl: normalizeTrendyolStoreUrl(
				typeof m.storeUrl === 'string' ? m.storeUrl.trim() : null,
				merchantId,
				m.name,
			),
			srUrl: buildTrendyolSellerSearchUrl(merchantId),
		};
	}

	function readSellerMissingMode(modalBodyEl) {
		const raw = String(
			modalBodyEl?.querySelector('#kg-seller-crawl-missing-mode')?.value || '',
		).trim();
		const allowed = new Set([
			'any_missing',
			'last_scrape_missing',
			'follower_missing',
			'platform_product_missing',
		]);
		return allowed.has(raw) ? raw : 'any_missing';
	}

	function describeMissingMode(mode) {
		if (mode === 'last_scrape_missing') return 'sadece son tarama yok';
		if (mode === 'follower_missing') return 'sadece takipçi eksik';
		if (mode === 'platform_product_missing') return 'sadece platform ürün sayısı eksik';
		return 'eksik profil (herhangi biri)';
	}

	async function fetchCrawlQueuePage(page, perPage, missingOnly, missingMode) {
		const qs = new URLSearchParams({
			page: String(page),
			perPage: String(perPage),
			platform: 'trendyol',
		});
		if (missingOnly) {
			qs.set('missingOnly', '1');
			qs.set('missingMode', missingMode || 'any_missing');
		}
		const res = await fetch(panelApiUrl(`/scraped-products/merchants/crawl-queue?${qs}`));
		const data = await res.json().catch(() => ({}));
		if (!res.ok || !data.ok) {
			throw new Error(data.error || `Kuyruk alınamadı (HTTP ${res.status})`);
		}
		return data;
	}

	function ahtapotOpenSellerDataCrawler(modalTitleEl, modalBodyEl, onClose) {
		modalTitleEl.textContent = 'Seller Data Crawler';
		modalBodyEl.innerHTML = `
			<div class="kg-epey-modal" role="region" aria-label="Seller Data Crawler">
				<p class="kg-lc-p">Veritabanındaki Trendyol satıcıları sırayla taranır: <code class="kg-lc-code">/sr?mid=…</code> ile platform ürün sayısı, <code class="kg-lc-code">/magaza/…</code> ile takipçi sayısı okunup <code class="kg-lc-code">merchant</code> profiline yazılır.</p>
				<p class="kg-lc-p kg-lc-p--muted"><code class="kg-lc-code">npm run api</code> çalışır olmalı. <strong>Dur</strong> ile istediğiniz anda durdurabilirsiniz.</p>
				<label class="kg-scrape-mode-option kg-seller-crawl-filter">
					<input type="checkbox" id="kg-seller-crawl-missing-only" checked />
					<span>Yalnızca profili eksik satıcılar <span class="kg-scrape-mode-hint">(takipçi / platform ürün sayısı / son tarama yok)</span></span>
				</label>
				<label class="kg-product-modal-lead" for="kg-seller-crawl-missing-mode">Eksik profil filtresi</label>
				<select class="kg-product-input" id="kg-seller-crawl-missing-mode" aria-label="Eksik profil filtresi">
					<option value="any_missing" selected>Herhangi biri eksik</option>
					<option value="last_scrape_missing">Sadece son tarama yok</option>
					<option value="follower_missing">Sadece takipçi yok</option>
					<option value="platform_product_missing">Sadece platform ürün sayısı yok</option>
				</select>
				<label class="kg-product-modal-lead" for="kg-seller-crawl-tab-concurrency">Eşzamanlı satıcı</label>
				<select class="kg-product-input kg-scrape-tab-select" id="kg-seller-crawl-tab-concurrency" aria-label="Eşzamanlı satıcı sayısı">
					<option value="1">1 satıcı (sıralı)</option>
					<option value="2">2 satıcı</option>
					<option value="3">3 satıcı</option>
					<option value="4">4 satıcı</option>
					<option value="5">5 satıcı</option>
					<option value="6">6 satıcı</option>
					<option value="7">7 satıcı</option>
					<option value="8">8 satıcı</option>
					<option value="9">9 satıcı</option>
					<option value="10">10 satıcı</option>
					<option value="11">11 satıcı</option>
					<option value="12">12 satıcı</option>
					<option value="13">13 satıcı</option>
					<option value="14">14 satıcı</option>
					<option value="15">15 satıcı</option>
					<option value="16">16 satıcı</option>
					<option value="17">17 satıcı</option>
					<option value="18">18 satıcı</option>
					<option value="19">19 satıcı</option>
					<option value="20">20 satıcı</option>
					<option value="21">21 satıcı</option>
					<option value="22">22 satıcı</option>
					<option value="23">23 satıcı</option>
					<option value="24">24 satıcı</option>
					<option value="25">25 satıcı</option>
					<option value="26">26 satıcı</option>
					<option value="27">27 satıcı</option>
					<option value="28">28 satıcı</option>
					<option value="29">29 satıcı</option>
					<option value="30" selected>30 satıcı</option>
				</select>
				<p class="kg-scrape-mode-hint kg-scrape-tab-hint">Her satıcı için 2 sekme açılır (SR + mağaza). 30 satıcı ≈ 60 sekme. Çok yüksek değerlerde tarayıcı/Trendyol limiti veya bellek baskısı oluşabilir.</p>
				<p class="kg-product-status" id="kg-seller-crawl-status">Hazır.</p>
				<div class="kg-product-errors-wrap" id="kg-seller-crawl-log-wrap" hidden>
					<h4 class="kg-product-errors-title">İşlem günlüğü</h4>
					<pre class="kg-seller-crawl-log" id="kg-seller-crawl-log"></pre>
				</div>
				<div class="kg-lc-actions-row" id="kg-seller-crawl-actions"></div>
			</div>
		`;

		const missingOnlyEl = modalBodyEl.querySelector('#kg-seller-crawl-missing-only');
		const missingModeEl = modalBodyEl.querySelector('#kg-seller-crawl-missing-mode');
		const tabConcurrencyEl = modalBodyEl.querySelector('#kg-seller-crawl-tab-concurrency');
		const statusEl = modalBodyEl.querySelector('#kg-seller-crawl-status');
		const logWrap = modalBodyEl.querySelector('#kg-seller-crawl-log-wrap');
		const logEl = modalBodyEl.querySelector('#kg-seller-crawl-log');
		const actionsEl = modalBodyEl.querySelector('#kg-seller-crawl-actions');
		if (!actionsEl || !statusEl) return;

		const runBtn = document.createElement('button');
		runBtn.type = 'button';
		runBtn.className = 'kg-lc-btn kg-lc-btn--primary';
		runBtn.textContent = 'Otomatik tarama';
		const stopBtn = document.createElement('button');
		stopBtn.type = 'button';
		stopBtn.className = 'kg-lc-btn kg-lc-btn--ghost';
		stopBtn.textContent = 'Dur';
		stopBtn.disabled = true;
		const closeBtn = document.createElement('button');
		closeBtn.type = 'button';
		closeBtn.className = 'kg-lc-btn kg-lc-btn--ghost';
		closeBtn.textContent = 'Kapat';
		closeBtn.addEventListener('click', () => onClose?.());
		actionsEl.append(runBtn, stopBtn, closeBtn);

		let running = false;
		let stopRequested = false;
		const logLines = [];
		const perPage = 50;
		let runSeenMerchantIds = new Set();

		function appendLog(line) {
			logLines.push(line);
			if (logLines.length > 200) logLines.shift();
			if (logEl) logEl.textContent = logLines.join('\n');
			logWrap.hidden = false;
		}

		function setRunningState(active) {
			running = active;
			runBtn.disabled = active;
			stopBtn.disabled = !active;
			if (missingOnlyEl instanceof HTMLInputElement) missingOnlyEl.disabled = active;
			if (missingModeEl instanceof HTMLSelectElement) missingModeEl.disabled = active;
			if (tabConcurrencyEl instanceof HTMLSelectElement) tabConcurrencyEl.disabled = active;
		}

		function formatSellerResultLog(r) {
			const label = r?.name || (r?.merchantId != null ? `mid ${r.merchantId}` : 'satıcı');
			if (r?.ok) {
				const ex = r.extracted || {};
				const prod =
					ex.platformProductCount != null
						? `${formatCount(ex.platformProductCount)}${ex.platformProductCountMinimum ? '+' : ''} ürün`
						: 'ürün —';
				const fol =
					ex.followerCount != null
						? `${formatCount(ex.followerCount)} takipçi`
						: 'takipçi —';
				return { label, line: `✓ ${label} · ${prod} · ${fol}` };
			}
			return { label, line: `✗ ${label} → ${r?.error || 'Hata'}` };
		}

		stopBtn.addEventListener('click', () => {
			if (!running) return;
			stopRequested = true;
			statusEl.textContent = 'Durduruluyor…';
		});

		runBtn.addEventListener('click', async () => {
			if (running) return;
			stopRequested = false;
			logLines.length = 0;
			if (logEl) logEl.textContent = '';
			logWrap.hidden = true;
			runSeenMerchantIds = new Set();

			const missingOnly =
				missingOnlyEl instanceof HTMLInputElement ? missingOnlyEl.checked : true;
			const missingMode = readSellerMissingMode(modalBodyEl);
			const tabConcurrency = readSellerTabConcurrency(modalBodyEl);
			const tabsPrefix =
				tabConcurrency > 1 ? `${sellerTabConcurrencyLabel(tabConcurrency)} · ` : '';

			setRunningState(true);
			let okN = 0;
			let failN = 0;
			let processed = 0;
			let total = 0;

			try {
				statusEl.textContent = 'Satıcı kuyruğu yükleniyor…';
				const probe = await fetchCrawlQueuePage(1, perPage, missingOnly, missingMode);
				total = probe.total != null ? Number(probe.total) : 0;

				if (!total) {
					statusEl.textContent = missingOnly
						? 'Profili eksik satıcı bulunamadı.'
						: 'Veritabanında taranacak Trendyol satıcısı yok (merchant_id gerekli).';
					return;
				}

				appendLog(
					`Kuyruk: ${formatCount(total)} satıcı · ${missingOnly ? describeMissingMode(missingMode) : 'tümü'} · ${tabsPrefix || '1 satıcı'}`,
				);

				let page = 1;
				const totalPages = missingOnly
					? 1
					: probe.totalPages != null
						? Number(probe.totalPages)
						: 1;

				while (!stopRequested) {
					if (!missingOnly && page > totalPages) break;

					const batch = await fetchCrawlQueuePage(
						missingOnly ? 1 : page,
						perPage,
						missingOnly,
						missingMode,
					);
					const merchants = Array.isArray(batch.merchants) ? batch.merchants : [];
					if (!merchants.length) break;

					if (missingOnly) {
						total = batch.total != null ? Number(batch.total) : total;
					}

					const pageEntries = merchants
						.map((m) => merchantToCrawlEntry(m))
						.filter((e) => {
							if (!e || e.merchantId == null) return false;
							if (runSeenMerchantIds.has(e.merchantId)) return false;
							return true;
						})
						.filter(Boolean);
					if (!pageEntries.length) {
						if (missingOnly) {
							statusEl.textContent =
								`Bu turda yeni satıcı kalmadı. ` +
								`${okN} başarılı, ${failN} hata · ${processed} işlendi.`;
							break;
						}
						page++;
						continue;
					}

					for (let start = 0; start < pageEntries.length; start += tabConcurrency) {
						if (stopRequested) break;
						const chunk = pageEntries.slice(start, start + tabConcurrency);
						const chunkEnd = Math.min(start + chunk.length, pageEntries.length);
						const chunkLabels = chunk
							.map((e) => e.name || `mid ${e.merchantId}`)
							.join(', ');
						const progressTotal = missingOnly ? total : total;
						const chunkProcessed = processed + chunk.length;
						statusEl.textContent = missingOnly
							? `${tabsPrefix}[${chunkProcessed}/${progressTotal}] ${chunkLabels} · kuyrukta ~${formatCount(Math.max(0, total - chunkProcessed))} kaldı`
							: `${tabsPrefix}[${chunkProcessed}/${progressTotal}] ${chunkLabels} · sayfa ${page}/${totalPages}`;

						try {
							const response = await chrome.runtime.sendMessage({
								type: 'ahtapot-crawl-seller-profiles',
								entries: chunk,
								tabConcurrency,
								delayMs: tabConcurrency > 1 ? 0 : 700,
							});
							if (!response?.ok) {
								throw new Error(response?.error || 'Tarama başarısız.');
							}
							const chunkResults = Array.isArray(response.results) ? response.results : [];
							for (let ri = 0; ri < chunkResults.length; ri++) {
								processed++;
								const chunkEntry = chunk[ri];
								if (chunkEntry?.merchantId != null) {
									runSeenMerchantIds.add(chunkEntry.merchantId);
								}
								const formatted = formatSellerResultLog(chunkResults[ri]);
								if (chunkResults[ri]?.ok) {
									okN++;
									appendLog(formatted.line);
								} else {
									failN++;
									appendLog(formatted.line);
								}
							}
						} catch (err) {
							for (let ci = 0; ci < chunk.length; ci++) {
								processed++;
								failN++;
								if (chunk[ci]?.merchantId != null) {
									runSeenMerchantIds.add(chunk[ci].merchantId);
								}
								const label = chunk[ci].name || `mid ${chunk[ci].merchantId}`;
								appendLog(
									`✗ ${label} → ${err instanceof Error ? err.message : String(err)}`,
								);
							}
						}

						if (!stopRequested && tabConcurrency > 1 && chunkEnd < pageEntries.length) {
							await new Promise((r) => setTimeout(r, 400));
						}
					}

					if (missingOnly) continue;
					page++;
				}

				statusEl.textContent = stopRequested
					? `Durduruldu: ${okN} başarılı, ${failN} hata · ${processed} işlendi.`
					: `Bitti: ${okN} başarılı, ${failN} hata · ${processed} satıcı.`;
			} catch (err) {
				statusEl.textContent =
					'Hata: ' + (err instanceof Error ? err.message : String(err));
				appendLog(err instanceof Error ? err.message : String(err));
			} finally {
				setRunningState(false);
				stopRequested = false;
			}
		});

		globalThis.ahtapotLcCleanup = () => {
			stopRequested = true;
			running = false;
		};
	}

	globalThis.ahtapotOpenSellerDataCrawler = ahtapotOpenSellerDataCrawler;
})();
