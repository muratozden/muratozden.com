// Popup: mode toggles + compact activity + settings.

const DEFAULT_CRAWLER_LIMIT = 1;
const MAX_CRAWLER_LIMIT = 100;
const DEFAULT_JITTER_MIN_MS = 45_000;
const DEFAULT_JITTER_MAX_MS = 120_000;

function clampCrawlerLimit(value) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n) || n < 1) return DEFAULT_CRAWLER_LIMIT;
  if (n > MAX_CRAWLER_LIMIT) return MAX_CRAWLER_LIMIT;
  return n;
}

const els = {
  headerTitle: document.getElementById("header-title"),
  headerSub: document.getElementById("header-sub"),
  btnSettings: document.getElementById("btn-settings"),
  viewMain: document.getElementById("view-main"),
  viewSettings: document.getElementById("view-settings"),
  settingsApiUrl: document.getElementById("settings-api-url"),
  settingsApiKey: document.getElementById("settings-api-key"),
  settingsCrawlerLimit: document.getElementById("settings-crawler-limit"),
  settingsDeviceLabel: document.getElementById("settings-device-label"),
  settingsJitterMin: document.getElementById("settings-jitter-min"),
  settingsJitterMax: document.getElementById("settings-jitter-max"),
  settingsKeyHint: document.getElementById("settings-key-hint"),
  settingsError: document.getElementById("settings-error"),
  btnSave: document.getElementById("btn-save"),
  btnCancel: document.getElementById("btn-cancel"),
  toggle: document.getElementById("toggle-enabled"),
  toggleTour: document.getElementById("toggle-akakce-tour"),
  toggleMerchant: document.getElementById("toggle-merchant-links"),
  toggleBackfill: document.getElementById("toggle-merchant-backfill"),
  cardVisit: document.getElementById("card-visit"),
  cardTour: document.getElementById("card-tour"),
  cardMerchant: document.getElementById("card-merchant"),
  cardBackfill: document.getElementById("card-backfill"),
  switchLabel: document.getElementById("switch-label"),
  tourSwitchLabel: document.getElementById("tour-switch-label"),
  merchantSwitchLabel: document.getElementById("merchant-switch-label"),
  backfillSwitchLabel: document.getElementById("backfill-switch-label"),
  statusDot: document.getElementById("status-dot"),
  statDone: document.getElementById("stat-done"),
  statFailed: document.getElementById("stat-failed"),
  tourStats: document.getElementById("tour-stats"),
  merchantStats: document.getElementById("merchant-stats"),
  backfillStats: document.getElementById("backfill-stats"),
  statTourDone: document.getElementById("stat-tour-done"),
  statTourVisited: document.getElementById("stat-tour-visited"),
  statMerchantDone: document.getElementById("stat-merchant-done"),
  statMerchantFailed: document.getElementById("stat-merchant-failed"),
  merchantCategory: document.getElementById("merchant-category"),
  merchantFilter: document.getElementById("merchant-filter"),
  statBackfillDone: document.getElementById("stat-backfill-done"),
  statBackfillFailed: document.getElementById("stat-backfill-failed"),
  lastUrl: document.getElementById("last-url"),
  mainError: document.getElementById("main-error"),
  quarantineBanner: document.getElementById("quarantine-banner"),
  quarantineDetail: document.getElementById("quarantine-detail"),
  btnResume: document.getElementById("btn-resume"),
  deviceId: document.getElementById("device-id"),
  deviceLabelDisplay: document.getElementById("device-label-display"),
};

/** True when the user opened Settings from the main screen (Cancel returns there). */
let settingsFromMain = false;

init();

async function init() {
  const state = await loadState();

  if (state.apiKey) {
    showMain(state);
  } else {
    els.settingsApiUrl.value = state.apiUrl || DEFAULT_API_URL;
    els.settingsApiKey.value = "";
    els.settingsCrawlerLimit.value = String(DEFAULT_CRAWLER_LIMIT);
    showSettings({ firstRun: true });
  }

  els.btnSettings.addEventListener("click", () => openSettings());
  els.btnSave.addEventListener("click", onSave);
  els.btnCancel.addEventListener("click", onCancel);
  els.toggle.addEventListener("change", onToggle);
  els.toggleTour.addEventListener("change", onTourToggle);
  els.toggleMerchant.addEventListener("change", onMerchantToggle);
  els.toggleBackfill.addEventListener("change", onBackfillToggle);
  els.merchantCategory.addEventListener("change", onMerchantCategoryChange);
  els.btnResume.addEventListener("click", onResume);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.visitsDone) els.statDone.textContent = changes.visitsDone.newValue;
    if (changes.visitsFailed) els.statFailed.textContent = changes.visitsFailed.newValue;
    if (changes.lastUrl) setLastUrl(changes.lastUrl.newValue);
    if (changes.lastError) setMainError(changes.lastError.newValue);
    if (changes.akakceTourDone) els.statTourDone.textContent = changes.akakceTourDone.newValue;
    if (changes.akakceTourVisitedUrls) {
      els.statTourVisited.textContent = (changes.akakceTourVisitedUrls.newValue || []).length;
    }
    if (changes.merchantLinkDone) els.statMerchantDone.textContent = changes.merchantLinkDone.newValue;
    if (changes.merchantLinkFailed) els.statMerchantFailed.textContent = changes.merchantLinkFailed.newValue;
    if (changes.merchantBackfillDone) els.statBackfillDone.textContent = changes.merchantBackfillDone.newValue;
    if (changes.merchantBackfillFailed) els.statBackfillFailed.textContent = changes.merchantBackfillFailed.newValue;
    if (changes.enabled) {
      renderEnabled(changes.enabled.newValue);
      renderStatusDot(
        changes.enabled.newValue,
        els.toggleTour.checked,
        els.toggleMerchant.checked,
        els.toggleBackfill.checked,
      );
    }
    if (changes.akakceTourEnabled) {
      renderTourEnabled(changes.akakceTourEnabled.newValue);
      renderStatusDot(
        els.toggle.checked,
        changes.akakceTourEnabled.newValue,
        els.toggleMerchant.checked,
        els.toggleBackfill.checked,
      );
    }
    if (changes.merchantLinkResolverEnabled) {
      renderMerchantEnabled(changes.merchantLinkResolverEnabled.newValue);
      renderStatusDot(
        els.toggle.checked,
        els.toggleTour.checked,
        changes.merchantLinkResolverEnabled.newValue,
        els.toggleBackfill.checked,
      );
    }
    if (changes.merchantLinkCategory) {
      els.merchantCategory.value = changes.merchantLinkCategory.newValue || "";
    }
    if (changes.merchantLinkBackfillEnabled) {
      renderBackfillEnabled(changes.merchantLinkBackfillEnabled.newValue);
      renderStatusDot(
        els.toggle.checked,
        els.toggleTour.checked,
        els.toggleMerchant.checked,
        changes.merchantLinkBackfillEnabled.newValue,
        els.toggle.disabled && changes.quarantined?.newValue !== false,
      );
    }
    if (changes.quarantined || changes.quarantineReason || changes.last403Url) {
      chrome.storage.local.get(
        ["quarantined", "quarantineReason", "last403Url", "quarantinedAt", "enabled", "akakceTourEnabled", "merchantLinkResolverEnabled", "merchantLinkBackfillEnabled"],
        (s) => {
          renderQuarantine(s);
          setToggleQuarantineState(s.quarantined);
          renderStatusDot(s.enabled, s.akakceTourEnabled, s.merchantLinkResolverEnabled, s.merchantLinkBackfillEnabled, s.quarantined);
        },
      );
    }
  });
}

async function loadState() {
  return chrome.storage.local.get({
    apiUrl: DEFAULT_API_URL,
    apiKey: "",
    enabled: false,
    akakceTourEnabled: false,
    merchantLinkResolverEnabled: false,
    merchantLinkCategory: "",
    merchantLinkBackfillEnabled: false,
    visitsDone: 0,
    visitsFailed: 0,
    akakceTourDone: 0,
    akakceTourVisitedUrls: [],
    merchantLinkDone: 0,
    merchantLinkFailed: 0,
    merchantBackfillDone: 0,
    merchantBackfillFailed: 0,
    lastUrl: "",
    lastError: "",
    crawlerLimit: DEFAULT_CRAWLER_LIMIT,
    deviceId: "",
    deviceLabel: "",
    quarantined: false,
    quarantineReason: "",
    last403Url: "",
    quarantinedAt: "",
    jitterMinMs: DEFAULT_JITTER_MIN_MS,
    jitterMaxMs: DEFAULT_JITTER_MAX_MS,
  });
}

function showMain(state) {
  settingsFromMain = false;
  els.viewMain.hidden = false;
  els.viewSettings.hidden = true;
  els.btnSettings.hidden = false;
  els.headerTitle.textContent = "n11 Crawler Agent";
  els.headerSub.textContent = "External visit client";
  els.toggle.checked = state.enabled && !state.quarantined;
  els.toggleTour.checked = state.akakceTourEnabled && !state.quarantined;
  els.toggleMerchant.checked = state.merchantLinkResolverEnabled && !state.quarantined;
  els.toggleBackfill.checked = state.merchantLinkBackfillEnabled && !state.quarantined;
  els.merchantCategory.value = state.merchantLinkCategory || "";
  setToggleQuarantineState(state.quarantined);
  renderQuarantine(state);
  els.deviceId.textContent = state.deviceId || "—";
  els.deviceLabelDisplay.textContent = state.deviceLabel || "—";
  renderEnabled(state.enabled && !state.quarantined);
  renderTourEnabled(state.akakceTourEnabled && !state.quarantined);
  renderMerchantEnabled(state.merchantLinkResolverEnabled && !state.quarantined);
  renderBackfillEnabled(state.merchantLinkBackfillEnabled && !state.quarantined);
  renderStatusDot(
    state.enabled,
    state.akakceTourEnabled,
    state.merchantLinkResolverEnabled,
    state.merchantLinkBackfillEnabled,
    state.quarantined,
  );
  els.statDone.textContent = state.visitsDone;
  els.statFailed.textContent = state.visitsFailed;
  els.statTourDone.textContent = state.akakceTourDone;
  els.statTourVisited.textContent = (state.akakceTourVisitedUrls || []).length;
  els.statMerchantDone.textContent = state.merchantLinkDone;
  els.statMerchantFailed.textContent = state.merchantLinkFailed;
  els.statBackfillDone.textContent = state.merchantBackfillDone;
  els.statBackfillFailed.textContent = state.merchantBackfillFailed;
  setLastUrl(state.lastUrl);
  setMainError(state.lastError);
  loadMerchantCategories(state);
}

async function loadMerchantCategories(state) {
  if (!state.apiUrl || !state.apiKey) return;

  const selected = state.merchantLinkCategory || "";
  els.merchantCategory.disabled = true;

  try {
    const res = await fetch(state.apiUrl + "/v1/akakce-hub/merchant-links/categories", {
      headers: { Authorization: "ApiKey " + state.apiKey },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const items = (data && data.items) || [];

    const options = ['<option value="">All categories</option>'];
    for (const item of items) {
      const slug = String(item.slug || "");
      if (!slug) continue;
      const label = item.label || slug;
      const count = Number(item.pending_count) || 0;
      const suffix = count > 0 ? ` (${count})` : "";
      options.push(
        `<option value="${escapeHtml(slug)}">${escapeHtml(label)}${suffix}</option>`,
      );
    }
    els.merchantCategory.innerHTML = options.join("");
    els.merchantCategory.value = items.some((item) => item.slug === selected) ? selected : "";
    if (selected && els.merchantCategory.value !== selected) {
      await chrome.storage.local.set({ merchantLinkCategory: "", merchantLinkCursor: "" });
    }
  } catch {
    els.merchantCategory.innerHTML = '<option value="">All categories</option>';
    els.merchantCategory.value = "";
  } finally {
    els.merchantCategory.disabled = false;
  }
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function showSettings({ firstRun }) {
  els.viewMain.hidden = true;
  els.viewSettings.hidden = false;
  els.btnSettings.hidden = true;
  els.headerTitle.textContent = "Settings";
  els.headerSub.textContent = "API connection";
  els.settingsError.hidden = true;
  els.btnCancel.hidden = firstRun;
  els.settingsKeyHint.hidden = firstRun;
}

async function openSettings() {
  settingsFromMain = true;
  const state = await loadState();
  els.settingsApiUrl.value = state.apiUrl || DEFAULT_API_URL;
  els.settingsApiKey.value = "";
  els.settingsCrawlerLimit.value = String(clampCrawlerLimit(state.crawlerLimit));
  els.settingsDeviceLabel.value = state.deviceLabel || "";
  els.settingsJitterMin.value = String(Math.round((state.jitterMinMs || DEFAULT_JITTER_MIN_MS) / 1000));
  els.settingsJitterMax.value = String(Math.round((state.jitterMaxMs || DEFAULT_JITTER_MAX_MS) / 1000));
  showSettings({ firstRun: false });
}

function renderEnabled(enabled) {
  els.cardVisit.classList.toggle("is-on", enabled);
  els.switchLabel.textContent = enabled ? "Running" : "Off";
}

function renderTourEnabled(enabled) {
  els.cardTour.classList.toggle("is-on", enabled);
  els.tourSwitchLabel.textContent = enabled ? "Running" : "Off";
  els.tourStats.hidden = !enabled;
}

function renderMerchantEnabled(enabled) {
  els.cardMerchant.classList.toggle("is-on", enabled);
  els.merchantSwitchLabel.textContent = enabled ? "Running" : "Off";
  els.merchantStats.hidden = !enabled;
}

function renderBackfillEnabled(enabled) {
  els.cardBackfill.classList.toggle("is-on", enabled);
  els.backfillSwitchLabel.textContent = enabled ? "Running" : "Off";
  els.backfillStats.hidden = !enabled;
}

function renderStatusDot(enabled, tourEnabled, merchantEnabled, backfillEnabled, quarantined = false) {
  if (quarantined) {
    els.statusDot.classList.remove("on");
    els.statusDot.classList.add("quarantined");
    return;
  }
  els.statusDot.classList.remove("quarantined");
  const on = Boolean(enabled) || Boolean(tourEnabled) || Boolean(merchantEnabled) || Boolean(backfillEnabled);
  els.statusDot.classList.toggle("on", on);
}

function renderQuarantine(state) {
  if (state.quarantined) {
    els.quarantineBanner.hidden = false;
    const parts = [];
    if (state.quarantineReason) parts.push(state.quarantineReason);
    if (state.last403Url) parts.push(state.last403Url);
    if (state.quarantinedAt) parts.push(new Date(state.quarantinedAt).toLocaleString());
    els.quarantineDetail.textContent = parts.join(" · ") || "HTTP 403 detected";
  } else {
    els.quarantineBanner.hidden = true;
  }
}

function setToggleQuarantineState(quarantined) {
  const disabled = Boolean(quarantined);
  els.toggle.disabled = disabled;
  els.toggleTour.disabled = disabled;
  els.toggleMerchant.disabled = disabled;
  els.toggleBackfill.disabled = disabled;
}

function setLastUrl(url) {
  els.lastUrl.hidden = !url;
  els.lastUrl.textContent = url || "";
}

function setMainError(msg) {
  els.mainError.hidden = !msg;
  els.mainError.textContent = msg || "";
}

function showSettingsError(msg) {
  els.settingsError.hidden = false;
  els.settingsError.textContent = msg;
}

async function onSave() {
  const apiUrl = els.settingsApiUrl.value.trim().replace(/\/+$/, "");
  const keyInput = els.settingsApiKey.value.trim();
  const crawlerLimit = clampCrawlerLimit(els.settingsCrawlerLimit.value);
  const deviceLabel = els.settingsDeviceLabel.value.trim();
  const jitterMinMs = Math.max(5, parseInt(els.settingsJitterMin.value, 10) || 45) * 1000;
  const jitterMaxMs = Math.max(jitterMinMs / 1000, parseInt(els.settingsJitterMax.value, 10) || 120) * 1000;
  const stored = await loadState();
  const apiKey = keyInput || stored.apiKey;

  els.settingsError.hidden = true;

  if (!apiUrl) {
    showSettingsError("API URL is required.");
    return;
  }
  if (!apiKey) {
    showSettingsError("API key is required.");
    return;
  }

  els.btnSave.disabled = true;
  els.btnSave.textContent = "Checking…";
  try {
    const res = await fetch(apiUrl + "/v1/stats", {
      headers: { Authorization: "ApiKey " + apiKey },
    });
    if (res.status === 401) throw new Error("API key rejected (401).");
    if (!res.ok) throw new Error(`API responded with HTTP ${res.status}.`);
  } catch (err) {
    showSettingsError(err instanceof Error ? err.message : "Could not reach the API.");
    els.btnSave.disabled = false;
    els.btnSave.textContent = "Save";
    return;
  }

  const patch = { apiUrl, apiKey, crawlerLimit, deviceLabel, jitterMinMs, jitterMaxMs };
  if (!stored.apiKey) {
    patch.enabled = false;
    patch.akakceTourEnabled = false;
    patch.merchantLinkResolverEnabled = false;
    patch.merchantLinkBackfillEnabled = false;
  }
  await chrome.storage.local.set(patch);

  els.btnSave.disabled = false;
  els.btnSave.textContent = "Save";
  els.settingsApiKey.value = "";

  const state = await loadState();
  showMain(state);
}

async function onCancel() {
  if (!settingsFromMain) return;
  els.settingsApiKey.value = "";
  els.settingsError.hidden = true;
  const state = await loadState();
  showMain(state);
}

async function onToggle() {
  const state = await loadState();
  if (state.quarantined) {
    els.toggle.checked = false;
    return;
  }
  const enabled = els.toggle.checked;
  await chrome.storage.local.set({ enabled, lastError: "" });
  renderEnabled(enabled);
  renderStatusDot(enabled, state.akakceTourEnabled, state.merchantLinkResolverEnabled, state.merchantLinkBackfillEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "enabled-changed", enabled }).catch(() => {});
}

async function onTourToggle() {
  const state = await loadState();
  if (state.quarantined) {
    els.toggleTour.checked = false;
    return;
  }
  const akakceTourEnabled = els.toggleTour.checked;
  await chrome.storage.local.set({ akakceTourEnabled, lastError: "" });
  renderTourEnabled(akakceTourEnabled);
  renderStatusDot(state.enabled, akakceTourEnabled, state.merchantLinkResolverEnabled, state.merchantLinkBackfillEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "akakce-tour-changed", enabled: akakceTourEnabled }).catch(() => {});
}

async function onMerchantToggle() {
  const state = await loadState();
  if (state.quarantined) {
    els.toggleMerchant.checked = false;
    return;
  }
  const merchantLinkResolverEnabled = els.toggleMerchant.checked;
  await chrome.storage.local.set({ merchantLinkResolverEnabled, lastError: "" });
  renderMerchantEnabled(merchantLinkResolverEnabled);
  renderStatusDot(state.enabled, state.akakceTourEnabled, merchantLinkResolverEnabled, state.merchantLinkBackfillEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "merchant-link-changed", enabled: merchantLinkResolverEnabled }).catch(() => {});
}

async function onMerchantCategoryChange() {
  const merchantLinkCategory = els.merchantCategory.value.trim();
  await chrome.storage.local.set({
    merchantLinkCategory,
    merchantLinkCursor: "",
    lastError: "",
  });
  chrome.runtime.sendMessage({ type: "merchant-category-changed", category: merchantLinkCategory }).catch(() => {});
}

async function onBackfillToggle() {
  const state = await loadState();
  if (state.quarantined) {
    els.toggleBackfill.checked = false;
    return;
  }
  const merchantLinkBackfillEnabled = els.toggleBackfill.checked;
  await chrome.storage.local.set({ merchantLinkBackfillEnabled, lastError: "" });
  renderBackfillEnabled(merchantLinkBackfillEnabled);
  renderStatusDot(state.enabled, state.akakceTourEnabled, state.merchantLinkResolverEnabled, merchantLinkBackfillEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "merchant-backfill-changed", enabled: merchantLinkBackfillEnabled }).catch(() => {});
}

async function onResume() {
  const res = await chrome.runtime.sendMessage({ type: "resume-device" });
  if (!res?.ok) {
    setMainError(res?.error || "Could not clear quarantine");
    return;
  }
  const state = await loadState();
  showMain(state);
}
