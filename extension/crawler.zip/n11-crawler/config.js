// Production crawler API (shared with admin and other datascraper clients).
const DEFAULT_API_URL = "https://api.datascraper.net";

// Visit pacing (phone-fleet friendly defaults).
const DEFAULT_JITTER_MIN_MS = 45_000;
const DEFAULT_JITTER_MAX_MS = 120_000;
const DEFAULT_POLL_EMPTY_MIN_MS = 30_000;
const DEFAULT_POLL_EMPTY_MAX_MS = 75_000;
const SETTLE_MIN_MS = 4_000;
const SETTLE_MAX_MS = 8_000;
const AKAKCE_SETTLE_MIN_MS = 4_000;
const AKAKCE_SETTLE_MAX_MS = 8_000;
