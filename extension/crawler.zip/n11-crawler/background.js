importScripts("config.js");

// n11 Crawler external visit client (docs/API.md).
//
// While enabled, the work loop claims up to crawlerLimit 'api'-agent pages via
// POST /v1/visits/claim (queued first; when empty the API offers done pages whose
// http_status is not 200, oldest fetch first), opens each in an inactive browser
// tab (in parallel), captures the rendered DOM after the page settles, and reports
// outcomes via POST /v1/visits/{id}/result. crawlerLimit defaults to 1 (sequential behavior).
//
// MV3 service workers are ephemeral: a 30s watchdog alarm restarts the loop
// after the worker is suspended. Visit leases on the server make interrupted
// work reclaimable, so a mid-visit suspension is safe.

const TOUR_POLL_EMPTY_MS = 30_000;
const MERCHANT_POLL_EMPTY_MS = 30_000;
const MERCHANT_PAGE_DELAY_MS = 1_500;
const MERCHANT_RESOLVE_TIMEOUT_MS = 45_000;
const MERCHANT_TARGETS_BATCH = 20;
const TOUR_PAGE_DELAY_MS = 3_000;
const TAB_LOAD_TIMEOUT_MS = 60_000;
const MAX_BODY_BYTES = 10 * 1024 * 1024;
const WATCHDOG_ALARM = "kodigen-watchdog";
const HEARTBEAT_ALARM = "kodigen-heartbeat";
const EXTENSION_VERSION = chrome.runtime.getManifest().version;
const DEFAULT_CRAWLER_LIMIT = 1;
const MAX_CRAWLER_LIMIT = 100;
const CAPTURE_TARGETS_BATCH = 50;

let working = false;
let tourWorking = false;
let merchantLinkWorking = false;
let merchantBackfillWorking = false;
let activeFetches = 0;
let backgroundWorkDepth = 0;
let savedUserFocus = null;
let suppressWorkTabActivation = false;

chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === WATCHDOG_ALARM) maybeRun();
  if (alarm.name === HEARTBEAT_ALARM) sendHeartbeat();
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "enabled-changed") {
    if (msg.enabled) {
      maybeRun();
    }
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === "akakce-tour-changed") {
    if (msg.enabled) {
      maybeRun();
    }
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === "merchant-link-changed") {
    if (msg.enabled) {
      maybeRun();
    }
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === "merchant-category-changed") {
    maybeRun();
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === "merchant-backfill-changed") {
    if (msg.enabled) {
      maybeRun();
    }
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === "akakce-page-capture") {
    handleAkakcePageCapture(msg)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, error: errMessage(err) }));
    return true;
  }
  if (msg && msg.type === "resume-device") {
    clearQuarantine()
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: errMessage(err) }));
    return true;
  }
  return false;
});

maybeRun();

async function setup() {
  await migrateApiUrl();
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: 0.5 });
  await chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: 1 });
  chrome.tabs.onActivated.addListener(onWorkTabActivated);
  sendHeartbeat();
  maybeRun();
}

async function onWorkTabActivated(activeInfo) {
  if (!suppressWorkTabActivation || !savedUserFocus?.tabId) return;
  if (activeInfo.tabId === savedUserFocus.tabId) return;

  const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
  if (!workTabIds.includes(activeInfo.tabId)) return;

  try {
    const win = await chrome.windows.get(activeInfo.windowId);
    if (!win.focused) return;
    await chrome.tabs.update(savedUserFocus.tabId, { active: true });
  } catch {
    // User closed the window or tab.
  }
}

async function migrateApiUrl() {
  const { apiUrl } = await chrome.storage.local.get({ apiUrl: "" });
  const legacy = new Set(["", "http://localhost:8080", "https://crawler.datascraper.net/api"]);
  if (legacy.has(apiUrl)) {
    await chrome.storage.local.set({ apiUrl: DEFAULT_API_URL });
  }
}

function clampCrawlerLimit(value) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n) || n < 1) return DEFAULT_CRAWLER_LIMIT;
  if (n > MAX_CRAWLER_LIMIT) return MAX_CRAWLER_LIMIT;
  return n;
}

function randomBetween(minMs, maxMs) {
  const min = Math.max(0, minMs);
  const max = Math.max(min, maxMs);
  return min + Math.floor(Math.random() * (max - min + 1));
}

async function getState() {
  const state = await chrome.storage.local.get({
    apiUrl: DEFAULT_API_URL,
    apiKey: "",
    enabled: false,
    akakceTourEnabled: false,
    merchantLinkResolverEnabled: false,
    merchantLinkCategory: "",
    merchantLinkBackfillEnabled: false,
    deviceId: "",
    deviceLabel: "",
    clientId: "",
    quarantined: false,
    quarantineReason: "",
    quarantinedAt: "",
    last403Url: "",
    jitterMinMs: DEFAULT_JITTER_MIN_MS,
    jitterMaxMs: DEFAULT_JITTER_MAX_MS,
    pollEmptyMinMs: DEFAULT_POLL_EMPTY_MIN_MS,
    pollEmptyMaxMs: DEFAULT_POLL_EMPTY_MAX_MS,
    crawlerLimit: DEFAULT_CRAWLER_LIMIT,
    workTabIds: [],
    visitsDone: 0,
    visitsFailed: 0,
    akakceTourVisitedUrls: [],
    akakceTourCursor: "",
    akakceTourDone: 0,
    akakceTourFailed: 0,
    merchantLinkDone: 0,
    merchantLinkFailed: 0,
    merchantLinkCursor: "",
    merchantBackfillDone: 0,
    merchantBackfillFailed: 0,
    merchantBackfillCursor: "",
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  if (!state.deviceId) {
    state.deviceId = "phone-" + crypto.randomUUID().slice(0, 8);
    await chrome.storage.local.set({ deviceId: state.deviceId });
  }
  if (!state.clientId) {
    state.clientId = "chrome-ext-" + crypto.randomUUID().slice(0, 8);
    await chrome.storage.local.set({ clientId: state.clientId });
  }
  state.crawlerLimit = clampCrawlerLimit(state.crawlerLimit);
  return state;
}

async function maybeRun() {
  const state = await getState();
  const anyWorkActive = working || tourWorking || merchantLinkWorking || merchantBackfillWorking || activeFetches > 0;
  if (!anyWorkActive && state.workTabIds.length > 0) {
    await closeOrphanTabs(state.workTabIds);
    await chrome.storage.local.set({ workTabIds: [] });
  }
  if (state.quarantined) return;
  if (state.enabled && state.apiUrl && state.apiKey) {
    runLoop();
  }
  if (state.akakceTourEnabled && state.apiUrl && state.apiKey) {
    runAkakceTourLoop();
  }
  if (state.merchantLinkResolverEnabled && state.apiUrl && state.apiKey) {
    runMerchantLinkResolverLoop();
  }
  if (state.merchantLinkBackfillEnabled && state.apiUrl && state.apiKey) {
    runMerchantLinkBackfillLoop();
  }
}

async function closeOrphanTabs(tabIds) {
  for (const tabId of tabIds) {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
      // Tab is already gone.
    }
  }
}

async function runLoop() {
  if (working) return;
  working = true;
  await beginBackgroundWork();
  try {
    for (;;) {
      const state = await getState();
      if (state.quarantined || !state.enabled || !state.apiUrl || !state.apiKey) break;

      await sleep(randomBetween(state.jitterMinMs, state.jitterMaxMs));

      const fresh = await getState();
      if (fresh.quarantined || !fresh.enabled || !fresh.apiUrl || !fresh.apiKey) break;

      const limit = fresh.crawlerLimit;
      let claim;
      try {
        claim = await apiFetch(fresh, "POST", "/v1/visits/claim", {
          limit,
          client_id: fresh.clientId,
        });
      } catch (err) {
        await updateStats({ lastError: `claim failed: ${errMessage(err)}` });
        schedulePoll(fresh);
        break;
      }

      const visits = (claim && claim.visits) || [];
      if (visits.length === 0) {
        await updateStats({ lastError: "" });
        schedulePoll(fresh);
        break;
      }

      let quarantined = false;
      for (const visit of visits) {
        const current = await getState();
        if (current.quarantined || !current.enabled) break;
        const result = await processVisit(current, visit);
        await applyVisitResults([result]);
        if (result.quarantined) {
          quarantined = true;
          break;
        }
        if (visits.length > 1) {
          await sleep(randomBetween(current.jitterMinMs, current.jitterMaxMs));
        }
      }
      if (quarantined) break;
    }
  } finally {
    await endBackgroundWork();
    working = false;
    maybeRun();
  }
}

function schedulePoll(state) {
  const minMs = state?.pollEmptyMinMs ?? DEFAULT_POLL_EMPTY_MIN_MS;
  const maxMs = state?.pollEmptyMaxMs ?? DEFAULT_POLL_EMPTY_MAX_MS;
  setTimeout(maybeRun, randomBetween(minMs, maxMs));
}

/** @returns {Promise<{visitsDone?: number, visitsFailed?: number, lastUrl?: string, lastStatus?: string, lastError?: string}>} */
async function processVisit(state, visit) {
  const started = Date.now();
  let fetched = null;
  let fetchError = null;
  try {
    fetched = await fetchInTab(visit.target_url, { expandAkakcePrices: false });
  } catch (err) {
    fetchError = errMessage(err);
  }
  const durationMs = Date.now() - started;

  let bodyBytes = null;
  if (fetched) {
    bodyBytes = new TextEncoder().encode(fetched.html);
    if (bodyBytes.length > MAX_BODY_BYTES) {
      fetched = null;
      fetchError = `rendered body exceeds ${MAX_BODY_BYTES} bytes`;
    }
  }

  const httpStatus = fetched?.httpStatus ?? null;
  if (httpStatus === 403) {
    try {
      await apiFetch(state, "POST", `/v1/visits/${visit.page_id}/result`, {
        client_id: state.clientId,
        status: "done",
        http_status: 403,
        final_url: fetched?.url,
        content_type: fetched?.contentType,
        body_base64: bodyBytes ? bytesToBase64(bodyBytes) : undefined,
        duration_ms: durationMs,
      });
    } catch {
      // Best effort before quarantine.
    }
    await quarantineDevice(state, {
      reason: "http_403",
      url: visit.target_url,
      httpStatus: 403,
    });
    return {
      visitsFailed: 1,
      lastUrl: visit.target_url,
      lastStatus: "quarantined",
      lastError: "HTTP 403 — device paused",
      quarantined: true,
    };
  }

  try {
    if (fetched) {
      await apiFetch(state, "POST", `/v1/visits/${visit.page_id}/result`, {
        client_id: state.clientId,
        status: "done",
        http_status: httpStatus ?? undefined,
        final_url: fetched.url,
        content_type: fetched.contentType,
        body_base64: bytesToBase64(bodyBytes),
        duration_ms: durationMs,
      });
      return {
        visitsDone: 1,
        lastUrl: visit.target_url,
        lastStatus: "done",
        lastError: "",
      };
    }
    await apiFetch(state, "POST", `/v1/visits/${visit.page_id}/result`, {
      client_id: state.clientId,
      status: "failed",
      error: (fetchError || "fetch failed").slice(0, 500),
      duration_ms: durationMs,
    });
    return {
      visitsFailed: 1,
      lastUrl: visit.target_url,
      lastStatus: "failed",
      lastError: fetchError || "fetch failed",
    };
  } catch (err) {
    return {
      visitsFailed: 1,
      lastUrl: visit.target_url,
      lastStatus: "report-error",
      lastError: `result failed: ${errMessage(err)}`,
    };
  }
}

async function handleAkakcePageCapture(msg) {
  const state = await getState();
  if (!state.apiUrl || !state.apiKey) {
    return { ok: false, skipped: true, reason: "disabled" };
  }
  if (!state.enabled && !state.akakceTourEnabled) {
    return { ok: false, skipped: true, reason: "disabled" };
  }

  const bodyBytes = new TextEncoder().encode(msg.html);
  if (bodyBytes.length > MAX_BODY_BYTES) {
    return { ok: false, error: "rendered body exceeds size limit" };
  }

  try {
    const data = await apiFetch(state, "POST", "/v1/pages/capture", {
      url: msg.url,
      client_id: state.clientId,
      body_base64: bytesToBase64(bodyBytes),
      final_url: msg.finalUrl,
      http_status: 200,
      content_type: "text/html",
    });
    await markAkakceTourVisited(msg.url);
    return {
      ok: true,
      page_id: data.page_id,
      offers_saved: data.offers_saved ?? 0,
    };
  } catch (err) {
    const message = errMessage(err);
    if (message.includes("not found") || message.includes("HTTP 404")) {
      return { ok: false, reason: "not_found" };
    }
    throw err;
  }
}

async function runAkakceTourLoop() {
  if (tourWorking) return;
  if (working || merchantLinkWorking || merchantBackfillWorking) {
    scheduleTourPoll();
    return;
  }
  tourWorking = true;
  let tourTabId = null;
  await beginBackgroundWork();
  try {
    for (;;) {
      const state = await getState();
      if (state.quarantined || !state.akakceTourEnabled || !state.apiUrl || !state.apiKey) break;

      const nextUrl = await pickNextAkakceTourUrl(state);
      if (!nextUrl) {
        await updateAkakceTourStats({ lastError: "" });
        scheduleTourPoll();
        break;
      }

      const result = await processAkakceTourPage(state, nextUrl, tourTabId);
      if (result.tourTabId != null) {
        tourTabId = result.tourTabId;
      }
      if (result.quarantined) break;
      if (result.ok) {
        await markAkakceTourVisited(nextUrl);
        await updateAkakceTourStats({
          akakceTourDone: 1,
          lastUrl: nextUrl,
          lastStatus: "tour-done",
          lastError: "",
        });
      } else {
        await updateAkakceTourStats({
          akakceTourFailed: 1,
          lastUrl: nextUrl,
          lastStatus: "tour-failed",
          lastError: result.error || "tour failed",
        });
      }

      await sleep(TOUR_PAGE_DELAY_MS);
    }
  } finally {
    await closeTourWorkTab(tourTabId);
    await endBackgroundWork();
    tourWorking = false;
    maybeRun();
  }
}

async function closeTourWorkTab(tabId) {
  if (tabId == null) return;
  try {
    await chrome.tabs.remove(tabId);
  } catch {
    // Tab is already gone.
  }
  await removeWorkTab(tabId);
}

function scheduleTourPoll() {
  setTimeout(maybeRun, TOUR_POLL_EMPTY_MS);
}

async function runMerchantLinkResolverLoop() {
  if (merchantLinkWorking) return;
  if (working || tourWorking || merchantBackfillWorking) {
    scheduleMerchantPoll();
    return;
  }
  merchantLinkWorking = true;
  await beginBackgroundWork();
  try {
    for (;;) {
      const state = await getState();
      if (state.quarantined || !state.merchantLinkResolverEnabled || !state.apiUrl || !state.apiKey) break;

      const batch = await fetchMerchantLinkTargetBatch(state);
      if (!batch.items.length) {
        await updateMerchantLinkStats({ lastError: "" });
        scheduleMerchantPoll();
        break;
      }

      for (const target of batch.items) {
        const loopState = await getState();
        if (!loopState.merchantLinkResolverEnabled || !loopState.apiUrl || !loopState.apiKey) return;
        if (working || tourWorking || merchantBackfillWorking) {
          scheduleMerchantPoll();
          return;
        }

        const result = await processMerchantLinkTarget(loopState, target);
        if (result.ok) {
          await updateMerchantLinkStats({
            merchantLinkDone: 1,
            lastUrl: result.resolvedHref || target.merchant_href,
            lastStatus: "merchant-resolved",
            lastError: "",
          });
        } else {
          await updateMerchantLinkStats({
            merchantLinkFailed: 1,
            lastUrl: target.merchant_href,
            lastStatus: "merchant-failed",
            lastError: result.error || "merchant link resolve failed",
          });
        }

        await sleep(MERCHANT_PAGE_DELAY_MS);
      }

      await chrome.storage.local.set({
        merchantLinkCursor: batch.nextCursor || "",
      });
    }
  } finally {
    await endBackgroundWork();
    merchantLinkWorking = false;
    maybeRun();
  }
}

async function fetchMerchantLinkTargetBatch(state) {
  const cursor = state.merchantLinkCursor || "";
  const category = String(state.merchantLinkCategory || "").trim();
  let path =
    `/v1/akakce-hub/merchant-links/resolve-targets?limit=${MERCHANT_TARGETS_BATCH}` +
    (cursor ? `&cursor=${encodeURIComponent(cursor)}` : "");
  if (category) {
    path += `&akakce_category=${encodeURIComponent(category)}`;
  }
  const batch = await apiFetch(state, "GET", path);
  const items = (batch && batch.items) || [];
  if (!batch.next_cursor && items.length === 0) {
    await chrome.storage.local.set({ merchantLinkCursor: "" });
  }
  return { items, nextCursor: batch.next_cursor || "" };
}

function scheduleMerchantPoll() {
  setTimeout(maybeRun, MERCHANT_POLL_EMPTY_MS);
}

async function processMerchantLinkTarget(state, target) {
  try {
    const resolved = await resolveMerchantHrefInTab(target.merchant_href);
    const body = {
      merchant_href: target.merchant_href,
      resolved_href: cleanMerchantDestinationUrl(resolved.finalUrl),
      client_id: state.clientId,
    };
    if (resolved.n11ProductId) {
      body.platform_product_id = resolved.n11ProductId;
    }
    if (resolved.n11PimsId) {
      body.platform_model_id = resolved.n11PimsId;
    }
    await apiFetch(state, "POST", `/v1/akakce-hub/merchant-links/${target.id}/resolve`, body);
    return { ok: true, resolvedHref: resolved.finalUrl };
  } catch (err) {
    return { ok: false, error: errMessage(err) };
  }
}

function cleanMerchantDestinationUrl(url) {
  const raw = String(url || "").trim();
  if (!raw || /akakce\.com\/c/i.test(raw)) return raw;
  if (!isAllowedMerchantDestination(raw)) return raw;
  const q = raw.indexOf("?");
  if (q >= 0) return raw.slice(0, q);
  const h = raw.indexOf("#");
  if (h >= 0) return raw.slice(0, h);
  return raw;
}

function normalizeAkakceMerchantHref(href) {
  const raw = String(href || "").trim();
  if (raw.startsWith("/c/")) return "https://www.akakce.com" + raw;
  return raw;
}

function isAllowedMerchantDestination(url) {
  if (!url || url.startsWith("chrome-error://")) return false;
  return /:\/\/([^/]+\.)?n11\.com\//i.test(url) ||
    /:\/\/([^/]+\.)?trendyol\.com\//i.test(url) ||
    /:\/\/([^/]+\.)?hepsiburada\.com\//i.test(url);
}

async function resolveMerchantHrefInTab(akakceHref) {
  const targetUrl = normalizeAkakceMerchantHref(akakceHref);

  activeFetches++;

  const targetWindowId = await resolveTargetWindowId();
  const tab = await chrome.tabs.create({
    url: targetUrl,
    windowId: targetWindowId,
    active: false,
  });
  const tabId = tab.id;
  await addWorkTab(tabId);
  await keepUserTabInForeground();

  try {
    const finalUrl = await waitForMerchantRedirect(tabId, MERCHANT_RESOLVE_TIMEOUT_MS);
    if (!finalUrl || !isAllowedMerchantDestination(finalUrl)) {
      throw new Error("redirect did not reach n11, trendyol, or hepsiburada");
    }
    let n11ProductId = "";
    let n11PimsId = "";
    if (/:\/\/([^/]+\.)?n11\.com\//i.test(finalUrl)) {
      const n11Meta = await extractN11ProductMeta(tabId);
      n11ProductId = n11Meta.productId || "";
      n11PimsId = n11Meta.pimsId || "";
    }
    return { finalUrl, n11ProductId, n11PimsId };
  } finally {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
      // Tab was closed by the user or the browser.
    }
    await removeWorkTab(tabId);
    activeFetches--;
  }
}

async function extractN11ProductMeta(tabId) {
  const maxAttempts = 40;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: readN11ProductMetaFromPage,
      });
      if (result?.productId) {
        return result;
      }
    } catch {
      // Tab may still be loading.
    }
    await sleep(500);
  }
  return { productId: "", pimsId: "" };
}

function readN11ProductMetaFromPage() {
  const product = window.model?.product;
  if (product?.id) {
    return {
      productId: String(product.id),
      pimsId: product.defaultPimsId ? String(product.defaultPimsId) : "",
    };
  }

  const html = document.documentElement?.innerHTML || "";
  const marker = "window.model";
  const start = html.indexOf(marker);
  if (start < 0) return null;
  const brace = html.indexOf("{", start);
  if (brace < 0) return null;

  let depth = 0;
  for (let i = brace; i < html.length; i++) {
    const ch = html[i];
    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) {
        try {
          const model = JSON.parse(html.slice(brace, i + 1));
          const parsed = model?.product;
          if (!parsed?.id) return null;
          return {
            productId: String(parsed.id),
            pimsId: parsed.defaultPimsId ? String(parsed.defaultPimsId) : "",
          };
        } catch {
          return null;
        }
      }
    }
  }
  return null;
}

async function visitN11ProductForMeta(merchantUrl) {
  activeFetches++;

  const targetWindowId = await resolveTargetWindowId();
  const tab = await chrome.tabs.create({
    url: merchantUrl,
    windowId: targetWindowId,
    active: false,
  });
  const tabId = tab.id;
  await addWorkTab(tabId);
  await keepUserTabInForeground();

  try {
    await waitForTabLoad(tabId, TAB_LOAD_TIMEOUT_MS);
    await sleep(randomBetween(SETTLE_MIN_MS, SETTLE_MAX_MS));
    return await extractN11ProductMeta(tabId);
  } finally {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
      // Tab was closed by the user or the browser.
    }
    await removeWorkTab(tabId);
    activeFetches--;
  }
}

async function runMerchantLinkBackfillLoop() {
  if (merchantBackfillWorking) return;
  if (working || tourWorking || merchantLinkWorking) {
    scheduleMerchantBackfillPoll();
    return;
  }
  merchantBackfillWorking = true;
  await beginBackgroundWork();
  try {
    for (;;) {
      const state = await getState();
      if (state.quarantined || !state.merchantLinkBackfillEnabled || !state.apiUrl || !state.apiKey) break;

      const batch = await fetchMerchantLinkBackfillBatch(state);
      if (!batch.items.length) {
        await updateMerchantBackfillStats({ lastError: "" });
        scheduleMerchantBackfillPoll();
        break;
      }

      for (const target of batch.items) {
        const loopState = await getState();
        if (!loopState.merchantLinkBackfillEnabled || !loopState.apiUrl || !loopState.apiKey) return;
        if (working || tourWorking || merchantLinkWorking) {
          scheduleMerchantBackfillPoll();
          return;
        }

        const result = await processMerchantLinkBackfillTarget(loopState, target);
        if (result.ok) {
          await updateMerchantBackfillStats({
            merchantBackfillDone: 1,
            lastUrl: target.merchant_href,
            lastStatus: "backfill-done",
            lastError: "",
          });
        } else {
          await updateMerchantBackfillStats({
            merchantBackfillFailed: 1,
            lastUrl: target.merchant_href,
            lastStatus: "backfill-failed",
            lastError: result.error || "n11 backfill failed",
          });
        }

        await sleep(MERCHANT_PAGE_DELAY_MS);
      }

      await chrome.storage.local.set({
        merchantBackfillCursor: batch.nextCursor || "",
      });
    }
  } finally {
    await endBackgroundWork();
    merchantBackfillWorking = false;
    maybeRun();
  }
}

async function fetchMerchantLinkBackfillBatch(state) {
  const cursor = state.merchantBackfillCursor || "";
  const path =
    `/v1/akakce-hub/merchant-links/backfill-targets?limit=${MERCHANT_TARGETS_BATCH}` +
    (cursor ? `&cursor=${encodeURIComponent(cursor)}` : "");
  const batch = await apiFetch(state, "GET", path);
  const items = (batch && batch.items) || [];
  if (!batch.next_cursor && items.length === 0) {
    await chrome.storage.local.set({ merchantBackfillCursor: "" });
  }
  return { items, nextCursor: batch.next_cursor || "" };
}

function scheduleMerchantBackfillPoll() {
  setTimeout(maybeRun, MERCHANT_POLL_EMPTY_MS);
}

async function processMerchantLinkBackfillTarget(state, target) {
  try {
    const meta = await visitN11ProductForMeta(target.merchant_href);
    if (!meta.productId && !meta.pimsId) {
      throw new Error("n11 product meta not found");
    }
    await apiFetch(state, "POST", `/v1/akakce-hub/merchant-links/${target.id}/backfill-n11`, {
      merchant_href: target.merchant_href,
      client_id: state.clientId,
      platform_product_id: meta.productId || undefined,
      platform_model_id: meta.pimsId || undefined,
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: errMessage(err) };
  }
}

async function updateMerchantBackfillStats(delta) {
  const cur = await chrome.storage.local.get({
    merchantBackfillDone: 0,
    merchantBackfillFailed: 0,
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  await chrome.storage.local.set({
    merchantBackfillDone: cur.merchantBackfillDone + (delta.merchantBackfillDone || 0),
    merchantBackfillFailed: cur.merchantBackfillFailed + (delta.merchantBackfillFailed || 0),
    lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
    lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
    lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
    lastActivityAt: Date.now(),
  });
}

function waitForMerchantRedirect(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (fn, val) => {
      if (settled) return;
      settled = true;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.webNavigation.onCompleted.removeListener(onCompleted);
      clearTimeout(timer);
      fn(val);
    };

    const check = (url) => {
      if (!url || url.startsWith("chrome-error://")) return;
      if (isAllowedMerchantDestination(url)) {
        keepUserTabInForeground().catch(() => {});
        finish(resolve, url);
      }
    };

    const onUpdated = (id, changeInfo, tab) => {
      if (id !== tabId) return;
      if (changeInfo.url) check(changeInfo.url);
      if (changeInfo.status === "complete" && tab.url) check(tab.url);
    };

    const onCompleted = (details) => {
      if (details.tabId !== tabId || details.frameId !== 0) return;
      chrome.tabs.get(tabId).then((tab) => check(tab.url)).catch(() => {});
    };

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.webNavigation.onCompleted.addListener(onCompleted, {
      url: [{ schemes: ["http", "https"] }],
    });

    chrome.tabs.get(tabId).then((tab) => {
      if (tab.url) check(tab.url);
    }).catch(() => {});

    const timer = setTimeout(
      () => finish(reject, new Error(`merchant redirect timed out after ${Math.round(timeoutMs / 1000)}s`)),
      timeoutMs,
    );
  });
}

async function updateMerchantLinkStats(delta) {
  const cur = await chrome.storage.local.get({
    merchantLinkDone: 0,
    merchantLinkFailed: 0,
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  await chrome.storage.local.set({
    merchantLinkDone: cur.merchantLinkDone + (delta.merchantLinkDone || 0),
    merchantLinkFailed: cur.merchantLinkFailed + (delta.merchantLinkFailed || 0),
    lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
    lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
    lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
    lastActivityAt: Date.now(),
  });
}

async function pickNextAkakceTourUrl(state) {
  const visited = new Set(state.akakceTourVisitedUrls || []);
  let cursor = state.akakceTourCursor || "";

  for (let pass = 0; pass < 200; pass++) {
    const path =
      `/v1/pages/capture-targets?hostname=www.akakce.com&limit=${CAPTURE_TARGETS_BATCH}` +
      (cursor ? `&cursor=${encodeURIComponent(cursor)}` : "");
    const batch = await apiFetch(state, "GET", path);
    const items = (batch && batch.items) || [];

    for (const item of items) {
      const url = cleanAkakceUrl(item.target_url);
      if (!visited.has(url)) {
        return url;
      }
    }

    if (!batch.next_cursor) {
      await chrome.storage.local.set({ akakceTourCursor: "" });
      return null;
    }
    cursor = batch.next_cursor;
    await chrome.storage.local.set({ akakceTourCursor: cursor });
  }
  return null;
}

async function processAkakceTourPage(state, targetUrl, tourTabId) {
  await refreshUserFocusIfIdle();
  const started = Date.now();
  let tabId = tourTabId;
  try {
    const fetched = await fetchInTab(targetUrl, {
      expandAkakcePrices: true,
      reuseTabId: tourTabId,
      keepTabOpen: true,
    });
    tabId = fetched.tabId;
    if (fetched.httpStatus === 403) {
      await quarantineDevice(state, { reason: "http_403", url: targetUrl, httpStatus: 403 });
      return { ok: false, error: "HTTP 403 — device paused", tourTabId: tabId, quarantined: true };
    }
    const bodyBytes = new TextEncoder().encode(fetched.html);
    if (bodyBytes.length > MAX_BODY_BYTES) {
      return { ok: false, error: "rendered body exceeds size limit", tourTabId: tabId };
    }

    await apiFetch(state, "POST", "/v1/pages/capture", {
      url: cleanAkakceUrl(targetUrl),
      client_id: state.clientId,
      body_base64: bytesToBase64(bodyBytes),
      final_url: fetched.url,
      http_status: fetched.httpStatus ?? 200,
      content_type: fetched.contentType,
      duration_ms: Date.now() - started,
    });
    await markAkakceTourVisited(targetUrl);
    return { ok: true, tourTabId: tabId };
  } catch (err) {
    return { ok: false, error: errMessage(err), tourTabId: tabId };
  }
}

async function markAkakceTourVisited(url) {
  const clean = cleanAkakceUrl(url);
  const { akakceTourVisitedUrls = [] } = await chrome.storage.local.get({
    akakceTourVisitedUrls: [],
  });
  if (akakceTourVisitedUrls.includes(clean)) return;
  await chrome.storage.local.set({
    akakceTourVisitedUrls: [...akakceTourVisitedUrls, clean],
  });
}

async function updateAkakceTourStats(delta) {
  const cur = await chrome.storage.local.get({
    akakceTourDone: 0,
    akakceTourFailed: 0,
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  await chrome.storage.local.set({
    akakceTourDone: cur.akakceTourDone + (delta.akakceTourDone || 0),
    akakceTourFailed: cur.akakceTourFailed + (delta.akakceTourFailed || 0),
    lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
    lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
    lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
    lastActivityAt: Date.now(),
  });
}

function cleanAkakceUrl(raw) {
  return String(raw).split(/[?#]/)[0];
}

async function applyVisitResults(results) {
  let visitsDone = 0;
  let visitsFailed = 0;
  let lastUrl = "";
  let lastStatus = "";
  let lastError = "";
  for (const r of results) {
    visitsDone += r.visitsDone || 0;
    visitsFailed += r.visitsFailed || 0;
    if (r.lastUrl) {
      lastUrl = r.lastUrl;
      lastStatus = r.lastStatus || "";
      lastError = r.lastError || "";
    }
  }
  await updateStats({
    visitsDone,
    visitsFailed,
    lastUrl,
    lastStatus,
    lastError: visitsFailed > 0 && lastError ? lastError : "",
  });
  sendHeartbeat();
}

async function addWorkTab(tabId) {
  const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
  if (!workTabIds.includes(tabId)) {
    await chrome.storage.local.set({ workTabIds: [...workTabIds, tabId] });
  }
}

async function removeWorkTab(tabId) {
  const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
  await chrome.storage.local.set({
    workTabIds: workTabIds.filter((id) => id !== tabId),
  });
}

async function resolveTargetWindowId() {
  if (savedUserFocus?.windowId != null) {
    try {
      await chrome.windows.get(savedUserFocus.windowId);
      return savedUserFocus.windowId;
    } catch {
      // User closed the window while the extension was working.
    }
  }
  const win = await chrome.windows.getLastFocused();
  return win.id;
}

async function rememberUserFocus() {
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!activeTab?.windowId || activeTab.id == null) return null;
    return { windowId: activeTab.windowId, tabId: activeTab.id };
  } catch {
    return null;
  }
}

async function beginBackgroundWork() {
  if (backgroundWorkDepth === 0) {
    savedUserFocus = await rememberUserFocus();
    suppressWorkTabActivation = true;
  }
  backgroundWorkDepth++;
}

async function endBackgroundWork() {
  if (backgroundWorkDepth <= 0) return;
  backgroundWorkDepth--;
  if (backgroundWorkDepth === 0) {
    suppressWorkTabActivation = false;
    if (savedUserFocus) {
      await keepUserTabInForeground();
      savedUserFocus = null;
    }
  }
}

async function refreshUserFocusIfIdle() {
  if (!suppressWorkTabActivation) return;
  try {
    const win = await chrome.windows.getLastFocused();
    if (!win?.focused) return;
    const [activeTab] = await chrome.tabs.query({ active: true, windowId: win.id });
    if (!activeTab?.id) return;
    const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
    if (workTabIds.includes(activeTab.id)) return;
    savedUserFocus = { windowId: activeTab.windowId, tabId: activeTab.id };
  } catch {
    // Window or tab went away.
  }
}

async function restoreUserTab(snapshot) {
  if (!snapshot?.windowId || snapshot.tabId == null) return;
  try {
    const win = await chrome.windows.get(snapshot.windowId);
    // Never steal OS focus from another app. Only fix the active tab when the
    // user is already in this Chrome window.
    if (!win.focused) return;
    await chrome.tabs.update(snapshot.tabId, { active: true });
  } catch {
    // User closed the window or tab.
  }
}

async function keepUserTabInForeground() {
  if (!suppressWorkTabActivation || !savedUserFocus?.tabId) return;
  try {
    const win = await chrome.windows.get(savedUserFocus.windowId);
    if (!win.focused) return;
    const [activeTab] = await chrome.tabs.query({ active: true, windowId: savedUserFocus.windowId });
    if (!activeTab?.id || activeTab.id === savedUserFocus.tabId) return;
    const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
    if (!workTabIds.includes(activeTab.id)) return;
    await chrome.tabs.update(savedUserFocus.tabId, { active: true });
  } catch {
    // User closed the window or tab.
  }
}

async function fetchInTab(targetUrl, options = {}) {
  const expandAkakcePrices = options.expandAkakcePrices === true;
  const keepTabOpen = options.keepTabOpen === true;
  const reuseTabId = options.reuseTabId ?? null;

  activeFetches++;

  const targetWindowId = await resolveTargetWindowId();
  let tabId = reuseTabId;
  let previousUrl = null;

  if (tabId != null) {
    try {
      const existing = await chrome.tabs.get(tabId);
      previousUrl = existing.url || null;
      await chrome.tabs.update(tabId, { url: targetUrl, active: false });
    } catch {
      tabId = null;
      previousUrl = null;
    }
  }

  if (tabId == null) {
    const tab = await chrome.tabs.create({
      url: targetUrl,
      windowId: targetWindowId,
      active: false,
    });
    tabId = tab.id;
    await addWorkTab(tabId);
  }

  await keepUserTabInForeground();

  let httpStatus = null;
  const onCompleted = (details) => {
    if (details.tabId === tabId) httpStatus = details.statusCode;
  };
  chrome.webRequest.onCompleted.addListener(onCompleted, {
    urls: ["http://*/*", "https://*/*"],
    types: ["main_frame"],
  });

  try {
    await waitForTabLoad(tabId, TAB_LOAD_TIMEOUT_MS, { previousUrl });
    const settleMs = expandAkakcePrices
      ? randomBetween(AKAKCE_SETTLE_MIN_MS, AKAKCE_SETTLE_MAX_MS)
      : randomBetween(SETTLE_MIN_MS, SETTLE_MAX_MS);
    await sleep(settleMs);
    const captured = await captureRenderedPage(tabId, expandAkakcePrices);
    return { ...captured, httpStatus, tabId };
  } finally {
    chrome.webRequest.onCompleted.removeListener(onCompleted);
    if (!keepTabOpen) {
      try {
        await chrome.tabs.remove(tabId);
      } catch {
        // Tab was closed by the user or the browser.
      }
      await removeWorkTab(tabId);
    }
    activeFetches--;
  }
}

async function captureRenderedPage(tabId, expandAkakcePrices) {
  if (expandAkakcePrices) {
    await waitForAkakceDom(tabId, 25_000);
  }

  await executeScriptWithRetry(tabId, {
    func: (expand) => {
      window.__kodigenExpandAkakcePrices = expand;
    },
    args: [expandAkakcePrices],
  });
  await executeScriptWithRetry(tabId, { files: ["page-capture.js"] });

  const [injection] = await executeScriptWithRetry(tabId, {
    func: () => window.kodigenCaptureRenderedPage(),
  });
  if (!injection || injection.result == null) {
    throw new Error("could not read rendered page");
  }
  return injection.result;
}

async function executeScriptWithRetry(tabId, spec, maxAttempts = 6) {
  let lastErr;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      await assertTabInjectable(tabId);
      return await chrome.scripting.executeScript({
        target: { tabId, allFrames: false },
        ...spec,
      });
    } catch (err) {
      lastErr = err;
      if (!isRetryableScriptError(err) || attempt >= maxAttempts - 1) {
        throw err;
      }
      await sleep(400 + attempt * 300);
    }
  }
  throw lastErr;
}

function isRetryableScriptError(err) {
  const msg = errMessage(err).toLowerCase();
  return (
    msg.includes("frame with id") ||
    msg.includes("frame was removed") ||
    msg.includes("cannot access") ||
    msg.includes("no tab with id")
  );
}

async function assertTabInjectable(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (tab.discarded) {
    throw new Error("tab discarded before script injection");
  }
  if (tab.status !== "complete") {
    await waitForTabLoad(tabId, 15_000);
  }
  if (tab.url && tab.url.startsWith("chrome-error://")) {
    throw new Error("navigation failed (network or DNS error)");
  }
}

async function waitForAkakceDom(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      await assertTabInjectable(tabId);
      const [hit] = await chrome.scripting.executeScript({
        target: { tabId, allFrames: false },
        func: () => {
          const pl = document.getElementById("PL");
          if (pl && pl.querySelectorAll("li").length > 0) return true;
          return document.readyState === "complete" && Boolean(document.getElementById("PL_h"));
        },
      });
      if (hit?.result) return;
    } catch (err) {
      if (!isRetryableScriptError(err)) throw err;
    }
    await sleep(400);
  }
}

async function waitForTabLoad(tabId, timeoutMs, options = {}) {
  const previousUrl = options.previousUrl ?? null;
  const deadline = Date.now() + timeoutMs;

  if (previousUrl != null) {
    while (Date.now() < deadline) {
      let tab;
      try {
        tab = await chrome.tabs.get(tabId);
      } catch {
        throw new Error("tab closed before load finished");
      }
      if (tab.status === "loading" || tab.url !== previousUrl) break;
      await sleep(100);
    }
  }

  for (;;) {
    let tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch {
      throw new Error("tab closed before load finished");
    }
    if (tab.status === "complete") {
      if (tab.url && tab.url.startsWith("chrome-error://")) {
        throw new Error("navigation failed (network or DNS error)");
      }
      if (previousUrl != null && tab.url === previousUrl) {
        if (Date.now() > deadline) {
          throw new Error(`page load timed out after ${Math.round(timeoutMs / 1000)}s`);
        }
        await sleep(200);
        continue;
      }
      return;
    }
    if (Date.now() > deadline) {
      throw new Error(`page load timed out after ${Math.round(timeoutMs / 1000)}s`);
    }
    await sleep(500);
  }
}

async function apiFetch(state, method, path, body) {
  const res = await fetch(state.apiUrl + path, {
    method,
    headers: {
      Authorization: "ApiKey " + state.apiKey,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    // Non-JSON error body; fall back to status code below.
  }
  if (!res.ok) {
    const msg = data && data.error ? data.error : `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return data;
}

async function updateStats(delta) {
  const cur = await chrome.storage.local.get({
    visitsDone: 0,
    visitsFailed: 0,
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  await chrome.storage.local.set({
    visitsDone: cur.visitsDone + (delta.visitsDone || 0),
    visitsFailed: cur.visitsFailed + (delta.visitsFailed || 0),
    lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
    lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
    lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
    lastActivityAt: Date.now(),
  });
}

function bytesToBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function errMessage(err) {
  return err instanceof Error ? err.message : String(err);
}

function truncate(text, max) {
  const s = String(text || "");
  return s.length <= max ? s : s.slice(0, max - 1) + "…";
}

async function quarantineDevice(state, details) {
  await chrome.storage.local.set({
    quarantined: true,
    enabled: false,
    akakceTourEnabled: false,
    merchantLinkResolverEnabled: false,
    merchantLinkBackfillEnabled: false,
    quarantineReason: details.reason || "http_403",
    quarantinedAt: new Date().toISOString(),
    last403Url: details.url || "",
    lastError: `HTTP ${details.httpStatus || 403} — device paused`,
    lastStatus: "quarantined",
  });

  try {
    await apiFetch(state, "POST", "/v1/devices/quarantine", {
      device_id: state.deviceId,
      client_id: state.clientId,
      reason: details.reason || "http_403",
      url: details.url || "",
      http_status: details.httpStatus || 403,
    });
  } catch {
    // Local stop still applies.
  }

  const label = state.deviceLabel || state.deviceId;
  chrome.notifications.create(`quarantine-${state.deviceId}`, {
    type: "basic",
    iconUrl: "icon.png",
    title: "n11 Crawler Agent — device paused",
    message: `${label}: HTTP 403 on ${truncate(details.url || "page", 80)}`,
    priority: 2,
  });

  sendHeartbeat();
}

async function clearQuarantine() {
  await chrome.storage.local.set({
    quarantined: false,
    quarantineReason: "",
    quarantinedAt: "",
    last403Url: "",
    lastError: "",
  });
  sendHeartbeat();
}

async function sendHeartbeat() {
  const state = await getState();
  if (!state.apiUrl || !state.apiKey) return;
  try {
    const anyEnabled =
      (state.enabled || state.akakceTourEnabled || state.merchantLinkResolverEnabled || state.merchantLinkBackfillEnabled) &&
      !state.quarantined;
    const res = await apiFetch(state, "POST", "/v1/devices/heartbeat", {
      device_id: state.deviceId,
      device_label: state.deviceLabel,
      client_id: state.clientId,
      extension_version: EXTENSION_VERSION,
      enabled: anyEnabled,
      visits_done: state.visitsDone,
      visits_failed: state.visitsFailed,
      last_url: state.lastUrl,
    });
    if (res?.quarantined && !state.quarantined) {
      await chrome.storage.local.set({
        quarantined: true,
        enabled: false,
        akakceTourEnabled: false,
        merchantLinkResolverEnabled: false,
        merchantLinkBackfillEnabled: false,
        quarantineReason: res.device?.quarantine_reason || "server_quarantine",
        quarantinedAt: new Date().toISOString(),
      });
    }
  } catch {
    // Best effort.
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
