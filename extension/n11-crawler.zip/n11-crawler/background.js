importScripts("config.js");

// n11 Crawler external visit client (docs/API.md).
//
// While enabled, the work loop claims up to crawlerLimit 'api'-agent pages via
// POST /v1/visits/claim, opens each in an inactive browser tab (in parallel),
// captures the rendered DOM after the page settles, and reports outcomes via
// POST /v1/visits/{id}/result. crawlerLimit defaults to 1 (sequential behavior).
//
// MV3 service workers are ephemeral: a 30s watchdog alarm restarts the loop
// after the worker is suspended. Visit leases on the server make interrupted
// work reclaimable, so a mid-visit suspension is safe.

const POLL_EMPTY_MS = 15_000;
const TOUR_POLL_EMPTY_MS = 30_000;
const MERCHANT_POLL_EMPTY_MS = 30_000;
const MERCHANT_PAGE_DELAY_MS = 1_500;
const MERCHANT_RESOLVE_TIMEOUT_MS = 45_000;
const MERCHANT_TARGETS_BATCH = 20;
const TOUR_PAGE_DELAY_MS = 3_000;
const TAB_LOAD_TIMEOUT_MS = 60_000;
const SETTLE_MS = 2_000;
const AKAKCE_SETTLE_MS = 2_000;
const MAX_BODY_BYTES = 10 * 1024 * 1024;
const WATCHDOG_ALARM = "kodigen-watchdog";
const DEFAULT_CRAWLER_LIMIT = 1;
const MAX_CRAWLER_LIMIT = 100;
const CAPTURE_TARGETS_BATCH = 50;

let working = false;
let tourWorking = false;
let merchantLinkWorking = false;
let activeFetches = 0;
let backgroundWorkDepth = 0;
let savedUserFocus = null;
let suppressWorkTabActivation = false;

chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === WATCHDOG_ALARM) maybeRun();
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "enabled-changed") {
    if (msg.enabled) {
      maybeRun();
    }
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === "akakce-tour-changed") {
    if (msg.enabled) {
      maybeRun();
    }
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === "merchant-link-changed") {
    if (msg.enabled) {
      maybeRun();
    }
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === "akakce-page-capture") {
    handleAkakcePageCapture(msg)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, error: errMessage(err) }));
    return true;
  }
  return false;
});

maybeRun();

async function setup() {
  await migrateApiUrl();
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: 0.5 });
  chrome.tabs.onActivated.addListener(onWorkTabActivated);
  maybeRun();
}

async function onWorkTabActivated(activeInfo) {
  if (!suppressWorkTabActivation || !savedUserFocus?.tabId) return;
  if (activeInfo.tabId === savedUserFocus.tabId) return;

  const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
  if (!workTabIds.includes(activeInfo.tabId)) return;

  try {
    const win = await chrome.windows.get(activeInfo.windowId);
    if (!win.focused) return;
    await chrome.tabs.update(savedUserFocus.tabId, { active: true });
  } catch {
    // User closed the window or tab.
  }
}

async function migrateApiUrl() {
  const { apiUrl } = await chrome.storage.local.get({ apiUrl: "" });
  const legacy = new Set(["", "http://localhost:8080", "https://crawler.datascraper.net/api"]);
  if (legacy.has(apiUrl)) {
    await chrome.storage.local.set({ apiUrl: DEFAULT_API_URL });
  }
}

function clampCrawlerLimit(value) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n) || n < 1) return DEFAULT_CRAWLER_LIMIT;
  if (n > MAX_CRAWLER_LIMIT) return MAX_CRAWLER_LIMIT;
  return n;
}

async function getState() {
  const state = await chrome.storage.local.get({
    apiUrl: DEFAULT_API_URL,
    apiKey: "",
    enabled: false,
    akakceTourEnabled: false,
    merchantLinkResolverEnabled: false,
    clientId: "",
    crawlerLimit: DEFAULT_CRAWLER_LIMIT,
    workTabIds: [],
    akakceTourVisitedUrls: [],
    akakceTourCursor: "",
    akakceTourDone: 0,
    akakceTourFailed: 0,
    merchantLinkDone: 0,
    merchantLinkFailed: 0,
    merchantLinkCursor: "",
  });
  if (!state.clientId) {
    state.clientId = "chrome-ext-" + crypto.randomUUID().slice(0, 8);
    await chrome.storage.local.set({ clientId: state.clientId });
  }
  state.crawlerLimit = clampCrawlerLimit(state.crawlerLimit);
  return state;
}

async function maybeRun() {
  const state = await getState();
  const anyWorkActive = working || tourWorking || merchantLinkWorking || activeFetches > 0;
  if (!anyWorkActive && state.workTabIds.length > 0) {
    await closeOrphanTabs(state.workTabIds);
    await chrome.storage.local.set({ workTabIds: [] });
  }
  if (state.enabled && state.apiUrl && state.apiKey) {
    runLoop();
  }
  if (state.akakceTourEnabled && state.apiUrl && state.apiKey) {
    runAkakceTourLoop();
  }
  if (state.merchantLinkResolverEnabled && state.apiUrl && state.apiKey) {
    runMerchantLinkResolverLoop();
  }
}

async function closeOrphanTabs(tabIds) {
  for (const tabId of tabIds) {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
      // Tab is already gone.
    }
  }
}

async function runLoop() {
  if (working) return;
  working = true;
  await beginBackgroundWork();
  try {
    for (;;) {
      const state = await getState();
      if (!state.enabled || !state.apiUrl || !state.apiKey) break;

      const limit = state.crawlerLimit;
      let claim;
      try {
        claim = await apiFetch(state, "POST", "/v1/visits/claim", {
          limit,
          client_id: state.clientId,
        });
      } catch (err) {
        await updateStats({ lastError: `claim failed: ${errMessage(err)}` });
        schedulePoll();
        break;
      }

      const visits = (claim && claim.visits) || [];
      if (visits.length === 0) {
        await updateStats({ lastError: "" });
        schedulePoll();
        break;
      }

      const results = await Promise.all(
        visits.map((visit) => processVisit(state, visit)),
      );
      await applyVisitResults(results);
    }
  } finally {
    await endBackgroundWork();
    working = false;
    maybeRun();
  }
}

function schedulePoll() {
  setTimeout(maybeRun, POLL_EMPTY_MS);
}

/** @returns {Promise<{visitsDone?: number, visitsFailed?: number, lastUrl?: string, lastStatus?: string, lastError?: string}>} */
async function processVisit(state, visit) {
  const started = Date.now();
  let fetched = null;
  let fetchError = null;
  try {
    fetched = await fetchInTab(visit.target_url, { expandAkakcePrices: false });
  } catch (err) {
    fetchError = errMessage(err);
  }
  const durationMs = Date.now() - started;

  let bodyBytes = null;
  if (fetched) {
    bodyBytes = new TextEncoder().encode(fetched.html);
    if (bodyBytes.length > MAX_BODY_BYTES) {
      fetched = null;
      fetchError = `rendered body exceeds ${MAX_BODY_BYTES} bytes`;
    }
  }

  try {
    if (fetched) {
      await apiFetch(state, "POST", `/v1/visits/${visit.page_id}/result`, {
        client_id: state.clientId,
        status: "done",
        http_status: fetched.httpStatus ?? undefined,
        final_url: fetched.url,
        content_type: fetched.contentType,
        body_base64: bytesToBase64(bodyBytes),
        duration_ms: durationMs,
      });
      return {
        visitsDone: 1,
        lastUrl: visit.target_url,
        lastStatus: "done",
        lastError: "",
      };
    }
    await apiFetch(state, "POST", `/v1/visits/${visit.page_id}/result`, {
      client_id: state.clientId,
      status: "failed",
      error: (fetchError || "fetch failed").slice(0, 500),
      duration_ms: durationMs,
    });
    return {
      visitsFailed: 1,
      lastUrl: visit.target_url,
      lastStatus: "failed",
      lastError: fetchError || "fetch failed",
    };
  } catch (err) {
    return {
      visitsFailed: 1,
      lastUrl: visit.target_url,
      lastStatus: "report-error",
      lastError: `result failed: ${errMessage(err)}`,
    };
  }
}

async function handleAkakcePageCapture(msg) {
  const state = await getState();
  if (!state.apiUrl || !state.apiKey) {
    return { ok: false, skipped: true, reason: "disabled" };
  }
  if (!state.enabled && !state.akakceTourEnabled) {
    return { ok: false, skipped: true, reason: "disabled" };
  }

  const bodyBytes = new TextEncoder().encode(msg.html);
  if (bodyBytes.length > MAX_BODY_BYTES) {
    return { ok: false, error: "rendered body exceeds size limit" };
  }

  try {
    const data = await apiFetch(state, "POST", "/v1/pages/capture", {
      url: msg.url,
      client_id: state.clientId,
      body_base64: bytesToBase64(bodyBytes),
      final_url: msg.finalUrl,
      http_status: 200,
      content_type: "text/html",
    });
    await markAkakceTourVisited(msg.url);
    return {
      ok: true,
      page_id: data.page_id,
      offers_saved: data.offers_saved ?? 0,
    };
  } catch (err) {
    const message = errMessage(err);
    if (message.includes("not found") || message.includes("HTTP 404")) {
      return { ok: false, reason: "not_found" };
    }
    throw err;
  }
}

async function runAkakceTourLoop() {
  if (tourWorking) return;
  if (working || merchantLinkWorking) {
    scheduleTourPoll();
    return;
  }
  tourWorking = true;
  let tourTabId = null;
  await beginBackgroundWork();
  try {
    for (;;) {
      const state = await getState();
      if (!state.akakceTourEnabled || !state.apiUrl || !state.apiKey) break;

      const nextUrl = await pickNextAkakceTourUrl(state);
      if (!nextUrl) {
        await updateAkakceTourStats({ lastError: "" });
        scheduleTourPoll();
        break;
      }

      const result = await processAkakceTourPage(state, nextUrl, tourTabId);
      if (result.tourTabId != null) {
        tourTabId = result.tourTabId;
      }
      if (result.ok) {
        await markAkakceTourVisited(nextUrl);
        await updateAkakceTourStats({
          akakceTourDone: 1,
          lastUrl: nextUrl,
          lastStatus: "tour-done",
          lastError: "",
        });
      } else {
        await updateAkakceTourStats({
          akakceTourFailed: 1,
          lastUrl: nextUrl,
          lastStatus: "tour-failed",
          lastError: result.error || "tour failed",
        });
      }

      await sleep(TOUR_PAGE_DELAY_MS);
    }
  } finally {
    await closeTourWorkTab(tourTabId);
    await endBackgroundWork();
    tourWorking = false;
    maybeRun();
  }
}

async function closeTourWorkTab(tabId) {
  if (tabId == null) return;
  try {
    await chrome.tabs.remove(tabId);
  } catch {
    // Tab is already gone.
  }
  await removeWorkTab(tabId);
}

function scheduleTourPoll() {
  setTimeout(maybeRun, TOUR_POLL_EMPTY_MS);
}

async function runMerchantLinkResolverLoop() {
  if (merchantLinkWorking) return;
  if (working || tourWorking) {
    scheduleMerchantPoll();
    return;
  }
  merchantLinkWorking = true;
  await beginBackgroundWork();
  try {
    for (;;) {
      const state = await getState();
      if (!state.merchantLinkResolverEnabled || !state.apiUrl || !state.apiKey) break;

      const batch = await fetchMerchantLinkTargetBatch(state);
      if (!batch.items.length) {
        await updateMerchantLinkStats({ lastError: "" });
        scheduleMerchantPoll();
        break;
      }

      for (const target of batch.items) {
        const loopState = await getState();
        if (!loopState.merchantLinkResolverEnabled || !loopState.apiUrl || !loopState.apiKey) return;
        if (working || tourWorking) {
          scheduleMerchantPoll();
          return;
        }

        const result = await processMerchantLinkTarget(loopState, target);
        if (result.ok) {
          await updateMerchantLinkStats({
            merchantLinkDone: 1,
            lastUrl: result.resolvedHref || target.merchant_href,
            lastStatus: "merchant-resolved",
            lastError: "",
          });
        } else {
          await updateMerchantLinkStats({
            merchantLinkFailed: 1,
            lastUrl: target.merchant_href,
            lastStatus: "merchant-failed",
            lastError: result.error || "merchant link resolve failed",
          });
        }

        await sleep(MERCHANT_PAGE_DELAY_MS);
      }

      await chrome.storage.local.set({
        merchantLinkCursor: batch.nextCursor || "",
      });
    }
  } finally {
    await endBackgroundWork();
    merchantLinkWorking = false;
    maybeRun();
  }
}

async function fetchMerchantLinkTargetBatch(state) {
  const cursor = state.merchantLinkCursor || "";
  const path =
    `/v1/akakce-hub/merchant-links/resolve-targets?limit=${MERCHANT_TARGETS_BATCH}` +
    (cursor ? `&cursor=${encodeURIComponent(cursor)}` : "");
  const batch = await apiFetch(state, "GET", path);
  const items = (batch && batch.items) || [];
  if (!batch.next_cursor && items.length === 0) {
    await chrome.storage.local.set({ merchantLinkCursor: "" });
  }
  return { items, nextCursor: batch.next_cursor || "" };
}

function scheduleMerchantPoll() {
  setTimeout(maybeRun, MERCHANT_POLL_EMPTY_MS);
}

async function processMerchantLinkTarget(state, target) {
  try {
    const resolved = await resolveMerchantHrefInTab(target.merchant_href);
    const body = {
      merchant_href: target.merchant_href,
      resolved_href: resolved.finalUrl,
      client_id: state.clientId,
    };
    if (resolved.n11ProductId) {
      body.platform_product_id = resolved.n11ProductId;
    }
    if (resolved.n11PimsId) {
      body.platform_model_id = resolved.n11PimsId;
    }
    await apiFetch(state, "POST", `/v1/akakce-hub/merchant-links/${target.id}/resolve`, body);
    return { ok: true, resolvedHref: resolved.finalUrl };
  } catch (err) {
    return { ok: false, error: errMessage(err) };
  }
}

function normalizeAkakceMerchantHref(href) {
  const raw = String(href || "").trim();
  if (raw.startsWith("/c/")) return "https://www.akakce.com" + raw;
  return raw;
}

function isAllowedMerchantDestination(url) {
  if (!url || url.startsWith("chrome-error://")) return false;
  return /:\/\/([^/]+\.)?n11\.com\//i.test(url) ||
    /:\/\/([^/]+\.)?trendyol\.com\//i.test(url) ||
    /:\/\/([^/]+\.)?hepsiburada\.com\//i.test(url);
}

async function resolveMerchantHrefInTab(akakceHref) {
  const targetUrl = normalizeAkakceMerchantHref(akakceHref);

  activeFetches++;

  const targetWindowId = await resolveTargetWindowId();
  const tab = await chrome.tabs.create({
    url: targetUrl,
    windowId: targetWindowId,
    active: false,
  });
  const tabId = tab.id;
  await addWorkTab(tabId);
  await keepUserTabInForeground();

  try {
    const finalUrl = await waitForMerchantRedirect(tabId, MERCHANT_RESOLVE_TIMEOUT_MS);
    if (!finalUrl || !isAllowedMerchantDestination(finalUrl)) {
      throw new Error("redirect did not reach n11, trendyol, or hepsiburada");
    }
    let n11ProductId = "";
    let n11PimsId = "";
    if (/:\/\/([^/]+\.)?n11\.com\//i.test(finalUrl)) {
      const n11Meta = await extractN11ProductMeta(tabId);
      n11ProductId = n11Meta.productId || "";
      n11PimsId = n11Meta.pimsId || "";
    }
    return { finalUrl, n11ProductId, n11PimsId };
  } finally {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
      // Tab was closed by the user or the browser.
    }
    await removeWorkTab(tabId);
    activeFetches--;
  }
}

async function extractN11ProductMeta(tabId) {
  const maxAttempts = 20;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const product = window.model?.product;
          if (!product || !product.id) return null;
          return {
            productId: String(product.id),
            pimsId: product.defaultPimsId ? String(product.defaultPimsId) : "",
          };
        },
      });
      if (result?.productId) {
        return result;
      }
    } catch {
      // Tab may still be loading.
    }
    await sleep(500);
  }
  return { productId: "", pimsId: "" };
}

function waitForMerchantRedirect(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (fn, val) => {
      if (settled) return;
      settled = true;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.webNavigation.onCompleted.removeListener(onCompleted);
      clearTimeout(timer);
      fn(val);
    };

    const check = (url) => {
      if (!url || url.startsWith("chrome-error://")) return;
      if (isAllowedMerchantDestination(url)) {
        keepUserTabInForeground().catch(() => {});
        finish(resolve, url);
      }
    };

    const onUpdated = (id, changeInfo, tab) => {
      if (id !== tabId) return;
      if (changeInfo.url) check(changeInfo.url);
      if (changeInfo.status === "complete" && tab.url) check(tab.url);
    };

    const onCompleted = (details) => {
      if (details.tabId !== tabId || details.frameId !== 0) return;
      chrome.tabs.get(tabId).then((tab) => check(tab.url)).catch(() => {});
    };

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.webNavigation.onCompleted.addListener(onCompleted, {
      url: [{ schemes: ["http", "https"] }],
    });

    chrome.tabs.get(tabId).then((tab) => {
      if (tab.url) check(tab.url);
    }).catch(() => {});

    const timer = setTimeout(
      () => finish(reject, new Error(`merchant redirect timed out after ${Math.round(timeoutMs / 1000)}s`)),
      timeoutMs,
    );
  });
}

async function updateMerchantLinkStats(delta) {
  const cur = await chrome.storage.local.get({
    merchantLinkDone: 0,
    merchantLinkFailed: 0,
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  await chrome.storage.local.set({
    merchantLinkDone: cur.merchantLinkDone + (delta.merchantLinkDone || 0),
    merchantLinkFailed: cur.merchantLinkFailed + (delta.merchantLinkFailed || 0),
    lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
    lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
    lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
    lastActivityAt: Date.now(),
  });
}

async function pickNextAkakceTourUrl(state) {
  const visited = new Set(state.akakceTourVisitedUrls || []);
  let cursor = state.akakceTourCursor || "";

  for (let pass = 0; pass < 200; pass++) {
    const path =
      `/v1/pages/capture-targets?hostname=www.akakce.com&limit=${CAPTURE_TARGETS_BATCH}` +
      (cursor ? `&cursor=${encodeURIComponent(cursor)}` : "");
    const batch = await apiFetch(state, "GET", path);
    const items = (batch && batch.items) || [];

    for (const item of items) {
      const url = cleanAkakceUrl(item.target_url);
      if (!visited.has(url)) {
        return url;
      }
    }

    if (!batch.next_cursor) {
      await chrome.storage.local.set({ akakceTourCursor: "" });
      return null;
    }
    cursor = batch.next_cursor;
    await chrome.storage.local.set({ akakceTourCursor: cursor });
  }
  return null;
}

async function processAkakceTourPage(state, targetUrl, tourTabId) {
  await refreshUserFocusIfIdle();
  const started = Date.now();
  let tabId = tourTabId;
  try {
    const fetched = await fetchInTab(targetUrl, {
      expandAkakcePrices: true,
      reuseTabId: tourTabId,
      keepTabOpen: true,
    });
    tabId = fetched.tabId;
    const bodyBytes = new TextEncoder().encode(fetched.html);
    if (bodyBytes.length > MAX_BODY_BYTES) {
      return { ok: false, error: "rendered body exceeds size limit", tourTabId: tabId };
    }

    await apiFetch(state, "POST", "/v1/pages/capture", {
      url: cleanAkakceUrl(targetUrl),
      client_id: state.clientId,
      body_base64: bytesToBase64(bodyBytes),
      final_url: fetched.url,
      http_status: fetched.httpStatus ?? 200,
      content_type: fetched.contentType,
      duration_ms: Date.now() - started,
    });
    await markAkakceTourVisited(targetUrl);
    return { ok: true, tourTabId: tabId };
  } catch (err) {
    return { ok: false, error: errMessage(err), tourTabId: tabId };
  }
}

async function markAkakceTourVisited(url) {
  const clean = cleanAkakceUrl(url);
  const { akakceTourVisitedUrls = [] } = await chrome.storage.local.get({
    akakceTourVisitedUrls: [],
  });
  if (akakceTourVisitedUrls.includes(clean)) return;
  await chrome.storage.local.set({
    akakceTourVisitedUrls: [...akakceTourVisitedUrls, clean],
  });
}

async function updateAkakceTourStats(delta) {
  const cur = await chrome.storage.local.get({
    akakceTourDone: 0,
    akakceTourFailed: 0,
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  await chrome.storage.local.set({
    akakceTourDone: cur.akakceTourDone + (delta.akakceTourDone || 0),
    akakceTourFailed: cur.akakceTourFailed + (delta.akakceTourFailed || 0),
    lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
    lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
    lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
    lastActivityAt: Date.now(),
  });
}

function cleanAkakceUrl(raw) {
  return String(raw).split(/[?#]/)[0];
}

async function applyVisitResults(results) {
  let visitsDone = 0;
  let visitsFailed = 0;
  let lastUrl = "";
  let lastStatus = "";
  let lastError = "";
  for (const r of results) {
    visitsDone += r.visitsDone || 0;
    visitsFailed += r.visitsFailed || 0;
    if (r.lastUrl) {
      lastUrl = r.lastUrl;
      lastStatus = r.lastStatus || "";
      lastError = r.lastError || "";
    }
  }
  await updateStats({
    visitsDone,
    visitsFailed,
    lastUrl,
    lastStatus,
    lastError: visitsFailed > 0 && lastError ? lastError : "",
  });
}

async function addWorkTab(tabId) {
  const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
  if (!workTabIds.includes(tabId)) {
    await chrome.storage.local.set({ workTabIds: [...workTabIds, tabId] });
  }
}

async function removeWorkTab(tabId) {
  const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
  await chrome.storage.local.set({
    workTabIds: workTabIds.filter((id) => id !== tabId),
  });
}

async function resolveTargetWindowId() {
  if (savedUserFocus?.windowId != null) {
    try {
      await chrome.windows.get(savedUserFocus.windowId);
      return savedUserFocus.windowId;
    } catch {
      // User closed the window while the extension was working.
    }
  }
  const win = await chrome.windows.getLastFocused();
  return win.id;
}

async function rememberUserFocus() {
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!activeTab?.windowId || activeTab.id == null) return null;
    return { windowId: activeTab.windowId, tabId: activeTab.id };
  } catch {
    return null;
  }
}

async function beginBackgroundWork() {
  if (backgroundWorkDepth === 0) {
    savedUserFocus = await rememberUserFocus();
    suppressWorkTabActivation = true;
  }
  backgroundWorkDepth++;
}

async function endBackgroundWork() {
  if (backgroundWorkDepth <= 0) return;
  backgroundWorkDepth--;
  if (backgroundWorkDepth === 0) {
    suppressWorkTabActivation = false;
    if (savedUserFocus) {
      await keepUserTabInForeground();
      savedUserFocus = null;
    }
  }
}

async function refreshUserFocusIfIdle() {
  if (!suppressWorkTabActivation) return;
  try {
    const win = await chrome.windows.getLastFocused();
    if (!win?.focused) return;
    const [activeTab] = await chrome.tabs.query({ active: true, windowId: win.id });
    if (!activeTab?.id) return;
    const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
    if (workTabIds.includes(activeTab.id)) return;
    savedUserFocus = { windowId: activeTab.windowId, tabId: activeTab.id };
  } catch {
    // Window or tab went away.
  }
}

async function restoreUserTab(snapshot) {
  if (!snapshot?.windowId || snapshot.tabId == null) return;
  try {
    const win = await chrome.windows.get(snapshot.windowId);
    // Never steal OS focus from another app. Only fix the active tab when the
    // user is already in this Chrome window.
    if (!win.focused) return;
    await chrome.tabs.update(snapshot.tabId, { active: true });
  } catch {
    // User closed the window or tab.
  }
}

async function keepUserTabInForeground() {
  if (!suppressWorkTabActivation || !savedUserFocus?.tabId) return;
  try {
    const win = await chrome.windows.get(savedUserFocus.windowId);
    if (!win.focused) return;
    const [activeTab] = await chrome.tabs.query({ active: true, windowId: savedUserFocus.windowId });
    if (!activeTab?.id || activeTab.id === savedUserFocus.tabId) return;
    const { workTabIds = [] } = await chrome.storage.local.get({ workTabIds: [] });
    if (!workTabIds.includes(activeTab.id)) return;
    await chrome.tabs.update(savedUserFocus.tabId, { active: true });
  } catch {
    // User closed the window or tab.
  }
}

async function fetchInTab(targetUrl, options = {}) {
  const expandAkakcePrices = options.expandAkakcePrices === true;
  const keepTabOpen = options.keepTabOpen === true;
  const reuseTabId = options.reuseTabId ?? null;

  activeFetches++;

  const targetWindowId = await resolveTargetWindowId();
  let tabId = reuseTabId;
  let previousUrl = null;

  if (tabId != null) {
    try {
      const existing = await chrome.tabs.get(tabId);
      previousUrl = existing.url || null;
      await chrome.tabs.update(tabId, { url: targetUrl, active: false });
    } catch {
      tabId = null;
      previousUrl = null;
    }
  }

  if (tabId == null) {
    const tab = await chrome.tabs.create({
      url: targetUrl,
      windowId: targetWindowId,
      active: false,
    });
    tabId = tab.id;
    await addWorkTab(tabId);
  }

  await keepUserTabInForeground();

  let httpStatus = null;
  const onCompleted = (details) => {
    if (details.tabId === tabId) httpStatus = details.statusCode;
  };
  chrome.webRequest.onCompleted.addListener(onCompleted, {
    urls: ["http://*/*", "https://*/*"],
    types: ["main_frame"],
  });

  try {
    await waitForTabLoad(tabId, TAB_LOAD_TIMEOUT_MS, { previousUrl });
    await sleep(expandAkakcePrices ? AKAKCE_SETTLE_MS : SETTLE_MS);
    const captured = await captureRenderedPage(tabId, expandAkakcePrices);
    return { ...captured, httpStatus, tabId };
  } finally {
    chrome.webRequest.onCompleted.removeListener(onCompleted);
    if (!keepTabOpen) {
      try {
        await chrome.tabs.remove(tabId);
      } catch {
        // Tab was closed by the user or the browser.
      }
      await removeWorkTab(tabId);
    }
    activeFetches--;
  }
}

async function captureRenderedPage(tabId, expandAkakcePrices) {
  if (expandAkakcePrices) {
    await waitForAkakceDom(tabId, 25_000);
  }

  await executeScriptWithRetry(tabId, {
    func: (expand) => {
      window.__kodigenExpandAkakcePrices = expand;
    },
    args: [expandAkakcePrices],
  });
  await executeScriptWithRetry(tabId, { files: ["page-capture.js"] });

  const [injection] = await executeScriptWithRetry(tabId, {
    func: () => window.kodigenCaptureRenderedPage(),
  });
  if (!injection || injection.result == null) {
    throw new Error("could not read rendered page");
  }
  return injection.result;
}

async function executeScriptWithRetry(tabId, spec, maxAttempts = 6) {
  let lastErr;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      await assertTabInjectable(tabId);
      return await chrome.scripting.executeScript({
        target: { tabId, allFrames: false },
        ...spec,
      });
    } catch (err) {
      lastErr = err;
      if (!isRetryableScriptError(err) || attempt >= maxAttempts - 1) {
        throw err;
      }
      await sleep(400 + attempt * 300);
    }
  }
  throw lastErr;
}

function isRetryableScriptError(err) {
  const msg = errMessage(err).toLowerCase();
  return (
    msg.includes("frame with id") ||
    msg.includes("frame was removed") ||
    msg.includes("cannot access") ||
    msg.includes("no tab with id")
  );
}

async function assertTabInjectable(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (tab.discarded) {
    throw new Error("tab discarded before script injection");
  }
  if (tab.status !== "complete") {
    await waitForTabLoad(tabId, 15_000);
  }
  if (tab.url && tab.url.startsWith("chrome-error://")) {
    throw new Error("navigation failed (network or DNS error)");
  }
}

async function waitForAkakceDom(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      await assertTabInjectable(tabId);
      const [hit] = await chrome.scripting.executeScript({
        target: { tabId, allFrames: false },
        func: () => {
          const pl = document.getElementById("PL");
          if (pl && pl.querySelectorAll("li").length > 0) return true;
          return document.readyState === "complete" && Boolean(document.getElementById("PL_h"));
        },
      });
      if (hit?.result) return;
    } catch (err) {
      if (!isRetryableScriptError(err)) throw err;
    }
    await sleep(400);
  }
}

async function waitForTabLoad(tabId, timeoutMs, options = {}) {
  const previousUrl = options.previousUrl ?? null;
  const deadline = Date.now() + timeoutMs;

  if (previousUrl != null) {
    while (Date.now() < deadline) {
      let tab;
      try {
        tab = await chrome.tabs.get(tabId);
      } catch {
        throw new Error("tab closed before load finished");
      }
      if (tab.status === "loading" || tab.url !== previousUrl) break;
      await sleep(100);
    }
  }

  for (;;) {
    let tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch {
      throw new Error("tab closed before load finished");
    }
    if (tab.status === "complete") {
      if (tab.url && tab.url.startsWith("chrome-error://")) {
        throw new Error("navigation failed (network or DNS error)");
      }
      if (previousUrl != null && tab.url === previousUrl) {
        if (Date.now() > deadline) {
          throw new Error(`page load timed out after ${Math.round(timeoutMs / 1000)}s`);
        }
        await sleep(200);
        continue;
      }
      return;
    }
    if (Date.now() > deadline) {
      throw new Error(`page load timed out after ${Math.round(timeoutMs / 1000)}s`);
    }
    await sleep(500);
  }
}

async function apiFetch(state, method, path, body) {
  const res = await fetch(state.apiUrl + path, {
    method,
    headers: {
      Authorization: "ApiKey " + state.apiKey,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    // Non-JSON error body; fall back to status code below.
  }
  if (!res.ok) {
    const msg = data && data.error ? data.error : `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return data;
}

async function updateStats(delta) {
  const cur = await chrome.storage.local.get({
    visitsDone: 0,
    visitsFailed: 0,
    lastUrl: "",
    lastStatus: "",
    lastError: "",
  });
  await chrome.storage.local.set({
    visitsDone: cur.visitsDone + (delta.visitsDone || 0),
    visitsFailed: cur.visitsFailed + (delta.visitsFailed || 0),
    lastUrl: delta.lastUrl !== undefined ? delta.lastUrl : cur.lastUrl,
    lastStatus: delta.lastStatus !== undefined ? delta.lastStatus : cur.lastStatus,
    lastError: delta.lastError !== undefined ? delta.lastError : cur.lastError,
    lastActivityAt: Date.now(),
  });
}

function bytesToBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function errMessage(err) {
  return err instanceof Error ? err.message : String(err);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
