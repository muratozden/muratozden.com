// Popup: main on/off switch + Akakce tour + Settings (API URL / key).

const DEFAULT_CRAWLER_LIMIT = 1;
const MAX_CRAWLER_LIMIT = 100;

function clampCrawlerLimit(value) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n) || n < 1) return DEFAULT_CRAWLER_LIMIT;
  if (n > MAX_CRAWLER_LIMIT) return MAX_CRAWLER_LIMIT;
  return n;
}

const els = {
  headerTitle: document.getElementById("header-title"),
  btnSettings: document.getElementById("btn-settings"),
  viewMain: document.getElementById("view-main"),
  viewSettings: document.getElementById("view-settings"),
  settingsApiUrl: document.getElementById("settings-api-url"),
  settingsApiKey: document.getElementById("settings-api-key"),
  settingsCrawlerLimit: document.getElementById("settings-crawler-limit"),
  settingsKeyHint: document.getElementById("settings-key-hint"),
  settingsError: document.getElementById("settings-error"),
  btnSave: document.getElementById("btn-save"),
  btnCancel: document.getElementById("btn-cancel"),
  toggle: document.getElementById("toggle-enabled"),
  toggleTour: document.getElementById("toggle-akakce-tour"),
  toggleMerchant: document.getElementById("toggle-merchant-links"),
  switchLabel: document.getElementById("switch-label"),
  tourSwitchLabel: document.getElementById("tour-switch-label"),
  merchantSwitchLabel: document.getElementById("merchant-switch-label"),
  statusDot: document.getElementById("status-dot"),
  statDone: document.getElementById("stat-done"),
  statFailed: document.getElementById("stat-failed"),
  tourStats: document.getElementById("tour-stats"),
  merchantStats: document.getElementById("merchant-stats"),
  statTourDone: document.getElementById("stat-tour-done"),
  statTourVisited: document.getElementById("stat-tour-visited"),
  statMerchantDone: document.getElementById("stat-merchant-done"),
  statMerchantFailed: document.getElementById("stat-merchant-failed"),
  lastUrl: document.getElementById("last-url"),
  mainError: document.getElementById("main-error"),
};

/** True when the user opened Settings from the main screen (Cancel returns there). */
let settingsFromMain = false;

init();

async function init() {
  const state = await loadState();

  if (state.apiKey) {
    showMain(state);
  } else {
    els.settingsApiUrl.value = state.apiUrl || DEFAULT_API_URL;
    els.settingsApiKey.value = "";
    els.settingsCrawlerLimit.value = String(DEFAULT_CRAWLER_LIMIT);
    showSettings({ firstRun: true });
  }

  els.btnSettings.addEventListener("click", () => openSettings());
  els.btnSave.addEventListener("click", onSave);
  els.btnCancel.addEventListener("click", onCancel);
  els.toggle.addEventListener("change", onToggle);
  els.toggleTour.addEventListener("change", onTourToggle);
  els.toggleMerchant.addEventListener("change", onMerchantToggle);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.visitsDone) els.statDone.textContent = changes.visitsDone.newValue;
    if (changes.visitsFailed) els.statFailed.textContent = changes.visitsFailed.newValue;
    if (changes.lastUrl) setLastUrl(changes.lastUrl.newValue);
    if (changes.lastError) setMainError(changes.lastError.newValue);
    if (changes.akakceTourDone) els.statTourDone.textContent = changes.akakceTourDone.newValue;
    if (changes.akakceTourVisitedUrls) {
      els.statTourVisited.textContent = (changes.akakceTourVisitedUrls.newValue || []).length;
    }
    if (changes.merchantLinkDone) els.statMerchantDone.textContent = changes.merchantLinkDone.newValue;
    if (changes.merchantLinkFailed) els.statMerchantFailed.textContent = changes.merchantLinkFailed.newValue;
    if (changes.enabled || changes.akakceTourEnabled || changes.merchantLinkResolverEnabled) {
      renderStatusDot(
        changes.enabled?.newValue,
        changes.akakceTourEnabled?.newValue,
        changes.merchantLinkResolverEnabled?.newValue,
      );
    }
  });
}

async function loadState() {
  return chrome.storage.local.get({
    apiUrl: DEFAULT_API_URL,
    apiKey: "",
    enabled: false,
    akakceTourEnabled: false,
    merchantLinkResolverEnabled: false,
    visitsDone: 0,
    visitsFailed: 0,
    akakceTourDone: 0,
    akakceTourVisitedUrls: [],
    merchantLinkDone: 0,
    merchantLinkFailed: 0,
    lastUrl: "",
    lastError: "",
    crawlerLimit: DEFAULT_CRAWLER_LIMIT,
  });
}

function showMain(state) {
  settingsFromMain = false;
  els.viewMain.hidden = false;
  els.viewSettings.hidden = true;
  els.btnSettings.hidden = false;
  els.headerTitle.textContent = "n11 Crawler Agent";
  els.toggle.checked = state.enabled;
  els.toggleTour.checked = state.akakceTourEnabled;
  els.toggleMerchant.checked = state.merchantLinkResolverEnabled;
  renderEnabled(state.enabled);
  renderTourEnabled(state.akakceTourEnabled);
  renderMerchantEnabled(state.merchantLinkResolverEnabled);
  renderStatusDot(state.enabled, state.akakceTourEnabled, state.merchantLinkResolverEnabled);
  els.statDone.textContent = state.visitsDone;
  els.statFailed.textContent = state.visitsFailed;
  els.statTourDone.textContent = state.akakceTourDone;
  els.statTourVisited.textContent = (state.akakceTourVisitedUrls || []).length;
  els.statMerchantDone.textContent = state.merchantLinkDone;
  els.statMerchantFailed.textContent = state.merchantLinkFailed;
  els.tourStats.hidden = !state.akakceTourEnabled;
  els.merchantStats.hidden = !state.merchantLinkResolverEnabled;
  setLastUrl(state.lastUrl);
  setMainError(state.lastError);
}

function showSettings({ firstRun }) {
  els.viewMain.hidden = true;
  els.viewSettings.hidden = false;
  els.btnSettings.hidden = true;
  els.headerTitle.textContent = "Settings";
  els.settingsError.hidden = true;
  els.btnCancel.hidden = firstRun;
  els.settingsKeyHint.hidden = firstRun;
}

async function openSettings() {
  settingsFromMain = true;
  const state = await loadState();
  els.settingsApiUrl.value = state.apiUrl || DEFAULT_API_URL;
  els.settingsApiKey.value = "";
  els.settingsCrawlerLimit.value = String(clampCrawlerLimit(state.crawlerLimit));
  showSettings({ firstRun: false });
}

function renderEnabled(enabled) {
  els.switchLabel.textContent = enabled ? "On — visiting pages" : "Off";
  els.switchLabel.classList.toggle("on", enabled);
}

function renderTourEnabled(enabled) {
  els.tourSwitchLabel.textContent = enabled ? "Akakce tour on" : "Akakce tour off";
  els.tourSwitchLabel.classList.toggle("on", enabled);
  els.tourStats.hidden = !enabled;
}

function renderMerchantEnabled(enabled) {
  els.merchantSwitchLabel.textContent = enabled ? "Merchant links on" : "Merchant links off";
  els.merchantSwitchLabel.classList.toggle("on", enabled);
  els.merchantStats.hidden = !enabled;
}

function renderStatusDot(enabled, tourEnabled, merchantEnabled) {
  const on = Boolean(enabled) || Boolean(tourEnabled) || Boolean(merchantEnabled);
  els.statusDot.classList.toggle("on", on);
}

function setLastUrl(url) {
  els.lastUrl.hidden = !url;
  els.lastUrl.textContent = url ? `Last: ${url}` : "";
}

function setMainError(msg) {
  els.mainError.hidden = !msg;
  els.mainError.textContent = msg || "";
}

function showSettingsError(msg) {
  els.settingsError.hidden = false;
  els.settingsError.textContent = msg;
}

async function onSave() {
  const apiUrl = els.settingsApiUrl.value.trim().replace(/\/+$/, "");
  const keyInput = els.settingsApiKey.value.trim();
  const crawlerLimit = clampCrawlerLimit(els.settingsCrawlerLimit.value);
  const stored = await loadState();
  const apiKey = keyInput || stored.apiKey;

  els.settingsError.hidden = true;

  if (!apiUrl) {
    showSettingsError("API URL is required.");
    return;
  }
  if (!apiKey) {
    showSettingsError("API key is required.");
    return;
  }

  els.btnSave.disabled = true;
  els.btnSave.textContent = "Checking…";
  try {
    const res = await fetch(apiUrl + "/v1/stats", {
      headers: { Authorization: "ApiKey " + apiKey },
    });
    if (res.status === 401) throw new Error("API key rejected (401).");
    if (!res.ok) throw new Error(`API responded with HTTP ${res.status}.`);
  } catch (err) {
    showSettingsError(err instanceof Error ? err.message : "Could not reach the API.");
    els.btnSave.disabled = false;
    els.btnSave.textContent = "Save";
    return;
  }

  const patch = { apiUrl, apiKey, crawlerLimit };
  if (!stored.apiKey) {
    patch.enabled = false;
    patch.akakceTourEnabled = false;
    patch.merchantLinkResolverEnabled = false;
  }
  await chrome.storage.local.set(patch);

  els.btnSave.disabled = false;
  els.btnSave.textContent = "Save";
  els.settingsApiKey.value = "";

  const state = await loadState();
  showMain(state);
}

async function onCancel() {
  if (!settingsFromMain) return;
  els.settingsApiKey.value = "";
  els.settingsError.hidden = true;
  const state = await loadState();
  showMain(state);
}

async function onToggle() {
  const enabled = els.toggle.checked;
  await chrome.storage.local.set({ enabled, lastError: "" });
  renderEnabled(enabled);
  const state = await loadState();
  renderStatusDot(enabled, state.akakceTourEnabled, state.merchantLinkResolverEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "enabled-changed", enabled }).catch(() => {});
}

async function onTourToggle() {
  const akakceTourEnabled = els.toggleTour.checked;
  await chrome.storage.local.set({ akakceTourEnabled, lastError: "" });
  renderTourEnabled(akakceTourEnabled);
  const state = await loadState();
  renderStatusDot(state.enabled, akakceTourEnabled, state.merchantLinkResolverEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "akakce-tour-changed", enabled: akakceTourEnabled }).catch(() => {});
}

async function onMerchantToggle() {
  const merchantLinkResolverEnabled = els.toggleMerchant.checked;
  await chrome.storage.local.set({ merchantLinkResolverEnabled, lastError: "" });
  renderMerchantEnabled(merchantLinkResolverEnabled);
  const state = await loadState();
  renderStatusDot(state.enabled, state.akakceTourEnabled, merchantLinkResolverEnabled);
  setMainError("");
  chrome.runtime.sendMessage({ type: "merchant-link-changed", enabled: merchantLinkResolverEnabled }).catch(() => {});
}
