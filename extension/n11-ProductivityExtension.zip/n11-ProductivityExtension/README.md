## n11 Productivity Extension

Bu eklenti, n11 ve BO sayfalarında günlük işleri hızlandırmak için hazırlanmıştır.

## Özellikler

- **Akakce Product Crawler** – n11 ürün linklerinden başlık alıp Google'da akakce aratarak fiyat karşılaştırması. "Manuel Güncelle" ile akakce sayfasında:
  - Sayfa açılır açılmaz bilgi banner'ı gösterilir (sayfa en üstte, scroll: 0).
  - Banner'a tıklanınca sayfa 1000px aşağı kayar ("Daha fazla fiyat gör" alanına yaklaşmak için).
  - "Daha fazla fiyat gör" tıklandıktan sonra fiyatlar otomatik alınır.
- n11 sayfalarında sayfa/ürün/mağaza/kategori ID yakalama ve kopyalama.
- Deeplink üretimi ve kopyalama.
- Sekme linkleri toplama (tüm n11 sekmeleri / sadece ürün sekmeleri).
- URL > Product ID aracı (link listesinden ürün ID çıkarma + Excel/CSV indirme).
- Banner Checker (kapalı promosyonları tespit eder, görsel + ID + durum listeler).
- BO Promosyon Ürün ID toplayıcı (listeyi dolaşarak ID çıkarma + CSV indirme).
- BO campaign sayfası için Page Checker (lazy load için sayfayı otomatik kaydırma).
- BO inventoryManagement sayfasında otomatik alan senkronizasyonu:
  - `#contentBannerName` -> `#imageSEODescription`
  - `#contentBannerUrl` -> `#contentMobileWebUrl`
  - promotions linki girilirse ilgili alanı otomatik doldurma
- Dynamic Page için Clear Cache akışı:
  - Dynamic Page ID tespit edilince “Clear Cache” kutusu görünür.
  - BO Dynamic Page Management sayfası açılır, arama yapılır, ilgili satıra gidilir ve Clear Cache tıklanır.
  - İşlem sonrası “Cacle Temizlendi” mesajı gösterilir.

## Notlar

- Akakce Product Crawler ve manuel banner sadece **n11.com** ve **akakce.com** sayfalarında çalışır.
- “Clear Cache” kutusu sadece **Dynamic Page** tipinde görünür.
- “Banner Checker” tüm n11.com sayfalarında görünür.
- BO sayfalarında sadece ilgili araçlar görünür.
