/**
 * Akakce "Daha fazla fiyat gör" (SAP) butonuna tıklar.
 * Bu script sayfa bağlamında (world: MAIN) çalıştırılır.
 */
(function () {
  const findBtn = (doc) => {
    return doc.querySelector("button#SAP") || doc.querySelector("[id='SAP']") || doc.querySelector("button.t2b.more") ||
      Array.from(doc.querySelectorAll("button, a, [role='button'], .t2b")).find((el) =>
        (el.textContent || "").includes("Daha fazla fiyat")
      );
  };
  const searchDoc = (doc) => {
    const btn = findBtn(doc);
    if (btn) return btn;
    for (const ifr of doc.querySelectorAll("iframe")) {
      try {
        const idoc = ifr.contentDocument || ifr.contentWindow?.document;
        if (idoc) {
          const b = searchDoc(idoc);
          if (b) return b;
        }
      } catch (_) {}
    }
    return null;
  };
  const btn = searchDoc(document);
  if (!btn) return;
  btn.scrollIntoView({ block: "center" });
  const rect = btn.getBoundingClientRect();
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0, buttons: 1, detail: 1 };
  btn.focus();
  btn.dispatchEvent(new MouseEvent("mousedown", opts));
  btn.dispatchEvent(new MouseEvent("mouseup", opts));
  btn.dispatchEvent(new MouseEvent("click", opts));
  btn.click();
  const inner = btn.querySelector("i");
  if (inner) inner.click();
  const atPoint = document.elementFromPoint(x, y);
  if (atPoint) atPoint.click();
})();
