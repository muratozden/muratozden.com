// BO Cart Coupon Add/Edit (buyerLoyalty) productivity helpers.
// Pages:
// - https://bo.n11.com/backoffice/buyerLoyalty/cartCouponAdd.xhtml
// - https://bo.n11.com/backoffice/buyerLoyalty/cartCouponEdit.xhtml
// - https://testbo.n11.com/backoffice/buyerLoyalty/cartCouponAdd.xhtml
// - https://testbo.n11.com/backoffice/buyerLoyalty/cartCouponEdit.xhtml
// - https://qabo.n11.com/backoffice/buyerLoyalty/cartCouponAdd.xhtml
// - https://qabo.n11.com/backoffice/buyerLoyalty/cartCouponEdit.xhtml

const CART_COUPON_PATHS = new Set([
  "/backoffice/buyerLoyalty/cartCouponAdd.xhtml",
  "/backoffice/buyerLoyalty/cartCouponEdit.xhtml"
]);

const CART_COUPON_HOSTS = new Set(["bo.n11.com", "testbo.n11.com", "qabo.n11.com"]);

const VOUCHER_ISSUANCE_OWNER_SALES_LABEL = "Sales";
const VOUCHER_ISSUANCE_OWNER_SALES_VALUE = "enums.voucher.IssuanceOwner_42";
const REGULAR_TIK_HIZI_TOKEN = "Regular Tık Hızı";
const VOUCHER_NAME_DEFAULT = "Tık Hızı İndirim Kuponu";
const VOUCHER_DISCOUNT_TYPE_PRICE_LABEL = "Price";
const VOUCHER_DISCOUNT_TYPE_PRICE_VALUE = "PRICE";

const CART_COUPON_COMPONENT_CANDIDATES = {
  voucherDescription: ["voucherDescription", "tabView:voucherDescription"],
  voucherIssuanceOwner: ["voucherIssuanceOwner", "tabView:voucherIssuanceOwner"],
  voucherName: ["voucherName", "tabView:voucherName"],
  voucherDiscountType: ["voucherDiscountType", "tabView:voucherDiscountType"],
  voucherAmount: ["voucherAmount", "tabView:voucherAmount"],
  voucherMaxAmount: ["voucherMaxAmount", "tabView:voucherMaxAmount"],
  voucherApplicableAmount: ["voucherApplicableAmount", "tabView:voucherApplicableAmount"]
};

const cartCouponEditSelectors = {
  voucherDescription: "voucherDescription",
  voucherIssuanceOwner: "voucherIssuanceOwner",
  voucherName: "voucherName",
  voucherDiscountType: "voucherDiscountType",
  voucherAmount: "voucherAmount",
  voucherMaxAmount: "voucherMaxAmount",
  voucherApplicableAmount: "voucherApplicableAmount"
};

const isCartCouponPage = () => {
  try {
    const url = new URL(window.location.href);
    return CART_COUPON_HOSTS.has(url.hostname) && CART_COUPON_PATHS.has(url.pathname);
  } catch {
    return false;
  }
};

const queryById = (id) =>
  document.getElementById(id) || document.querySelector(`[id="${id}"]`);

const resolveComponentId = (baseName) => {
  const candidates = CART_COUPON_COMPONENT_CANDIDATES[baseName] || [baseName];
  for (const id of candidates) {
    if (queryById(id) || queryById(`${id}_input`)) {
      return id;
    }
  }
  return candidates[0];
};

const findVoucherDescriptionInput = () => {
  const componentId = resolveComponentId("voucherDescription");
  const byId = queryById(componentId);
  if (byId) {
    return byId;
  }

  return (
    document.querySelector('textarea[name="voucherDescription"]') ||
    document.querySelector('input[name="voucherDescription"]') ||
    document.querySelector('textarea[name="tabView:voucherDescription"]') ||
    document.querySelector('input[name="tabView:voucherDescription"]')
  );
};

const cartCouponDelay = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

const waitForCartCouponElement = async (finder, tries = 30, delay = 500) => {
  for (let attempt = 0; attempt < tries; attempt += 1) {
    const result = finder();
    if (result) {
      return result;
    }
    await new Promise((resolve) => setTimeout(resolve, delay));
  }
  return null;
};

const parseAmountSegment = (segment) => {
  const text = String(segment ?? "").trim();
  const match = text.match(/(\d+)\s*\/\s*(\d+)/);
  if (!match) {
    return null;
  }
  return {
    applicableAmount: match[1],
    voucherAmount: match[2],
    raw: text
  };
};

const parseVoucherDescription = (raw) => {
  const text = String(raw ?? "").trim();
  const parts = text
    .split(";")
    .map((part) => part.trim())
    .filter(Boolean);
  const amounts = parts.length > 1 ? parseAmountSegment(parts[1]) : null;

  return {
    raw: text,
    parts,
    amounts,
    hasRegularTikHizi: text.includes(REGULAR_TIK_HIZI_TOKEN),
    hasAmountPair: Boolean(amounts)
  };
};

const setInputFieldValue = (input, value) => {
  if (!input || value == null || value === "") {
    return false;
  }
  const nextValue = String(value);
  if (input.value === nextValue) {
    return true;
  }
  input.value = nextValue;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  input.dispatchEvent(new Event("blur", { bubbles: true }));
  return input.value === nextValue;
};

const findInputByComponent = (baseName) => {
  const componentId = resolveComponentId(baseName);
  return queryById(componentId);
};

const getWidgetVarCandidates = (componentId) => {
  const normalized = String(componentId || "").replace(/:/g, "_");
  const base = String(componentId || "").split(":").pop();
  return [`widget_${normalized}`, `widget_${base}`, normalized, base];
};

const getPrimeFacesWidgetByVar = (widgetVar) => {
  if (!widgetVar) {
    return null;
  }

  if (typeof window.PF === "function") {
    try {
      const widget = window.PF(widgetVar);
      if (widget) {
        return widget;
      }
    } catch {
      // PF throws when widget is missing.
    }
  }

  return window.PrimeFaces?.widgets?.[widgetVar] || null;
};

const findPrimeFacesWidgetByComponentId = (componentId) => {
  for (const widgetVar of getWidgetVarCandidates(componentId)) {
    const byVar = getPrimeFacesWidgetByVar(widgetVar);
    if (byVar) {
      return byVar;
    }
  }

  if (typeof window.PrimeFaces?.getWidgetById === "function") {
    const byId = window.PrimeFaces.getWidgetById(componentId);
    if (byId) {
      return byId;
    }
  }

  const suffix = String(componentId).split(":").pop();
  const widgets = window.PrimeFaces?.widgets;
  const nativeSelect = queryById(`${componentId}_input`);

  if (widgets) {
    for (const [key, widget] of Object.entries(widgets)) {
      if (key === suffix || key.endsWith(`_${suffix}`) || key.includes(suffix)) {
        const input = widget?.input?.[0] || widget?.input;
        const inputId = input?.id || input?.getAttribute?.("id");
        if (!nativeSelect || inputId === nativeSelect.id) {
          return widget;
        }
      }
    }

    if (nativeSelect) {
      for (const widget of Object.values(widgets)) {
        const input = widget?.jq?.find?.("select")?.[0] || widget?.input?.[0];
        if (input === nativeSelect) {
          return widget;
        }
      }
    }
  }

  return null;
};

const resolveOneMenuOption = (nativeSelect, { labelText, optionValue }) => {
  let resolvedValue = optionValue;
  let resolvedLabel = labelText;

  if (!resolvedValue && resolvedLabel) {
    for (const option of nativeSelect.options) {
      if (option.textContent.trim() === resolvedLabel) {
        resolvedValue = option.value;
        break;
      }
    }
  }

  if (resolvedValue && !resolvedLabel) {
    for (const option of nativeSelect.options) {
      if (option.value === resolvedValue) {
        resolvedLabel = option.textContent.trim();
        break;
      }
    }
  }

  return { resolvedValue, resolvedLabel };
};

const isOneMenuValueSelected = (nativeSelect, resolvedValue) => {
  if (!nativeSelect || !resolvedValue) {
    return false;
  }
  return nativeSelect.value === resolvedValue;
};

const waitForOneMenuValue = async (nativeSelect, resolvedValue, tries = 20, delay = 120) => {
  for (let attempt = 0; attempt < tries; attempt += 1) {
    if (isOneMenuValueSelected(nativeSelect, resolvedValue)) {
      return true;
    }
    await cartCouponDelay(delay);
  }
  return isOneMenuValueSelected(nativeSelect, resolvedValue);
};

const tryWidgetSelectValue = async (widget, resolvedValue, nativeSelect) => {
  if (!widget || typeof widget.selectValue !== "function" || !resolvedValue) {
    return false;
  }

  try {
    widget.selectValue(resolvedValue);
  } catch {
    try {
      widget.selectValue(resolvedValue, true);
    } catch {
      return false;
    }
  }

  await cartCouponDelay(120);
  return isOneMenuValueSelected(nativeSelect, resolvedValue);
};

const tryJQuerySelectValue = async (nativeSelect, resolvedValue) => {
  const jq = window.jQuery || window.$;
  if (!jq || !nativeSelect || !resolvedValue) {
    return false;
  }

  try {
    jq(nativeSelect).val(resolvedValue).trigger("change");
    await cartCouponDelay(80);
    return nativeSelect.value === resolvedValue;
  } catch {
    return false;
  }
};

const isVisibleElement = (element) => {
  if (!element) {
    return false;
  }
  const style = window.getComputedStyle(element);
  return style.display !== "none" && style.visibility !== "hidden" && element.offsetParent !== null;
};

const dispatchUiClick = (element) => {
  if (!element) {
    return;
  }
  element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
  element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
  element.click();
};

const openOneMenuDropdown = (componentId) => {
  const root = queryById(componentId);
  if (!root) {
    return false;
  }

  const label = root.querySelector(".ui-selectonemenu-label");
  const trigger = root.querySelector(".ui-selectonemenu-trigger");
  dispatchUiClick(label);
  dispatchUiClick(trigger);
  dispatchUiClick(root);
  return true;
};

const collectOneMenuPanels = (componentId, root) => {
  const panels = [];
  const addPanel = (panel) => {
    if (panel && !panels.includes(panel)) {
      panels.push(panel);
    }
  };

  addPanel(root?.querySelector(".ui-selectonemenu-panel"));
  addPanel(queryById(`${componentId}_panel`));

  document.querySelectorAll(".ui-selectonemenu-panel").forEach((panel) => {
    if (isVisibleElement(panel)) {
      addPanel(panel);
    }
  });

  return panels;
};

const clickOneMenuItemByLabel = async (componentId, resolvedLabel, resolvedValue) => {
  const root = queryById(componentId);
  const nativeSelect = queryById(`${componentId}_input`);
  if (!root || !resolvedLabel || !nativeSelect) {
    return false;
  }

  for (let attempt = 0; attempt < 12; attempt += 1) {
    openOneMenuDropdown(componentId);
    await cartCouponDelay(120 + attempt * 60);

    const panels = collectOneMenuPanels(componentId, root);
    for (const panel of panels) {
      const items = panel.querySelectorAll(
        "li.ui-selectonemenu-item, li.ui-selectonemenu-list-item"
      );
      for (const item of items) {
        const itemLabel = item.textContent.trim();
        const itemDataLabel = item.getAttribute("data-label") || "";
        const matchesLabel =
          itemLabel === resolvedLabel || itemDataLabel === resolvedLabel;
        const matchesValue =
          resolvedValue &&
          (item.getAttribute("data-value") === resolvedValue ||
            item.getAttribute("data-item-value") === resolvedValue);
        if (!matchesLabel && !matchesValue) {
          continue;
        }
        dispatchUiClick(item);
        if (await waitForOneMenuValue(nativeSelect, resolvedValue, 12, 100)) {
          return true;
        }
      }
    }
  }

  return isOneMenuValueSelected(nativeSelect, resolvedValue);
};

const selectPrimeFacesOneMenu = async ({
  componentId,
  labelText,
  optionValue,
  uiClickFirst = true
}) => {
  const nativeSelect = queryById(`${componentId}_input`);
  if (!nativeSelect) {
    return false;
  }

  const { resolvedValue, resolvedLabel } = resolveOneMenuOption(nativeSelect, {
    labelText,
    optionValue
  });
  if (!resolvedValue) {
    return false;
  }

  if (isOneMenuValueSelected(nativeSelect, resolvedValue)) {
    return true;
  }

  if (uiClickFirst) {
    if (await clickOneMenuItemByLabel(componentId, resolvedLabel, resolvedValue)) {
      return true;
    }
  }

  const widget = findPrimeFacesWidgetByComponentId(componentId);
  if (await tryWidgetSelectValue(widget, resolvedValue, nativeSelect)) {
    return true;
  }
  if (await tryJQuerySelectValue(nativeSelect, resolvedValue)) {
    return true;
  }

  if (!uiClickFirst) {
    if (await clickOneMenuItemByLabel(componentId, resolvedLabel, resolvedValue)) {
      return true;
    }
  }

  return isOneMenuValueSelected(nativeSelect, resolvedValue);
};

const resolveSelectOptionValue = (nativeSelect, labelText, fallbackValue) => {
  if (!nativeSelect) {
    return fallbackValue;
  }
  for (const option of nativeSelect.options) {
    if (option.textContent.trim() === labelText) {
      return option.value;
    }
  }
  return fallbackValue;
};

const applyVoucherNameFromDescription = () => {
  const input = findInputByComponent("voucherName");
  if (!input) {
    return {
      applied: false,
      field: "voucherName",
      reason: "voucherName alanı bulunamadı."
    };
  }

  const applied = setInputFieldValue(input, VOUCHER_NAME_DEFAULT);
  return {
    applied,
    field: "voucherName",
    value: VOUCHER_NAME_DEFAULT,
    reason: applied ? undefined : "voucherName yazılamadı."
  };
};

const applyVoucherDiscountTypePrice = async () => {
  const componentId = resolveComponentId("voucherDiscountType");
  const nativeSelect = queryById(`${componentId}_input`);
  if (!nativeSelect) {
    return {
      applied: false,
      field: "voucherDiscountType",
      reason: "voucherDiscountType select alanı bulunamadı."
    };
  }

  const priceValue = resolveSelectOptionValue(
    nativeSelect,
    VOUCHER_DISCOUNT_TYPE_PRICE_LABEL,
    VOUCHER_DISCOUNT_TYPE_PRICE_VALUE
  );

  const selected = await selectPrimeFacesOneMenu({
    componentId,
    labelText: VOUCHER_DISCOUNT_TYPE_PRICE_LABEL,
    optionValue: priceValue,
    uiClickFirst: true
  });

  if (selected) {
    await cartCouponDelay(900);
  }

  return {
    applied: selected,
    field: "voucherDiscountType",
    value: VOUCHER_DISCOUNT_TYPE_PRICE_LABEL,
    reason: selected ? undefined : "Price seçilemedi."
  };
};

const applyVoucherAmountFields = async (amounts) => {
  if (!amounts?.voucherAmount || !amounts?.applicableAmount) {
    return {
      applied: false,
      field: "voucherAmount",
      reason: "750/100 formatında tutar bulunamadı."
    };
  }

  const voucherAmountInput = await waitForCartCouponElement(
    () => findInputByComponent("voucherAmount"),
    25,
    250
  );
  const applicableInput = await waitForCartCouponElement(
    () => findInputByComponent("voucherApplicableAmount"),
    10,
    150
  );

  if (!voucherAmountInput) {
    return {
      applied: false,
      field: "voucherAmount",
      reason: "voucherAmount alanı bulunamadı."
    };
  }

  if (!applicableInput) {
    return {
      applied: false,
      field: "voucherApplicableAmount",
      reason: "voucherApplicableAmount alanı bulunamadı."
    };
  }

  const voucherAmountApplied = setInputFieldValue(voucherAmountInput, amounts.voucherAmount);
  const applicableApplied = setInputFieldValue(applicableInput, amounts.applicableAmount);

  return {
    applied: voucherAmountApplied && applicableApplied,
    field: "voucherAmount",
    voucherAmount: amounts.voucherAmount,
    applicableAmount: amounts.applicableAmount,
    reason:
      voucherAmountApplied && applicableApplied
        ? undefined
        : "voucherAmount veya voucherApplicableAmount yazılamadı."
  };
};

const applyVoucherIssuanceOwnerFromDescription = async (parsed) => {
  if (!parsed?.hasRegularTikHizi) {
    return { applied: false, reason: "Regular Tık Hızı bulunamadı." };
  }

  const componentId = resolveComponentId("voucherIssuanceOwner");
  const nativeSelect = queryById(`${componentId}_input`);
  if (!nativeSelect) {
    return {
      applied: false,
      field: "voucherIssuanceOwner",
      reason: "voucherIssuanceOwner select alanı bulunamadı."
    };
  }

  const salesValue = resolveSelectOptionValue(
    nativeSelect,
    VOUCHER_ISSUANCE_OWNER_SALES_LABEL,
    VOUCHER_ISSUANCE_OWNER_SALES_VALUE
  );

  const selected = await selectPrimeFacesOneMenu({
    componentId,
    labelText: VOUCHER_ISSUANCE_OWNER_SALES_LABEL,
    optionValue: salesValue
  });

  return {
    applied: selected,
    field: "voucherIssuanceOwner",
    value: VOUCHER_ISSUANCE_OWNER_SALES_LABEL,
    reason: selected ? undefined : "Sales seçilemedi."
  };
};

const applyVoucherDescriptionRules = async (rawValue) => {
  const parsed = parseVoucherDescription(rawValue);
  if (!parsed.raw) {
    return { parsed, results: [] };
  }

  const results = [
    applyVoucherNameFromDescription(),
    await applyVoucherIssuanceOwnerFromDescription(parsed),
    await applyVoucherDiscountTypePrice()
  ];

  if (parsed.hasAmountPair) {
    results.push(await applyVoucherAmountFields(parsed.amounts));
  }

  return { parsed, results };
};

let voucherDescriptionDebounceTimer = null;

const handleVoucherDescriptionChange = (input) => {
  window.clearTimeout(voucherDescriptionDebounceTimer);
  voucherDescriptionDebounceTimer = window.setTimeout(() => {
    applyVoucherDescriptionRules(input.value).catch(() => {});
  }, 180);
};

const attachCartCouponEditFeature = () => {
  if (!isCartCouponPage()) {
    return false;
  }

  const voucherDescriptionInput = findVoucherDescriptionInput();
  if (!voucherDescriptionInput) {
    return false;
  }

  if (voucherDescriptionInput.dataset.n11CartCouponBound !== "1") {
    const onChange = () => handleVoucherDescriptionChange(voucherDescriptionInput);
    voucherDescriptionInput.addEventListener("input", onChange);
    voucherDescriptionInput.addEventListener("change", onChange);
    voucherDescriptionInput.addEventListener("blur", onChange);
    voucherDescriptionInput.addEventListener("paste", () => {
      window.setTimeout(onChange, 80);
    });
    voucherDescriptionInput.dataset.n11CartCouponBound = "1";

    if (voucherDescriptionInput.value.trim()) {
      applyVoucherDescriptionRules(voucherDescriptionInput.value).catch(() => {});
    }
  }

  return true;
};

let cartCouponEditObserver = null;

const initCartCouponEditFeature = () => {
  if (!isCartCouponPage()) {
    return;
  }
  if (window.__n11CartCouponEditInitialized) {
    attachCartCouponEditFeature();
    return;
  }
  window.__n11CartCouponEditInitialized = true;

  attachCartCouponEditFeature();

  if (!cartCouponEditObserver) {
    cartCouponEditObserver = new MutationObserver(() => {
      attachCartCouponEditFeature();
    });
    cartCouponEditObserver.observe(document.body, { childList: true, subtree: true });
  }
};

const bootCartCouponEditFeature = () => {
  if (!isCartCouponPage()) {
    return;
  }
  initCartCouponEditFeature();
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action !== "bo-cart-coupon-edit") {
    return false;
  }

  if (!isCartCouponPage()) {
    sendResponse({
      success: false,
      error: "Cart Coupon Add/Edit sayfasında değilsiniz."
    });
    return false;
  }

  const subAction = String(request.subAction || "").trim();
  if (subAction === "apply-from-description") {
    const input = findVoucherDescriptionInput();
    const value = String(request.value ?? input?.value ?? "").trim();
    if (!value) {
      sendResponse({ success: false, error: "voucherDescription boş." });
      return false;
    }
    applyVoucherDescriptionRules(value)
      .then((result) => sendResponse({ success: true, result }))
      .catch((error) =>
        sendResponse({ success: false, error: error?.message || String(error) })
      );
    return true;
  }

  if (!subAction) {
    sendResponse({
      success: false,
      error: "subAction belirtilmedi."
    });
    return false;
  }

  sendResponse({
    success: false,
    error: `Henüz uygulanmadı: ${subAction}`
  });
  return false;
});

window.n11BoCartCouponEdit = {
  paths: Array.from(CART_COUPON_PATHS),
  hosts: Array.from(CART_COUPON_HOSTS),
  selectors: cartCouponEditSelectors,
  tokens: {
    regularTikHizi: REGULAR_TIK_HIZI_TOKEN,
    voucherNameDefault: VOUCHER_NAME_DEFAULT
  },
  setInputFieldValue,
  parseAmountSegment,
  isPage: isCartCouponPage,
  parseVoucherDescription,
  applyVoucherDescriptionRules,
  selectPrimeFacesOneMenu,
  findPrimeFacesWidgetByComponentId,
  getPrimeFacesWidgetByVar,
  resolveComponentId,
  findVoucherDescriptionInput,
  attach: attachCartCouponEditFeature,
  init: initCartCouponEditFeature,
  waitForElement: waitForCartCouponElement
};

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bootCartCouponEditFeature);
} else {
  bootCartCouponEditFeature();
}
