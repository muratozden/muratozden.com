"use strict";

const { describe, it } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");
const { extractEpeyFromHtml, extractSpecRows } = require("../lib/attribute-crawler/epey-extract");
const { buildProductFromEpeyHtml } = require("../lib/attribute-crawler/build-product");

const fixturePath = path.join(__dirname, "..", "epey.html");
const html = fs.readFileSync(fixturePath, "utf8");

describe("extractEpeyFromHtml", () => {
  it("özet tablodan ve #bilgilerden yeterli satır toplar", () => {
    const { rawPlatformAttributes } = extractEpeyFromHtml(html);
    assert.ok(rawPlatformAttributes.length >= 80, `expected >= 80 rows, got ${rawPlatformAttributes.length}`);
  });

  it("bilinen alanları phone + core patch'e doldurur", () => {
    const { corePatch, phonePatch } = extractEpeyFromHtml(html);
    assert.equal(corePatch.identity.brand, "Apple");
    assert.equal(corePatch.identity.commercialName, "Apple iPhone 17");
    assert.equal(corePatch.marketplaceMeta.platformIds.epey.productId, "1023347");
    assert.equal(corePatch.aggregateRating.reviewCount, 330);
    assert.equal(corePatch.aggregateRating.ratingValue, 4);

    assert.equal(phonePatch.display.sizeInch, 6.3);
    assert.equal(phonePatch.display.refreshRateHz, 120);
    assert.equal(phonePatch.display.resolutionWidth, 1206);
    assert.equal(phonePatch.display.resolutionHeight, 2622);
    assert.equal(phonePatch.battery.capacityMah, 3692);
    assert.equal(phonePatch.battery.wiredChargingWatt, 40);
    assert.equal(phonePatch.performance.ramGb, 8);
    assert.equal(phonePatch.performance.storageGb, 256);
    assert.equal(phonePatch.connectivity.cellularGeneration, "5G");
    assert.equal(phonePatch.identity, undefined);
    assert.equal(corePatch.identity.releaseYear, 2025);
    assert.equal(phonePatch.regulatoryHealth.sarHeadWkg, 1.49);
    assert.equal(phonePatch.regulatoryHealth.sarBodyWkg, 1.49);
  });
});

describe("buildProductFromEpeyHtml", () => {
  it("şablonlarla birleşik ürün nesnesi üretir", () => {
    const product = buildProductFromEpeyHtml(html);
    assert.equal(product.productKind, "physical-product");
    assert.equal(product.extensions.phone.extensionId, "phone");
    assert.equal(product.identity.brand, "Apple");
    assert.equal(product.extensions.phone.display.sizeInch, 6.3);
    assert.ok(Array.isArray(product.media.gallery));
    assert.ok(product.media.gallery.length >= 3);
    assert.equal(product.media.primaryImageUrl.includes("1023347"), true);
  });
});

describe("extractSpecRows", () => {
  it("cheerio ile satır çıkarımı tutarlı", () => {
    const cheerio = require("cheerio");
    const $ = cheerio.load(html);
    const rows = extractSpecRows($);
    const ekran = rows.find((r) => r.key === "Ekran Boyutu");
    assert.ok(ekran);
    assert.match(ekran.value, /6\.3/);
  });
});
