(function initN11PricePool() {
  const TRACKING_STORAGE_KEY = "productPriceTrackingRows";
  const USER_TAG_STORAGE_KEY = "pricePoolUserTag";
  const AUTH_SESSION_STORAGE_KEY = "pricePoolSupabaseSession";
  const PRICE_POOL_BOX_ID = "price-pool-extension-box";
  const PRICE_POOL_MODAL_ID = "price-pool-extension-modal";
  const LOGIN_MODAL_ID = "price-pool-login-modal";
  const LOGO_URLS = {
    n11: "https://n11scdn.akamaized.net/custom/upload/56/71/4643320758776974115.svg",
    trendyol: "https://n11scdn.akamaized.net/custom/upload/52/34/8306016460707706841.svg",
    hepsiburada: "https://n11scdn.akamaized.net/custom/upload/49/75/9137271869470559939.svg",
    amazon: "https://n11scdn.akamaized.net/custom/upload/67/31/4443647868650764054.svg",
    pazarama: "https://n11scdn.akamaized.net/custom/upload/87/47/7511380717719014849.svg",
    pttavm: "https://n11scdn.akamaized.net/custom/upload/69/20/3989916881263112432.svg",
    idefix: "https://n11scdn.akamaized.net/custom/upload/77/62/6970520296776748069.svg",
    teknosa: "https://n11scdn.akamaized.net/custom/upload/65/11/4286337531925084530.svg"
  };
  const PLATFORM_CONFIG = [
    { key: "n11", urlKey: "n11Url", priceKey: "n11Price" },
    { key: "trendyol", urlKey: "trendyolUrl", priceKey: "trendyolPrice" },
    { key: "hepsiburada", urlKey: "hepsiburadaUrl", priceKey: "hepsiburadaPrice" },
    { key: "amazon", urlKey: "amazonUrl", priceKey: "amazonPrice" },
    { key: "pazarama", urlKey: "pazaramaUrl", priceKey: "pazaramaPrice" },
    { key: "pttavm", urlKey: "pttavmUrl", priceKey: "pttavmPrice" },
    { key: "idefix", urlKey: "idefixUrl", priceKey: "idefixPrice" },
    { key: "teknosa", urlKey: "teknosaUrl", priceKey: "teknosaPrice" }
  ];

  let priceHistorySchemaCache = null;

  const getConfig = () => {
    const cfg = window.PRICE_POOL_CONFIG || {};
    return {
      url: String(cfg.SUPABASE_URL || "").trim().replace(/\/+$/, ""),
      anonKey: String(cfg.SUPABASE_ANON_KEY || "").trim(),
      userTable: String(cfg.PRICE_POOL_USER_TABLE || "price_pool_users").trim()
    };
  };

  const parsePrice = (raw) => {
    if (raw == null) return null;
    const text = String(raw).trim();
    if (!text || text === "-") return null;

    let cleaned = text
      .replace(/TL|TRY|₺/gi, "")
      .replace(/\s+/g, "")
      .replace(/[^0-9,.\-]/g, "");
    if (!cleaned) return null;

    const lastComma = cleaned.lastIndexOf(",");
    const lastDot = cleaned.lastIndexOf(".");

    if (lastComma !== -1 && lastDot !== -1) {
      // Use the last separator as decimal mark, remove the other as thousands.
      if (lastComma > lastDot) {
        cleaned = cleaned.replace(/\./g, "").replace(",", ".");
      } else {
        cleaned = cleaned.replace(/,/g, "");
      }
    } else if (lastComma !== -1) {
      const fracLen = cleaned.length - lastComma - 1;
      cleaned = fracLen === 2
        ? cleaned.replace(/\./g, "").replace(",", ".")
        : cleaned.replace(/,/g, "");
    } else if (lastDot !== -1) {
      const fracLen = cleaned.length - lastDot - 1;
      cleaned = fracLen === 2
        ? cleaned.replace(/,/g, "")
        : cleaned.replace(/\./g, "");
    }

    const value = Number(cleaned);
    return Number.isFinite(value) ? value : null;
  };

  const hashString = (s) => {
    let h = 5381;
    for (let i = 0; i < s.length; i++) {
      h = ((h << 5) + h) + s.charCodeAt(i);
      h &= 0xffffffff;
    }
    return String(h >>> 0);
  };

  const syntheticSku = (platform, url, fallback) => {
    const source = String(url || fallback || "").trim();
    return `pp-${platform}-${hashString(source || String(Date.now()))}`;
  };

  const normalizeProductUrl = (rawUrl) => {
    const value = String(rawUrl || "").trim();
    if (!value) return "";
    try {
      const u = new URL(value);
      u.hash = "";
      u.search = "";
      const normalizedPath = u.pathname.replace(/\/+$/, "");
      u.pathname = normalizedPath || "/";
      return u.toString();
    } catch {
      return value;
    }
  };

  const headers = (anonKey, prefer = "return=representation") => ({
    apikey: anonKey,
    Authorization: `Bearer ${anonKey}`,
    "Content-Type": "application/json",
    Prefer: prefer
  });

  const authHeaders = (config, accessToken) => ({
    apikey: config.anonKey,
    Authorization: `Bearer ${accessToken || config.anonKey}`,
    "Content-Type": "application/json"
  });
  const restHeaders = (config, accessToken, prefer = "return=representation") => ({
    apikey: config.anonKey,
    Authorization: `Bearer ${accessToken || config.anonKey}`,
    "Content-Type": "application/json",
    Prefer: prefer
  });

  const readSession = () => {
    try {
      const raw = localStorage.getItem(AUTH_SESSION_STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return null;
      return parsed;
    } catch {
      return null;
    }
  };

  const saveSession = (session) => {
    localStorage.setItem(AUTH_SESSION_STORAGE_KEY, JSON.stringify(session));
  };

  const clearSession = () => {
    localStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
  };

  const sessionUserEmail = () => {
    const session = readSession();
    return String(session?.user?.email || "").trim();
  };

  const getUserTag = (interactive) => {
    const fromAuth = sessionUserEmail();
    if (fromAuth) return fromAuth;
    const existing = String(localStorage.getItem(USER_TAG_STORAGE_KEY) || "").trim();
    if (existing) return existing;
    if (!interactive) return "";
    const entered = String(window.prompt("Price Pool - user_tag giriniz:", "") || "").trim();
    if (!entered) return "";
    localStorage.setItem(USER_TAG_STORAGE_KEY, entered);
    return entered;
  };

  const signInWithEmailPassword = async (config, email, password) => {
    const res = await fetch(`${config.url}/auth/v1/token?grant_type=password`, {
      method: "POST",
      headers: authHeaders(config),
      body: JSON.stringify({ email, password })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.access_token) {
      throw new Error(String(data.error_description || data.msg || "Login basarisiz."));
    }
    const expiresAt = data.expires_at || (Math.floor(Date.now() / 1000) + Number(data.expires_in || 3600));
    const session = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || "",
      expires_at: expiresAt,
      user: data.user || {}
    };
    saveSession(session);
    return session;
  };

  const getAuthUser = async (config, session) => {
    if (!session?.access_token) return null;
    const res = await fetch(`${config.url}/auth/v1/user`, {
      method: "GET",
      headers: authHeaders(config, session.access_token)
    });
    if (!res.ok) return null;
    return res.json();
  };

  const ensureAuthSession = async (config, interactive) => {
    const session = readSession();
    if (session?.access_token && Number(session.expires_at || 0) > Math.floor(Date.now() / 1000) + 30) {
      const user = await getAuthUser(config, session);
      if (user && user.id) {
        return { ok: true, session: { ...session, user } };
      }
      clearSession();
    }
    if (!interactive) return { ok: false, reason: "not-authenticated" };
    const loggedIn = await openLoginModal(config);
    if (!loggedIn) return { ok: false, reason: "login-cancelled" };
    const refreshed = readSession();
    return refreshed?.access_token ? { ok: true, session: refreshed } : { ok: false, reason: "login-failed" };
  };

  const ensureLoginModal = () => {
    let modal = document.getElementById(LOGIN_MODAL_ID);
    if (modal) return modal;
    modal = document.createElement("div");
    modal.id = LOGIN_MODAL_ID;
    modal.style.display = "none";
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Price Pool Login</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="textarea-group">
          <label for="price-pool-login-email">Email</label>
          <input id="price-pool-login-email" type="email" placeholder="ornek@mail.com" />
        </div>
        <div class="textarea-group">
          <label for="price-pool-login-password">Sifre</label>
          <input id="price-pool-login-password" type="password" placeholder="********" />
        </div>
        <div class="modal-controls">
          <button class="collect-btn" id="price-pool-login-submit">Giris Yap</button>
          <button class="clear-btn" id="price-pool-login-cancel">Iptal</button>
        </div>
        <div class="status" id="price-pool-login-status"></div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) modal.style.display = "none";
    });
    document.body.appendChild(modal);
    return modal;
  };

  const openLoginModal = async (config) =>
    new Promise((resolve) => {
      const modal = ensureLoginModal();
      const emailInput = modal.querySelector("#price-pool-login-email");
      const passInput = modal.querySelector("#price-pool-login-password");
      const submitBtn = modal.querySelector("#price-pool-login-submit");
      const cancelBtn = modal.querySelector("#price-pool-login-cancel");
      const closeBtn = modal.querySelector(".modal-close");
      const statusEl = modal.querySelector("#price-pool-login-status");

      let resolved = false;
      const done = (result) => {
        if (resolved) return;
        resolved = true;
        modal.style.display = "none";
        submitBtn.onclick = null;
        cancelBtn.onclick = null;
        closeBtn.onclick = null;
        resolve(result);
      };

      const setStatus = (text, type = "info") => {
        statusEl.textContent = text;
        statusEl.className = `status ${type}`;
      };

      submitBtn.onclick = async () => {
        const email = String(emailInput.value || "").trim();
        const password = String(passInput.value || "");
        if (!email || !password) {
          setStatus("Email ve sifre zorunlu.", "error");
          return;
        }
        submitBtn.disabled = true;
        setStatus("Giris yapiliyor...", "info");
        try {
          await signInWithEmailPassword(config, email, password);
          setStatus("Giris basarili.", "success");
          done(true);
        } catch (error) {
          setStatus((error && error.message) || "Giris basarisiz.", "error");
        } finally {
          submitBtn.disabled = false;
        }
      };
      cancelBtn.onclick = () => done(false);
      closeBtn.onclick = () => done(false);
      modal.style.display = "flex";
      emailInput.focus();
    });

  const fetchTrackingRowsFromStorage = () =>
    new Promise((resolve) => {
      if (!chrome?.storage?.local) {
        resolve([]);
        return;
      }
      chrome.storage.local.get(TRACKING_STORAGE_KEY, (result) => {
        const list = result && Array.isArray(result[TRACKING_STORAGE_KEY])
          ? result[TRACKING_STORAGE_KEY]
          : [];
        resolve(list);
      });
    });

  const normalizeTrackingRows = (rows) => (Array.isArray(rows) ? rows : []);

  const rowsToPriceEntries = (rows) => {
    const entries = [];
    normalizeTrackingRows(rows).forEach((row) => {
      const rowObj = row && typeof row === "object" ? row : {};
      const name = String(rowObj.productTitle || "").trim() || "Untitled Product";
      const rowSku = String(rowObj.skuId || "").trim();
      const rowProductId = String(rowObj.productId || "").trim();
      PLATFORM_CONFIG.forEach((platform) => {
        const url = normalizeProductUrl(rowObj[platform.urlKey] || "");
        if (!url) return;
        const price = parsePrice(rowObj[platform.priceKey]);
        if (price == null) return;
        const sku = platform.key === "n11" && rowSku
          ? `n11-${rowSku}`
          : syntheticSku(platform.key, url, rowProductId || rowObj.id || name);
        entries.push({
          sku,
          name,
          platform: platform.key,
          url,
          price
        });
      });
    });
    // Keep one entry per product key in same sync batch
    const bySku = new Map();
    entries.forEach((entry) => {
      bySku.set(entry.sku, entry);
    });
    return Array.from(bySku.values());
  };

  const rowsToTrackingRecords = (rows) => {
    const list = [];
    normalizeTrackingRows(rows).forEach((row) => {
      const rowObj = row && typeof row === "object" ? row : {};
      const n11Url = normalizeProductUrl(rowObj.n11Url || "");
      if (!n11Url) return;
      list.push({
        product_title: String(rowObj.productTitle || "").trim() || null,
        sku: String(rowObj.skuId || "").trim() || null,
        product_id: String(rowObj.productId || "").trim() || null,
        pims_id: String(rowObj.pimsId || "").trim() || null,
        group_id: String(rowObj.groupId || "").trim() || null,
        n11_url: n11Url,
        n11_price: parsePrice(rowObj.n11Price),
        trendyol_url: normalizeProductUrl(rowObj.trendyolUrl || ""),
        trendyol_price: parsePrice(rowObj.trendyolPrice),
        hepsiburada_url: normalizeProductUrl(rowObj.hepsiburadaUrl || ""),
        hepsiburada_price: parsePrice(rowObj.hepsiburadaPrice),
        amazon_url: normalizeProductUrl(rowObj.amazonUrl || ""),
        amazon_price: parsePrice(rowObj.amazonPrice),
        pazarama_url: normalizeProductUrl(rowObj.pazaramaUrl || ""),
        pazarama_price: parsePrice(rowObj.pazaramaPrice),
        pttavm_url: normalizeProductUrl(rowObj.pttavmUrl || ""),
        pttavm_price: parsePrice(rowObj.pttavmPrice),
        idefix_url: normalizeProductUrl(rowObj.idefixUrl || ""),
        idefix_price: parsePrice(rowObj.idefixPrice),
        teknosa_url: normalizeProductUrl(rowObj.teknosaUrl || ""),
        teknosa_price: parsePrice(rowObj.teknosaPrice)
      });
    });
    const byN11Url = new Map();
    list.forEach((item) => {
      byN11Url.set(item.n11_url, item);
    });
    return Array.from(byN11Url.values());
  };

  const upsertProduct = async (config, entry) => {
    const url = `${config.url}/rest/v1/products?on_conflict=sku`;
    const res = await fetch(url, {
      method: "POST",
      headers: headers(config.anonKey, "resolution=merge-duplicates,return=representation"),
      body: JSON.stringify([
        {
          sku: entry.sku,
          name: entry.name,
          platform: entry.platform,
          url: entry.url
        }
      ])
    });
    if (!res.ok) {
      throw new Error(`products upsert failed: ${res.status} ${await res.text()}`);
    }
    const rows = await res.json();
    if (!Array.isArray(rows) || !rows[0] || !rows[0].id) {
      throw new Error("products upsert response has no id.");
    }
    return rows[0];
  };

  const upsertUserProfile = async (config, session) => {
    const user = session?.user || {};
    if (!user.id) return;
    const res = await fetch(`${config.url}/rest/v1/${config.userTable}?on_conflict=id`, {
      method: "POST",
      headers: headers(config.anonKey, "resolution=merge-duplicates,return=minimal"),
      body: JSON.stringify([
        {
          id: user.id,
          email: String(user.email || "").trim() || null,
          last_login_at: new Date().toISOString()
        }
      ])
    });
    if (!res.ok) {
      // Table may not exist yet; do not block flow.
      console.warn("Price Pool user profile upsert skipped:", await res.text());
    }
  };

  const fetchTrackingRowByN11Url = async (config, accessToken, ownerUserId, n11Url) => {
    const query =
      `${config.url}/rest/v1/price_pool_tracking?` +
      "select=*" +
      `&owner_user_id=eq.${encodeURIComponent(String(ownerUserId))}` +
      `&n11_url=eq.${encodeURIComponent(String(n11Url))}` +
      "&limit=1";
    const res = await fetch(query, { method: "GET", headers: restHeaders(config, accessToken) });
    if (!res.ok) return null;
    const rows = await res.json();
    return Array.isArray(rows) && rows[0] ? rows[0] : null;
  };

  const mergeTrackingRecord = (existing, incoming, ownerUserId) => {
    const next = {
      owner_user_id: ownerUserId,
      updated_at: new Date().toISOString()
    };
    if (incoming.product_title) next.product_title = incoming.product_title;
    if (incoming.sku) next.sku = incoming.sku;
    if (incoming.product_id) next.product_id = incoming.product_id;
    if (incoming.pims_id) next.pims_id = incoming.pims_id;
    if (incoming.group_id) next.group_id = incoming.group_id;
    next.n11_url = incoming.n11_url;
    if (incoming.n11_price != null) next.n11_price = incoming.n11_price;

    PLATFORM_CONFIG.forEach((platform) => {
      const urlKey = `${platform.key}_url`;
      const priceKey = `${platform.key}_price`;
      const incomingUrl = incoming[urlKey];
      const incomingPrice = incoming[priceKey];
      const existingUrl = existing ? existing[urlKey] : null;
      const existingPrice = existing ? existing[priceKey] : null;
      next[urlKey] = incomingUrl || existingUrl || null;
      if (incomingPrice != null) {
        next[priceKey] = incomingPrice;
      } else if (existingPrice != null) {
        next[priceKey] = existingPrice;
      } else {
        next[priceKey] = null;
      }
    });
    return next;
  };

  const trackingPayloadChanged = (existing, merged) => {
    if (!existing) return true;
    const keys = [
      "product_title",
      "sku",
      "product_id",
      "pims_id",
      "group_id",
      "n11_url",
      "n11_price",
      "trendyol_url",
      "trendyol_price",
      "hepsiburada_url",
      "hepsiburada_price",
      "amazon_url",
      "amazon_price",
      "pazarama_url",
      "pazarama_price",
      "pttavm_url",
      "pttavm_price",
      "idefix_url",
      "idefix_price",
      "teknosa_url",
      "teknosa_price"
    ];
    return keys.some((key) => {
      const a = existing[key] == null ? null : String(existing[key]);
      const b = merged[key] == null ? null : String(merged[key]);
      return a !== b;
    });
  };

  const upsertTrackingRecord = async (config, accessToken, ownerUserId, incoming) => {
    const existing = await fetchTrackingRowByN11Url(config, accessToken, ownerUserId, incoming.n11_url);
    const merged = mergeTrackingRecord(existing, incoming, ownerUserId);
    if (!trackingPayloadChanged(existing, merged)) {
      return { ok: true, changed: false };
    }

    if (existing && existing.id) {
      const patchUrl = `${config.url}/rest/v1/price_pool_tracking?id=eq.${encodeURIComponent(String(existing.id))}`;
      const patchRes = await fetch(patchUrl, {
        method: "PATCH",
        headers: restHeaders(config, accessToken, "return=minimal"),
        body: JSON.stringify(merged)
      });
      if (!patchRes.ok) {
        throw new Error(`price_pool_tracking update failed: ${patchRes.status} ${await patchRes.text()}`);
      }
      return { ok: true, changed: true };
    }

    const insertRes = await fetch(`${config.url}/rest/v1/price_pool_tracking`, {
      method: "POST",
      headers: restHeaders(config, accessToken, "return=minimal"),
      body: JSON.stringify([merged])
    });
    if (!insertRes.ok) {
      throw new Error(`price_pool_tracking insert failed: ${insertRes.status} ${await insertRes.text()}`);
    }
    return { ok: true, changed: true };
  };

  const detectExistingColumn = async (config, table, column) => {
    const url =
      `${config.url}/rest/v1/${table}?` +
      `select=${encodeURIComponent(column)}` +
      "&limit=1";
    const res = await fetch(url, { method: "GET", headers: headers(config.anonKey) });
    if (res.ok) return true;
    const text = await res.text();
    if (/Could not find the .* column/i.test(text) || /PGRST204/i.test(text)) {
      return false;
    }
    return false;
  };

  const detectFirstExistingColumn = async (config, table, candidates) => {
    for (const column of candidates) {
      // eslint-disable-next-line no-await-in-loop
      const exists = await detectExistingColumn(config, table, column);
      if (exists) return column;
    }
    return "";
  };

  const getPriceHistorySchema = async (config) => {
    if (priceHistorySchemaCache) return priceHistorySchemaCache;
    const productRefColumn = await detectFirstExistingColumn(config, "price_history", [
      "product_id",
      "productId",
      "productid",
      "sku",
      "sku_id",
      "skuId"
    ]);
    const userTagColumn = await detectFirstExistingColumn(config, "price_history", [
      "user_tag",
      "userTag",
      "usertag"
    ]);
    const priceColumn = await detectFirstExistingColumn(config, "price_history", [
      "price",
      "amount"
    ]);
    priceHistorySchemaCache = { productRefColumn, userTagColumn, priceColumn };
    return priceHistorySchemaCache;
  };

  const getProductRefValue = (entry, productRow, productRefColumn) => {
    const col = String(productRefColumn || "");
    if (col === "product_id" || col === "productId" || col === "productid") {
      return productRow.id;
    }
    if (col === "sku" || col === "sku_id" || col === "skuId") {
      return entry.sku;
    }
    return null;
  };

  const fetchLastPriceByProductAndUser = async (config, entry, productRow, userTag, schema) => {
    if (!schema.productRefColumn || !schema.userTagColumn || !schema.priceColumn) {
      return null;
    }
    const refValue = getProductRefValue(entry, productRow, schema.productRefColumn);
    if (refValue == null || refValue === "") return null;
    const refFilter = `${schema.productRefColumn}=eq.${encodeURIComponent(String(refValue))}`;
    const userFilter = `${schema.userTagColumn}=eq.${encodeURIComponent(String(userTag || "").trim())}`;
    const url =
      `${config.url}/rest/v1/price_history?` +
      `${refFilter}` +
      `&${userFilter}` +
      `&select=${encodeURIComponent(schema.priceColumn)},created_at` +
      "&order=created_at.desc" +
      "&limit=1";
    const res = await fetch(url, { method: "GET", headers: headers(config.anonKey) });
    if (!res.ok) return null;
    const rows = await res.json();
    return Array.isArray(rows) && rows[0] ? rows[0] : null;
  };

  const insertPriceHistory = async (config, entry, productRow, userTag, schema) => {
    if (!schema.productRefColumn || !schema.userTagColumn || !schema.priceColumn) {
      throw new Error("price_history tablosu beklenen kolonlari icermiyor.");
    }
    const refValue = getProductRefValue(entry, productRow, schema.productRefColumn);
    if (refValue == null || refValue === "") {
      throw new Error("price_history referans kolonu icin deger olusturulamadi.");
    }
    const payload = {};
    payload[schema.productRefColumn] = refValue;
    payload[schema.priceColumn] = entry.price;
    payload[schema.userTagColumn] = userTag;

    const res = await fetch(`${config.url}/rest/v1/price_history`, {
      method: "POST",
      headers: headers(config.anonKey),
      body: JSON.stringify([payload])
    });
    if (!res.ok) {
      throw new Error(`price_history insert failed: ${res.status} ${await res.text()}`);
    }
    return res.json();
  };

  const syncTrackingRecords = async (recordsInput, options = {}) => {
    const interactive = Boolean(options && options.interactive);
    const config = getConfig();
    if (!config.url || !config.anonKey) {
      return { ok: false, reason: "missing-config", synced: 0 };
    }
    const auth = await ensureAuthSession(config, interactive);
    if (!auth.ok) {
      return { ok: false, reason: auth.reason || "not-authenticated", synced: 0 };
    }
    await upsertUserProfile(config, auth.session);

    const ownerUserId = auth.session?.user?.id;
    const accessToken = auth.session?.access_token || "";
    if (!ownerUserId) {
      return { ok: false, reason: "missing-user-id", synced: 0 };
    }
    const records = Array.isArray(recordsInput) ? recordsInput : [];
    if (!records.length) {
      return { ok: true, synced: 0, skipped: 0 };
    }

    let synced = 0;
    let skipped = 0;
    for (const record of records) {
      // eslint-disable-next-line no-await-in-loop
      const result = await upsertTrackingRecord(config, accessToken, ownerUserId, record);
      if (result && result.changed) {
        synced += 1;
      } else {
        skipped += 1;
      }
    }
    return { ok: true, synced, skipped };
  };

  const syncRowsFromTracking = async (rowsInput, options = {}) => {
    const records = rowsToTrackingRecords(rowsInput);
    return syncTrackingRecords(records, options);
  };

  const syncSingleTrackingRow = async (rowInput, options = {}) => {
    const records = rowsToTrackingRecords([rowInput]);
    return syncTrackingRecords(records, options);
  };

  const fetchRecentPoolRows = async () => {
    const config = getConfig();
    if (!config.url || !config.anonKey) return [];
    const auth = await ensureAuthSession(config, false);
    if (!auth.ok) return [];
    const ownerUserId = auth.session?.user?.id;
    const accessToken = auth.session?.access_token || "";
    if (!ownerUserId) return [];
    const query =
      `${config.url}/rest/v1/price_pool_tracking?` +
      "select=*" +
      `&owner_user_id=eq.${encodeURIComponent(String(ownerUserId))}` +
      "&order=updated_at.desc" +
      "&limit=1000";
    const res = await fetch(query, { method: "GET", headers: restHeaders(config, accessToken) });
    if (!res.ok) return [];
    const rows = await res.json();
    return Array.isArray(rows) ? rows : [];
  };

  const fetchPoolCount = async () => {
    const config = getConfig();
    if (!config.url || !config.anonKey) return 0;
    const auth = await ensureAuthSession(config, false);
    if (!auth.ok) return 0;
    const ownerUserId = auth.session?.user?.id;
    const accessToken = auth.session?.access_token || "";
    if (!ownerUserId) return 0;
    const res = await fetch(
      `${config.url}/rest/v1/price_pool_tracking?select=id&owner_user_id=eq.${encodeURIComponent(String(ownerUserId))}`,
      {
      method: "GET",
      headers: restHeaders(config, accessToken, "count=exact")
    }
    );
    if (!res.ok) return 0;
    const contentRange = String(res.headers.get("content-range") || "");
    const match = contentRange.match(/\/(\d+)$/);
    return match && match[1] ? Number(match[1]) : 0;
  };

  const escapeHtml = (value) =>
    String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

  const formatDateTime = (value) => {
    if (!value) return "-";
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return String(value);
    return d.toLocaleString("tr-TR");
  };

  const formatPrice = (value) => {
    const parsed = parsePrice(value);
    if (parsed == null || Number.isNaN(parsed)) return "-";
    const hasFraction = Math.abs(parsed % 1) > 0.000001;
    const text = parsed.toLocaleString("tr-TR", {
      minimumFractionDigits: hasFraction ? 2 : 0,
      maximumFractionDigits: 2
    });
    return `${text} TL`;
  };

  const fetchProductById = async (config, idValue) => {
    if (idValue == null || idValue === "") return null;
    const url =
      `${config.url}/rest/v1/products?` +
      "select=id,sku,name,platform,url" +
      `&id=eq.${encodeURIComponent(String(idValue))}` +
      "&limit=1";
    const res = await fetch(url, { method: "GET", headers: headers(config.anonKey) });
    if (!res.ok) return null;
    const rows = await res.json();
    return Array.isArray(rows) && rows[0] ? rows[0] : null;
  };

  const fetchProductBySku = async (config, skuValue) => {
    if (!skuValue) return null;
    const url =
      `${config.url}/rest/v1/products?` +
      "select=id,sku,name,platform,url" +
      `&sku=eq.${encodeURIComponent(String(skuValue))}` +
      "&limit=1";
    const res = await fetch(url, { method: "GET", headers: headers(config.anonKey) });
    if (!res.ok) return null;
    const rows = await res.json();
    return Array.isArray(rows) && rows[0] ? rows[0] : null;
  };

  const enrichRowsWithProductData = async (config, rows) => {
    if (!Array.isArray(rows) || rows.length === 0) return [];
    const schema = await getPriceHistorySchema(config);
    const enriched = [];
    for (const row of rows) {
      if (row && row.products && typeof row.products === "object") {
        enriched.push(row);
        continue;
      }
      let product = null;
      if (schema.productRefColumn === "product_id" || schema.productRefColumn === "productId" || schema.productRefColumn === "productid") {
        // eslint-disable-next-line no-await-in-loop
        product = await fetchProductById(config, row[schema.productRefColumn]);
      } else if (schema.productRefColumn === "sku" || schema.productRefColumn === "sku_id" || schema.productRefColumn === "skuId") {
        // eslint-disable-next-line no-await-in-loop
        product = await fetchProductBySku(config, row[schema.productRefColumn]);
      } else {
        // eslint-disable-next-line no-await-in-loop
        product = await fetchProductById(config, row.product_id);
        if (!product) {
          // eslint-disable-next-line no-await-in-loop
          product = await fetchProductBySku(config, row.sku || row.sku_id);
        }
      }
      enriched.push({ ...row, products: product || null });
    }
    return enriched;
  };

  const ensurePoolModal = () => {
    let modal = document.getElementById(PRICE_POOL_MODAL_ID);
    if (modal) return modal;
    modal = document.createElement("div");
    modal.id = PRICE_POOL_MODAL_ID;
    modal.style.display = "none";
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Price Pool</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="price-pool-actions">
          <button type="button" class="collect-btn" id="price-pool-sync-btn">Supabase'e Senkronla</button>
          <button type="button" class="clear-btn" id="price-pool-refresh-btn">Listeyi Yenile</button>
          <input type="search" id="price-pool-search-input" class="price-pool-search-input" placeholder="Ürün ara..." />
          <div id="price-pool-total" class="price-pool-total">Toplam kayıt: 0</div>
        </div>
        <div class="price-pool-table-wrap">
          <table class="price-pool-table">
            <thead>
              <tr>
                <th>Ürün</th>
                <th><img src="${LOGO_URLS.n11}" alt="n11" class="price-pool-header-logo" /></th>
                <th><img src="${LOGO_URLS.trendyol}" alt="Trendyol" class="price-pool-header-logo" /></th>
                <th><img src="${LOGO_URLS.hepsiburada}" alt="Hepsiburada" class="price-pool-header-logo" /></th>
                <th><img src="${LOGO_URLS.amazon}" alt="Amazon" class="price-pool-header-logo" /></th>
                <th><img src="${LOGO_URLS.pazarama}" alt="Pazarama" class="price-pool-header-logo" /></th>
                <th><img src="${LOGO_URLS.pttavm}" alt="PttAVM" class="price-pool-header-logo" /></th>
                <th><img src="${LOGO_URLS.idefix}" alt="idefix" class="price-pool-header-logo" /></th>
                <th><img src="${LOGO_URLS.teknosa}" alt="Teknosa" class="price-pool-header-logo" /></th>
                <th>Tarih</th>
              </tr>
            </thead>
            <tbody id="price-pool-tbody"></tbody>
          </table>
        </div>
        <div class="status" id="price-pool-status"></div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) modal.style.display = "none";
    });
    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
    document.body.appendChild(modal);
    return modal;
  };

  const setPoolStatus = (modal, message, type = "info") => {
    const status = modal.querySelector("#price-pool-status");
    if (!status) return;
    status.textContent = message || "";
    status.className = `status ${type}`;
    status.style.display = message ? "block" : "none";
  };

  const renderPoolRows = (modal, rows) => {
    const tbody = modal.querySelector("#price-pool-tbody");
    if (!tbody) return;
    const searchInput = modal.querySelector("#price-pool-search-input");
    const searchTerm = String(searchInput?.value || "").toLowerCase().trim();
    if (!Array.isArray(rows) || rows.length === 0) {
      modal.__pricePoolUniqueCount = 0;
      modal.__pricePoolHistoryCount = 0;
      tbody.innerHTML = `<tr><td colspan="10" class="akakce-crawler-empty">Kayıt bulunamadı.</td></tr>`;
      return;
    }
    const normalizeKeyText = (value) =>
      String(value || "")
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim();

    const groupedMap = new Map();
    rows.forEach((item) => {
      const name = String(item.product_title || item.name || item.sku || "-").trim();
      const sku = String(item.sku || item.sku_id || item.product_id || "-").trim();
      const canonicalName = normalizeKeyText(name);
      const canonicalUrl = normalizeKeyText(item.n11_url || item.url || "");
      const canonicalSku = normalizeKeyText(sku);
      const rowKey = canonicalName || canonicalUrl || canonicalSku || `row-${Math.random().toString(36).slice(2)}`;
      const createdAt = item && (item.updated_at || item.created_at) ? (item.updated_at || item.created_at) : "";
      const createdAtMs = createdAt ? new Date(createdAt).getTime() : 0;
      if (!groupedMap.has(rowKey)) {
        groupedMap.set(rowKey, {
          name,
          sku,
          latestCreatedAt: createdAt || "",
          platforms: {
            n11: { price: "-", url: "", at: 0 },
            trendyol: { price: "-", url: "", at: 0 },
            hepsiburada: { price: "-", url: "", at: 0 },
            amazon: { price: "-", url: "", at: 0 },
            pazarama: { price: "-", url: "", at: 0 },
            pttavm: { price: "-", url: "", at: 0 },
            idefix: { price: "-", url: "", at: 0 },
            teknosa: { price: "-", url: "", at: 0 }
          }
        });
      }
      const group = groupedMap.get(rowKey);
      if (createdAt && (!group.latestCreatedAt || createdAtMs > new Date(group.latestCreatedAt).getTime())) {
        group.latestCreatedAt = createdAt;
      }

      PLATFORM_CONFIG.forEach((platform) => {
        const urlKey = `${platform.key}_url`;
        const priceKey = `${platform.key}_price`;
        const nextUrl = String(item[urlKey] || "").trim();
        const nextPrice = item[priceKey];
        if (!nextUrl && (nextPrice == null || String(nextPrice).trim() === "")) return;
        const current = group.platforms[platform.key];
        if (!current.at || createdAtMs >= current.at) {
          group.platforms[platform.key] = { price: nextPrice, url: nextUrl, at: createdAtMs };
        }
      });
    });
    let grouped = Array.from(groupedMap.values());
    if (searchTerm) {
      grouped = grouped.filter((row) => String(row.name || "").toLowerCase().includes(searchTerm));
    }
    if (!grouped.length) {
      modal.__pricePoolUniqueCount = 0;
      modal.__pricePoolHistoryCount = rows.length;
      tbody.innerHTML = `<tr><td colspan="10" class="akakce-crawler-empty">Arama kriterine uygun kayıt bulunamadı.</td></tr>`;
      return;
    }
    modal.__pricePoolUniqueCount = grouped.length;
    modal.__pricePoolHistoryCount = rows.length;

    const platformCell = (cell) => {
      const formattedPrice = formatPrice(cell && cell.price != null ? cell.price : "-");
      const url = cell && cell.url ? String(cell.url).trim() : "";
      if (!url) return `<span>${escapeHtml(formattedPrice)}</span>`;
      return `<a href="${escapeHtml(url)}" target="_blank" rel="noopener" class="price-pool-price-link">${escapeHtml(formattedPrice)}</a>`;
    };

    tbody.innerHTML = grouped.map((row) => {
      return `
        <tr>
          <td>${escapeHtml(row.name)}</td>
          <td class="text-center">${platformCell(row.platforms.n11)}</td>
          <td class="text-center">${platformCell(row.platforms.trendyol)}</td>
          <td class="text-center">${platformCell(row.platforms.hepsiburada)}</td>
          <td class="text-center">${platformCell(row.platforms.amazon)}</td>
          <td class="text-center">${platformCell(row.platforms.pazarama)}</td>
          <td class="text-center">${platformCell(row.platforms.pttavm)}</td>
          <td class="text-center">${platformCell(row.platforms.idefix)}</td>
          <td class="text-center">${platformCell(row.platforms.teknosa)}</td>
          <td>${escapeHtml(formatDateTime(row.latestCreatedAt))}</td>
        </tr>
      `;
    }).join("");
  };

  const updatePoolModalData = async (modal, options = {}) => {
    const withSync = Boolean(options.withSync);
    setPoolStatus(modal, "Veriler yükleniyor...", "info");
    const totalEl = modal.querySelector("#price-pool-total");
    try {
      if (withSync) {
        const localRows = await fetchTrackingRowsFromStorage();
        const syncResult = await syncRowsFromTracking(localRows, { interactive: true });
        if (syncResult && syncResult.ok === false) {
          setPoolStatus(modal, `Senkron yapılamadı: ${syncResult.reason || "bilinmeyen hata"}`, "error");
        }
      }
      const [recent, totalCount] = await Promise.all([fetchRecentPoolRows(), fetchPoolCount()]);
      modal.__pricePoolRows = Array.isArray(recent) ? recent : [];
      renderPoolRows(modal, recent);
      const uniqueCount = Number(modal.__pricePoolUniqueCount || 0);
      const historyCount = Number(modal.__pricePoolHistoryCount || 0);
      if (totalEl) {
        totalEl.textContent = `Toplam ürün: ${uniqueCount} | History: ${Number(totalCount || historyCount || 0)}`;
      }
      setPoolStatus(modal, `Liste güncellendi. Ürün sayısı: ${uniqueCount}`, "success");
      await renderIntoBox();
    } catch (error) {
      console.error("Price Pool modal data error:", error);
      setPoolStatus(modal, "Veriler alınamadı. Konsolu kontrol edin.", "error");
    }
  };

  const renderIntoBox = async (boxEl) => {
    try {
      const target = boxEl || document.getElementById(PRICE_POOL_BOX_ID);
      if (!target) return;
      const hintEl = target.querySelector(".hint");
      if (!hintEl) return;
      const auth = await ensureAuthSession(getConfig(), false);
      if (!auth.ok) {
        hintEl.textContent = "Price Pool (Login gerekli)";
        return;
      }
      const count = await fetchPoolCount();
      hintEl.textContent = count > 0 ? `Price Pool (${count} kayit)` : "Price Pool";
    } catch {
      // Keep UI stable even if Supabase is unavailable
    }
  };

  const openFromTrackingBox = async () => {
    const config = getConfig();
    const auth = await ensureAuthSession(config, true);
    if (!auth.ok) {
      return;
    }
    const modal = ensurePoolModal();
    modal.style.display = "flex";
    const syncBtn = modal.querySelector("#price-pool-sync-btn");
    const refreshBtn = modal.querySelector("#price-pool-refresh-btn");
    const searchInput = modal.querySelector("#price-pool-search-input");
    if (syncBtn && !syncBtn.dataset.bound) {
      syncBtn.dataset.bound = "1";
      syncBtn.addEventListener("click", async () => {
        syncBtn.disabled = true;
        refreshBtn.disabled = true;
        await updatePoolModalData(modal, { withSync: true });
        syncBtn.disabled = false;
        refreshBtn.disabled = false;
      });
    }
    if (refreshBtn && !refreshBtn.dataset.bound) {
      refreshBtn.dataset.bound = "1";
      refreshBtn.addEventListener("click", async () => {
        refreshBtn.disabled = true;
        syncBtn.disabled = true;
        await updatePoolModalData(modal, { withSync: false });
        refreshBtn.disabled = false;
        syncBtn.disabled = false;
      });
    }
    if (searchInput && !searchInput.dataset.bound) {
      searchInput.dataset.bound = "1";
      searchInput.addEventListener("input", () => {
        renderPoolRows(modal, modal.__pricePoolRows || []);
      });
    }
    await updatePoolModalData(modal, { withSync: false });
  };

  // Backward compatibility: old click handlers may still call this.
  const sendCurrentProductToSupabase = async () => {
    await openFromTrackingBox();
  };

  window.n11PricePool = {
    syncSingleTrackingRow,
    syncRowsFromTracking,
    openFromTrackingBox,
    renderIntoBox,
    fetchRecentPoolRows,
    sendCurrentProductToSupabase
  };
})();
