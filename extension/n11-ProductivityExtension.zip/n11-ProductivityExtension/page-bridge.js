(() => {
  const SOURCE = "pageid-extension";
  let lastDynamicId = "";
  let lastProductId = "";
  let lastSellerId = "";
  let lastCategoryId = "";
  let lastIsCategory = "";
  let lastDataLayerPageName = "";
  let lastModelTotalCountKey = "\u0000";

  const emitModelTotalCount = () => {
    try {
      if (!window.model || typeof window.model !== "object") {
        return;
      }
      const raw = window.model.totalCount;
      if (raw == null || raw === "") {
        return;
      }
      const n = Number(raw);
      if (!Number.isFinite(n)) {
        return;
      }
      const key = String(n);
      if (key === lastModelTotalCountKey) {
        return;
      }
      lastModelTotalCountKey = key;
      window.postMessage({ source: SOURCE, modelTotalCount: n }, "*");
    } catch (error) {
      // ignore
    }
  };

  const emitDataLayerPageName = () => {
    try {
      const dl = window.dataLayer;
      if (!Array.isArray(dl)) {
        return;
      }
      const first = dl.filter((item) => item && item.pageName)[0];
      const name = first?.pageName != null ? String(first.pageName) : "";
      if (name === lastDataLayerPageName) {
        return;
      }
      lastDataLayerPageName = name;
      window.postMessage(
        { source: SOURCE, dataLayerPageName: name },
        "*"
      );
    } catch (error) {
      // ignore
    }
  };

  const emitDynamic = (id) => {
    const value = String(id || "");
    if (!value || value === lastDynamicId) {
      return;
    }
    lastDynamicId = value;
    try {
      window.postMessage({ source: SOURCE, dynamicPageId: value }, "*");
    } catch (error) {
      // ignore
    }
  };

  const emitProduct = (id) => {
    const value = String(id || "");
    if (!value || value === lastProductId) {
      return;
    }
    lastProductId = value;
    try {
      window.postMessage({ source: SOURCE, productId: value }, "*");
    } catch (error) {
      // ignore
    }
  };

  const emitSeller = (id) => {
    const value = String(id || "");
    if (!value || value === lastSellerId) {
      return;
    }
    lastSellerId = value;
    try {
      window.postMessage({ source: SOURCE, sellerId: value }, "*");
    } catch (error) {
      // ignore
    }
  };

  const emitCategory = (id) => {
    const value = String(id || "");
    if (!value || value === lastCategoryId) {
      return;
    }
    lastCategoryId = value;
    try {
      window.postMessage({ source: SOURCE, categoryId: value }, "*");
    } catch (error) {
      // ignore
    }
  };

  const emitIsCategory = (value) => {
    const stringValue = value ? "true" : "false";
    if (stringValue === lastIsCategory) {
      return;
    }
    lastIsCategory = stringValue;
    try {
      window.postMessage({ source: SOURCE, isCategoryPage: value }, "*");
    } catch (error) {
      // ignore
    }
  };

  const findProductIdDeep = () => {
    const visited = new Set();
    const candidates = [];
    const pushCandidate = (value) => {
      if (value == null) {
        return;
      }
      const str = String(value).trim();
      if (!/^\d+$/.test(str)) {
        return;
      }
      candidates.push(str);
    };
    const stack = [];
    if (window.model && typeof window.model === "object") {
      stack.push(window.model);
    }
    while (stack.length > 0) {
      const current = stack.pop();
      if (!current || typeof current !== "object") {
        continue;
      }
      if (visited.has(current)) {
        continue;
      }
      visited.add(current);
      if (Array.isArray(current)) {
        current.forEach((item) => stack.push(item));
        continue;
      }
      Object.entries(current).forEach(([key, value]) => {
        if (typeof key === "string" && key.toLowerCase() === "productid") {
          pushCandidate(value);
        } else if (value && typeof value === "object") {
          stack.push(value);
        }
      });
    }
    if (candidates.length === 0) {
      return "";
    }
    candidates.sort((a, b) => b.length - a.length);
    return candidates[0];
  };

  const readModel = () => {
    try {
      if (window.model && window.model.dynamicPage && window.model.dynamicPage.id) {
        emitDynamic(window.model.dynamicPage.id);
      }
      const productId = findProductIdDeep();
      if (productId) {
        emitProduct(productId);
      }
      if (
        window.model &&
        window.model.sellerInfo &&
        window.model.sellerInfo.sellerShopDto &&
        window.model.sellerInfo.sellerShopDto.sellerId
      ) {
        emitSeller(window.model.sellerInfo.sellerShopDto.sellerId);
      }
      if (window.model && window.model.data && window.model.data.categoryIdForSeo) {
        emitCategory(window.model.data.categoryIdForSeo);
      } else if (window.model && window.model.biddingAdImpression) {
        if (window.model.biddingAdImpression.pageTypeValue) {
          emitCategory(window.model.biddingAdImpression.pageTypeValue);
        }
      }
      if (window.model && typeof window.model._isCategoryPage !== "undefined") {
        emitIsCategory(Boolean(window.model._isCategoryPage));
      }
    } catch (error) {
      // ignore
    }
    return Boolean(lastDynamicId || lastProductId || lastSellerId || lastCategoryId);
  };

  let tries = 0;
  const maxTries = 60;
  const timer = window.setInterval(() => {
    tries += 1;
    emitDataLayerPageName();
    emitModelTotalCount();
    readModel();
    if (tries >= maxTries) {
      window.clearInterval(timer);
    }
  }, 500);

  emitDataLayerPageName();
  emitModelTotalCount();
  readModel();
})();
