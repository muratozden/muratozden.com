const collectN11Links = async (productOnly, windowId) => {
  let query = {};
  if (typeof windowId === "number" && windowId >= 0) {
    query = { windowId };
  } else {
    query = { lastFocusedWindow: true };
  }
  const tabs = await chrome.tabs.query(query);
  const links = [];

  for (const tab of tabs) {
    const url = tab.url || "";
    if (!url.startsWith("https://www.n11.com")) {
      continue;
    }
    if (productOnly) {
      if (url.includes("https://www.n11.com/urun/")) {
        links.push(url);
      }
      continue;
    }
    links.push(url);
  }

  return links;
};

const TOGGLE_MENU_ID = "toggle-extension-ui";

const ensureContextMenu = () => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: TOGGLE_MENU_ID,
      title: "Extension Gizle / Göster",
      contexts: ["all"]
    });
  });
};

const STORAGE_KEY_UI_HIDDEN = "extensionUiHidden";
const CONTAINER_ID = "pageid-extension-container";
const TOGGLE_MODAL_IDS = [
  "pageid-extension-modal",
  "pageid-extension-url-modal",
  "pageid-extension-productid-url-modal",
  "id-sku-extension-modal",
  "pims-id-extension-modal",
  "listing-product-crawler-extension-modal",
  "offer-controller-extension-modal",
  "akakce-product-crawler-extension-modal",
  "pageid-extension-bo-modal",
  "pagechecker-extension-modal",
  "bannerchecker-extension-modal",
  "editorial-controller-extension-modal",
  "price-protector-extension-modal",
  "akakce-id-n11-product-extension-modal",
  "seller-products-crawler-extension-modal",
  "seller-product-match-extension-modal",
  "hepsiburada-seller-products-crawler-extension-modal",
  "product-deal-controller-extension-modal",
  "seller-product-count-extension-modal",
  "promotion-theme-pin-extension-modal",
  "so-announcement-popup-extension-modal",
  "banner-mailing-extension-modal",
  "logo-resizer-extension-modal",
  "logo-list-extension-modal"
];

const arrayBufferToBase64 = (buffer) => {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
};

const fetchImageAsDataUrl = async (url) => {
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
      "Accept-Language": "tr-TR,tr;q=0.9",
      Referer: "https://www.n11.com/",
      Origin: "https://www.n11.com/",
      "User-Agent":
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    },
    credentials: "omit"
  });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  const blob = await response.blob();
  const mime = String(blob.type || "").trim() || "image/jpeg";
  if (!mime.startsWith("image/")) {
    throw new Error(`Unexpected content type: ${mime}`);
  }
  const base64 = arrayBufferToBase64(await blob.arrayBuffer());
  return `data:${mime};base64,${base64}`;
};

/** Sayfada UI görünürlüğünü doğrudan uygular (content script yanıt vermediğinde yedek). */
const applyVisibilityInTab = (tabId, hidden) => {
  chrome.scripting.executeScript({
    target: { tabId },
    func: (containerId, modalIds, isHidden) => {
      const container = document.getElementById(containerId);
      if (container) {
        container.style.display = isHidden ? "none" : "";
      }
      if (document.body) {
        document.body.dataset.extensionHidden = isHidden ? "true" : "false";
      }
      if (isHidden) {
        modalIds.forEach((id) => {
          const el = document.getElementById(id);
          if (el && el.style.display !== "none") el.style.display = "none";
        });
      }
    },
    args: [CONTAINER_ID, TOGGLE_MODAL_IDS, hidden]
  }).catch(() => {});
};

const SELLER_PRODUCT_COUNT_KEYS = {
  sellers: "sellerProductCountSellers",
  results: "sellerProductCountResults"
};

const sellerProductCountExtractFirstInt = (text) => {
  if (!text) return null;
  const m = String(text).match(/\d[\d.,]*/);
  if (!m) return null;
  const n = parseInt(m[0].replace(/[.,]/g, ""), 10);
  return Number.isFinite(n) ? n : null;
};

const sellerProductCountFetch = (url) =>
  fetch(url, {
    method: "GET",
    headers: {
      Accept: "text/html,application/xhtml+xml,*/*;q=0.9",
      "Accept-Language": "tr-TR,tr;q=0.9"
    }
  }).then((r) => {
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.text();
  });

const sellerProductCountParseHtml = (html) => {
  try {
    if (typeof DOMParser === "undefined") return null;
    return new DOMParser().parseFromString(html, "text/html");
  } catch (_) {
    return null;
  }
};

const sellerProductCountScrapeN11 = async (url) => {
  const html = await sellerProductCountFetch(url);
  let count = null;
  const fromModel = html.match(/model\.sellerInfo\.sellerProductsCount\s*[=:]\s*(\d+)/) ||
    html.match(/"sellerProductsCount"\s*:\s*(\d+)/) ||
    html.match(/sellerInfo[\s\S]*?"sellerProductsCount"\s*:\s*(\d+)/);
  if (fromModel && fromModel[1]) {
    const n = parseInt(fromModel[1], 10);
    if (Number.isFinite(n)) return n;
  }
  const doc = sellerProductCountParseHtml(html);
  if (doc) {
    const el = doc.querySelector(".listingGroup .resultText strong");
    if (el) count = sellerProductCountExtractFirstInt(el.textContent);
  }
  if (count == null) {
    const m = html.match(/listingGroup[\s\S]*?resultText[\s\S]*?<strong[^>]*>([^<]+)/i);
    if (m && m[1]) count = sellerProductCountExtractFirstInt(m[1]);
  }
  if (count == null) throw new Error("Sonuç sayısı bulunamadı (n11)");
  return count;
};

const sellerProductCountScrapeHepsiburada = async (url) => {
  const html = await sellerProductCountFetch(url);
  const doc = sellerProductCountParseHtml(html);
  if (doc) {
    const el = doc.querySelector("#merchantSubInfos strong");
    if (el) {
      const c = sellerProductCountExtractFirstInt(el.textContent);
      if (c !== null) return c;
    }
  }
  const m = html.match(/"totalProductCount"\s*:\s*(\d+)/i);
  if (m && m[1]) return parseInt(m[1], 10);
  const scripts = doc ? doc.querySelectorAll("script") : [];
  for (const s of scripts) {
    const mm = (s.textContent || "").match(/"totalProductCount"\s*:\s*(\d+)/i);
    if (mm && mm[1]) return parseInt(mm[1], 10);
  }
  throw new Error("totalProductCount bulunamadı");
};

const sellerProductCountScrapeTrendyol = async (url) => {
  const html = await sellerProductCountFetch(url);
  const doc = sellerProductCountParseHtml(html);
  const re = /(\d[\d.,\s]*)\s*\+?\s*Ürün/gi;
  const nums = [];
  let match;
  while ((match = re.exec(html)) !== null) {
    const n = parseInt((match[1] || "").replace(/\D/g, ""), 10);
    if (Number.isFinite(n) && n > 10) nums.push(n);
  }
  if (nums.length > 0) return Math.max(...nums);
  const re2 = /"totalCount"\s*:\s*(\d+)/i;
  const m = html.match(re2);
  if (m && m[1]) return parseInt(m[1], 10);
  throw new Error("totalCount bulunamadı (Trendyol)");
};

const sellerProductCountGetSellers = () =>
  chrome.storage.local.get(SELLER_PRODUCT_COUNT_KEYS.sellers).then((o) => {
    const list = o[SELLER_PRODUCT_COUNT_KEYS.sellers];
    return Array.isArray(list) ? list : [];
  });

const sellerProductCountSaveSellers = (sellers) => {
  const clean = (Array.isArray(sellers) ? sellers : []).map((s) => {
    const brand = String(s.brand || "").trim();
    const n11Url = String(s.n11Url || "").trim();
    const trendyolUrl = String(s.trendyolUrl || "").trim();
    const hepsiburadaUrl = String(s.hepsiburadaUrl || "").trim();
    const id = s.id || (Date.now().toString(36) + Math.random().toString(36).slice(2));
    return { id, brand, n11Url, trendyolUrl, hepsiburadaUrl };
  });
  return chrome.storage.local.set({ [SELLER_PRODUCT_COUNT_KEYS.sellers]: clean }).then(() => clean);
};

const sellerProductCountGetResults = () =>
  chrome.storage.local.get(SELLER_PRODUCT_COUNT_KEYS.results).then((o) => {
    const list = o[SELLER_PRODUCT_COUNT_KEYS.results];
    return Array.isArray(list) ? list : [];
  });

const sellerProductCountSaveResults = (results) =>
  chrome.storage.local.set({
    [SELLER_PRODUCT_COUNT_KEYS.results]: Array.isArray(results) ? results : []
  });

const sellerProductCountClearData = () =>
  chrome.storage.local.remove([SELLER_PRODUCT_COUNT_KEYS.sellers, SELLER_PRODUCT_COUNT_KEYS.results]);

const sellerProductCountScrapeForSeller = async (seller) => {
  const out = {
    sellerId: seller.id,
    brand: seller.brand || "",
    n11: { ok: false, count: null, error: null },
    trendyol: { ok: false, count: null, error: null },
    hepsiburada: { ok: false, count: null, error: null }
  };
  const tasks = [];
  if (seller.n11Url) {
    tasks.push(
      sellerProductCountScrapeN11(seller.n11Url)
        .then((c) => { out.n11 = { ok: true, count: c, error: null }; })
        .catch((e) => { out.n11 = { ok: false, count: null, error: e && e.message ? e.message : String(e) }; })
    );
  }
  if (seller.trendyolUrl) {
    tasks.push(
      sellerProductCountScrapeTrendyol(seller.trendyolUrl)
        .then((c) => { out.trendyol = { ok: true, count: c, error: null }; })
        .catch((e) => { out.trendyol = { ok: false, count: null, error: e && e.message ? e.message : String(e) }; })
    );
  }
  if (seller.hepsiburadaUrl) {
    tasks.push(
      sellerProductCountScrapeHepsiburada(seller.hepsiburadaUrl)
        .then((c) => { out.hepsiburada = { ok: true, count: c, error: null }; })
        .catch((e) => { out.hepsiburada = { ok: false, count: null, error: e && e.message ? e.message : String(e) }; })
    );
  }
  if (tasks.length === 0) {
    return out;
  }
  await Promise.all(tasks);
  return out;
};

const sendToggleMessage = (tabId) => {
  if (!tabId) {
    return;
  }
  chrome.tabs.sendMessage(tabId, { type: "toggle-extension-ui" }, (response) => {
    if (chrome.runtime.lastError || !response) {
      chrome.storage.local.get(STORAGE_KEY_UI_HIDDEN, (result) => {
        const nextHidden = !Boolean(result[STORAGE_KEY_UI_HIDDEN]);
        chrome.storage.local.set({ [STORAGE_KEY_UI_HIDDEN]: nextHidden }, () => {
          applyVisibilityInTab(tabId, nextHidden);
        });
      });
    }
  });
};

chrome.runtime.onInstalled.addListener(() => {
  ensureContextMenu();
});

chrome.runtime.onStartup.addListener(() => {
  ensureContextMenu();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== TOGGLE_MENU_ID) {
    return;
  }
  if (tab && tab.id) {
    sendToggleMessage(tab.id);
    return;
  }
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].id) {
      sendToggleMessage(tabs[0].id);
    }
  });
});

chrome.commands.onCommand.addListener((command) => {
  if (command !== "toggle-extension-ui") {
    return;
  }
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].id) {
      sendToggleMessage(tabs[0].id);
    }
  });
});

const AKAKCE_THROTTLE_EVERY = 25;
const AKAKCE_THROTTLE_PAUSE_MS = 5000;
const STORAGE_KEY_AKAKCE_FLOW_COUNT = "akakceFlowCount";

const awaitAkakceThrottle = (senderTabId) => {
  return new Promise((resolve) => {
    chrome.storage.local.get(STORAGE_KEY_AKAKCE_FLOW_COUNT, (data) => {
      const count = (data[STORAGE_KEY_AKAKCE_FLOW_COUNT] || 0) + 1;
      chrome.storage.local.set({ [STORAGE_KEY_AKAKCE_FLOW_COUNT]: count }, () => {
        if (count % AKAKCE_THROTTLE_EVERY === 0 && count > 0) {
          if (senderTabId) {
            chrome.tabs.sendMessage(senderTabId, { type: "akakce-throttle-wait", seconds: AKAKCE_THROTTLE_PAUSE_MS / 1000 }).catch(() => {});
          }
          setTimeout(resolve, AKAKCE_THROTTLE_PAUSE_MS);
        } else {
          resolve();
        }
      });
    });
  });
};

const decodeHtmlEntities = (value) => {
  if (!value) return "";
  return String(value)
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
};

const stripHtmlTags = (value) => {
  if (!value) return "";
  return decodeHtmlEntities(String(value).replace(/<[^>]*>/g, " "))
    .replace(/\s+/g, " ")
    .trim();
};

const parseFirstPriceFromText = (text) => {
  if (!text) return "";
  const m = String(text).match(/\d{1,3}(?:\.\d{3})*(?:,\d{2})?\s*TL|\d{1,3}(?:\.\d{3})*(?:,\d{2})?/i);
  return m && m[0] ? m[0].replace(/\s+/g, " ").trim() : "";
};

const extractAkakceUrlFromGoogleHtml = (html) => {
  if (!html) return "";
  const hrefMatches = html.match(/href="([^"]+)"/g) || [];
  for (const rawHref of hrefMatches) {
    const href = rawHref.slice(6, -1);
    const decoded = decodeHtmlEntities(href);
    let candidate = decoded;
    if (/^\/url\?/i.test(decoded)) {
      const qMatch = decoded.match(/[?&]q=([^&]+)/i);
      if (qMatch && qMatch[1]) {
        candidate = decodeURIComponent(qMatch[1].replace(/\+/g, " "));
      }
    }
    if (!candidate.includes("akakce.com")) {
      continue;
    }
    try {
      const u = new URL(candidate);
      if (!/(\.|^)akakce\.com$/i.test(u.hostname)) {
        continue;
      }
      if (u.pathname === "/" || u.pathname === "") {
        continue;
      }
      return u.toString();
    } catch {
      // ignore malformed candidate
    }
  }
  return "";
};

const parseAkakceListDataFromHtml = (html) => {
  if (!html) {
    return { items: [], title: "", n11Link: null, allPrices: [], bestPrice: "", redirectedToHome: false };
  }
  const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  const title = titleMatch ? stripHtmlTags(titleMatch[1]) : "";
  const ulMatch = html.match(/<ul[^>]+id=["']PL["'][^>]*>([\s\S]*?)<\/ul>/i);
  if (!ulMatch) {
    return { items: [], title, n11Link: null, allPrices: [], bestPrice: "", redirectedToHome: true };
  }

  const ulHtml = ulMatch[1];
  const liMatches = ulHtml.match(/<li\b[\s\S]*?<\/li>/gi) || [];
  const items = [];
  const allPrices = [];
  let n11Link = null;

  const domainToBrand = {
    "trendyol.com": "Trendyol",
    "n11.com": "n11",
    "hepsiburada.com": "Hepsiburada",
    "amazon.com.tr": "Amazon Türkiye",
    "pazarama.com": "Pazarama",
    "pttavm.com": "PttAVM",
    "idefix.com": "idefix"
  };

  for (const li of liMatches) {
    const hrefMatch = li.match(/<a[^>]+href=["']([^"']+)["']/i);
    const href = hrefMatch ? decodeHtmlEntities(hrefMatch[1]) : "";
    const altMatch = li.match(/<img[^>]+alt=["']([^"']+)["']/i);
    const rawAlt = altMatch ? stripHtmlTags(altMatch[1]) : "";
    const altKey = rawAlt.toLowerCase().replace(/\s+/g, "");
    const brandMap = {
      trendyol: "Trendyol",
      trendyolplus: "Trendyol",
      n11: "n11",
      "amazontürkiye": "Amazon Türkiye",
      amazonturkiye: "Amazon Türkiye",
      hepsiburada: "Hepsiburada",
      pazarama: "Pazarama",
      pttavm: "PttAVM",
      "pttavm.com": "PttAVM",
      idefix: "idefix"
    };
    let brand = brandMap[altKey] || null;
    if (!brand && href) {
      for (const [domain, b] of Object.entries(domainToBrand)) {
        if (href.includes(domain)) {
          brand = b;
          break;
        }
      }
    }
    if (!brand) {
      continue;
    }
    if (brand === "n11" && href && !n11Link) {
      n11Link = href;
    }
    const productNameMatch = li.match(/class=["'][^"']*(?:pn_v8|pn_v9)[^"']*["'][^>]*>([\s\S]*?)<\/[^>]+>/i);
    const productName = productNameMatch ? stripHtmlTags(productNameMatch[1]) : "";
    const price = parseFirstPriceFromText(stripHtmlTags(li));
    if (price) {
      allPrices.push(price);
    }
    items.push({ brand, productName, price });
  }

  let bestPrice = "";
  if (items.length > 0) {
    const first = items[0];
    bestPrice = `${first.brand || "?"} - ${first.price || "-"}`;
  }
  return { items, title, n11Link, allPrices, bestPrice, redirectedToHome: false };
};

const extractProductIdFromN11Html = (html) => {
  if (!html) return "";
  const patterns = [
    /window\.model\.product\.id\s*=\s*["']?(\d+)["']?/i,
    /model\.product\.id\s*=\s*["']?(\d+)["']?/i,
    /"productId"\s*:\s*["']?(\d+)["']?/i,
    /"id"\s*:\s*["']?(\d{7,})["']?\s*,\s*"sellerId"/i
  ];
  for (const re of patterns) {
    const m = html.match(re);
    if (m && m[1]) return String(m[1]).trim();
  }
  return "";
};

const tryAkakceFlowNoTab = async ({ googleUrl, productId, productName, productUrl, n11PriceFromContent, sellerNickName, idFromN11Url }) => {
  try {
    const googleResp = await fetch(googleUrl, { credentials: "omit" });
    if (!googleResp.ok) return { ok: false };
    const googleHtml = await googleResp.text();
    const akakceUrl = extractAkakceUrlFromGoogleHtml(googleHtml);
    if (!akakceUrl) return { ok: false };

    const akakceResp = await fetch(akakceUrl, { credentials: "omit" });
    if (!akakceResp.ok) return { ok: false };
    const akakceHtml = await akakceResp.text();
    const parsed = parseAkakceListDataFromHtml(akakceHtml);
    if (!Array.isArray(parsed.items) || parsed.items.length === 0) return { ok: false };

    let resolvedProductId = productId;
    if (!resolvedProductId && parsed.n11Link) {
      try {
        const n11Resp = await fetch(parsed.n11Link, { credentials: "omit" });
        if (n11Resp.ok) {
          const n11Html = await n11Resp.text();
          resolvedProductId = extractProductIdFromN11Html(n11Html) || resolvedProductId;
        }
      } catch {
        // no-op
      }
    }

    const payload = {
      productId: resolvedProductId,
      productName: parsed.title || productName,
      data: parsed.items,
      akakceUrl,
      akakceOriginalUrl: akakceUrl,
      allPrices: Array.isArray(parsed.allPrices) ? parsed.allPrices : [],
      bestPrice: parsed.bestPrice != null ? String(parsed.bestPrice).trim() : "",
      idFromN11Url
    };
    if (n11PriceFromContent) payload.n11Price = n11PriceFromContent;
    if (productUrl) payload.productUrl = productUrl;
    if (sellerNickName) payload.sellerNickName = sellerNickName;
    if (parsed.redirectedToHome) payload.redirectedToHome = true;
    return { ok: true, payload };
  } catch {
    return { ok: false };
  }
};

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "akakce-flow" && port.name !== "price-protector-flow") return;
  const resultMessageType = port.name === "price-protector-flow" ? "price-protector-page-data" : "akakce-page-data";
  port.onMessage.addListener((msg) => {
    const googleUrl = (msg.googleUrl || "").trim();
    const senderTabId = port.sender?.tab?.id || null;
    const productId = (msg.productId != null && msg.productId !== "") ? String(msg.productId) : "";
    const productName = (msg.productName != null) ? String(msg.productName) : "";
    const productUrl = (msg.productUrl || "").trim();
    const n11PriceFromContent = (msg.n11Price != null && String(msg.n11Price).trim() !== "") ? String(msg.n11Price).trim() : "";
    const sellerNickName = (msg.sellerNickName != null && String(msg.sellerNickName).trim() !== "") ? String(msg.sellerNickName).trim() : "";
    const idFromN11Url = msg.isFromN11Url === true;
    if (!googleUrl || !googleUrl.includes("google.com")) {
      port.postMessage({ error: "Geçersiz URL" });
      return;
    }
    awaitAkakceThrottle(senderTabId).then(() => {
      tryAkakceFlowNoTab({
        googleUrl,
        productId,
        productName,
        productUrl,
        n11PriceFromContent,
        sellerNickName,
        idFromN11Url
      }).then((noTabResult) => {
        if (noTabResult && noTabResult.ok && noTabResult.payload) {
          if (senderTabId) {
            chrome.tabs.sendMessage(senderTabId, {
              type: resultMessageType,
              ...noTabResult.payload
            }).catch(() => {});
          }
          port.postMessage({ ok: true });
          return;
        }
        chrome.tabs.create({ url: googleUrl, active: false }).then((tab) => {
        if (!tab || !tab.id) {
          port.postMessage({ error: "Sekme açılamadı." });
          return;
        }
        const tabId = tab.id;
        let listenerHandled = false;
        const listener = (updatedId, info) => {
          if (updatedId !== tabId || info.status !== "complete") return;
          if (listenerHandled) return;
          listenerHandled = true;
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.scripting
            .executeScript({
              target: { tabId },
              func: () => {
                const isProductUrl = (u) => {
                  try {
                    const url = new URL(u);
                    if (!/akakce\.com$/i.test(url.hostname)) return false;
                    if (url.pathname === "/" || url.pathname === "") return false;
                  } catch (e) {}
                  if (/,(\d+)\.html\b/i.test(u)) return true;
                  if (/en-ucuz/i.test(u)) return true;
                  return false;
                };
                const isGoogleAdResult = (anchor) => {
                  if (!anchor) return false;
                  const block =
                    anchor.closest("div[data-text-ad]") ||
                    anchor.closest("div[data-sokoban-container]") ||
                    anchor.closest("div[data-pla-slot-pos]") ||
                    anchor.closest("div.g") ||
                    anchor.parentElement;
                  const text = String(block?.innerText || "")
                    .replace(/\s+/g, " ")
                    .toLowerCase();
                  return (
                    text.includes("ücretli sponsorlu reklam") ||
                    text.includes("sponsorlu reklam") ||
                    text.includes("sponsorlu") ||
                    text.includes("sponsored")
                  );
                };

                const anchors = Array.from(
                  document.querySelectorAll('a[href*="akakce.com"]')
                );
                const seen = new Set();
                const candidates = anchors
                  .map((a) => {
                    const href = a && a.href ? a.href : "";
                    return {
                      href,
                      isSponsored: isGoogleAdResult(a)
                    };
                  })
                  .filter(
                    (x) =>
                      x.href &&
                      !x.href.includes("webcache") &&
                      !x.href.includes("translate.google")
                  )
                  .filter((x) => {
                    if (seen.has(x.href)) return false;
                    seen.add(x.href);
                    return true;
                  });
                if (!candidates.length) return null;

                const productCandidates = candidates.filter((x) =>
                  isProductUrl(x.href)
                );
                const pool = productCandidates.length ? productCandidates : candidates;

                // Google ilk sonucu sponsorlu reklamsa organik olan bir sonraki sonucu seç.
                if (pool[0]?.isSponsored && pool[1]) {
                  const nextOrganic = pool.find((x, idx) => idx > 0 && !x.isSponsored);
                  return (nextOrganic && nextOrganic.href) || pool[1].href;
                }
                return pool[0].href;
              }
            })
            .then((results) => {
              const akakceUrl = results && results[0] && results[0].result;
              if (!akakceUrl) {
                if (senderTabId) {
                  chrome.tabs.sendMessage(senderTabId, {
                    type: resultMessageType,
                    productId,
                    productName,
                    productUrl,
                    akakceUrl: "",
                    data: [],
                    allPrices: [],
                    n11Price: n11PriceFromContent,
                    sellerNickName,
                    idFromN11Url
                  }).catch(() => {});
                }
                port.postMessage({ ok: true });
                chrome.tabs.remove(tabId).catch(() => {});
                return;
              }
              chrome.tabs.update(tabId, { url: akakceUrl, active: false }).then((updatedTab) => {
                if (!updatedTab || !updatedTab.id) {
                  port.postMessage({ ok: true });
                  return;
                }
                const akakceTabId = tabId;
                let loadListenerHandled = false;
                const loadListener = (updatedId, info) => {
                  if (updatedId !== akakceTabId || info.status !== "complete") return;
                  if (loadListenerHandled) return;
                  loadListenerHandled = true;
                  chrome.tabs.onUpdated.removeListener(loadListener);
                  const isCloudflare = () => chrome.scripting.executeScript({
                    target: { tabId: akakceTabId },
                    func: () => /Performing security verification|security check|Cloudflare|Just a moment/i.test(document.body?.innerText || "")
                  }).then((r) => r && r[0] && r[0].result === true);
                  const waitForContent = (attempt = 0) => {
                    return new Promise((r) => setTimeout(r, 2000))
                      .then(() => isCloudflare())
                      .then((cf) => (cf && attempt < 2) ? waitForContent(attempt + 1) : Promise.resolve());
                  };
                  waitForContent(0)
                    .then(() => chrome.scripting.executeScript({
                      target: { tabId: akakceTabId },
                      func: function extractAkakceListData() {
                        const brandMap = {
                          "trendyol": "Trendyol",
                          "trendyolplus": "Trendyol",
                          "n11": "n11",
                          "amazon türkiye": "Amazon Türkiye",
                          "amazon turkiye": "Amazon Türkiye",
                          "hepsiburada": "Hepsiburada",
                          "pazarama": "Pazarama",
                          "pttavm": "PttAVM",
                          "ptt avm": "PttAVM",
                          "idefix": "idefix"
                        };
                        const domainToBrand = {
                          "trendyol.com": "Trendyol",
                          "n11.com": "n11",
                          "hepsiburada.com": "Hepsiburada",
                          "amazon.com.tr": "Amazon Türkiye",
                          "pazarama.com": "Pazarama",
                          "pttavm.com": "PttAVM",
                          "idefix.com": "idefix"
                        };
                        const path = (window.location && window.location.pathname) ? window.location.pathname : "";
                        const isHomeLike = path === "/" || path === "" || /^\/(anasayfa|home|index(\.php)?)$/i.test(path);
                        const titleEl = document.querySelector("#pd_v8 h1");
                        const pageTitle = titleEl ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
                        const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
                        let n11Link = null;
                        const allPrices = [];
                        if (!ul) return { items: [], title: pageTitle, n11Link: null, allPrices: [], bestPrice: "", redirectedToHome: isHomeLike };
                        const items = [];
                        ul.querySelectorAll("li").forEach((li) => {
                          let brand = null;
                          const link = li.querySelector("a[href]");
                          const img = li.querySelector("img");
                          if (img && img.alt) {
                            const rawBrand = (img.alt || "").trim();
                            const brandKey = rawBrand.toLowerCase().replace(/\s+/g, "");
                            brand =
                              brandMap[brandKey] ||
                              ([
                                "Trendyol",
                                "n11",
                                "Amazon Türkiye",
                                "Hepsiburada",
                                "Pazarama",
                                "PttAVM",
                                "idefix"
                              ].includes(rawBrand)
                                ? rawBrand
                                : null);
                          }
                          if (!brand && link && link.href) {
                            for (const [domain, b] of Object.entries(domainToBrand)) {
                              if (link.href.includes(domain)) { brand = b; break; }
                            }
                          }
                          if (brand === "n11" && link && link.href) n11Link = link.href;
                          const pb = li.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
                          let price = "";
                          if (pb) {
                            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
                            if (cmpgn) price = cmpgn.textContent.replace(/\s+/g, " ").trim();
                            else { const pt = pb.querySelector(".pt_v8, .pt_v9, [class*='pt_']"); if (pt) price = pt.textContent.replace(/\s+/g, " ").trim(); }
                          }
                          if (price && price.trim()) allPrices.push(price.trim());
                          if (!brand) return;
                          const nameEl = li.querySelector(".pn_v8, .pn_v9, [class*='pn_']");
                          const productName = nameEl ? nameEl.textContent.replace(/\s+/g, " ").trim() : "";
                          items.push({ brand, productName, price });
                        });
                        let bestPrice = "";
                        const firstLi = ul.querySelector("li");
                        if (firstLi) {
                          const img = firstLi.querySelector("img");
                          const pb = firstLi.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
                          let price = "";
                          if (pb) {
                            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
                            if (cmpgn) price = cmpgn.textContent.replace(/\s+/g, " ").trim();
                            else { const pt = pb.querySelector(".pt_v8, ".concat(".pt_v9, [class*='pt_']")); if (pt) price = pt.textContent.replace(/\s+/g, " ").trim(); }
                          }
                          let label = "";
                          if (img && img.alt) {
                            label = String(img.alt).trim();
                          } else {
                            const sellerEl = firstLi.querySelector(".w_v8 .v_v8 b, .v_v8 b, .w_v8 b");
                            if (sellerEl && sellerEl.textContent) {
                              label = sellerEl.textContent.replace(/\s+/g, " ").trim();
                            }
                          }
                          if (!label) label = "?";
                          bestPrice = label + " - " + (price && price.trim() ? price.trim() : "-");
                        }
                        return { items, title: pageTitle, n11Link, allPrices, bestPrice, redirectedToHome: false };
                      }
                    }))
                    .then((extractResults) => {
                      const raw = extractResults && extractResults[0] && extractResults[0].result;
                      const data = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.items) ? raw.items : []);
                      const akakceTitle = (raw && raw.title) ? String(raw.title).trim() : "";
                      const finalProductName = akakceTitle || productName;
                      let resolvedProductId = productId;
                      const n11Link = (raw && raw.n11Link) ? String(raw.n11Link).trim() : "";
                      const redirectedToHome = Boolean(raw && raw.redirectedToHome);
                      const fetchProductIdFromN11Link = (url) => {
                        if (!url || (!url.includes("akakce.com") && !url.includes("n11.com"))) return Promise.resolve("");
                        return chrome.tabs.create({ url, active: false }).then((tab) => {
                          if (!tab || !tab.id) return Promise.resolve("");
                          const n11TabId = tab.id;
                          const waitForN11 = (attempt) => {
                            if (attempt >= 12) return chrome.tabs.remove(n11TabId).then(() => "");
                            return new Promise((r) => setTimeout(r, attempt === 0 ? 2000 : 1500))
                              .then(() => chrome.tabs.get(n11TabId))
                              .then((t) => (t.url || "").includes("n11.com/urun/") ? n11TabId : null)
                              .catch(() => null)
                              .then((tid) => {
                                if (tid) return tid;
                                return waitForN11(attempt + 1);
                              });
                          };
                          return waitForN11(0)
                            .then((tid) => {
                              if (!tid) return "";
                              return new Promise((r) => setTimeout(r, 1500))
                                .then(() => chrome.scripting.executeScript({
                                  target: { tabId: tid },
                                  func: () => {
                                    try {
                                      if (window.model && window.model.product && window.model.product.id != null) return String(window.model.product.id);
                                      if (window.model && window.model.productMeta && window.model.productMeta.productId != null) return String(window.model.productMeta.productId);
                                    } catch (e) {}
                                    return "";
                                  }
                                }))
                                .then((res) => (res && res[0] && res[0].result) ? res[0].result : "")
                                .finally(() => chrome.tabs.remove(n11TabId).catch(() => {}));
                            });
                        });
                      };
                    const sendResult = () => {
                      const allPrices = (raw && Array.isArray(raw.allPrices)) ? raw.allPrices : [];
                      const bestPrice = (raw && raw.bestPrice != null) ? String(raw.bestPrice).trim() : "";
                      const payload = {
                        type: resultMessageType,
                        productId: resolvedProductId,
                        productName: finalProductName,
                        data,
                        akakceUrl,
                        akakceOriginalUrl: akakceUrl,
                        allPrices,
                        bestPrice,
                        idFromN11Url
                      };
                        if (redirectedToHome) payload.redirectedToHome = true;
                        if (n11PriceFromContent) payload.n11Price = n11PriceFromContent;
                        if (productUrl) payload.productUrl = productUrl;
                        if (sellerNickName) payload.sellerNickName = sellerNickName;
                        if (senderTabId) chrome.tabs.sendMessage(senderTabId, payload).catch(() => {});
                        chrome.tabs.remove(akakceTabId).catch(() => {});
                        port.postMessage({ ok: true });
                      };
                      if (!resolvedProductId && n11Link && productUrl) {
                        fetchProductIdFromN11Link(n11Link).then((id) => {
                          resolvedProductId = id || resolvedProductId;
                          sendResult();
                        }).catch(() => sendResult());
                      } else {
                        sendResult();
                      }
                    })
                    .catch(() => {
                      if (port.name === "price-protector-flow" && senderTabId) {
                        chrome.tabs.sendMessage(senderTabId, {
                          type: resultMessageType,
                          productId,
                          productName,
                          productUrl,
                          akakceUrl,
                          data: [],
                          allPrices: [],
                          bestPrice: "",
                          n11Price: n11PriceFromContent,
                          sellerNickName,
                          idFromN11Url
                        }).catch(() => {});
                      }
                      chrome.tabs.remove(akakceTabId).catch(() => {});
                      port.postMessage({ ok: true });
                    });
                };
                chrome.tabs.onUpdated.addListener(loadListener);
              });
            })
            .catch(() => port.postMessage({ error: "Google sonuçlarından akakce linki bulunamadı." }));
        };
        chrome.tabs.onUpdated.addListener(listener);
        }).catch(() => port.postMessage({ error: "Bağlantı hatası." }));
      });
    });
  });
});

const runManuelUpdateFlow = (message, sender, sendResponse, resultType) => {
  const productId = (message.productId != null) ? String(message.productId) : "";
  const productName = (message.productName != null) ? String(message.productName) : "";
  const akakceUrl = (message.akakceUrl || "").trim();
  const rowIndex = typeof message.rowIndex === "number" ? message.rowIndex : -1;
  const n11TabId = sender?.tab?.id || null;
  if (!akakceUrl || !akakceUrl.includes("akakce.com")) {
    sendResponse({ ok: false, error: "Geçersiz Akakce URL" });
    return;
  }
  if (!n11TabId) {
    sendResponse({ ok: false, error: "Tab bulunamadı" });
    return;
  }
  const base = (akakceUrl.split("#")[0] || akakceUrl).trim();
  const url = base + (base.includes("?") ? "&" : "?") + "n11_manuel=1";
  const openPassive = resultType === "akakce-manuel-update-result";
  chrome.tabs.create({ url, active: !openPassive }).then((tab) => {
    if (!tab || !tab.id) {
      sendResponse({ ok: false, error: "Sekme açılamadı" });
      return;
    }
    const akakceTabId = tab.id;
    const extractData = () => chrome.scripting.executeScript({
      target: { tabId: akakceTabId },
      func: function extractAkakceListData() {
        const brandMap = {
          "trendyol": "Trendyol",
          "trendyolplus": "Trendyol",
          "n11": "n11",
          "amazon türkiye": "Amazon Türkiye",
          "amazon turkiye": "Amazon Türkiye",
          "hepsiburada": "Hepsiburada",
          "pazarama": "Pazarama",
          "pttavm": "PttAVM",
          "ptt avm": "PttAVM",
          "idefix": "idefix"
        };
        const domainToBrand = {
          "trendyol.com": "Trendyol",
          "n11.com": "n11",
          "hepsiburada.com": "Hepsiburada",
          "amazon.com.tr": "Amazon Türkiye",
          "pazarama.com": "Pazarama",
          "pttavm.com": "PttAVM",
          "idefix.com": "idefix"
        };
        const path = (window.location && window.location.pathname) ? window.location.pathname : "";
        const isHomeLike = path === "/" || path === "" || /^\/(anasayfa|home|index(\.php)?)$/i.test(path);
        const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
        if (!ul) return { items: [], allPrices: [], bestPrice: "", redirectedToHome: isHomeLike };
        const items = [];
        ul.querySelectorAll("li").forEach((li) => {
          let brand = null;
          const img = li.querySelector("img");
          if (img && img.alt) {
            const rawBrand = (img.alt || "").trim();
            const brandKey = rawBrand.toLowerCase().replace(/\s+/g, "");
            brand =
              brandMap[brandKey] ||
              ([
                "Trendyol",
                "n11",
                "Amazon Türkiye",
                "Hepsiburada",
                "Pazarama",
                "PttAVM",
                "idefix"
              ].includes(rawBrand)
                ? rawBrand
                : null);
          }
          if (!brand) {
            const link = li.querySelector(
              "a[href*='trendyol'], a[href*='n11.com'], a[href*='hepsiburada'], a[href*='amazon.com.tr'], a[href*='pazarama.com'], a[href*='pttavm.com'], a[href*='idefix.com']"
            );
            if (link && link.href) {
              for (const [domain, b] of Object.entries(domainToBrand)) {
                if (link.href.includes(domain)) { brand = b; break; }
              }
            }
          }
          if (!brand) return;
          const pb = li.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
          let price = "";
          if (pb) {
            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
            if (cmpgn) price = cmpgn.textContent.replace(/\s+/g, " ").trim();
            else { const pt = pb.querySelector(".pt_v8, .pt_v9, [class*='pt_']"); if (pt) price = pt.textContent.replace(/\s+/g, " ").trim(); }
          }
          items.push({ brand, price });
        });
        const allPrices = [];
        ul.querySelectorAll("li").forEach((li) => {
          const pb = li.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
          if (pb) {
            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
            const pt = !cmpgn ? pb.querySelector(".pt_v8, .pt_v9, [class*='pt_']") : null;
            const p = (cmpgn || pt) ? (cmpgn || pt).textContent.replace(/\s+/g, " ").trim() : "";
            if (p) allPrices.push(p);
          }
        });
        let bestPrice = "";
        const firstLi = ul.querySelector("li");
        if (firstLi) {
          const img = firstLi.querySelector("img");
          const pb = firstLi.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
          let price = "";
          if (pb) {
            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
            if (cmpgn) price = cmpgn.textContent.replace(/\s+/g, " ").trim();
            else { const pt = pb.querySelector(".pt_v8, .pt_v9, [class*='pt_']"); if (pt) price = pt.textContent.replace(/\s+/g, " ").trim(); }
          }
          let label = "";
          if (img && img.alt) {
            label = String(img.alt).trim();
          } else {
            const sellerEl = firstLi.querySelector(".w_v8 .v_v8 b, .v_v8 b, .w_v8 b");
            if (sellerEl && sellerEl.textContent) {
              label = sellerEl.textContent.replace(/\s+/g, " ").trim();
            }
          }
          if (!label) label = "?";
          bestPrice = label + " - " + (price && price.trim() ? price.trim() : "-");
        }
        return { items, allPrices, bestPrice, redirectedToHome: false };
      }
    });
    const loadListener = (updatedId, info) => {
      if (updatedId !== akakceTabId || info.status !== "complete") return;
      chrome.tabs.onUpdated.removeListener(loadListener);
      const isCf = () => chrome.scripting.executeScript({
        target: { tabId: akakceTabId },
        func: () => /Performing security verification|security check|Cloudflare|Just a moment/i.test(document.body?.innerText || "")
      }).then((r) => r && r[0] && r[0].result === true);
      const hasContent = () => chrome.scripting.executeScript({
        target: { tabId: akakceTabId },
        func: () => Boolean(document.querySelector("ul#PL, [id='PL'], #pd_v8"))
      }).then((r) => r && r[0] && r[0].result === true);
      const waitReady = (n) => {
        if (n >= 5) return Promise.resolve();
        return new Promise((r) => setTimeout(r, n === 0 ? 1000 : 2500))
          .then(() => isCf())
          .then((cf) => cf ? waitReady(n + 1) : hasContent().then((ok) => ok ? Promise.resolve() : waitReady(n + 1)));
      };
      waitReady(0)
        .then(() => chrome.tabs.sendMessage(akakceTabId, { type: "akakce-manuel-update-mode" }).catch(() => {}))
        .then(() => chrome.scripting.executeScript({
          target: { tabId: akakceTabId },
          func: () => {
            const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
            return ul ? ul.querySelectorAll("li").length : 0;
          }
        }))
        .then((r) => {
          const initialCount = (r && r[0] && typeof r[0].result === "number") ? r[0].result : 0;
          const poll = (elapsed) => {
            if (elapsed >= 18000) return Promise.resolve();
            return new Promise((resolve) => setTimeout(resolve, 800))
              .then(() => chrome.scripting.executeScript({
                target: { tabId: akakceTabId },
                func: () => {
                  const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
                  return ul ? ul.querySelectorAll("li").length : 0;
                }
              }))
              .then((res) => {
                const cur = res && res[0] && typeof res[0].result === "number" ? res[0].result : 0;
                if (cur > initialCount) return Promise.resolve();
                return poll(elapsed + 800);
              });
          };
          return poll(0);
        })
        .then(() => chrome.tabs.sendMessage(akakceTabId, { type: "akakce-hide-manual-banner" }).catch(() => {}))
        .then(() => new Promise((r) => setTimeout(r, 400)))
        .then(() => extractData())
        .then((extractResults) => {
          const raw = extractResults && extractResults[0] && extractResults[0].result;
          const data = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.items) ? raw.items : []);
          const allPrices = (raw && Array.isArray(raw.allPrices)) ? raw.allPrices : [];
          const redirectedToHome = Boolean(raw && raw.redirectedToHome);
          const msg = { type: resultType, productId, data, rowIndex };
          if (allPrices.length > 0) msg.allPrices = allPrices;
          if (raw && raw.bestPrice != null) msg.bestPrice = String(raw.bestPrice).trim();
          if (redirectedToHome) msg.redirectedToHome = true;
          chrome.tabs.sendMessage(n11TabId, msg).catch(() => {});
          chrome.tabs.remove(akakceTabId).catch(() => {});
        })
        .catch(() => {
          chrome.tabs.remove(akakceTabId).catch(() => {});
          chrome.tabs.sendMessage(n11TabId, { type: resultType, productId, data: [], rowIndex }).catch(() => {});
        });
    };
    chrome.tabs.onUpdated.addListener(loadListener);
  });
  sendResponse({ ok: true });
};

const DEEP_ANALYSIS_SYSTEM = `Sen bir e-ticaret fiyat analiz uzmanısın. Sana verilen n11 ürün bilgilerini kullanarak Google Search üzerinden Trendyol, Hepsiburada, Amazon Türkiye veya diğer güvenilir platformlarda bu ürünün fiyatlarını bul.

Kurallar:
- Sadece aynı model, aynı teknik özellik ve aynı kondisyondaki (sıfır ürün) fiyatları dikkate al.
- Mağaza/satıcı adı eşleşmese bile farklı mağazalardan ve satıcılardan aynı ürünü ara; herhangi bir satıcının fiyatını bulabilirsin.
- Farklı varyasyonları (renk, hafıza vb.) karıştırma.
- Sonucu SADECE aşağıdaki JSON formatında dön, başka hiçbir açıklama yapma:
{
  "found": true/false,
  "competitor_price": 0.0,
  "source_url": "link",
  "platform": "Hepsiburada/Trendyol/Amazon",
  "confidence_score": 0-100,
  "analysis_note": "Neden bu sonucu bulduğuna dair kısa not"
}`;

function runDeepAnalysis(message, sendResult) {
  const DEFAULT_GEMINI_API_KEY = "AIzaSyDskGFLy6Gs_gbn-1B-mG7rqIzt2SlMZmc";
  chrome.storage.local.get("geminiApiKey", async (stored) => {
    const apiKey = (stored.geminiApiKey || DEFAULT_GEMINI_API_KEY || "").trim();
    if (!apiKey) {
      sendResult(null, "Gemini API Key bulunamadı.");
      return;
    }
    const productUrl = (message.productUrl || "").trim();
    const n11Price = (message.n11Price || "").trim();
    const sellerNickName = (message.sellerNickName || "").trim();
    const productName = (message.productName || "").trim();
    const userContent = `n11 Ürün Linki: ${productUrl}\nn11 Fiyatı: ${n11Price}\nSatıcı Adı: ${sellerNickName}\nÜrün Adı: ${productName}`;
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(apiKey)}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userContent }] }],
          systemInstruction: { parts: [{ text: DEEP_ANALYSIS_SYSTEM }] },
          tools: [{ google_search: {} }],
          safetySettings: [
            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
          ]
        })
      });
      const json = await res.json();
      if (!res.ok) {
        const errMsg = json?.error?.message || json?.error || String(res.status);
        sendResult(null, errMsg);
        return;
      }
      const text = json?.candidates?.[0]?.content?.parts?.[0]?.text || "";
      let parsed = null;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          parsed = JSON.parse(jsonMatch[0]);
        } catch (e) {}
      }
      sendResult(parsed, null);
    } catch (err) {
      sendResult(null, err?.message || String(err));
    }
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "seller-product-count-getData") {
    Promise.all([sellerProductCountGetSellers(), sellerProductCountGetResults()])
      .then(([sellers, results]) => sendResponse({ ok: true, sellers, results }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-saveUrls") {
    const sellers = Array.isArray(message.sellers) ? message.sellers : [];
    sellerProductCountSaveSellers(sellers)
      .then((saved) => sendResponse({ ok: true, sellers: saved }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-scrape") {
    const sellers = Array.isArray(message.sellers) ? message.sellers : [];
    Promise.all(sellers.map((s) => sellerProductCountScrapeForSeller(s)))
      .then((results) => sellerProductCountSaveResults(results).then(() => sendResponse({ ok: true, results })))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-getResults") {
    sellerProductCountGetResults()
      .then((results) => sendResponse({ ok: true, results }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-clearData") {
    sellerProductCountClearData()
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-restore") {
    const sellersList = Array.isArray(message.sellers) ? message.sellers : [];
    const resultsList = Array.isArray(message.results) ? message.results : [];
    Promise.all([
      sellerProductCountSaveSellers(sellersList),
      sellerProductCountSaveResults(resultsList)
    ])
      .then(([savedSellers]) => sendResponse({ ok: true, sellers: savedSellers, results: resultsList }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "trendyol-seller-products") {
    const mid = message.mid != null ? String(message.mid) : "";
    const pi = Math.max(1, parseInt(message.pi, 10) || 1);
    if (!mid) {
      sendResponse({ ok: false, error: "mid gerekli" });
      return true;
    }
    const url = `https://apigw.trendyol.com/discovery-sfint-search-service/api/search/products?mid=${encodeURIComponent(mid)}&os=1&pathModel=sr&pi=${pi}`;
    fetch(url)
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        sendResponse({ ok: true, products: data.products || [], totalCount: data.totalCount });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "İstek başarısız" });
      });
    return true;
  }
  if (message && message.type === "hepsiburada-seller-products") {
    const merchantName = (message.merchantName != null && message.merchantName !== "") ? String(message.merchantName).trim() : "";
    const page = Math.max(1, parseInt(message.page, 10) || 1);
    if (!merchantName) {
      sendResponse({ ok: false, error: "merchantName gerekli" });
      return true;
    }
    const filter = `VariantList.VariantListing.MerchantName:${encodeURIComponent(merchantName)}`;
    const url = `https://blackgate.hepsiburada.com/moriaapi/api/product?filter=${filter}&page=${page}&pageType=Merchant&size=36`;
    fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        Referer: "https://www.hepsiburada.com/",
        Origin: "https://www.hepsiburada.com",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        sendResponse({ ok: true, products: data.products || [] });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "İstek başarısız" });
      });
    return true;
  }
  if (message && message.type === "barcode-products-crawl") {
    const barcodes = Array.isArray(message.barcodes)
      ? message.barcodes.map((x) => String(x || "").trim()).filter((x) => /^\d{8,14}$/.test(x))
      : [];
    const uniqueBarcodes = Array.from(new Set(barcodes));
    if (!uniqueBarcodes.length) {
      sendResponse({ ok: false, error: "Gecerli barkod bulunamadi." });
      return true;
    }

    const waitComplete = (tabId, timeoutMs) => new Promise((resolve) => {
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      };
      const onUpdated = (updatedId, info) => {
        if (updatedId === tabId && info && info.status === "complete") finish();
      };
      chrome.tabs.onUpdated.addListener(onUpdated);
      chrome.tabs.get(tabId).then((tab) => {
        if (tab && tab.status === "complete") finish();
      }).catch(() => {});
      setTimeout(finish, timeoutMs || 20000);
    });

    const scrapeInNewTab = (url, scrapeFn, readyFn) =>
      chrome.tabs.create({ url, active: false }).then((tab) => {
        if (!tab || !tab.id) return [];
        const tabId = tab.id;
        const waitMs = (ms) => new Promise((r) => setTimeout(r, ms));
        const waitUntilReady = () => {
          if (typeof readyFn !== "function") return Promise.resolve();
          const maxTry = 12;
          let attempt = 0;
          const step = () => {
            attempt += 1;
            return chrome.scripting.executeScript({
              target: { tabId },
              func: readyFn
            })
              .then((r) => Boolean(r && r[0] && r[0].result === true))
              .catch(() => false)
              .then((isReady) => {
                if (isReady) return Promise.resolve();
                if (attempt >= maxTry) return Promise.resolve();
                return waitMs(1200).then(step);
              });
          };
          return step();
        };
        return waitComplete(tabId, 25000)
          .then(() => waitUntilReady())
          .then(() => waitMs(600))
          .then(() =>
            chrome.scripting.executeScript({
              target: { tabId },
              func: scrapeFn
            })
          )
          .then((result) => (result && result[0] && Array.isArray(result[0].result) ? result[0].result : []))
          .catch(() => [])
          .finally(() => {
            chrome.tabs.remove(tabId).catch(() => {});
          });
      });

    const scrapeHepsiburada = () => {
      const toAbs = (href) => {
        if (!href) return "";
        try { return new URL(href, location.origin).href; } catch { return href; }
      };
      const normalizePriceText = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d{1,3}(?:\.\d{3})*|\d+)(?:,(\d{2}))?/);
        if (!m) return "";
        const whole = (m[1] || "").replace(/\./g, "");
        const frac = (m[2] || "00");
        const n = Number.parseFloat(whole + "." + frac);
        if (!Number.isFinite(n) || n <= 0) return "";
        return n.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
      };
      const normalizeRating = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d+(?:[.,]\d+)?)/);
        if (!m) return "";
        return String(m[1]).replace(".", ",");
      };
      const normalizeReviewCount = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d[\d.]*)/);
        if (!m) return "";
        return String(m[1]).replace(/\./g, "");
      };
      const normalizeReviewCountFromAria = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim().toLowerCase();
        if (!raw) return "";
        // Sadece "164 derecelendirme" gibi formati kabul et; "5 yildiz uzerinden..." kabul etme.
        const m = raw.match(/^(\d[\d.]*)\s*(?:değerlendirme|degerlendirme)\b/i);
        if (!m) return "";
        return String(m[1]).replace(/\./g, "");
      };
      const cards = Array.from(
        document.querySelectorAll(
          'li.productListContent-zAP0Y5msy8OHn5z7T_K_, [data-test-id="product-card"], [data-listingid], li[class*="productListContent"], div[class*="productListContent"]'
        )
      );
      const uniq = new Set();
      const out = [];
      cards.forEach((card) => {
        const a =
          card.querySelector('a[data-test-id="product-card-name"]') ||
          card.querySelector('a[href*="-p-"]') ||
          card.querySelector("a[href]");
        const href = toAbs(a && a.getAttribute("href"));
        if (!href || uniq.has(href)) return;
        uniq.add(href);
        const titleEl =
          card.querySelector('h2[data-test-id^="title-"] a, h2 a, h2') ||
          card.querySelector('[data-test-id="title-1"], [data-test-id^="title-"]') ||
          a;
        const finalPriceEl =
          card.querySelector('[data-test-id^="final-price-"], .price-module_finalPrice__LtjvY');
        const titleContainer = card.querySelector('h2[data-test-id^="title-"], h2');
        const ratingEl =
          card.querySelector('.rate-module_rating__19oVu, [data-test-id^="rating-"] .rate-module_rating__19oVu');
        const reviewCountEl =
          card.querySelector('.rate-module_count__fjUng, [data-test-id^="rating-"] .rate-module_count__fjUng');
        const srOnlyRatingEl =
          card.querySelector('[data-test-id^="rating-"] .rate-module_srOnly__oeW3d');
        const imgEl = card.querySelector("img");
        const title = (titleEl && titleEl.textContent ? titleEl.textContent : "").replace(/\s+/g, " ").trim();
        let price = normalizePriceText(finalPriceEl && finalPriceEl.textContent ? finalPriceEl.textContent : "");
        if (!price && titleContainer) {
          const aria = String(titleContainer.getAttribute("aria-label") || "");
          const ariaMatch = aria.match(/fiyat:\s*([\d.,]+)\s*TL/i);
          if (ariaMatch && ariaMatch[1]) price = normalizePriceText(ariaMatch[1] + " TL");
        }
        let rating = normalizeRating(ratingEl && ratingEl.textContent ? ratingEl.textContent : "");
        let reviewCount = normalizeReviewCount(reviewCountEl && reviewCountEl.textContent ? reviewCountEl.textContent : "");
        if (srOnlyRatingEl) {
          const sr = String(srOnlyRatingEl.textContent || "");
          const rm = sr.match(/ürün puanı\s*([\d.,]+)\s*,\s*(\d[\d.]*)\s*değerlendirme/i);
          if (rm) {
            rating = normalizeRating(rm[1]) || rating;
            reviewCount = normalizeReviewCount(rm[2]) || reviewCount;
          }
        }
        if (!rating || !reviewCount) {
          const cardText = String(card.textContent || "").replace(/\s+/g, " ").trim();
          const rm = cardText.match(/ürün puanı\s*([\d.,]+)\s*,\s*(\d[\d.]*)\s*değerlendirme/i);
          if (rm) {
            rating = normalizeRating(rm[1]) || rating;
            reviewCount = normalizeReviewCount(rm[2]) || reviewCount;
          }
        }
        const image = imgEl ? (imgEl.getAttribute("src") || imgEl.getAttribute("data-src") || "") : "";
        if (!title && !price && !image) return;
        out.push({ link: href, title, price, image, rating, reviewCount });
      });
      return out.slice(0, 40);
    };

    const scrapeAmazon = () => {
      const toAbs = (href) => {
        if (!href) return "";
        try { return new URL(href, location.origin).href; } catch { return href; }
      };
      const normalizeRating = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d+(?:[.,]\d+)?)/);
        if (!m) return "";
        return String(m[1]).replace(".", ",");
      };
      const normalizeReviewCount = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d[\d.]*)/);
        if (!m) return "";
        return String(m[1]).replace(/\./g, "");
      };
      const normalizeReviewCountFromAria = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim().toLowerCase();
        if (!raw) return "";
        // Sadece "164 derecelendirme" formatini kabul et.
        const m = raw.match(/(^|\s)(\d[\d.]*)\s*(?:değerlendirme|degerlendirme)\b/i);
        if (!m) return "";
        return String(m[2]).replace(/\./g, "");
      };
      const cards = Array.from(document.querySelectorAll('div[data-component-type="s-search-result"]'));
      const uniq = new Set();
      const out = [];
      cards.forEach((card) => {
        const a = card.querySelector("h2 a.a-link-normal") || card.querySelector("a.a-link-normal[href]");
        const href = toAbs(a && a.getAttribute("href"));
        if (!href || uniq.has(href)) return;
        uniq.add(href);
        const titleEl = card.querySelector("h2 span") || a;
        const priceEl = card.querySelector(".a-price .a-offscreen, .a-price-whole");
        const imgEl = card.querySelector("img.s-image, img");
        const ratingEl =
          card.querySelector('[data-cy="reviews-block"] span.a-size-small.a-color-base') ||
          card.querySelector("i.a-icon-star-small span.a-icon-alt, i.a-icon-star-mini span.a-icon-alt");
        const reviewCountLink =
          card.querySelector('a[href*="#customerReviews"][aria-label]') ||
          card.querySelector('[data-cy="reviews-block"] a[href*="#customerReviews"][aria-label]') ||
          card.querySelector('[data-cy="reviews-block"] a[aria-label*="değerlendirme"]:not([aria-label*="yıldız"]):not([aria-label*="yildiz"])');
        const reviewCountTextEl =
          (reviewCountLink && reviewCountLink.querySelector("span")) ||
          card.querySelector('a[href*="#customerReviews"] span') ||
          card.querySelector('[data-cy="reviews-block"] a[aria-label*="değerlendirme"] span');
        const ratingAriaEl =
          card.querySelector('i.a-icon-star-mini span.a-icon-alt, i.a-icon-star-small span.a-icon-alt');
        const reviewsBlockEl = card.querySelector('[data-cy="reviews-block"]');
        const title = (titleEl && titleEl.textContent ? titleEl.textContent : "").replace(/\s+/g, " ").trim();
        const price = (priceEl && priceEl.textContent ? priceEl.textContent : "").replace(/\s+/g, " ").trim();
        let rating = normalizeRating(ratingEl && ratingEl.textContent ? ratingEl.textContent : "");
        let reviewCount = "";
        if (reviewCountLink) {
          // Örn: aria-label="164 derecelendirme"
          reviewCount = normalizeReviewCountFromAria(reviewCountLink.getAttribute("aria-label") || "") || "";
        }
        if (!reviewCount && reviewCountTextEl) {
          // Örn: "(164)"
          reviewCount = normalizeReviewCount(reviewCountTextEl.textContent || "");
        }
        if (!rating && ratingAriaEl) {
          rating = normalizeRating(ratingAriaEl.textContent || "");
        }
        if ((!rating || !reviewCount) && reviewsBlockEl) {
          const blockText = String(reviewsBlockEl.textContent || "").replace(/\s+/g, " ").trim();
          const rm = blockText.match(/(\d+(?:[.,]\d+)?)\s*(?:_)?\s*5 yıldız üzerinden/i);
          const cm = blockText.match(/\(?\s*(\d[\d.]*)\s*\)?\s*(?:değerlendirme|degerlendirme)\b/i) || blockText.match(/\((\d[\d.]*)\)/);
          if (!rating && rm) rating = normalizeRating(rm[1]);
          if (!reviewCount && cm) reviewCount = normalizeReviewCount(cm[1]);
        }
        const image = imgEl ? (imgEl.getAttribute("src") || "") : "";
        if (!title && !price && !image) return;
        out.push({ link: href, title, price, image, rating, reviewCount });
      });
      return out.slice(0, 40);
    };

    (async () => {
      const rows = [];
      for (const barcode of uniqueBarcodes) {
        const hbUrl = "https://www.hepsiburada.com/ara?q=" + encodeURIComponent(barcode);
        const amzUrl = "https://www.amazon.com.tr/s?k=" + encodeURIComponent(barcode);

        const hbProducts = await scrapeInNewTab(
          hbUrl,
          scrapeHepsiburada,
          () => {
            const hasProducts = document.querySelectorAll(
              'li.productListContent-zAP0Y5msy8OHn5z7T_K_, [data-test-id="product-card"], [data-listingid], li[class*="productListContent"], div[class*="productListContent"]'
            ).length > 0;
            const hasRating = document.querySelectorAll(
              '.rate-module_rating__19oVu, .rate-module_count__fjUng, [data-test-id^="rating-"]'
            ).length > 0;
            if (hasProducts && hasRating) return true;
            // "Aramana uygun ürün bulunamadı" ekranında hemen bitirme, beklemeye devam et.
            const noResultText = (document.body && document.body.innerText ? document.body.innerText : "")
              .toLowerCase();
            const noResultVisible =
              noResultText.includes("aramana uygun ürün bulunamadı") ||
              noResultText.includes("aramana uygun urun bulunamadi") ||
              Boolean(document.querySelector('[class*="no-result-view"]'));
            if (noResultVisible) return false;
            return false;
          }
        );
        hbProducts.forEach((p) => {
          rows.push({
            barcode,
            platform: "Hepsiburada",
            queryUrl: hbUrl,
            link: p.link || "",
            title: p.title || "",
            price: p.price || "",
            image: p.image || "",
            rating: p.rating || "",
            reviewCount: p.reviewCount || ""
          });
        });

        const amzProducts = await scrapeInNewTab(amzUrl, scrapeAmazon);
        amzProducts.forEach((p) => {
          rows.push({
            barcode,
            platform: "Amazon.com.tr",
            queryUrl: amzUrl,
            link: p.link || "",
            title: p.title || "",
            price: p.price || "",
            image: p.image || "",
            rating: p.rating || "",
            reviewCount: p.reviewCount || ""
          });
        });
      }
      sendResponse({ ok: true, rows });
    })().catch((err) => {
      sendResponse({ ok: false, error: err && err.message ? err.message : "Tarama hatasi" });
    });
    return true;
  }
  if (message && message.type === "logo-list-fetch") {
    const url = String(message.url || "").trim();
    if (!url || !/^https?:\/\/mobileapi\.n11\.com\//i.test(url)) {
      sendResponse({ ok: false, error: "Gecersiz logo list URL." });
      return true;
    }
    fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Accept-Language": "tr-TR,tr;q=0.9"
      }
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        sendResponse({ ok: true, data });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "Logo listesi alinamadi." });
      });
    return true;
  }
  if (message && message.type === "product-mailing-fetch-html") {
    const url = String(message.url || "").trim();
    // product sayfasi veya extension template dosyasi: chrome-extension://... da gelebilir.
    if (!/^https?:\/\/.+/i.test(url) && !/^chrome-extension:\/\//i.test(url)) {
      sendResponse({ ok: false, error: "Gecersiz urun URL." });
      return true;
    }
    fetch(url, {
      method: "GET",
      headers: {
        Accept: "text/html,application/xhtml+xml,*/*;q=0.9",
        "Accept-Language": "tr-TR,tr;q=0.9",
        Referer: "https://www.n11.com/",
        Origin: "https://www.n11.com/",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      },
      credentials: "omit"
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        return res.text();
      })
      .then((html) => {
        sendResponse({ ok: true, html });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "Urun sayfasi alinamadi." });
      });
    return true;
  }
  if (message && message.type === "product-match-score-fetch-image-data-url") {
    const url = String(message.url || "").trim();
    if (!/^https?:\/\/.+/i.test(url)) {
      sendResponse({ ok: false, error: "Gecersiz gorsel URL." });
      return true;
    }
    fetchImageAsDataUrl(url)
      .then((dataUrl) => {
        sendResponse({ ok: true, dataUrl });
      })
      .catch((err) => {
        sendResponse({
          ok: false,
          error: err?.message || "Gorsel alinamadi."
        });
      });
    return true;
  }
  if (message && message.type === "price-protector-deep-analysis") {
    const tabId = sender?.tab?.id || null;
    const sendResult = (result, error) => {
      if (tabId) {
        chrome.tabs.sendMessage(tabId, {
          type: "price-protector-deep-analysis-result",
          result,
          error,
          rowIndex: message.rowIndex
        }).catch(() => {});
      }
      sendResponse({ ok: !error });
    };
    runDeepAnalysis(message, sendResult);
    return true;
  }
  if (message && message.type === "akakce-deep-analysis") {
    const tabId = sender?.tab?.id || null;
    const sendResult = (result, error) => {
      if (tabId) {
        chrome.tabs.sendMessage(tabId, {
          type: "akakce-deep-analysis-result",
          result,
          error,
          rowIndex: message.rowIndex
        }).catch(() => {});
      }
      sendResponse({ ok: !error });
    };
    runDeepAnalysis(message, sendResult);
    return true;
  }
  if (message && message.type === "akakce-manuel-update") {
    runManuelUpdateFlow(message, sender, sendResponse, "akakce-manuel-update-result");
    return true;
  }
  if (message && message.type === "price-protector-manuel-update") {
    runManuelUpdateFlow(message, sender, sendResponse, "price-protector-manuel-update-result");
    return true;
  }
  if (message && message.type === "akakce-id-to-n11") {
    const akakceUrl = (message.akakceUrl || "").trim();
    if (!akakceUrl || !akakceUrl.includes("akakce.com")) {
      sendResponse({ ok: false, error: "Geçersiz Akakce URL" });
      return true;
    }
    chrome.tabs.create({ url: akakceUrl, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı" });
        return;
      }
      const tabId = tab.id;
      const extractN11Link = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
          if (!ul) return null;
          const items = ul.querySelectorAll("li");
          for (const li of items) {
            const link = li.querySelector("a[href*='n11.com']");
            if (link && link.href && link.href.includes("n11.com/urun/")) return link.href;
          }
          return null;
        }
      });
      const isCf = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => /Performing security verification|security check|Cloudflare|Just a moment/i.test(document.body?.innerText || "")
      }).then((r) => r && r[0] && r[0].result === true);
      const hasContent = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => Boolean(document.querySelector("ul#PL, [id='PL'], #pd_v8"))
      }).then((r) => r && r[0] && r[0].result === true);
      const waitReady = (n) => {
        if (n >= 5) return Promise.resolve();
        return new Promise((r) => setTimeout(r, n === 0 ? 1000 : 2500))
          .then(() => isCf())
          .then((cf) => cf ? waitReady(n + 1) : hasContent().then((ok) => ok ? Promise.resolve() : waitReady(n + 1)));
      };
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        waitReady(0)
          .then(() => extractN11Link())
          .then((r) => {
            const n11Link = (r && r[0] && r[0].result) ? String(r[0].result).trim() : null;
            chrome.tabs.remove(tabId).catch(() => {});
            sendResponse(n11Link ? { ok: true, n11Link } : { ok: false, error: "n11 linki bulunamadı" });
          })
          .catch((err) => {
            chrome.tabs.remove(tabId).catch(() => {});
            sendResponse({ ok: false, error: err?.message || "Hata" });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    });
    return true;
  }
  if (message && message.type === "akakce-id-to-link") {
    const akakceId = (message.akakceId || "").trim();
    if (!akakceId || !/^\d+$/.test(akakceId)) {
      sendResponse({ ok: false, error: "Geçersiz Akakce ID" });
      return true;
    }
    const googleUrl = "https://www.google.com/search?q=akakce+" + encodeURIComponent(akakceId);
    chrome.tabs.create({ url: googleUrl, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı" });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => { chrome.tabs.remove(tabId).catch(() => {}); };
      const waitComplete = () => new Promise((resolve) => {
        const check = (id, info) => {
          if (id === tabId && info && info.status === "complete") {
            chrome.tabs.onUpdated.removeListener(check);
            resolve();
          }
        };
        chrome.tabs.onUpdated.addListener(check);
        chrome.tabs.get(tabId).then((t) => {
          if (t && t.status === "complete") {
            chrome.tabs.onUpdated.removeListener(check);
            resolve();
          }
        }).catch(() => {});
        setTimeout(() => { chrome.tabs.onUpdated.removeListener(check); resolve(); }, 15000);
      });
      const isCf = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => /Performing security verification|security check|Cloudflare|Just a moment/i.test(document.body?.innerText || "")
      }).then((r) => r && r[0] && r[0].result === true);
      const hasPl = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => Boolean(document.querySelector("ul#PL, [id='PL']"))
      }).then((r) => r && r[0] && r[0].result === true);
      const waitAkakceReady = (n) => {
        if (n >= 5) return Promise.resolve();
        return new Promise((r) => setTimeout(r, n === 0 ? 1500 : 2500))
          .then(() => isCf())
          .then((cf) => cf ? waitAkakceReady(n + 1) : hasPl().then((ok) => ok ? Promise.resolve() : waitAkakceReady(n + 1)));
      };
      waitComplete()
        .then(() => new Promise((r) => setTimeout(r, 2000)))
        .then(() => chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const decodeGoogleRedirect = (href) => {
              let url = String(href || "");
              if (!url) return "";
              if (url.includes("google.com/url")) {
                const m = url.match(/[?&]q=([^&]+)/);
                if (m) url = decodeURIComponent(m[1].replace(/\+/g, " "));
              }
              return url;
            };
            const isGoogleAdResult = (anchor) => {
              if (!anchor) return false;
              const block =
                anchor.closest("div[data-text-ad]") ||
                anchor.closest("div[data-sokoban-container]") ||
                anchor.closest("div[data-pla-slot-pos]") ||
                anchor.closest("div.g") ||
                anchor.parentElement;
              const text = String(block?.innerText || "")
                .replace(/\s+/g, " ")
                .toLowerCase();
              return (
                text.includes("ücretli sponsorlu reklam") ||
                text.includes("sponsorlu reklam") ||
                text.includes("sponsorlu") ||
                text.includes("sponsored")
              );
            };

            const seen = new Set();
            const candidates = Array.from(document.querySelectorAll('a[href*="akakce.com"]'))
              .map((a) => ({
                url: decodeGoogleRedirect(a.href),
                isSponsored: isGoogleAdResult(a)
              }))
              .filter((x) => x.url && x.url.includes("akakce.com"))
              .filter((x) => {
                if (seen.has(x.url)) return false;
                seen.add(x.url);
                return true;
              });

            if (candidates.length > 0) {
              if (candidates[0].isSponsored && candidates[1]) {
                const nextOrganic = candidates.find((x, idx) => idx > 0 && !x.isSponsored);
                return (nextOrganic && nextOrganic.url) || candidates[1].url;
              }
              return candidates[0].url;
            }
            return null;
          }
        }))
        .then((r) => {
          const akakcePageUrl = r && r[0] && r[0].result ? String(r[0].result).trim() : null;
          if (!akakcePageUrl || !akakcePageUrl.includes("akakce.com")) {
            cleanup();
            sendResponse({ ok: false, error: "Akakce sayfası bulunamadı" });
            return;
          }
          return chrome.tabs.update(tabId, { url: akakcePageUrl }).then(() => waitComplete()).then(() => waitAkakceReady(0));
        })
        .then(() => Promise.all([
          chrome.tabs.get(tabId).then((t) => (t && t.url) || null),
          chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
              if (!ul) return null;
              const lis = ul.querySelectorAll("li");
              for (const li of lis) {
                const imgs = li.querySelectorAll("img[alt]");
                let hasN11Badge = false;
                let n11Img = null;
                for (const img of imgs) {
                  const alt = (img.getAttribute("alt") || "").trim().toLowerCase();
                  if (alt === "n11") {
                    hasN11Badge = true;
                    n11Img = img;
                    break;
                  }
                }
                const sellerText = (li.querySelector(".v_v8")?.textContent || "").trim();
                const hasN11SellerText = /\bn11\b/i.test(sellerText);
                if (!hasN11Badge && !hasN11SellerText) continue;

                if (n11Img) {
                  const a = n11Img.closest("a");
                  if (a && a.href) return a.href;
                }

                const a = li.querySelector("a[href]");
                if (a && a.href) return a.href;
              }
              return null;
            }
          })
        ]))
        .then(([akakcePageUrl, r]) => {
          let redirectUrl = r && r[0] && r[0].result ? String(r[0].result).trim() : null;
          cleanup();
          if (!redirectUrl || !redirectUrl.includes("akakce.com")) {
            sendResponse({ ok: false, error: "sayfada n11'e ait ürün bulunamadı" });
            return;
          }
          if (!/akakce\.com\/c\/\?/.test(redirectUrl)) {
            try {
              const u = new URL(redirectUrl);
              let qs = u.search ? u.search.slice(1) : "";
              if (u.hash && u.hash.includes("?")) {
                const afterQ = u.hash.split("?")[1] || "";
                if (afterQ) qs = afterQ;
              }
              if (qs) {
                redirectUrl = "https://www.akakce.com/c/?" + qs;
              }
            } catch (e) {}
          }
          sendResponse({
            ok: true,
            akakceUrl: akakcePageUrl || "",
            redirectUrl: redirectUrl
          });
        })
        .catch((err) => {
          cleanup();
          sendResponse({ ok: false, error: err?.message || "Hata" });
        });
    });
    return true;
  }
  if (message && message.type === "akakce-resolve-redirect-to-n11") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("akakce.com")) {
      sendResponse({ ok: false, error: "Geçersiz redirect URL" });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı" });
        return;
      }
      const tabId = tab.id;
      let done = false;
      const finish = (finalUrl) => {
        if (done) return;
        done = true;
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        sendResponse({ ok: true, url: finalUrl || "" });
        chrome.tabs.remove(tabId).catch(() => {});
      };
      const timeout = setTimeout(() => finish(""), 20000);
      const listener = (updatedId, changeInfo, t) => {
        if (updatedId !== tabId) return;
        const u = (changeInfo && changeInfo.url) || (t && t.url) || "";
        if (u && u.includes("n11.com/urun/")) {
          finish(u);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
      const poll = (n) => {
        if (done || n >= 25) return;
        chrome.tabs.get(tabId).then((t) => {
          if (done) return;
          const u = (t && t.url) || "";
          if (u.includes("n11.com/urun/")) {
            finish(u);
          } else {
            setTimeout(() => poll(n + 1), 800);
          }
        }).catch(() => setTimeout(() => poll(n + 1), 800));
      };
      setTimeout(() => poll(0), 1000);
    });
    return true;
  }
  if (message && message.type === "akakce-get-product-id-from-n11") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("n11.com/urun/")) {
      sendResponse({ ok: false, productId: null });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, productId: null });
        return;
      }
      const tabId = tab.id;
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 2500))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              try {
                if (window.model && window.model.product != null && window.model.product.id != null) {
                  return String(window.model.product.id);
                }
                if (window.model && window.model.productMeta != null && window.model.productMeta.productId != null) {
                  return String(window.model.productMeta.productId);
                }
              } catch (e) {}
              return null;
            }
          }))
          .then((r) => {
            const id = r && r[0] && r[0].result ? String(r[0].result) : null;
            chrome.tabs.remove(tabId).catch(() => {});
            sendResponse({ ok: true, productId: id });
          })
          .catch(() => {
            chrome.tabs.remove(tabId).catch(() => {});
            sendResponse({ ok: false, productId: null });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    });
    return true;
  }
  if (message && message.type === "akakce-custom-deal-open-tab-and-select-hepsiburada") {
    const url = String(message.url || "").trim();
    if (!url || !url.includes("akakce.com")) {
      sendResponse({ ok: false, error: "Gecersiz Akakce URL" });
      return true;
    }
    const AKAKCE_DEAL_ALLOWED_PLATFORMS = new Set([
      "tumu",
      "hepsiburada",
      "n11",
      "trendyol",
      "trendyol_plus",
      "amazon",
      "pazarama",
      "pttavm",
      "idefix",
      "teknosa"
    ]);
    const AKAKCE_LIST_FILTER_ID_BY_PLATFORM = {
      hepsiburada: 1195915,
      trendyol: 1207553,
      trendyol_plus: 1235722,
      pttavm: 1196733,
      amazon: 1198774,
      idefix: 1223236,
      teknosa: 1204735
    };
    const AKAKCE_DEAL_FILTER_PASS_ORDER = [
      "hepsiburada",
      "trendyol",
      "trendyol_plus",
      "pttavm",
      "amazon",
      "idefix",
      "teknosa"
    ];
    const rawPlat = message.platforms;
    let finalPlatforms = Array.isArray(rawPlat) && rawPlat.length
      ? rawPlat.map((p) => String(p || "").trim().toLowerCase()).filter((p) => AKAKCE_DEAL_ALLOWED_PLATFORMS.has(p))
      : [];
    if (!finalPlatforms.length) finalPlatforms = ["hepsiburada"];
    finalPlatforms = Array.from(
      new Set(
        finalPlatforms.map((p) => (p === "trendyol_plus" ? "trendyol" : p))
      )
    );
    const knownAkakceFilterIds = Object.values(AKAKCE_LIST_FILTER_ID_BY_PLATFORM);
    const stripAkakceListFilterSuffix = (rawUrl) => {
      try {
        const p = new URL(rawUrl);
        let path = String(p.pathname || "").replace(/\/+$/, "");
        for (let i = 0; i < knownAkakceFilterIds.length; i++) {
          const id = String(knownAkakceFilterIds[i]);
          if (path.endsWith("/" + id)) {
            path = path.slice(0, -(id.length + 1));
            break;
          }
        }
        p.pathname = path;
        return p.toString();
      } catch (e) {
        return rawUrl;
      }
    };
    const withAkakceListFilterSuffix = (rawUrl, filterId) => {
      try {
        const parsed = new URL(rawUrl);
        let path = String(parsed.pathname || "").replace(/\/+$/, "");
        const sid = String(filterId);
        for (let i = 0; i < knownAkakceFilterIds.length; i++) {
          const id = String(knownAkakceFilterIds[i]);
          if (path.endsWith("/" + id)) {
            path = path.slice(0, -(id.length + 1));
            break;
          }
        }
        parsed.pathname = path + "/" + sid;
        return parsed.toString();
      } catch (e) {
        return rawUrl;
      }
    };
    const baseListUrl = stripAkakceListFilterSuffix(url);
    const passes = [];
    const AKAKCE_TUMU_FILL_PLATFORMS = [
      "hepsiburada",
      "trendyol",
      "pttavm",
      "amazon",
      "idefix",
      "teknosa",
      "n11",
      "pazarama",
      "other"
    ];
    if (finalPlatforms.includes("tumu")) {
      finalPlatforms = ["tumu", "n11"];
      passes.push({
        url: baseListUrl,
        fill: AKAKCE_TUMU_FILL_PLATFORMS,
        useFirstRankedPrice: false,
        firstRankedPlatform: "",
        tumuMode: true
      });
    } else {
      AKAKCE_DEAL_FILTER_PASS_ORDER.forEach((plat) => {
        if (plat === "trendyol_plus") {
          if (!finalPlatforms.includes("trendyol")) return;
        } else if (!finalPlatforms.includes(plat)) return;
        const fid = AKAKCE_LIST_FILTER_ID_BY_PLATFORM[plat];
        if (fid == null) return;
        passes.push({
          url: withAkakceListFilterSuffix(baseListUrl, fid),
          fill: [plat, "n11"],
          useFirstRankedPrice: true,
          firstRankedPlatform: plat,
          tumuMode: false
        });
      });
      const platformsNeedingBaseList = finalPlatforms.filter(
        (p) => AKAKCE_LIST_FILTER_ID_BY_PLATFORM[p] == null
      );
      if (platformsNeedingBaseList.length) {
        const baseFillSet = new Set(platformsNeedingBaseList);
        baseFillSet.add("n11");
        passes.push({
          url: baseListUrl,
          fill: Array.from(baseFillSet),
          useFirstRankedPrice: false,
          firstRankedPlatform: "",
          tumuMode: false
        });
      }
      if (passes.length === 0) {
        passes.push({
          url: baseListUrl,
          fill: finalPlatforms,
          useFirstRankedPrice: false,
          firstRankedPlatform: "",
          tumuMode: false
        });
      }
    }
    const firstTabUrl = passes[0].url;
    const senderTabId = sender && sender.tab && sender.tab.id;
    chrome.tabs.create({ url: firstTabUrl, active: true }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Yeni sekme acilamadi." });
        return;
      }
      const tabId = tab.id;
      const mergeFieldByPlatform = {
        tumu: "tumuPrice",
        hepsiburada: "hepsiburadaPrice",
        n11: "n11Price",
        trendyol: "trendyolPrice",
        trendyol_plus: "trendyolPlusPrice",
        amazon: "amazonPrice",
        pazarama: "pazaramaPrice",
        pttavm: "pttavmPrice",
        idefix: "idefixPrice",
        teknosa: "teknosaPrice",
        other: "otherPrice"
      };
      const mergedById = new Map();
      let currentPassFill = passes[0] ? passes[0].fill : finalPlatforms;
      let currentPassOpts = passes[0]
        ? {
            useFirstRankedPrice: !!passes[0].useFirstRankedPrice,
            firstRankedPlatform: passes[0].firstRankedPlatform
              ? String(passes[0].firstRankedPlatform)
              : "",
            tumuMode: !!passes[0].tumuMode
          }
        : { useFirstRankedPrice: false, firstRankedPlatform: "", tumuMode: false };
      let totalPageCountAllPasses = 0;
      const parseAkakcePriceNumberMerge = (raw) => {
        const text = String(raw || "").trim();
        if (!text || text === "-") return null;
        const normalized = text
          .replace(/TL/gi, "")
          .replace(/[^\d,.\-]/g, "")
          .replace(/\./g, "")
          .replace(",", ".");
        const value = Number.parseFloat(normalized);
        return Number.isFinite(value) ? value : null;
      };
      const mergeTrendyolPriceMin = (row, incoming) => {
        const s = String(incoming || "").trim();
        if (!s || s === "-") return;
        const prev = String(row.trendyolPrice || "").trim();
        if (!prev || prev === "-") {
          row.trendyolPrice = s;
          return;
        }
        const nNew = parseAkakcePriceNumberMerge(s);
        const nOld = parseAkakcePriceNumberMerge(prev);
        if (nNew != null && (nOld == null || nNew < nOld)) row.trendyolPrice = s;
      };
      const mergeRowsIntoMap = (rows, fillKeys) => {
        if (!Array.isArray(rows) || !fillKeys || !fillKeys.length) return;
        rows.forEach((r) => {
          const id = String(r.akakceId || "").trim();
          if (!id) return;
          if (!mergedById.has(id)) {
            mergedById.set(id, {
              imageUrl: r.imageUrl || "",
              title: r.title || "",
              url: r.url || "",
              akakceId: id,
              tumuPrice: "-",
              hepsiburadaPrice: "-",
              n11Price: "-",
              trendyolPrice: "-",
              trendyolPlusPrice: "-",
              amazonPrice: "-",
              pazaramaPrice: "-",
              pttavmPrice: "-",
              idefixPrice: "-",
              teknosaPrice: "-",
              otherPrice: "-"
            });
          }
          const row = mergedById.get(id);
          fillKeys.forEach((pk) => {
            const fk = mergeFieldByPlatform[pk];
            if (!fk) return;
            const v = r[fk];
            const s = v != null ? String(v).trim() : "";
            if (!s || s === "-") return;
            if (pk === "trendyol" || pk === "trendyol_plus") {
              mergeTrendyolPriceMin(row, s);
              return;
            }
            row[fk] = s;
          });
          row.trendyolPlusPrice = "-";
          if (r.imageUrl && !row.imageUrl) row.imageUrl = r.imageUrl;
          if (r.title && !row.title) row.title = r.title;
          if (r.url && !row.url) row.url = r.url;
        });
      };
      let finished = false;
      let timeoutId;
      let loadListener = null;
      let lastWasChallenge = false;
      let crawlFlowStarted = false;
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const resetTimeout = (msFromNow) => {
        clearTimeout(timeoutId);
        const ms = typeof msFromNow === "number" ? msFromNow : 120000;
        timeoutId = setTimeout(() => {
          const err = lastWasChallenge
            ? "Guvenlik veya Captcha zaman asimina ugradi. Acik birakilan Akakce sekmesinde dogrulamayi tamamlayip tekrar deneyin."
            : "Sayfa zaman asimina ugradi.";
          finish({ ok: false, error: err }, { keepTabOpen: lastWasChallenge });
        }, ms);
      };
      const finish = (payload, opts) => {
        if (finished) return;
        finished = true;
        clearTimeout(timeoutId);
        if (loadListener) chrome.tabs.onUpdated.removeListener(loadListener);
        sendResponse(payload);
        const keepOpen = opts && opts.keepTabOpen === true;
        if (!keepOpen) chrome.tabs.remove(tabId).catch(() => {});
      };
      const detectAkakceCrawlPageState = () =>
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const cpl = document.querySelector("ul#CPL");
            const liCount = document.querySelectorAll("ul#CPL > li[data-pr]").length;
            const cplExists = !!cpl;
            const hasCpl = liCount > 0;
            const title = (document.title || "").trim();
            if (cplExists || hasCpl) {
              return { isChallenge: false, hasCpl, cplExists, liCount, title };
            }
            const href = String(location.href || "");
            const t = document.body && document.body.innerText ? document.body.innerText : "";
            const tShort = t.length > 4000 ? t.slice(0, 4000) : t;
            let isChallenge = false;
            if (/__cf_chl|__cf_bm=/.test(href)) isChallenge = true;
            if (!isChallenge && /^just a moment\b/i.test(title)) isChallenge = true;
            if (!isChallenge && /^attention required\b|^sorry, you have been blocked\b/i.test(title)) isChallenge = true;
            if (
              !isChallenge &&
              document.querySelector(
                "iframe[src*='challenges.cloudflare.com'], iframe[src*='challenges.cloudflare']"
              )
            ) {
              isChallenge = true;
            }
            if (!isChallenge && document.querySelector("#cf-challenge-running, #challenge-running, .cf-browser-verification")) {
              isChallenge = true;
            }
            if (
              !isChallenge &&
              tShort.length < 900 &&
              /checking your browser|one more step|confirm you are a human|ddos protection by cloudflare/i.test(tShort) &&
              !/akakce|ürün|urun|fiyat|kategori/i.test(tShort)
            ) {
              isChallenge = true;
            }
            return { isChallenge, hasCpl, cplExists, liCount, title };
          }
        });
      const waitUntilAkakceListReady = async (maxMs) => {
        const pollMs = 2000;
        const deadline = Date.now() + maxMs;
        let captchaNotified = false;
        while (Date.now() < deadline) {
          let s = null;
          try {
            const r = await detectAkakceCrawlPageState();
            s = r && r[0] && r[0].result ? r[0].result : null;
          } catch (e) {
            await sleep(pollMs);
            continue;
          }
          if (!s) {
            await sleep(pollMs);
            continue;
          }
          if (s.cplExists || s.hasCpl) {
            lastWasChallenge = false;
            return;
          }
          if (s.isChallenge) {
            lastWasChallenge = true;
            resetTimeout(600000);
            if (!captchaNotified && senderTabId) {
              captchaNotified = true;
              chrome.tabs
                .sendMessage(senderTabId, {
                  type: "akakce-custom-deal-captcha-wait",
                  hint:
                    "Akakce guvenlik dogrulamasi: Acilan sekmede Captcha / robot kontrolunu tamamlayin. Dogrulama bitince liste otomatik devam eder (yaklasik 10 dk beklenir)."
                })
                .catch(() => {});
            }
            await sleep(pollMs);
            continue;
          }
          lastWasChallenge = false;
          await sleep(pollMs);
        }
        throw new Error(
          "Akakce liste alani (ul#CPL) zaman asimina ugradi. Guvenlik sayfasi, captcha veya sayfa yapisi degismis olabilir."
        );
      };
      const waitForCplPricesReady = async () => {
        for (let iter = 0; iter < 45; iter++) {
          try {
            const r = await chrome.scripting.executeScript({
              target: { tabId },
              args: [iter],
              func: (iteration) => {
                const lis = document.querySelectorAll("ul#CPL > li[data-pr]");
                const n = lis.length;
                if (n === 0) return { ok: true, priced: 0, total: 0 };
                let priced = 0;
                lis.forEach((li) => {
                  const a = li.querySelector("a[href]");
                  if (!a) return;
                  const el =
                    a.querySelector("[class*='cmpgn_pt']") ||
                    a.querySelector(".pt_v8, .pt_v9, [class*='pt_v']");
                  const txt = el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : "";
                  if (txt && /\d/.test(txt)) priced++;
                });
                const enough = priced >= n || (priced > 0 && iteration >= 12);
                return { ok: enough, priced, total: n };
              }
            });
            const res = r && r[0] && r[0].result;
            if (res && res.ok) return;
          } catch (e) {}
          await sleep(280);
        }
      };
      const collectCurrentPageRows = (persistentVendorHints) =>
        chrome.scripting.executeScript({
        target: { tabId },
        args: [
          persistentVendorHints && typeof persistentVendorHints === "object" ? persistentVendorHints : {},
          currentPassFill,
          currentPassOpts && typeof currentPassOpts === "object" ? currentPassOpts : {}
        ],
        func: (persistentVendorHints, fillPlatforms, passOpts) => {
          const normalizeUrl = (raw) => {
            const s = String(raw || "").trim();
            if (!s) return "";
            if (s.startsWith("//")) return "https:" + s;
            try {
              return new URL(s, location.origin).href;
            } catch (e) {
              return s;
            }
          };
          const parseAkakceId = (href) => {
            const m = String(href || "").match(/,(\d+)\.html(?:$|\?)/);
            return m && m[1] ? m[1] : "";
          };
          const cleanText = (value) => String(value || "").replace(/\s+/g, " ").trim();
          const AKAKCE_N11_VENDOR_IDS = new Set(["11070"]);
          const isAkakceVendorIdN11 = (vid) => AKAKCE_N11_VENDOR_IDS.has(String(vid || "").trim());
          const AKAKCE_VENDOR_ID_PLATFORM = Object.assign(Object.create(null), {
            "11070": "n11",
            "10001": "amazon",
            "10402": "teknosa",
            "10694": "pazarama",
            "11281": "pttavm",
            "11707": "trendyol",
            "12088": "hepsiburada",
            "13275": "idefix",
            "14770": "trendyol"
          });
          const pickAkakceOfferPriceElement = (anchor) => {
            const selGroups = [
              "span.cmpgn_pt_v8, span.cmpgn_pt_v9, [class*='cmpgn_pt']",
              "span.pt_v8, .pt_v8, span.pt_v9, .pt_v9, [class*='pt_v']"
            ];
            for (const sel of selGroups) {
              const nodes = anchor.querySelectorAll(sel);
              for (let i = 0; i < nodes.length; i++) {
                const t = cleanText(nodes[i].textContent);
                if (t && /\d/.test(t)) return nodes[i];
              }
            }
            return null;
          };
          const getAkakceOfferFromAnchor = (anchor) => {
            const priceEl = pickAkakceOfferPriceElement(anchor);
            const priceText = cleanText(priceEl ? priceEl.textContent : "");
            if (!priceText) return null;
            const img = anchor.querySelector("span.l img, i img, img");
            if (!img) return null;
            const alt = cleanText(img.getAttribute("alt") || "");
            const srcRaw = String(img.getAttribute("src") || "").trim();
            const srcNorm = normalizeUrl(srcRaw);
            const hrefRaw = String(anchor.getAttribute("href") || anchor.href || "").trim();
            let v = "";
            try {
              const u = new URL(hrefRaw, location.origin);
              if (/akakce\.com$/i.test(u.hostname)) v = u.searchParams.get("v") || "";
            } catch (e) {}
            const hasM6 = /\/im\/m6\//i.test(srcRaw) || /\/im\/m6\//i.test(srcNorm);
            const mSvg = srcRaw.match(/\/im\/m6\/(\d+)\.svg/i) || srcNorm.match(/\/im\/m6\/(\d+)\.svg/i);
            if (!v && mSvg && mSvg[1]) v = mSvg[1];
            const digitAlt = /^\d+$/.test(alt) || (hasM6 && /^\d+$/.test(v));
            return { priceText, alt, srcRaw, hrefRaw, v, hasM6, digitAlt };
          };
          const getFirstRankedSellerPriceForLi = (li) => {
            const firstAnchor =
              li.querySelector(".p_w_v9 > a:first-child") ||
              li.querySelector(".p_w_v9 > a:first-of-type") ||
              li.querySelector(".p_w_v9 > a");
            if (!firstAnchor) return "-";
            const offer = getAkakceOfferFromAnchor(firstAnchor);
            if (offer && offer.priceText) return offer.priceText;
            const pel = pickAkakceOfferPriceElement(firstAnchor);
            return pel ? cleanText(pel.textContent) : "-";
          };
          const buildAkakceVendorPlatformHints = () => {
            const hints = Object.create(null);
            document.querySelectorAll("a[href*='akakce.com/c/']").forEach((anchor) => {
              const img = anchor.querySelector("img[alt]");
              if (!img) return;
              const alt = cleanText(img.getAttribute("alt") || "");
              let v = "";
              try {
                const u = new URL(anchor.getAttribute("href") || anchor.href, location.origin);
                if (!/akakce\.com$/i.test(u.hostname)) return;
                v = u.searchParams.get("v") || "";
              } catch (e) {
                return;
              }
              if (!v) return;
              const altLow = alt.toLowerCase();
              if (altLow.includes("hepsiburada")) hints[v] = "hb";
              else if (altLow === "n11" || /\bn11\b/.test(altLow)) hints[v] = "n11";
              else if (altLow.includes("trendyol") && altLow.includes("plus")) hints[v] = "trendyol_plus";
              else if (altLow.includes("trendyol")) hints[v] = "trendyol";
              else if (altLow.includes("amazon")) hints[v] = "amazon";
              else if (altLow.includes("pazarama")) hints[v] = "pazarama";
              else if (altLow.includes("ptt") && altLow.includes("avm")) hints[v] = "pttavm";
              else if (altLow.includes("idefix")) hints[v] = "idefix";
              else if (altLow.includes("teknosa")) hints[v] = "teknosa";
              if (!hints[v] && isAkakceVendorIdN11(v)) hints[v] = "n11";
            });
            return hints;
          };
          const isHepsiburadaFilteredListPath = () =>
            /\/1195915(?:\/|$|\?)/.test(String(location.pathname || ""));
          const getHbAndN11PricesForLi = (li, vendorHints) => {
            const hintsEmpty = !vendorHints || Object.keys(vendorHints).length === 0;
            let hb = "-";
            let n11 = "-";
            if (isHepsiburadaFilteredListPath()) {
              const hbAnchor =
                li.querySelector(".p_w_v9 > a:first-child") ||
                li.querySelector(".p_w_v9 > a:first-of-type") ||
                li.querySelector(".p_w_v9 > a");
              if (hbAnchor) {
                const hbOffer = getAkakceOfferFromAnchor(hbAnchor);
                if (hbOffer) hb = hbOffer.priceText;
                else {
                  const pel = pickAkakceOfferPriceElement(hbAnchor);
                  if (pel) hb = cleanText(pel.textContent);
                }
              }
              const pv9Anchors = Array.from(li.querySelectorAll(".p_w_v9 > a"));
              const n11Candidates = hbAnchor ? pv9Anchors.filter((a) => a !== hbAnchor) : pv9Anchors.slice(1);
              const offersHbFilter = [];
              for (let ai = 0; ai < n11Candidates.length; ai++) {
                const o = getAkakceOfferFromAnchor(n11Candidates[ai]);
                if (o) offersHbFilter.push(o);
              }
              const ambiguousHb = [];
              for (let oi = 0; oi < offersHbFilter.length; oi++) {
                const o = offersHbFilter[oi];
                const hrefNorm = normalizeUrl(o.hrefRaw);
                let kind = null;
                if (/^n11$/i.test(o.alt) || /\bn11\b/.test(o.alt) || /n11\.com/i.test(o.hrefRaw) || /n11\.com/i.test(hrefNorm)) {
                  kind = "n11";
                } else if (o.digitAlt && o.hasM6 && o.v && (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v))) {
                  kind = "n11";
                } else if (o.digitAlt && o.hasM6) {
                  ambiguousHb.push(o);
                  continue;
                }
                if (kind === "n11" && n11 === "-") n11 = o.priceText;
              }
              for (let ai = 0; ai < ambiguousHb.length; ai++) {
                const o = ambiguousHb[ai];
                if (
                  o.v &&
                  (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v)) &&
                  n11 === "-"
                ) {
                  n11 = o.priceText;
                }
              }
              if (ambiguousHb.length === 1 && n11 === "-" && hintsEmpty) n11 = ambiguousHb[0].priceText;
              if (ambiguousHb.length >= 2 && n11 === "-") n11 = ambiguousHb[0].priceText;
              return { hb, n11 };
            }
            let anchors = Array.from(
              li.querySelectorAll('a.iC[href*="/c/?"], a.iC[href*="akakce.com/c/?"]')
            );
            if (anchors.length === 0) {
              anchors = Array.from(li.querySelectorAll("div.p_w_v9 a, a"));
            }
            const offers = [];
            for (const anchor of anchors) {
              const o = getAkakceOfferFromAnchor(anchor);
              if (o) offers.push(o);
            }
            hb = "-";
            n11 = "-";
            const ambiguous = [];
            for (const o of offers) {
              const hrefNorm = normalizeUrl(o.hrefRaw);
              let kind = null;
              if (/hepsiburada/i.test(o.alt) || /hepsiburada\.com/i.test(o.hrefRaw) || /hepsiburada\.com/i.test(hrefNorm)) {
                kind = "hb";
              } else if (/^n11$/i.test(o.alt) || /\bn11\b/i.test(o.alt) || /n11\.com/i.test(o.hrefRaw) || /n11\.com/i.test(hrefNorm)) {
                kind = "n11";
              } else if (o.digitAlt && o.hasM6 && o.v && vendorHints[o.v] === "hb") {
                kind = "hb";
              } else if (
                o.digitAlt &&
                o.hasM6 &&
                o.v &&
                (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v))
              ) {
                kind = "n11";
              } else if (o.digitAlt && o.hasM6) {
                ambiguous.push(o);
                continue;
              }
              if (kind === "hb" && hb === "-") hb = o.priceText;
              else if (kind === "n11" && n11 === "-") n11 = o.priceText;
            }
            for (const o of ambiguous) {
              if (o.v && vendorHints[o.v] === "hb" && hb === "-") hb = o.priceText;
              else if (o.v && (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v)) && n11 === "-") {
                n11 = o.priceText;
              }
            }
            if (ambiguous.length === 2 && (hb === "-" || n11 === "-")) {
              if (n11 === "-") n11 = ambiguous[0].priceText;
              if (hb === "-") hb = ambiguous[1].priceText;
            } else if (ambiguous.length > 2 && (hb === "-" || n11 === "-")) {
              ambiguous.forEach((o) => {
                if (o.v && (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v)) && n11 === "-") {
                  n11 = o.priceText;
                }
                if (o.v && vendorHints[o.v] === "hb" && hb === "-") hb = o.priceText;
              });
            } else if (hintsEmpty && ambiguous.length === 1 && hb === "-" && n11 === "-") {
              hb = ambiguous[0].priceText;
            }
            return { hb, n11 };
          };
          const fp = Array.isArray(fillPlatforms) && fillPlatforms.length
            ? fillPlatforms
            : ["hepsiburada", "n11"];
          const firstRanked = !!(passOpts && passOpts.useFirstRankedPrice);
          const tumuMode = !!(passOpts && passOpts.tumuMode);
          const firstRankedPk = passOpts && passOpts.firstRankedPlatform
            ? String(passOpts.firstRankedPlatform).trim()
            : "";
          const firstRankedWithN11 =
            !tumuMode &&
            firstRanked &&
            firstRankedPk &&
            fp.includes(firstRankedPk) &&
            fp.includes("n11");
          const fieldMap = {
            tumu: "tumuPrice",
            hepsiburada: "hepsiburadaPrice",
            n11: "n11Price",
            trendyol: "trendyolPrice",
            trendyol_plus: "trendyolPlusPrice",
            amazon: "amazonPrice",
            pazarama: "pazaramaPrice",
            pttavm: "pttavmPrice",
            idefix: "idefixPrice",
            teknosa: "teknosaPrice",
            other: "otherPrice"
          };
          const emptyPrices = () => ({
            tumuPrice: "-",
            hepsiburadaPrice: "-",
            n11Price: "-",
            trendyolPrice: "-",
            trendyolPlusPrice: "-",
            amazonPrice: "-",
            pazaramaPrice: "-",
            pttavmPrice: "-",
            idefixPrice: "-",
            teknosaPrice: "-",
            otherPrice: "-"
          });
          const buildOffersFromLi = (li) => {
            let anchors = Array.from(
              li.querySelectorAll('a.iC[href*="/c/?"], a.iC[href*="akakce.com/c/?"]')
            );
            if (anchors.length === 0) anchors = Array.from(li.querySelectorAll("div.p_w_v9 a, a"));
            const arr = [];
            for (let i = 0; i < anchors.length; i++) {
              const o = getAkakceOfferFromAnchor(anchors[i]);
              if (o) arr.push(o);
            }
            return arr;
          };
          const assignPricesFromOffers = (offers, vendorHints, want) => {
            const out = emptyPrices();
            const hrefNormFor = (hrefRaw) => normalizeUrl(hrefRaw);
            for (let oi = 0; oi < offers.length; oi++) {
              const o = offers[oi];
              const hrefNorm = hrefNormFor(o.hrefRaw);
              for (let wi = 0; wi < want.length; wi++) {
                const p = want[wi];
                const fk = fieldMap[p];
                if (!fk || out[fk] !== "-") continue;
                let hit = false;
                if (p === "hepsiburada")
                  hit =
                    /hepsiburada/i.test(o.alt) ||
                    /hepsiburada\.com/i.test(o.hrefRaw) ||
                    /hepsiburada\.com/i.test(hrefNorm);
                else if (p === "n11")
                  hit =
                    /^n11$/i.test(o.alt) ||
                    /\bn11\b/.test(o.alt) ||
                    /n11\.com/i.test(o.hrefRaw) ||
                    /n11\.com/i.test(hrefNorm) ||
                    isAkakceVendorIdN11(o.v);
                else if (p === "trendyol")
                  hit =
                    /trendyol/i.test(o.alt) ||
                    /trendyol\.com/i.test(o.hrefRaw) ||
                    /trendyol\.com/i.test(hrefNorm);
                else if (p === "trendyol_plus")
                  hit =
                    (/trendyol/i.test(o.alt) && /plus/i.test(o.alt)) ||
                    /typlus|trendyol.*plus/i.test(o.hrefRaw) ||
                    /typlus|trendyol.*plus/i.test(hrefNorm);
                else if (p === "amazon")
                  hit =
                    /amazon/i.test(o.alt) ||
                    /amazon\.com\.tr/i.test(o.hrefRaw) ||
                    /amazon\.com\.tr/i.test(hrefNorm);
                else if (p === "pazarama")
                  hit =
                    /pazarama/i.test(o.alt) ||
                    /pazarama\.com/i.test(o.hrefRaw) ||
                    /pazarama\.com/i.test(hrefNorm);
                else if (p === "pttavm")
                  hit =
                    /ptt\s*avm/i.test(o.alt) ||
                    /pttavm\.com/i.test(o.hrefRaw) ||
                    /pttavm\.com/i.test(hrefNorm);
                else if (p === "idefix")
                  hit =
                    /idefix/i.test(o.alt) ||
                    /idefix\.com/i.test(o.hrefRaw) ||
                    /idefix\.com/i.test(hrefNorm);
                else if (p === "teknosa")
                  hit =
                    /teknosa/i.test(o.alt) ||
                    /teknosa\.com/i.test(o.hrefRaw) ||
                    /teknosa\.com/i.test(hrefNorm);
                if (hit) out[fk] = o.priceText;
              }
            }
            for (let oi = 0; oi < offers.length; oi++) {
              const o = offers[oi];
              if (!o.digitAlt || !o.hasM6 || !o.v) continue;
              for (let wi = 0; wi < want.length; wi++) {
                const p = want[wi];
                const fk = fieldMap[p];
                if (!fk || out[fk] !== "-") continue;
                if (p === "hepsiburada" && vendorHints[o.v] === "hb") out[fk] = o.priceText;
                else if (
                  p === "n11" &&
                  (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v))
                ) {
                  out[fk] = o.priceText;
                } else if (
                  p !== "hepsiburada" &&
                  p !== "n11" &&
                  p !== "trendyol_plus" &&
                  vendorHints[o.v] === p
                ) {
                  out[fk] = o.priceText;
                } else if (p === "trendyol_plus" && vendorHints[o.v] === "trendyol_plus") {
                  out[fk] = o.priceText;
                }
              }
            }
            return out;
          };
          const normalizeHintToTumuPlatform = (h) => {
            if (!h) return null;
            if (h === "hb") return "hepsiburada";
            if (h === "trendyol_plus") return "trendyol";
            if (
              h === "n11" ||
              h === "trendyol" ||
              h === "amazon" ||
              h === "pazarama" ||
              h === "pttavm" ||
              h === "idefix" ||
              h === "teknosa"
            ) {
              return h;
            }
            return null;
          };
          const classifyTumuPlatform = (o, vendorHints) => {
            if (!o) return null;
            const hrefNorm = normalizeUrl(o.hrefRaw);
            const v = String(o.v || "").trim();
            if (
              /^n11$/i.test(o.alt) ||
              /\bn11\b/.test(o.alt) ||
              /n11\.com/i.test(o.hrefRaw) ||
              /n11\.com/i.test(hrefNorm) ||
              isAkakceVendorIdN11(v)
            ) {
              return "n11";
            }
            if (
              /hepsiburada/i.test(o.alt) ||
              /hepsiburada\.com/i.test(o.hrefRaw) ||
              /hepsiburada\.com/i.test(hrefNorm)
            ) {
              return "hepsiburada";
            }
            if (
              (/trendyol/i.test(o.alt) && /plus/i.test(o.alt)) ||
              /typlus|trendyol.*plus/i.test(o.hrefRaw) ||
              /typlus|trendyol.*plus/i.test(hrefNorm)
            ) {
              return "trendyol";
            }
            if (
              /trendyol/i.test(o.alt) ||
              /trendyol\.com/i.test(o.hrefRaw) ||
              /trendyol\.com/i.test(hrefNorm)
            ) {
              return "trendyol";
            }
            if (
              /amazon/i.test(o.alt) ||
              /amazon\.com\.tr/i.test(o.hrefRaw) ||
              /amazon\.com\.tr/i.test(hrefNorm)
            ) {
              return "amazon";
            }
            if (
              /pazarama/i.test(o.alt) ||
              /pazarama\.com/i.test(o.hrefRaw) ||
              /pazarama\.com/i.test(hrefNorm)
            ) {
              return "pazarama";
            }
            if (
              /ptt\s*avm/i.test(o.alt) ||
              /pttavm\.com/i.test(o.hrefRaw) ||
              /pttavm\.com/i.test(hrefNorm)
            ) {
              return "pttavm";
            }
            if (
              /idefix/i.test(o.alt) ||
              /idefix\.com/i.test(o.hrefRaw) ||
              /idefix\.com/i.test(hrefNorm)
            ) {
              return "idefix";
            }
            if (
              /teknosa/i.test(o.alt) ||
              /teknosa\.com/i.test(o.hrefRaw) ||
              /teknosa\.com/i.test(hrefNorm)
            ) {
              return "teknosa";
            }
            const fromVid = AKAKCE_VENDOR_ID_PLATFORM[v];
            if (fromVid) return fromVid;
            const fromHint = normalizeHintToTumuPlatform(vendorHints[v]);
            if (fromHint) return fromHint;
            return null;
          };
          const parsePriceNumTumu = (text) => {
            const t = cleanText(String(text || ""));
            if (!t || t === "-") return null;
            const normalized = t
              .replace(/TL/gi, "")
              .replace(/[^\d,.\-]/g, "")
              .replace(/\./g, "")
              .replace(",", ".");
            const value = Number.parseFloat(normalized);
            return Number.isFinite(value) ? value : null;
          };
          const offerMatchesAnyTumuTrackedRetailer = (o, vendorHints) =>
            classifyTumuPlatform(o, vendorHints) != null;
          const rows = [];
          const baseHints =
            persistentVendorHints && typeof persistentVendorHints === "object" ? persistentVendorHints : {};
          const localHints = buildAkakceVendorPlatformHints();
          const vendorHints = Object.assign(Object.create(null), baseHints, localHints);
          const hintsThisPage = localHints;
          const items = Array.from(document.querySelectorAll("ul#CPL > li[data-pr]"));
          const wantHbN11 = fp.includes("hepsiburada") || fp.includes("n11");
          const singleFirstRanked =
            !tumuMode && firstRanked && fp.length === 1 && !firstRankedWithN11;
          items.forEach((li) => {
            const anchor = li.querySelector("a.iC[href], .w_v8 a[href], a[href*='fiyati,']");
            const href = anchor ? normalizeUrl(anchor.getAttribute("href") || anchor.href || "") : "";
            const img = li.querySelector("figure img");
            const imageUrl = normalizeUrl((img && (img.getAttribute("src") || img.getAttribute("data-src"))) || "");
            const title = String(
              (anchor && (anchor.getAttribute("title") || anchor.textContent)) ||
              (li.querySelector("h3.pn_v8") && li.querySelector("h3.pn_v8").textContent) ||
              (img && img.getAttribute("alt")) ||
              ""
            ).trim();
            const akakceId = parseAkakceId(href) || String(li.getAttribute("data-pr") || "").trim();
            const prices = emptyPrices();
            if (tumuMode) {
              const anchorsPw = li.querySelectorAll(".p_w_v9 > a");
              const bestByField = Object.create(null);
              for (let ai = 0; ai < anchorsPw.length; ai++) {
                const o = getAkakceOfferFromAnchor(anchorsPw[ai]);
                if (!o || !o.priceText) continue;
                const num = parsePriceNumTumu(o.priceText);
                if (num == null) continue;
                const plat = classifyTumuPlatform(o, vendorHints);
                if (!plat) continue;
                const fk = fieldMap[plat];
                if (!fk) continue;
                if (!bestByField[fk] || num < bestByField[fk].num) {
                  bestByField[fk] = { num, text: o.priceText };
                }
              }
              Object.keys(bestByField).forEach((fk) => {
                prices[fk] = bestByField[fk].text;
              });
              const firstPv9 =
                li.querySelector(".p_w_v9 > a:first-child") ||
                li.querySelector(".p_w_v9 > a:first-of-type") ||
                li.querySelector(".p_w_v9 > a");
              if (firstPv9) {
                const firstOffer = getAkakceOfferFromAnchor(firstPv9);
                if (
                  firstOffer &&
                  firstOffer.priceText &&
                  firstOffer.priceText !== "-" &&
                  !offerMatchesAnyTumuTrackedRetailer(firstOffer, vendorHints)
                ) {
                  prices.otherPrice = firstOffer.priceText;
                }
              }
            } else if (firstRankedWithN11) {
              const frfk = fieldMap[firstRankedPk];
              if (frfk) prices[frfk] = getFirstRankedSellerPriceForLi(li);
              const { n11: n11P } = getHbAndN11PricesForLi(li, vendorHints);
              prices.n11Price = n11P;
            } else if (singleFirstRanked) {
              const pk = fp[0];
              const fk = fieldMap[pk];
              if (fk) prices[fk] = getFirstRankedSellerPriceForLi(li);
            } else {
              if (wantHbN11) {
                const { hb: hbP, n11: n11P } = getHbAndN11PricesForLi(li, vendorHints);
                if (fp.includes("hepsiburada")) prices.hepsiburadaPrice = hbP;
                if (fp.includes("n11")) prices.n11Price = n11P;
              }
              const offers = buildOffersFromLi(li);
              const fromOffers = assignPricesFromOffers(offers, vendorHints, fp);
              fp.forEach((p) => {
                const fk = fieldMap[p];
                if (!fk) return;
                if (fromOffers[fk] && fromOffers[fk] !== "-") prices[fk] = fromOffers[fk];
              });
            }
            rows.push({
              imageUrl,
              title,
              akakceId,
              url: href,
              tumuPrice: prices.tumuPrice,
              hepsiburadaPrice: prices.hepsiburadaPrice,
              n11Price: prices.n11Price,
              trendyolPrice: prices.trendyolPrice,
              trendyolPlusPrice: prices.trendyolPlusPrice,
              amazonPrice: prices.amazonPrice,
              pazaramaPrice: prices.pazaramaPrice,
              pttavmPrice: prices.pttavmPrice,
              idefixPrice: prices.idefixPrice,
              teknosaPrice: prices.teknosaPrice,
              otherPrice: prices.otherPrice
            });
          });
          return { rows, hints: hintsThisPage };
        }
      });
      const getNextPageUrl = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const next = document.querySelector("p.pager_v8 a.p[title='Sonraki'], p.pager_v8 a[title='Sonraki']");
          if (!next) return "";
          const href = next.getAttribute("href") || next.href || "";
          if (!href) return "";
          try {
            return new URL(href, location.origin).href;
          } catch (e) {
            return href;
          }
        }
      });
      const waitForTabComplete = () =>
        new Promise((resolve) => {
          const onUpdate = (updatedId, info) => {
            if (updatedId !== tabId || info.status !== "complete") return;
            chrome.tabs.onUpdated.removeListener(onUpdate);
            resolve();
          };
          chrome.tabs.onUpdated.addListener(onUpdate);
          chrome.tabs.get(tabId).then((t) => {
            if (t && t.status === "complete") {
              chrome.tabs.onUpdated.removeListener(onUpdate);
              resolve();
            }
          }).catch(() => {});
        });
      const mergedRowsArray = () => Array.from(mergedById.values());
      const collectPagesForCurrentPass = async () => {
        const maxPages = 20;
        const progressEveryPages = 5;
        const vendorHintsAcc = {};
        for (let i = 0; i < maxPages; i++) {
          resetTimeout(180000);
          await waitForCplPricesReady();
          const pageRowsResult = await collectCurrentPageRows(vendorHintsAcc);
          const pack = pageRowsResult && pageRowsResult[0] ? pageRowsResult[0].result : null;
          const pageRows = pack && Array.isArray(pack.rows) ? pack.rows : [];
          if (pack && pack.hints && typeof pack.hints === "object") {
            Object.assign(vendorHintsAcc, pack.hints);
          }
          const fillKeys =
            currentPassFill && currentPassFill.length ? currentPassFill : finalPlatforms;
          mergeRowsIntoMap(pageRows, fillKeys);
          totalPageCountAllPasses += 1;
          if (senderTabId && totalPageCountAllPasses % progressEveryPages === 0) {
            chrome.tabs.sendMessage(senderTabId, {
              type: "akakce-custom-deal-progress",
              rows: mergedRowsArray(),
              pageCount: totalPageCountAllPasses
            }).catch(() => {});
          }
          const nextResult = await getNextPageUrl();
          const nextUrl = nextResult && nextResult[0] && nextResult[0].result
            ? String(nextResult[0].result).trim()
            : "";
          if (!nextUrl) break;
          await chrome.tabs.update(tabId, { url: nextUrl });
          await waitForTabComplete();
          await sleep(500);
          await waitUntilAkakceListReady(240000);
        }
      };
      const runAllPasses = async () => {
        for (let pi = 0; pi < passes.length; pi++) {
          currentPassFill =
            passes[pi].fill && passes[pi].fill.length ? passes[pi].fill : finalPlatforms;
          currentPassOpts = {
            useFirstRankedPrice: !!passes[pi].useFirstRankedPrice,
            firstRankedPlatform: passes[pi].firstRankedPlatform
              ? String(passes[pi].firstRankedPlatform)
              : "",
            tumuMode: !!passes[pi].tumuMode
          };
          if (pi > 0) {
            resetTimeout(180000);
            await chrome.tabs.update(tabId, { url: passes[pi].url });
            await waitForTabComplete();
            await sleep(500);
            await waitUntilAkakceListReady(240000);
          }
          await collectPagesForCurrentPass();
        }
        if (senderTabId) {
          chrome.tabs
            .sendMessage(senderTabId, {
              type: "akakce-custom-deal-progress",
              rows: mergedRowsArray(),
              pageCount: totalPageCountAllPasses
            })
            .catch(() => {});
        }
        finish({
          ok: true,
          rows: mergedRowsArray(),
          pageCount: Number(totalPageCountAllPasses || 0)
        });
      };
      const startFlow = () => {
        if (crawlFlowStarted) return;
        crawlFlowStarted = true;
        resetTimeout(120000);
        lastWasChallenge = false;
        sleep(800)
          .then(() => waitUntilAkakceListReady(600000))
          .then(() => runAllPasses())
          .catch((err) => {
            finish(
              { ok: false, error: err?.message || "Liste toplama sirasinda hata olustu." },
              { keepTabOpen: lastWasChallenge }
            );
          });
      };
      loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        loadListener = null;
        startFlow();
      };
      resetTimeout(120000);
      chrome.tabs.onUpdated.addListener(loadListener);
      chrome.tabs.get(tabId).then((currentTab) => {
        if (currentTab && currentTab.status === "complete") {
          chrome.tabs.onUpdated.removeListener(loadListener);
          loadListener = null;
          startFlow();
        }
      }).catch(() => {});
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme acma hatasi." });
    });
    return true;
  }
  if (message && message.type === "akakce-full-category-crawl") {
    const rawUrl = String(message.url || "").trim();
    if (!rawUrl || !rawUrl.includes("akakce.com")) {
      sendResponse({ ok: false, error: "Gecersiz Akakce URL" });
      return true;
    }
    let normalizedUrl = rawUrl;
    if (!/^https?:\/\//i.test(normalizedUrl)) normalizedUrl = "https://" + normalizedUrl;
    try {
      const p = new URL(normalizedUrl);
      if (!/(\.|^)akakce\.com$/i.test(p.hostname)) {
        sendResponse({ ok: false, error: "Sadece akakce.com" });
        return true;
      }
    } catch (e) {
      sendResponse({ ok: false, error: "Gecersiz URL" });
      return true;
    }
    const senderTabId = sender && sender.tab && sender.tab.id;
    const notifyStatus = (statusText) => {
      if (!senderTabId || !statusText) return;
      chrome.tabs
        .sendMessage(senderTabId, {
          type: "akakce-full-category-update",
          statusText: String(statusText)
        })
        .catch(() => {});
    };
    chrome.tabs.create({ url: normalizedUrl, active: true }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme acilamadi" });
        return;
      }
      const tabId = tab.id;
      let finished = false;
      let timeoutId;
      let loadListener = null;
      let lastWasChallenge = false;
      let crawlStarted = false;
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const finish = (payload, opts) => {
        if (finished) return;
        finished = true;
        clearTimeout(timeoutId);
        if (loadListener) chrome.tabs.onUpdated.removeListener(loadListener);
        sendResponse(payload);
        const keepOpen = opts && opts.keepTabOpen === true;
        if (!keepOpen) chrome.tabs.remove(tabId).catch(() => {});
      };
      const resetTimeout = (msFromNow) => {
        clearTimeout(timeoutId);
        const ms = typeof msFromNow === "number" ? msFromNow : 300000;
        timeoutId = setTimeout(() => {
          const err = lastWasChallenge
            ? "Captcha zaman asimi. Akakce sekmesinde dogrulamayi tamamlayip tekrar deneyin."
            : "Zaman asimi.";
          finish({ ok: false, error: err }, { keepTabOpen: lastWasChallenge });
        }, ms);
      };
      const detectAkakceCrawlPageState = () =>
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const cpl = document.querySelector("ul#CPL");
            const liCount = document.querySelectorAll("ul#CPL > li[data-pr]").length;
            const cplExists = !!cpl;
            const hasCpl = liCount > 0;
            const title = (document.title || "").trim();
            if (cplExists || hasCpl) {
              return { isChallenge: false, hasCpl, cplExists, liCount, title };
            }
            const href = String(location.href || "");
            const t = document.body && document.body.innerText ? document.body.innerText : "";
            const tShort = t.length > 4000 ? t.slice(0, 4000) : t;
            let isChallenge = false;
            if (/__cf_chl|__cf_bm=/.test(href)) isChallenge = true;
            if (!isChallenge && /^just a moment\b/i.test(title)) isChallenge = true;
            if (!isChallenge && /^attention required\b|^sorry, you have been blocked\b/i.test(title)) {
              isChallenge = true;
            }
            if (
              !isChallenge &&
              document.querySelector(
                "iframe[src*='challenges.cloudflare.com'], iframe[src*='challenges.cloudflare']"
              )
            ) {
              isChallenge = true;
            }
            if (!isChallenge && document.querySelector("#cf-challenge-running, #challenge-running, .cf-browser-verification")) {
              isChallenge = true;
            }
            if (
              !isChallenge &&
              tShort.length < 900 &&
              /checking your browser|one more step|confirm you are a human|ddos protection by cloudflare/i.test(tShort) &&
              !/akakce|ürün|urun|fiyat|kategori/i.test(tShort)
            ) {
              isChallenge = true;
            }
            return { isChallenge, hasCpl, cplExists, liCount, title };
          }
        });
      const waitUntilAkakceListReady = async (maxMs) => {
        const pollMs = 2000;
        const deadline = Date.now() + maxMs;
        let captchaNotified = false;
        while (Date.now() < deadline) {
          let s = null;
          try {
            const r = await detectAkakceCrawlPageState();
            s = r && r[0] && r[0].result ? r[0].result : null;
          } catch (e) {
            await sleep(pollMs);
            continue;
          }
          if (!s) {
            await sleep(pollMs);
            continue;
          }
          if (s.cplExists || s.hasCpl) {
            lastWasChallenge = false;
            return;
          }
          if (s.isChallenge) {
            lastWasChallenge = true;
            resetTimeout(600000);
            if (!captchaNotified) {
              captchaNotified = true;
              notifyStatus(
                "Akakce guvenlik: Acilan sekmede Captcha tamamlayin; liste hazir olunca tarama devam eder."
              );
            }
            await sleep(pollMs);
            continue;
          }
          lastWasChallenge = false;
          await sleep(pollMs);
        }
        throw new Error("Akakce liste (ul#CPL) zaman asimina ugradi.");
      };
      const collectCategoryProducts = () =>
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const normalizeUrl = (raw) => {
              const s = String(raw || "").trim();
              if (!s) return "";
              if (s.startsWith("//")) return "https:" + s;
              try {
                return new URL(s, location.origin).href;
              } catch (e) {
                return s;
              }
            };
            const parseAkakceIdFromHref = (href) => {
              const m = String(href || "").match(/,(\d+)\.html(?:$|\?)/);
              return m && m[1] ? m[1] : "";
            };
            const items = Array.from(document.querySelectorAll("ul#CPL > li[data-pr]"));
            const products = [];
            items.forEach((li) => {
              const anchor = li.querySelector("a.iC[href], .w_v8 a[href], a[href*='fiyati,']");
              if (!anchor) return;
              const hrefRaw = anchor.getAttribute("href") || anchor.href || "";
              const href = normalizeUrl(hrefRaw);
              let akakceId = parseAkakceIdFromHref(href);
              if (!akakceId) akakceId = String(li.getAttribute("data-pr") || "").trim();
              const img = li.querySelector("figure img");
              const imageSrc = normalizeUrl(
                (img && (img.getAttribute("src") || img.getAttribute("data-src"))) || ""
              );
              const titleAttr = String(anchor.getAttribute("title") || "").replace(/\s+/g, " ").trim();
              const h3El = li.querySelector("h3.pn_v8");
              const titleH3 = h3El
                ? String(h3El.textContent || "").replace(/\s+/g, " ").trim()
                : "";
              const titleText = String(anchor.textContent || "").replace(/\s+/g, " ").trim();
              const title = titleAttr || titleH3 || titleText;
              if (!href && !akakceId) return;
              products.push({
                akakceId: akakceId || "",
                title: title || "",
                href: href || "",
                imageSrc: imageSrc || ""
              });
            });
            return products;
          }
        });
      const getNextPageUrl = () =>
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const next = document.querySelector(
              "p.pager_v8 a.p[title='Sonraki'], p.pager_v8 a[title='Sonraki']"
            );
            if (!next) return "";
            const href = next.getAttribute("href") || next.href || "";
            if (!href) return "";
            try {
              return new URL(href, location.origin).href;
            } catch (e) {
              return href;
            }
          }
        });
      const waitForTabComplete = () =>
        new Promise((resolve) => {
          const onUpdate = (updatedId, info) => {
            if (updatedId !== tabId || info.status !== "complete") return;
            chrome.tabs.onUpdated.removeListener(onUpdate);
            resolve();
          };
          chrome.tabs.onUpdated.addListener(onUpdate);
          chrome.tabs
            .get(tabId)
            .then((t) => {
              if (t && t.status === "complete") {
                chrome.tabs.onUpdated.removeListener(onUpdate);
                resolve();
              }
            })
            .catch(() => {});
        });
      const runCrawl = async () => {
        const allProducts = [];
        const seenIds = new Set();
        const maxPages = 100;
        let pagesDone = 0;
        notifyStatus("Liste bekleniyor...");
        await sleep(600);
        await waitUntilAkakceListReady(600000);
        for (let pageIdx = 0; pageIdx < maxPages; pageIdx++) {
          resetTimeout(180000);
          const execResult = await collectCategoryProducts();
          const pageList =
            execResult && execResult[0] && Array.isArray(execResult[0].result)
              ? execResult[0].result
              : [];
          for (let pi = 0; pi < pageList.length; pi++) {
            const p = pageList[pi];
            const id = String(p.akakceId || "").trim();
            const dedupeKey = id || String(p.href || "");
            if (!dedupeKey) continue;
            if (seenIds.has(dedupeKey)) continue;
            seenIds.add(dedupeKey);
            allProducts.push(p);
          }
          pagesDone = pageIdx + 1;
          notifyStatus(
            "Sayfa " + pagesDone + " — " + allProducts.length + " urun (benzersiz ID/link)"
          );
          const nextResult = await getNextPageUrl();
          const nextUrl =
            nextResult && nextResult[0] && nextResult[0].result
              ? String(nextResult[0].result).trim()
              : "";
          if (!nextUrl) break;
          await chrome.tabs.update(tabId, { url: nextUrl });
          await waitForTabComplete();
          await sleep(500);
          await waitUntilAkakceListReady(240000);
        }
        finish({
          ok: true,
          products: allProducts,
          pageCount: pagesDone,
          sourceUrl: normalizedUrl
        });
      };
      const startFlow = () => {
        if (crawlStarted || finished) return;
        crawlStarted = true;
        resetTimeout(120000);
        lastWasChallenge = false;
        sleep(800)
          .then(() => runCrawl())
          .catch((err) => {
            finish(
              { ok: false, error: err?.message || "Kategori tarama hatasi." },
              { keepTabOpen: lastWasChallenge }
            );
          });
      };
      loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        loadListener = null;
        startFlow();
      };
      resetTimeout(120000);
      chrome.tabs.onUpdated.addListener(loadListener);
      chrome.tabs.get(tabId).then((currentTab) => {
        if (currentTab && currentTab.status === "complete") {
          chrome.tabs.onUpdated.removeListener(loadListener);
          loadListener = null;
          startFlow();
        }
      }).catch(() => {});
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme acma hatasi." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-n11-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("n11.com")) {
      sendResponse({ ok: false, error: "Geçersiz n11 linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 2600))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              try {
                const finalPrice = window?.model?.product?.personalizedData?.product?.finalPrice;
                if (finalPrice != null && String(finalPrice).trim() !== "") {
                  return String(finalPrice).trim();
                }
              } catch (e) {}
              const scripts = document.querySelectorAll("script");
              for (const scriptEl of scripts) {
                const text = scriptEl.textContent || "";
                if (!text || !/finalPrice/i.test(text)) continue;
                const fromPersonalized = text.match(/"personalizedData"\s*:\s*\{[\s\S]*?"product"\s*:\s*\{[\s\S]*?"finalPrice"\s*:\s*"([^"]+)"/i);
                if (fromPersonalized && fromPersonalized[1]) return fromPersonalized[1];
                const fromAnyFinal = text.match(/"finalPrice"\s*:\s*"([^"]+)"/i);
                if (fromAnyFinal && fromAnyFinal[1] && fromAnyFinal[1].toLowerCase() !== "null") return fromAnyFinal[1];
              }
              try {
                const direct = window?.model?.adData?.price;
                if (direct != null && String(direct).trim() !== "") {
                  return String(direct).trim();
                }
              } catch (e) {}
              for (const scriptEl of scripts) {
                const text = scriptEl.textContent || "";
                if (!text || !/adData/i.test(text) || !/price/i.test(text)) continue;
                const m1 = text.match(/model\.adData\.price\s*[=:]\s*["']?([\d.,]+)["']?/i);
                if (m1 && m1[1]) return m1[1];
                const m2 = text.match(/model\[['"]adData['"]\]\[['"]price['"]\]\s*[=:]\s*["']?([\d.,]+)["']?/i);
                if (m2 && m2[1]) return m2[1];
                const m3 = text.match(/"adData"\s*:\s*\{[\s\S]*?"price"\s*:\s*["']?([\d.,]+)["']?/i);
                if (m3 && m3[1]) return m3[1];
              }
              return null;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "model.product.personalizedData.product.finalPrice bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Fiyat okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-trendyol-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("trendyol.com")) {
      sendResponse({ ok: false, error: "Geçersiz Trendyol linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1200))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const discountedCandidates = [];
              const tyPlusCandidates = [];
              const parseTrPrice = (val) => {
                if (val == null) return null;
                let s = String(val).trim();
                if (!s) return null;
                s = s.replace(/TL/gi, "").replace(/\s+/g, "").replace(/\./g, "").replace(/,/g, ".");
                const n = Number(s);
                return Number.isFinite(n) ? n : null;
              };
              const pushCandidate = (arr, val) => {
                if (val == null) return;
                const s = String(val).trim();
                if (!s) return;
                arr.push(s);
              };
              const pickFromObject = (obj) => {
                try {
                  pushCandidate(discountedCandidates, obj?.price?.discountedPrice?.text);
                  pushCandidate(tyPlusCandidates, obj?.price?.tyPlusCouponApplicablePrice?.text);
                } catch (e) {}
              };
              const pickBestPrice = () => {
                const discounted = discountedCandidates
                  .map((v) => ({ raw: v, num: parseTrPrice(v) }))
                  .filter((x) => x.num != null);
                const tyPlus = tyPlusCandidates
                  .map((v) => ({ raw: v, num: parseTrPrice(v) }))
                  .filter((x) => x.num != null);
                const discountedMin = discounted.length
                  ? discounted.reduce((a, b) => (a.num <= b.num ? a : b))
                  : null;
                const tyPlusMin = tyPlus.length
                  ? tyPlus.reduce((a, b) => (a.num <= b.num ? a : b))
                  : null;
                if (tyPlusMin && (!discountedMin || tyPlusMin.num < discountedMin.num)) {
                  return tyPlusMin.raw;
                }
                if (discountedMin) return discountedMin.raw;
                return null;
              };
              const scanObject = (root) => {
                const visited = new Set();
                const stack = [root];
                while (stack.length) {
                  const cur = stack.pop();
                  if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
                  visited.add(cur);
                  pickFromObject(cur);
                  if (Array.isArray(cur)) {
                    for (const item of cur) stack.push(item);
                  } else {
                    for (const val of Object.values(cur)) {
                      if (val && typeof val === "object") stack.push(val);
                    }
                  }
                }
              };

              const winKeys = Object.keys(window || {});
              for (const k of winKeys) {
                if (!k || !k.includes("PROPS")) continue;
                try {
                  const v = window[k];
                  scanObject(v);
                } catch (e) {}
              }

              const scripts = document.querySelectorAll("script");
              for (const scriptEl of scripts) {
                const text = scriptEl.textContent || "";
                if (!text || !text.includes("price")) continue;
                const discountedMatches = text.matchAll(/"discountedPrice"\s*:\s*\{[\s\S]*?"text"\s*:\s*"([^"]+)"/gi);
                for (const m of discountedMatches) {
                  if (m && m[1]) pushCandidate(discountedCandidates, m[1]);
                }
                const tyPlusMatches = text.matchAll(/"tyPlusCouponApplicablePrice"\s*:\s*\{[\s\S]*?"text"\s*:\s*"([^"]+)"/gi);
                for (const m of tyPlusMatches) {
                  if (m && m[1]) pushCandidate(tyPlusCandidates, m[1]);
                }
              }
              return pickBestPrice();
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "price.discountedPrice.text / tyPlusCouponApplicablePrice.text bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Trendyol fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-hepsiburada-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("hepsiburada.com")) {
      sendResponse({ ok: false, error: "Geçersiz Hepsiburada linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 2600))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: async () => {
              const parseTrPrice = (val) => {
                if (val == null) return null;
                let s = String(val).trim();
                if (!s) return null;
                s = s.replace(/TL/gi, "").replace(/\s+/g, "").replace(/\./g, "").replace(/,/g, ".");
                const n = Number(s);
                return Number.isFinite(n) ? n : null;
              };
              const formatPrice = (val) => {
                const n = parseTrPrice(val);
                if (n == null) return null;
                return n.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
              };
              const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
              const pushCandidate = (val) => {
                if (val == null) return;
                const s = String(val).trim();
                return s || null;
              };
              const extractPremiumPrice = () => {
                const roots = [];
                const nonPremiumRoot = document.querySelector('[data-test-id="non-premium-price"]');
                if (nonPremiumRoot) roots.push(nonPremiumRoot);
                roots.push(document.body);
                const priceRegex = /premium\s*ile[\s\S]{0,80}?(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL/i;
                for (const root of roots) {
                  if (!root) continue;
                  const nodes = Array.from(root.querySelectorAll("span,div,p,b,strong"));
                  for (const node of nodes) {
                    const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
                    if (!text) continue;
                    const m = text.match(priceRegex);
                    if (m && m[1]) return `${m[1]} TL`;
                  }
                }
                return null;
              };
              const extractCheckoutPrice = () => {
                const boxes = Array.from(document.querySelectorAll('[data-test-id="checkout-price"]'));
                if (!boxes.length) return null;
                const labelRegex = /sepete\s*ozel\s*fiyat|sepete\s*özel\s*fiyat/i;
                const priceRegexWithTl = /(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL/gi;
                const priceRegexPlain = /\d{1,3}(?:\.\d{3})*(?:,\d{2})?/g;
                const strictPriceOnly = /^\s*(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL\s*$/i;
                for (const box of boxes) {
                  const boxText = String(box.textContent || "").trim();
                  if (!boxText) continue;
                  const normalized = boxText.toLocaleLowerCase("tr-TR");
                  if (!labelRegex.test(normalized)) continue;

                  // Prefer exact value nodes inside checkout-price (avoids campaign/earning numbers).
                  const valueNodes = Array.from(box.querySelectorAll("div,span,p,b,strong"))
                    .map((node) => String(node.textContent || "").replace(/\s+/g, " ").trim())
                    .filter(Boolean);
                  for (const nodeText of valueNodes) {
                    const strictMatch = nodeText.match(strictPriceOnly);
                    if (strictMatch && strictMatch[1]) {
                      return `${strictMatch[1]} TL`;
                    }
                  }

                  const withTlMatches = Array.from(boxText.matchAll(priceRegexWithTl));
                  if (withTlMatches.length) {
                    const raw = withTlMatches[0][1];
                    if (raw) return `${raw} TL`;
                  }
                  const plainMatches = boxText.match(priceRegexPlain) || [];
                  if (plainMatches.length) return `${plainMatches[0]} TL`;
                }
                return null;
              };
              const extractPriceBlockPrice = () => {
                const priceBlocks = Array.from(document.querySelectorAll('[data-test-id="price"]'));
                const strictPriceOnly = /^\s*(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL\s*$/i;
                for (const block of priceBlocks) {
                  const checkout = block.querySelector('[data-test-id="checkout-price"]');
                  const scope = checkout || block;
                  const nodes = Array.from(scope.querySelectorAll("div,span,p,b,strong"));
                  for (const node of nodes) {
                    const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
                    if (!text) continue;
                    const m = text.match(strictPriceOnly);
                    if (m && m[1]) return `${m[1]} TL`;
                  }
                }
                return null;
              };
              const extractVariantBoxPrice = () => {
                const direct = document.querySelector('[data-test-id="variant-box-price"]');
                if (direct) {
                  const text = String(direct.textContent || "").trim();
                  const m = text.match(/(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL/i);
                  if (m && m[1]) return `${m[1]} TL`;
                }
                const defaultPrice = document.querySelector('[data-test-id="default-price"]');
                if (defaultPrice) {
                  const text = String(defaultPrice.textContent || "").trim();
                  const m = text.match(/(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL/i);
                  if (m && m[1]) return `${m[1]} TL`;
                }
                return null;
              };
              const extractFromMetaAndSchema = () => {
                const metaAmount = document.querySelector('meta[property="product:price:amount"]');
                if (metaAmount) {
                  const fromMeta = formatPrice(metaAmount.getAttribute("content") || "");
                  if (fromMeta) return fromMeta;
                }
                const itemPropPrice = document.querySelector('[itemprop="price"]');
                if (itemPropPrice) {
                  const fromItemProp = formatPrice(itemPropPrice.getAttribute("content") || itemPropPrice.textContent || "");
                  if (fromItemProp) return fromItemProp;
                }
                const scriptEls = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
                for (const scriptEl of scriptEls) {
                  const text = (scriptEl.textContent || "").trim();
                  if (!text) continue;
                  try {
                    const data = JSON.parse(text);
                    const stack = [data];
                    while (stack.length) {
                      const cur = stack.pop();
                      if (!cur) continue;
                      if (Array.isArray(cur)) {
                        cur.forEach((item) => stack.push(item));
                        continue;
                      }
                      if (typeof cur !== "object") continue;
                      const typeVal = Array.isArray(cur["@type"]) ? cur["@type"].join(",") : String(cur["@type"] || "");
                      const isProduct = /product/i.test(typeVal);
                      if (isProduct) {
                        const offerObj = cur.offers;
                        const offerList = Array.isArray(offerObj) ? offerObj : (offerObj ? [offerObj] : []);
                        for (const offer of offerList) {
                          if (!offer || typeof offer !== "object") continue;
                          const fromOffer = formatPrice(offer.price || offer.lowPrice || offer.highPrice);
                          if (fromOffer) return fromOffer;
                        }
                        const fromProduct = formatPrice(cur.price || cur.lowPrice || cur.highPrice);
                        if (fromProduct) return fromProduct;
                      }
                      Object.values(cur).forEach((v) => {
                        if (v && typeof v === "object") stack.push(v);
                      });
                    }
                  } catch (e) {}
                }
                return null;
              };
              const extractStructuredFallbackPrice = () => {
                const candidates = [];
                const blockedPathRe = /(cargo|kargo|shipping|delivery|freight|installment|taksit|fee|commission|wallet|coupon|discount|sepet|basket)/i;
                const preferredPathRe = /(product|variant|offer|merchant|buybox|priceInfo|sale|final|list|current|sku)/i;
                const addCandidateWithPath = (val, path) => {
                  const s = pushCandidate(val);
                  if (!s) return;
                  const cleanPath = String(path || "");
                  if (blockedPathRe.test(cleanPath)) return;
                  const n = parseTrPrice(s);
                  if (n == null) return;
                  candidates.push({ raw: s, num: n, score: preferredPathRe.test(cleanPath) ? 2 : 1 });
                };
                const scanObject = (root) => {
                  const visited = new Set();
                  const stack = [{ value: root, path: "" }];
                  while (stack.length) {
                    const entry = stack.pop();
                    const cur = entry && entry.value;
                    const currentPath = entry && entry.path ? entry.path : "";
                    if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
                    visited.add(cur);
                    if (Object.prototype.hasOwnProperty.call(cur, "formattedPrice")) {
                      addCandidateWithPath(cur.formattedPrice, currentPath + ".formattedPrice");
                    }
                    if (Array.isArray(cur)) {
                      for (let i = 0; i < cur.length; i++) {
                        stack.push({ value: cur[i], path: `${currentPath}[${i}]` });
                      }
                    } else {
                      for (const [key, val] of Object.entries(cur)) {
                        if (/(^|_)(price|fiyat|amount|value)$/i.test(key) || /(price|fiyat|amount|value)/i.test(key)) {
                          addCandidateWithPath(val, `${currentPath}.${key}`);
                        }
                        if (val && typeof val === "object") {
                          stack.push({ value: val, path: `${currentPath}.${key}` });
                        }
                      }
                    }
                  }
                };
                try {
                  if (window.__INITIAL_STATE__) scanObject(window.__INITIAL_STATE__);
                } catch (e) {}
                try {
                  const keys = Object.keys(window || {});
                  for (const k of keys) {
                    if (!k || !/STATE|PROPS|DATA|PRODUCT/i.test(k)) continue;
                    const v = window[k];
                    if (v && typeof v === "object") scanObject(v);
                  }
                } catch (e) {}
                const scripts = document.querySelectorAll("script");
                for (const scriptEl of scripts) {
                  const text = scriptEl.textContent || "";
                  if (!text || (!text.includes("formattedPrice") && !text.includes("\"price\""))) continue;
                  const matches = text.matchAll(/"formattedPrice"\s*:\s*"([^"]+)"/gi);
                  for (const m of matches) {
                    if (m && m[1]) addCandidateWithPath(m[1], "script.formattedPrice");
                  }
                  const explicitPriceMatches = text.matchAll(/"(?:finalPrice|salePrice|currentPrice|listingPrice|discountedPrice|price)"\s*:\s*"?(\d{1,3}(?:\.\d{3})*(?:,\d{2})?|\d+(?:[.,]\d+)?)"?/gi);
                  for (const m of explicitPriceMatches) {
                    if (m && m[1]) addCandidateWithPath(m[1], "script.explicitPrice");
                  }
                }
                const parsed = candidates
                  .map((entry) => {
                    if (typeof entry === "string") {
                      const num = parseTrPrice(entry);
                      return num == null ? null : { raw: entry, num, score: 0 };
                    }
                    return entry && entry.num != null ? entry : null;
                  })
                  .filter(Boolean);
                if (!parsed.length) return null;
                parsed.sort((a, b) => {
                  if (b.score !== a.score) return b.score - a.score;
                  return b.num - a.num;
                });
                return formatPrice(parsed[0].raw);
              };

              let fallbackPrice = null;
              for (let attempt = 0; attempt < 14; attempt++) {
                const checkoutPrice = extractCheckoutPrice();
                if (checkoutPrice) return checkoutPrice;

                const priceBlockPrice = extractPriceBlockPrice();
                if (priceBlockPrice) return priceBlockPrice;

                const variantBoxPrice = extractVariantBoxPrice();
                if (variantBoxPrice) return variantBoxPrice;

                const premiumPrice = extractPremiumPrice();
                if (premiumPrice) return premiumPrice;

                const schemaPrice = extractFromMetaAndSchema();
                if (schemaPrice) return schemaPrice;

                const structuredFallback = extractStructuredFallbackPrice();
                if (structuredFallback) fallbackPrice = structuredFallback;
                if (attempt < 13) await sleep(500);
              }
              return fallbackPrice;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "formattedPrice bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Hepsiburada fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-amazon-price") {
    const url = (message.url || "").trim();
    if (!url || !/amazon\./i.test(url)) {
      sendResponse({ ok: false, error: "Geçersiz Amazon linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1400))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const prices = [];
              const parsePriceNum = (raw) => {
                if (raw == null) return null;
                let s = String(raw).trim();
                if (!s) return null;
                s = s.replace(/TL/gi, "").replace(/\s+/g, "").replace(/\./g, "").replace(/,/g, ".");
                const n = Number(s);
                return Number.isFinite(n) ? n : null;
              };
              const isUnavailableState = () => {
                const selectors = [
                  "#availability",
                  "#outOfStock",
                  "#availabilityInsideBuyBox_feature_div",
                  ".primary-availability-message",
                  "[data-feature-name='availabilityInsideBuyBox']",
                  "[data-csa-c-type='availability']"
                ];
                const unavailableRe = /şu anda mevcut değil|stokta yok|tükendi|currently unavailable|temporarily out of stock|out of stock|unavailable/i;
                for (const sel of selectors) {
                  const nodes = document.querySelectorAll(sel);
                  for (const node of nodes) {
                    const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
                    if (text && unavailableRe.test(text)) return true;
                  }
                }
                const bodyText = String(document.body?.innerText || "").replace(/\s+/g, " ").trim();
                return unavailableRe.test(bodyText);
              };
              const addCandidate = (whole, fraction) => {
                const w = (whole || "").replace(/[^\d.]/g, "").trim();
                const f = (fraction || "").replace(/[^\d]/g, "").trim();
                if (!w) return;
                const text = f ? `${w},${f}` : w;
                const num = parsePriceNum(text);
                if (num == null) return;
                prices.push({ raw: text, num });
              };

              const addRawCandidate = (raw) => {
                if (raw == null) return;
                const sourceText = String(raw).replace(/\s+/g, " ").trim();
                if (/\/\s*ay|ayda|taksit|installment/i.test(sourceText)) return;
                const s = sourceText.replace(/TL/gi, "").trim();
                if (!s) return;
                const num = parsePriceNum(s);
                if (num == null) return;
                prices.push({ raw: s, num });
              };

              if (isUnavailableState()) return null;

              // Prefer Amazon's "price to pay" block first.
              const apexBlocks = document.querySelectorAll(
                "#corePrice_feature_div .a-price, " +
                "#corePriceDisplay_desktop_feature_div .a-price, " +
                "#apex_desktop .a-price, " +
                "#tp_price_block_total_price_ww .a-price, " +
                "#exports_desktop_qualifiedBuyBox .a-price, " +
                ".apex-core-price-identifier .apex-pricetopay-value, " +
                ".apex-core-price-identifier .a-price"
              );
              for (const block of apexBlocks) {
                const offscreen = block.querySelector(".a-offscreen")?.textContent || "";
                if (offscreen) {
                  addRawCandidate(offscreen);
                }
                const whole = block.querySelector(".a-price-whole")?.textContent || "";
                const fraction = block.querySelector(".a-price-fraction")?.textContent || "";
                addCandidate(whole, fraction);
              }
              if (prices.length) {
                const minApex = prices.reduce((a, b) => (a.num <= b.num ? a : b));
                return minApex.raw;
              }

              const directPriceNodes = document.querySelectorAll(
                "#priceblock_ourprice, #priceblock_dealprice, #priceblock_saleprice, #corePriceDisplay_desktop_feature_div .a-offscreen, #corePrice_feature_div .a-offscreen"
              );
              for (const node of directPriceNodes) {
                addRawCandidate(node.textContent || "");
              }
              if (!prices.length) return null;
              const min = prices.reduce((a, b) => (a.num <= b.num ? a : b));
              return min.raw;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "Amazon fiyatı (.a-price-whole/.a-price-fraction) bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Amazon fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-pazarama-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("pazarama.com")) {
      sendResponse({ ok: false, error: "Geçersiz Pazarama linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1400))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const parseTrPrice = (raw) => {
                if (raw == null) return null;
                const s = String(raw).trim();
                if (!s) return null;
                const normalized = s
                  .replace(/TL/gi, "")
                  .replace(/\s+/g, "")
                  .replace(/\./g, "")
                  .replace(/,/g, ".");
                const n = Number(normalized);
                return Number.isFinite(n) ? n : null;
              };
              const extractPricesFromText = (text) => {
                if (!text) return [];
                const matches = text.match(/\d{1,3}(?:\.\d{3})*,\d{2}\s*TL|\d{1,3}(?:\.\d{3})*,\d{2}/g) || [];
                return matches
                  .map((m) => ({ raw: m.replace(/\s+/g, " ").trim(), num: parseTrPrice(m) }))
                  .filter((x) => x.num != null);
              };
              const detailRoot = document.querySelector('div[page-name="detail"]') || document;
              const isInsideOtherSellers = (el) => {
                if (!el || typeof el.closest !== "function") return false;
                return Boolean(
                  el.closest(
                    ".product__other-sellers, [class*='other-sellers'], [class*='otherSeller'], [class*='other-seller']"
                  )
                );
              };

              // 1) Prefer product-level Plus price when available.
              const plusCandidates = [];
              const collectPlusFromBlock = (block) => {
                if (!block) return;
                if (isInsideOtherSellers(block)) return;
                const strongNodes = block.querySelectorAll("span.font-bold.text-blue-500, span[class*='text-blue-500'], span[class*='font-bold']");
                for (const node of strongNodes) {
                  if (isInsideOtherSellers(node)) continue;
                  const prices = extractPricesFromText(node.textContent || "");
                  plusCandidates.push(...prices);
                }
                if (!plusCandidates.length) {
                  const allPrices = extractPricesFromText(block.textContent || "");
                  plusCandidates.push(...allPrices);
                }
              };

              const explicitPlusBlocks = document.querySelectorAll(
                "div.bg-pink-40, div[class*='bg-pink-40'], div[class*='border-pink-500']"
              );
              for (const block of explicitPlusBlocks) {
                if (isInsideOtherSellers(block)) continue;
                if (!detailRoot.contains(block)) continue;
                const txt = (block.textContent || "").toLowerCase();
                if (!txt.includes("plus") && !txt.includes("ile")) continue;
                collectPlusFromBlock(block);
              }

              const plusIconImgs = detailRoot.querySelectorAll("img[alt='plus-icon'], img[src*='pz-plus-icon']");
              for (const img of plusIconImgs) {
                if (isInsideOtherSellers(img)) continue;
                const block = img.closest("div");
                collectPlusFromBlock(block);
              }

              if (plusCandidates.length) {
                const plusMin = plusCandidates.reduce((a, b) => (a.num <= b.num ? a : b));
                return plusMin.raw;
              }

              // 2) Prefer "SEPETTE" discounted price in product area.
              const sepetteNodes = Array.from(detailRoot.querySelectorAll("div, span, p, strong, b"))
                .filter((el) => (el.textContent || "").trim().toUpperCase() === "SEPETTE" && !isInsideOtherSellers(el));
              for (const sepetteEl of sepetteNodes) {
                const nextText = sepetteEl.nextElementSibling?.textContent || "";
                const nextPrices = extractPricesFromText(nextText);
                if (nextPrices.length) {
                  return nextPrices[0].raw;
                }
                const parentText = sepetteEl.parentElement?.textContent || "";
                const parentMatch = parentText.match(/SEPETTE[\s\S]{0,80}?(\d{1,3}(?:\.\d{3})*,\d{2})\s*TL/i);
                if (parentMatch && parentMatch[1]) {
                  return parentMatch[1];
                }
              }

              // 3) Prefer main PDP final price block (exclude other sellers).
              const mainPriceNodes = detailRoot.querySelectorAll(
                ".b8e-text-scalable p.text-4xl, .b8e-text-scalable p[class*='text-4xl'], p.text-4xl, p[class*='text-4xl']"
              );
              for (const node of mainPriceNodes) {
                if (isInsideOtherSellers(node)) continue;
                const prices = extractPricesFromText(node.textContent || "");
                if (prices.length) {
                  return prices[0].raw;
                }
              }

              // 4) Fallback: normal price area (large text on PDP).
              const normalCandidates = [];
              const normalNodes = detailRoot.querySelectorAll("div.text-4xl, div[class*='text-4xl'], span.text-4xl, span[class*='text-4xl']");
              for (const node of normalNodes) {
                if (isInsideOtherSellers(node)) continue;
                const prices = extractPricesFromText(node.textContent || "");
                normalCandidates.push(...prices);
              }
              if (normalCandidates.length) {
                return normalCandidates[0].raw;
              }

              // Avoid broad page-wide fallback to prevent unrelated prices.
              return null;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "Pazarama fiyatı bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Pazarama fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-pttavm-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("pttavm.com")) {
      sendResponse({ ok: false, error: "Geçersiz PttAVM linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1400))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const getDiscountedPriceTextFromObject = (root) => {
                if (!root || typeof root !== "object") return "";
                const stack = [root];
                const visited = new Set();
                while (stack.length) {
                  const cur = stack.pop();
                  if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
                  visited.add(cur);
                  if (Object.prototype.hasOwnProperty.call(cur, "discountedPriceText")) {
                    const val = String(cur.discountedPriceText || "").trim();
                    if (val) return val;
                  }
                  if (Array.isArray(cur)) {
                    for (const item of cur) stack.push(item);
                  } else {
                    for (const val of Object.values(cur)) {
                      if (val && typeof val === "object") stack.push(val);
                    }
                  }
                }
                return "";
              };

              const scripts = document.querySelectorAll("script");
              for (const script of scripts) {
                const text = script.textContent || "";
                if (!text || !text.includes("__staticRouterHydrationData") || !text.includes("JSON.parse(")) continue;

                const parseCallMatch = text.match(/JSON\.parse\((\"[\s\S]*?\")\)/);
                if (parseCallMatch && parseCallMatch[1]) {
                  try {
                    const hydrationJsonText = JSON.parse(parseCallMatch[1]);
                    const hydrationObj = JSON.parse(hydrationJsonText);
                    const found = getDiscountedPriceTextFromObject(hydrationObj);
                    if (found) return found;
                  } catch {}
                }

                const rawMatch = text.match(/"discountedPriceText"\s*:\s*"([^"]+)"/);
                if (rawMatch && rawMatch[1]) {
                  return String(rawMatch[1]).trim();
                }
              }

              return "";
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "PttAVM fiyatı bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "PttAVM fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-idefix-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("idefix.com")) {
      sendResponse({ ok: false, error: "Geçersiz idefix linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1400))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const parseTrPrice = (raw) => {
                if (raw == null) return null;
                const s = String(raw).trim();
                if (!s) return null;
                const normalized = s
                  .replace(/TL/gi, "")
                  .replace(/[^\d.,]/g, "")
                  .replace(/\./g, "")
                  .replace(/,/g, ".");
                const n = Number(normalized);
                return Number.isFinite(n) ? n : null;
              };
              const candidates = [];
              const pushCandidate = (raw) => {
                if (raw == null) return;
                const txt = String(raw).trim();
                if (!txt) return;
                const num = parseTrPrice(txt);
                if (num == null) return;
                candidates.push({ raw: txt, num });
              };

              const ogSaleMeta = document.querySelector("meta[property='og:price:sale_price']");
              const ogSaleContent = (ogSaleMeta && ogSaleMeta.getAttribute("content")) ? String(ogSaleMeta.getAttribute("content")).trim() : "";
              if (ogSaleContent) {
                return ogSaleContent;
              }

              const scripts = document.querySelectorAll("script");
              for (const script of scripts) {
                const text = script.textContent || "";
                if (!text) continue;
                const match = text.match(/"discountedPriceText"\s*:\s*"([^"]+)"/i);
                if (match && match[1]) {
                  return String(match[1]).trim();
                }
              }

              const jsonLdScripts = document.querySelectorAll("script[type='application/ld+json']");
              for (const script of jsonLdScripts) {
                const text = script.textContent || "";
                if (!text) continue;
                try {
                  const parsed = JSON.parse(text);
                  const stack = [parsed];
                  const visited = new Set();
                  while (stack.length) {
                    const cur = stack.pop();
                    if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
                    visited.add(cur);
                    if (Object.prototype.hasOwnProperty.call(cur, "price")) {
                      pushCandidate(cur.price);
                    }
                    if (Array.isArray(cur)) {
                      for (const item of cur) stack.push(item);
                    } else {
                      for (const val of Object.values(cur)) {
                        if (val && typeof val === "object") stack.push(val);
                      }
                    }
                  }
                } catch {}
              }

              const itemPropPrice = document.querySelectorAll("[itemprop='price']");
              for (const el of itemPropPrice) {
                pushCandidate(el.getAttribute("content"));
                pushCandidate(el.textContent || "");
              }

              const visiblePriceNodes = document.querySelectorAll("[class*='price'], [id*='price']");
              for (const el of visiblePriceNodes) {
                pushCandidate(el.textContent || "");
              }

              if (!candidates.length) return null;
              const min = candidates.reduce((a, b) => (a.num <= b.num ? a : b));
              return min.raw;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "idefix fiyatı bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "idefix fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-teknosa-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("teknosa.com")) {
      sendResponse({ ok: false, error: "Geçersiz Teknosa linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1300))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const visiblePiInput = document.querySelector("input#visiblePi");
              const visiblePiValue = visiblePiInput ? String(visiblePiInput.value || "").trim() : "";
              if (visiblePiValue) return visiblePiValue;

              const ogSaleMeta = document.querySelector("meta[property='og:price:sale_price']");
              const ogSaleContent = ogSaleMeta ? String(ogSaleMeta.getAttribute("content") || "").trim() : "";
              if (ogSaleContent) return ogSaleContent;

              const ogAmountMeta = document.querySelector("meta[property='og:price:amount']");
              const ogAmountContent = ogAmountMeta ? String(ogAmountMeta.getAttribute("content") || "").trim() : "";
              if (ogAmountContent) return ogAmountContent;

              const itemPropPrice = document.querySelector("[itemprop='price']");
              const itemPropContent = itemPropPrice ? String(itemPropPrice.getAttribute("content") || itemPropPrice.textContent || "").trim() : "";
              if (itemPropContent) return itemPropContent;

              return "";
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "Teknosa fiyatı bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Teknosa fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-product-meta") {
    const url = (message.url || "").trim();
    if (!url || !/^https?:\/\//i.test(url)) {
      sendResponse({ ok: false, error: "Geçersiz ürün linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1000))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const absUrl = (val) => {
                if (!val) return "";
                try {
                  return new URL(String(val), window.location.origin).href;
                } catch {
                  return String(val);
                }
              };
              const title =
                (window?.model?.product?.title && String(window.model.product.title).trim())
                || (document.querySelector("meta[property='og:title']")?.getAttribute("content") || "").trim()
                || (document.querySelector("h1")?.textContent || "").trim()
                || (document.title || "").trim();
              const image =
                absUrl(document.querySelector("div.img-wrapper-onBoard img.thumbnail-img-0")?.getAttribute("src"))
                || absUrl(document.querySelector("div.img-wrapper-onBoard img.thumbnail-img-0")?.getAttribute("data-src"))
                || absUrl(document.querySelector("meta[property='og:image']")?.getAttribute("content"))
                || absUrl(document.querySelector("img")?.getAttribute("src"));
              return { title: title || "", image: image || "" };
            }
          }))
          .then((result) => {
            cleanup();
            const meta = result && result[0] && result[0].result ? result[0].result : {};
            sendResponse({ ok: true, title: String(meta.title || "").trim(), image: String(meta.image || "").trim() });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Ürün bilgisi okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "akakce-fetch-n11-page") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("n11.com/urun/")) {
      return Promise.resolve({ ok: false, error: "Geçersiz n11 ürün linki." });
    }
    return fetch(url, { credentials: "omit" })
      .then((res) => (res.ok ? res.text() : Promise.reject(new Error("Sayfa alınamadı."))))
      .then((html) => ({ ok: true, html }))
      .catch((err) => ({ ok: false, error: err && err.message ? err.message : "İstek başarısız." }));
  }
  if (message && message.type === "open-bo-product-management") {
    const productId = String(message.productId || "").trim();
    if (!productId) {
      sendResponse({ ok: false, error: "Product ID bulunamadı." });
      return false;
    }
    const sourceUrl = sender?.tab?.url || "";
    const isQaHost = sourceUrl.includes("://qa.n11.com/");
    const targetUrl = isQaHost
      ? "https://qabo.n11.com/backoffice/product/sellerProductManagementView.xhtml"
      : "https://bo.n11.com/backoffice/product/sellerProductManagementView.xhtml";
    chrome.tabs
      .create({
        url: targetUrl,
        active: true
      })
      .then((tab) => {
        if (!tab || !tab.id) {
          sendResponse({ ok: false, error: "Yeni sekme açılamadı." });
          return;
        }
        const tabId = tab.id;
        const listener = (updatedId, info) => {
          if (updatedId !== tabId || info.status !== "complete") {
            return;
          }
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.tabs.sendMessage(
            tabId,
            { action: "bo-product-search", productId },
            (response) => {
              if (chrome.runtime.lastError || !response || !response.success) {
                sendResponse({
                  ok: false,
                  error: response?.error || "BO ürün araması başlatılamadı."
                });
                return;
              }
              sendResponse({ ok: true });
            }
          );
        };
        chrome.tabs.onUpdated.addListener(listener);
      })
      .catch((error) => {
        sendResponse({ ok: false, error: String(error) });
      });
    return true;
  }
  if (!message || message.type !== "collect-n11-links") {
    if (message && message.type === "bo-collect") {
      const matchUrls = [
        "https://bo.n11.com/backoffice/exhibition/promotionProducts.xhtml*",
        "https://stbo.n11.com/backoffice/exhibition/promotionProducts.xhtml*"
      ];
      chrome.tabs
        .query({ url: matchUrls })
        .then((tabs) => {
          const target = tabs[0];
          if (!target || !target.id) {
            sendResponse({ ok: false, error: "BO promosyon sayfası bulunamadı." });
            return;
          }
          chrome.tabs.sendMessage(target.id, { action: "collectProductIds" }, (response) => {
            if (chrome.runtime.lastError || !response || !response.success) {
              sendResponse({
                ok: false,
                error: response?.error || "Ürün ID toplanamadı."
              });
              return;
            }
            sendResponse({ ok: true, products: response.data || [] });
          });
        })
        .catch((error) => {
          sendResponse({ ok: false, error: String(error) });
        });
      return true;
    }

    if (message && (message.type === "clear-dynamic-page-cache" || message.action === "clear-dynamic-page-cache")) {
      const dynamicPageId = String(message.dynamicPageId || "").trim();
      if (!dynamicPageId) {
        sendResponse({ ok: false, error: "Dynamic Page ID bulunamadı." });
        return false;
      }
      chrome.tabs
        .create({
          url: "https://bo.n11.com/backoffice/dynamicPageManagement/dynamicPageManagement.xhtml",
          active: true
        })
        .then((tab) => {
          if (!tab || !tab.id) {
            sendResponse({ ok: false, error: "Yeni sekme açılamadı." });
            return;
          }
          const tabId = tab.id;
          const listener = (updatedId, info, updatedTab) => {
            if (updatedId !== tabId || info.status !== "complete") {
              return;
            }
            chrome.tabs.onUpdated.removeListener(listener);
            const payload = { action: "clearDynamicPageCache", dynamicPageId };
            let attempts = 0;
            const maxAttempts = 6;
            const trySend = () => {
              attempts += 1;
              chrome.tabs.sendMessage(tabId, payload, (response) => {
                if (chrome.runtime.lastError || !response || !response.success) {
                  if (attempts < maxAttempts) {
                    setTimeout(trySend, 500);
                    return;
                  }
                  sendResponse({
                    ok: false,
                    error: response?.error || "Cache temizleme başlatılamadı."
                  });
                  return;
                }
                sendResponse({ ok: true });
              });
            };
            setTimeout(trySend, 500);
          };
          chrome.tabs.onUpdated.addListener(listener);
        })
        .catch((error) => {
          sendResponse({ ok: false, error: String(error) });
        });
      return true;
    }

    return false;
  }

  collectN11Links(Boolean(message.productOnly), sender?.tab?.windowId)
    .then((links) => {
      sendResponse({ ok: true, links });
    })
    .catch((error) => {
      sendResponse({ ok: false, error: String(error) });
    });

  return true;
});
