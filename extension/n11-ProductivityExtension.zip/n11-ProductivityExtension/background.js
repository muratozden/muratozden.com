const collectN11Links = async (productOnly, windowId) => {
  let query = {};
  if (typeof windowId === "number" && windowId >= 0) {
    query = { windowId };
  } else {
    query = { lastFocusedWindow: true };
  }
  const tabs = await chrome.tabs.query(query);
  const links = [];

  for (const tab of tabs) {
    const url = tab.url || "";
    if (!url.startsWith("https://www.n11.com")) {
      continue;
    }
    if (productOnly) {
      if (url.includes("https://www.n11.com/urun/")) {
        links.push(url);
      }
      continue;
    }
    links.push(url);
  }

  return links;
};

const TOGGLE_MENU_ID = "toggle-extension-ui";

const ensureContextMenu = () => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: TOGGLE_MENU_ID,
      title: "Extension Gizle / Göster",
      contexts: ["all"]
    });
  });
};

const STORAGE_KEY_UI_HIDDEN = "extensionUiHidden";
const CONTAINER_ID = "pageid-extension-container";
const TOGGLE_MODAL_IDS = [
  "pageid-extension-modal",
  "pageid-extension-url-modal",
  "pageid-extension-productid-url-modal",
  "id-sku-extension-modal",
  "pims-id-extension-modal",
  "listing-product-crawler-extension-modal",
  "offer-controller-extension-modal",
  "akakce-product-crawler-extension-modal",
  "pageid-extension-bo-modal",
  "pagechecker-extension-modal",
  "bannerchecker-extension-modal",
  "editorial-controller-extension-modal",
  "price-protector-extension-modal",
  "akakce-id-n11-product-extension-modal",
  "seller-products-crawler-extension-modal",
  "seller-scraping-extension-modal",
  "seller-product-match-extension-modal",
  "hepsiburada-seller-products-crawler-extension-modal",
  "product-deal-controller-extension-modal",
  "seller-product-count-extension-modal",
  "barcode-products-extension-modal",
  "ty-seller-follower-extension-modal",
  "promotion-theme-pin-extension-modal",
  "so-announcement-popup-extension-modal",
  "banner-mailing-extension-modal",
  "logo-resizer-extension-modal",
  "logo-list-extension-modal"
];

const arrayBufferToBase64 = (buffer) => {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
};

const fetchImageAsDataUrl = async (url) => {
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
      "Accept-Language": "tr-TR,tr;q=0.9",
      Referer: "https://www.n11.com/",
      Origin: "https://www.n11.com/",
      "User-Agent":
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    },
    credentials: "omit"
  });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  const blob = await response.blob();
  const mime = String(blob.type || "").trim() || "image/jpeg";
  if (!mime.startsWith("image/")) {
    throw new Error(`Unexpected content type: ${mime}`);
  }
  const base64 = arrayBufferToBase64(await blob.arrayBuffer());
  return `data:${mime};base64,${base64}`;
};

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let c = i;
    for (let j = 0; j < 8; j += 1) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c >>> 0;
  }
  return table;
})();

const crc32 = (data) => {
  let c = 0xffffffff;
  for (let i = 0; i < data.length; i += 1) {
    c = CRC32_TABLE[(c ^ data[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
};

const concatUint8Arrays = (chunks) => {
  const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    out.set(chunk, offset);
    offset += chunk.length;
  }
  return out;
};

const writeUint16LE = (view, offset, value) => {
  view.setUint16(offset, value, true);
};

const writeUint32LE = (view, offset, value) => {
  view.setUint32(offset, value, true);
};

const createStoredZipArchive = (entries) => {
  const encoder = new TextEncoder();
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  entries.forEach((entry) => {
    const path = String(entry.path || "").replace(/\\/g, "/");
    const nameBytes = encoder.encode(path);
    const data = entry.data instanceof Uint8Array ? entry.data : new Uint8Array(entry.data || []);
    const checksum = crc32(data);

    const localHeader = new Uint8Array(30 + nameBytes.length);
    const localView = new DataView(localHeader.buffer);
    writeUint32LE(localView, 0, 0x04034b50);
    writeUint16LE(localView, 4, 20);
    writeUint16LE(localView, 6, 0);
    writeUint16LE(localView, 8, 0);
    writeUint16LE(localView, 10, 0);
    writeUint16LE(localView, 12, 0);
    writeUint32LE(localView, 14, checksum);
    writeUint32LE(localView, 18, data.length);
    writeUint32LE(localView, 22, data.length);
    writeUint16LE(localView, 26, nameBytes.length);
    writeUint16LE(localView, 28, 0);
    localHeader.set(nameBytes, 30);
    localParts.push(localHeader, data);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const centralView = new DataView(centralHeader.buffer);
    writeUint32LE(centralView, 0, 0x02014b50);
    writeUint16LE(centralView, 4, 20);
    writeUint16LE(centralView, 6, 20);
    writeUint16LE(centralView, 8, 0);
    writeUint16LE(centralView, 10, 0);
    writeUint16LE(centralView, 12, 0);
    writeUint16LE(centralView, 14, 0);
    writeUint32LE(centralView, 16, checksum);
    writeUint32LE(centralView, 20, data.length);
    writeUint32LE(centralView, 24, data.length);
    writeUint16LE(centralView, 28, nameBytes.length);
    writeUint16LE(centralView, 30, 0);
    writeUint16LE(centralView, 32, 0);
    writeUint16LE(centralView, 34, 0);
    writeUint16LE(centralView, 36, 0);
    writeUint32LE(centralView, 38, 0);
    writeUint32LE(centralView, 42, offset);
    centralHeader.set(nameBytes, 46);
    centralParts.push(centralHeader);

    offset += localHeader.length + data.length;
  });

  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const endRecord = new Uint8Array(22);
  const endView = new DataView(endRecord.buffer);
  writeUint32LE(endView, 0, 0x06054b50);
  writeUint16LE(endView, 4, 0);
  writeUint16LE(endView, 6, 0);
  writeUint16LE(endView, 8, entries.length);
  writeUint16LE(endView, 10, entries.length);
  writeUint32LE(endView, 12, centralSize);
  writeUint32LE(endView, 16, offset);
  writeUint16LE(endView, 20, 0);

  return concatUint8Arrays([...localParts, ...centralParts, endRecord]);
};

const sanitizeZipSegment = (value, fallback) => {
  const cleaned = String(value || "")
    .replace(/[^\w.-]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 80);
  return cleaned || fallback;
};

const amazonImageKeyFromUrl = (url) => {
  const text = String(url || "");
  const productMatch = text.match(/\/images\/I\/([^./?]+)/i);
  if (productMatch) return productMatch[1];
  const aplusMatch = text.match(/\/images\/S\/aplus-media-library-service-media\/([^.?]+)/i);
  if (aplusMatch) return aplusMatch[1];
  return "";
};

const shouldPreserveAmazonImageUrl = (url) => {
  const value = String(url || "").toLowerCase();
  return (
    value.includes("/images/s/aplus-media-library-service-media/") ||
    value.includes("aplus-media-library-service-media")
  );
};

const normalizeAmazonAssetUrl = (url) => {
  const raw = String(url || "").trim();
  if (!raw || raw.startsWith("data:")) return "";
  if (raw.includes("sprite") || raw.includes("transparent-pixel")) return "";
  if (shouldPreserveAmazonImageUrl(raw)) {
    try {
      return new URL(raw, "https://www.amazon.com.tr/").href;
    } catch {
      return raw;
    }
  }
  const resized = raw.replace(/\._[A-Z0-9_,]+_\./, "._AC_SL1500_.");
  try {
    return new URL(resized, "https://www.amazon.com.tr/").href;
  } catch {
    return resized;
  }
};

const registerImageLookup = (lookup, remoteUrl, localPath) => {
  if (!remoteUrl || !localPath) return;
  lookup.set(String(remoteUrl), localPath);
  const normalized = normalizeAmazonAssetUrl(remoteUrl);
  if (normalized) lookup.set(normalized, localPath);
  const key = amazonImageKeyFromUrl(normalized || remoteUrl);
  if (key) lookup.set(key, localPath);
};

const resolveLocalImagePath = (remoteUrl, lookup) => {
  if (!remoteUrl || !lookup || !lookup.size) return "";
  const direct = lookup.get(String(remoteUrl).trim());
  if (direct) return direct;
  const normalized = normalizeAmazonAssetUrl(remoteUrl);
  if (normalized && lookup.has(normalized)) return lookup.get(normalized);
  const key = amazonImageKeyFromUrl(normalized || remoteUrl);
  if (key && lookup.has(key)) return lookup.get(key);
  return "";
};

const resolveBestImageUrlFromElement = (img) => {
  if (!img) return "";
  const attrs = [
    "data-src",
    "data-lazy-src",
    "data-original",
    "data-old-hires",
    "data-a-hires",
    "src"
  ];
  for (const attr of attrs) {
    const value = img.getAttribute(attr);
    if (value && !isPlaceholderImageSrc(value)) {
      return String(value).trim();
    }
  }
  const parent = img.parentElement;
  if (parent) {
    const siblings = parent.querySelectorAll("noscript img[src]");
    for (const fallbackImg of siblings) {
      const fallbackSrc = fallbackImg.getAttribute("src");
      if (fallbackSrc && !isPlaceholderImageSrc(fallbackSrc)) {
        return String(fallbackSrc).trim();
      }
    }
  }
  return "";
};

const rewriteHtmlImageSources = (html, lookup) => {
  if (!html) return html;
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString('<div id="n11-root">' + html + "</div>", "text/html");
    const root = doc.getElementById("n11-root");
    if (!root) return html;

    root.querySelectorAll("img").forEach((img) => {
      const remoteUrl = resolveBestImageUrlFromElement(img);
      let finalSrc = remoteUrl ? resolveLocalImagePath(remoteUrl, lookup) : "";
      if (!finalSrc) finalSrc = remoteUrl;
      if (finalSrc && !isPlaceholderImageSrc(finalSrc)) {
        img.setAttribute("src", finalSrc);
      }
      img.removeAttribute("srcset");
      img.removeAttribute("data-src");
      img.removeAttribute("data-lazy-src");
      img.removeAttribute("data-original");
      img.removeAttribute("data-old-hires");
      img.removeAttribute("data-a-hires");
      img.removeAttribute("class");
    });

    root.querySelectorAll("source[srcset]").forEach((source) => {
      const srcset = source.getAttribute("srcset") || "";
      const firstUrl = srcset.split(",")[0]?.trim().split(/\s+/)[0] || "";
      const local = resolveLocalImagePath(firstUrl, lookup);
      if (local) {
        source.setAttribute("srcset", local);
      } else {
        source.removeAttribute("srcset");
      }
    });

    root
      .querySelectorAll(".a-expander-content, .a-expander-extend-content")
      .forEach((node) => unwrapElementKeepChildren(node));
    removeAmazonExpanderUi(root);
    root
      .querySelectorAll(
        ".a-expander-container, .a-expander-extend-container, [data-a-expander-name]"
      )
      .forEach((node) => unwrapElementKeepChildren(node));
    removeAmazonExpanderUi(root);

    return root.innerHTML;
  } catch {
    return html;
  }
};

const imageExtensionFrom = (url, mime) => {
  const mimeText = String(mime || "").toLowerCase();
  if (mimeText.includes("png")) return "png";
  if (mimeText.includes("webp")) return "webp";
  if (mimeText.includes("gif")) return "gif";
  const match = String(url || "").match(/\.([a-z0-9]{3,4})(?:\?|$)/i);
  if (match) return match[1].toLowerCase();
  return "jpg";
};

const fetchAmazonImageBytes = async (url) => {
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
      "Accept-Language": "tr-TR,tr;q=0.9",
      Referer: "https://www.amazon.com.tr/",
      Origin: "https://www.amazon.com.tr/",
      "User-Agent":
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    },
    credentials: "omit"
  });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  const mime = String(response.headers.get("content-type") || "").split(";")[0].trim();
  const buffer = await response.arrayBuffer();
  return {
    bytes: new Uint8Array(buffer),
    mime,
    ext: imageExtensionFrom(url, mime)
  };
};

const waitForTabComplete = (tabId, timeoutMs) =>
  new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve();
    };
    const onUpdated = (updatedId, info) => {
      if (updatedId === tabId && info && info.status === "complete") finish();
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab && tab.status === "complete") finish();
    }).catch(() => {});
    setTimeout(finish, timeoutMs || 25000);
  });

const escapeTextareaValue = (value) =>
  String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

const PURE_HTML_ALLOWED_ATTRS = new Set([
  "src",
  "href",
  "alt",
  "title",
  "colspan",
  "rowspan",
  "width",
  "height"
]);

const isPlaceholderImageSrc = (src) => {
  const value = String(src || "").toLowerCase();
  return (
    !value ||
    value.includes("grey-pixel") ||
    value.includes("transparent-pixel") ||
    value.startsWith("data:image")
  );
};

const normalizePureHtmlImage = (img) => {
  if (!img || img.tagName !== "IMG") return;
  const bestSrc = resolveBestImageUrlFromElement(img);
  if (bestSrc) {
    img.setAttribute("src", bestSrc);
  }
};

const unwrapElementKeepChildren = (el) => {
  const parent = el && el.parentElement;
  if (!parent) return;
  while (el.firstChild) {
    parent.insertBefore(el.firstChild, el);
  }
  el.remove();
};

const removeAmazonExpanderUi = (root) => {
  if (!root) return;
  root
    .querySelectorAll(
      'a[data-action="a-expander-toggle"], a.a-expander-header, a.a-expander-extend-header, .a-expander-prompt'
    )
    .forEach((node) => node.remove());
  root
    .querySelectorAll(".a-expander-header, .a-icon, i.a-icon, i[class*='a-icon'], i")
    .forEach((node) => node.remove());
  root.querySelectorAll('a[href^="javascript:"]').forEach((node) => node.remove());
  root.querySelectorAll("a").forEach((anchor) => unwrapElementKeepChildren(anchor));
};

const stripHtmlNoiseWithRegex = (html) =>
  String(html || "")
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, "")
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, "");

const simplifyPureHtmlImages = (root) => {
  if (!root) return;
  root.querySelectorAll("img").forEach((img) => {
    const src = resolveBestImageUrlFromElement(img) || img.getAttribute("src") || "";
    if (!src || isPlaceholderImageSrc(src)) {
      img.remove();
      return;
    }
    while (img.attributes.length > 0) {
      img.removeAttribute(img.attributes[0].name);
    }
    img.setAttribute("src", src);
    img.setAttribute("alt", "");
  });
};

const escapeHtmlText = (value) =>
  String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const replaceCompetitorBrandNamesInText = (text) =>
  String(text ?? "")
    .replace(/amazon/gi, "n11")
    .replace(/hepsiburada/gi, "n11");

const replaceCompetitorBrandNamesInPureHtml = (html) => {
  if (!html) return "";
  let result = String(html).replace(/>([^<]+)</g, (match, text) => {
    const replaced = replaceCompetitorBrandNamesInText(text);
    return replaced === text ? match : ">" + replaced + "<";
  });
  result = result.replace(/\salt=(["'])(.*?)\1/gi, (match, quote, alt) => {
    const replaced = replaceCompetitorBrandNamesInText(alt);
    return replaced === alt ? match : " alt=" + quote + replaced + quote;
  });
  return result;
};

const extractPlainTextFromHtml = (html) =>
  String(html || "")
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/<[^>]+>/g, "")
    .replace(/\s+/g, " ")
    .trim();

const readHtmlAttribute = (attrs, name) => {
  const match = String(attrs || "").match(new RegExp("\\b" + name + '="([^"]*)"', "i"));
  return match ? match[1] : "";
};

const resolveAmazonImageSrcForPure = (attrs, lookup) => {
  const candidates = [
    readHtmlAttribute(attrs, "data-src"),
    readHtmlAttribute(attrs, "data-lazy-src"),
    readHtmlAttribute(attrs, "data-original"),
    readHtmlAttribute(attrs, "data-old-hires"),
    readHtmlAttribute(attrs, "src")
  ].filter(Boolean);
  for (const candidate of candidates) {
    if (isPlaceholderImageSrc(candidate)) continue;
    const local = lookup && lookup.size ? resolveLocalImagePath(candidate, lookup) : "";
    return local || candidate;
  }
  return "";
};

const parseAmazonProductDescriptionPure = (html) => {
  let cleaned = stripHtmlNoiseWithRegex(html);
  cleaned = cleaned.replace(/<a\b[^>]*>[\s\S]*?<\/a>/gi, "");

  const expanderMatch = cleaned.match(
    /class="[^"]*a-expander-content[^"]*"[^>]*>([\s\S]*?)<\/div>/i
  );
  if (expanderMatch) {
    cleaned = cleaned.replace(/<div[^>]*data-a-expander-name[\s\S]*$/i, expanderMatch[1]);
  }
  cleaned = cleaned.replace(/<div[^>]*data-a-expander-name[^>]*>/gi, "");

  const blocks = [];
  const tagRegex = /<(h[1-6]|p)\b[^>]*>([\s\S]*?)<\/\1>/gi;
  let match;
  while ((match = tagRegex.exec(cleaned))) {
    const tag = match[1].toLowerCase();
    const text = extractPlainTextFromHtml(match[2]);
    if (!text) continue;
    blocks.push("<" + tag + ">" + escapeHtmlText(text) + "</" + tag + ">");
  }
  return blocks.join("\n");
};

const parseAmazonAplusPure = (html, lookup) => {
  const cleaned = stripHtmlNoiseWithRegex(html);
  const lines = [];

  const h1Match = cleaned.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i);
  if (h1Match) {
    const title = extractPlainTextFromHtml(h1Match[1]);
    if (title) {
      lines.push("<h2>" + escapeHtmlText(title) + "</h2>");
    }
  }

  const seen = new Set();
  const imgRegex = /<img\b([^>]*)>/gi;
  let imgMatch;
  while ((imgMatch = imgRegex.exec(cleaned))) {
    const src = resolveAmazonImageSrcForPure(imgMatch[1], lookup);
    if (!src) continue;
    const key = amazonImageKeyFromUrl(src) || src;
    if (seen.has(key)) continue;
    seen.add(key);
    lines.push('<img src="' + escapeHtmlText(src) + '" alt="">');
  }
  return lines.join("\n");
};

const buildAmazonSectionPureHtml = (section, lookup) => {
  const title = String(section?.title || "").toLowerCase();
  const html = String(section?.html || "");
  if (!html) return "";

  if (
    title.includes("ürün") ||
    title.includes("urun") ||
    title.includes("açıklama") ||
    title.includes("aciklama")
  ) {
    return parseAmazonProductDescriptionPure(html);
  }
  if (title.includes("a+")) {
    return parseAmazonAplusPure(html, lookup);
  }
  return stripHtmlToPure(html);
};

const buildAmazonPureHtmlDocument = (sections, lookup) => {
  const html = (Array.isArray(sections) ? sections : [])
    .map((section) => buildAmazonSectionPureHtml(section, lookup))
    .filter(Boolean)
    .join("\n\n");
  return replaceCompetitorBrandNamesInPureHtml(html);
};

const formatPureHtmlOutput = (html) =>
  String(html || "")
    .replace(/>\s+</g, ">\n<")
    .replace(/<img([^>]*?)>/g, "<img$1 >")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

const stripHtmlToPure = (html) => {
  if (!html) return "";
  const withoutComments = stripHtmlNoiseWithRegex(html);
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(
      '<div id="n11-pure-root">' + withoutComments + "</div>",
      "text/html"
    );
    const root = doc.getElementById("n11-pure-root");
    if (!root) return formatPureHtmlOutput(withoutComments);

    root.querySelectorAll("noscript").forEach((noscript) => {
      const fallbackImg = noscript.querySelector("img[src]");
      const parent = noscript.parentElement;
      if (fallbackImg && parent) {
        const fallbackSrc = fallbackImg.getAttribute("src");
        const parentImgs = parent.querySelectorAll("img");
        parentImgs.forEach((parentImg) => {
          if (fallbackSrc && isPlaceholderImageSrc(parentImg.getAttribute("src"))) {
            parentImg.setAttribute("src", fallbackSrc);
          }
        });
      }
      noscript.remove();
    });

    root
      .querySelectorAll("script, style, link, meta, iframe, button, svg, form, input, textarea, select")
      .forEach((node) => node.remove());

    root
      .querySelectorAll(".a-expander-content, .a-expander-extend-content")
      .forEach((node) => unwrapElementKeepChildren(node));
    removeAmazonExpanderUi(root);
    root
      .querySelectorAll(
        ".a-expander-container, .a-expander-extend-container, [data-a-expander-name]"
      )
      .forEach((node) => unwrapElementKeepChildren(node));
    removeAmazonExpanderUi(root);

    root.querySelectorAll("img").forEach((img) => normalizePureHtmlImage(img));

    root.querySelectorAll("*").forEach((el) => {
      if (el.tagName === "IMG") return;
      [...el.attributes].forEach((attr) => {
        if (!PURE_HTML_ALLOWED_ATTRS.has(attr.name.toLowerCase())) {
          el.removeAttribute(attr.name);
        }
      });
    });

    removeAmazonExpanderUi(root);

    let unwrapSpans = true;
    while (unwrapSpans) {
      unwrapSpans = false;
      root.querySelectorAll("span").forEach((span) => {
        if (span.attributes.length > 0) return;
        unwrapElementKeepChildren(span);
        unwrapSpans = true;
      });
    }

    let structurePass = true;
    while (structurePass) {
      structurePass = false;

      root.querySelectorAll("div").forEach((div) => {
        const text = String(div.textContent || "").replace(/\s+/g, "").trim();
        const hasContentChild = Boolean(
          div.querySelector(
            "img, video, table, ul, ol, li, h1, h2, h3, h4, h5, h6, p, blockquote, pre, hr"
          )
        );
        if (!text && !hasContentChild) {
          div.remove();
          structurePass = true;
          return;
        }

        if (
          !text &&
          div.children.length === 1 &&
          div.firstElementChild &&
          div.firstElementChild.tagName === "DIV"
        ) {
          unwrapElementKeepChildren(div);
          structurePass = true;
          return;
        }

        if (
          !text &&
          div.children.length === 1 &&
          div.firstElementChild &&
          div.firstElementChild.tagName === "IMG"
        ) {
          unwrapElementKeepChildren(div);
          structurePass = true;
        }
      });
    }

    let unwrapDivs = true;
    while (unwrapDivs) {
      unwrapDivs = false;
      const divs = [...root.querySelectorAll("div")];
      const innermost = divs.find((div) => !div.querySelector("div"));
      if (innermost) {
        unwrapElementKeepChildren(innermost);
        unwrapDivs = true;
        continue;
      }
      if (divs.length) {
        unwrapElementKeepChildren(divs[0]);
        unwrapDivs = true;
      }
    }

    removeAmazonExpanderUi(root);
    simplifyPureHtmlImages(root);

    const pureHtml = root.innerHTML
      .replace(/\s(?:class|id|style|data-[a-z0-9_-]+|aria-[a-z0-9_-]+|role|tabindex)=(".*?"|'.*?'|[^\s>]+)/gi, "")
      .replace(/<\/?i\b[^>]*>/gi, "");

    return formatPureHtmlOutput(pureHtml);
  } catch {
    return formatPureHtmlOutput(stripHtmlNoiseWithRegex(html));
  }
};

const buildAmazonDescriptionDocument = (title, sections, lookup) => {
  const safeTitle = String(title || "Urun Aciklamasi")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
  const sectionHtml = (Array.isArray(sections) ? sections : [])
    .filter((section) => section && section.html)
    .map((section) => {
      const heading = String(section.title || "Icerik")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
      const pureHtml = buildAmazonSectionPureHtml(section, lookup || null);
      return (
        '<section class="content-section">' +
        '<h2 class="section-title">' + heading + "</h2>" +
        '<div class="section-body">' + pureHtml + "</div>" +
        '<label class="pure-html-label">Pure HTML (kopyalanabilir)</label>' +
        '<textarea class="pure-html-textarea" readonly spellcheck="false" onclick="this.focus();this.select();">' +
        escapeTextareaValue(pureHtml) +
        "</textarea>" +
        "</section>"
      );
    })
    .join("\n");

  return (
    "<!DOCTYPE html>\n" +
    '<html lang="tr">\n' +
    "<head>\n" +
    '<meta charset="utf-8">\n' +
    '<meta name="viewport" content="width=device-width, initial-scale=1">\n' +
    "<title>" + safeTitle + "</title>\n" +
    "<style>\n" +
    "* { box-sizing: border-box; }\n" +
    "body {\n" +
    "  margin: 0;\n" +
    '  font-family: "Amazon Ember", Arial, Helvetica, sans-serif;\n' +
    "  font-size: 14px;\n" +
    "  line-height: 1.6;\n" +
    "  color: #0f1111;\n" +
    "  background: #f3f3f3;\n" +
    "}\n" +
    ".page {\n" +
    "  max-width: 980px;\n" +
    "  margin: 0 auto;\n" +
    "  padding: 24px 16px 48px;\n" +
    "}\n" +
    ".page-header {\n" +
    "  background: #fff;\n" +
    "  border: 1px solid #d5d9d9;\n" +
    "  border-radius: 8px;\n" +
    "  padding: 20px 24px;\n" +
    "  margin-bottom: 20px;\n" +
    "  box-shadow: 0 1px 2px rgba(15, 17, 17, 0.08);\n" +
    "}\n" +
    ".page-header h1 {\n" +
    "  margin: 0;\n" +
    "  font-size: 22px;\n" +
    "  line-height: 1.35;\n" +
    "  font-weight: 700;\n" +
    "}\n" +
    ".content-section {\n" +
    "  background: #fff;\n" +
    "  border: 1px solid #d5d9d9;\n" +
    "  border-radius: 8px;\n" +
    "  padding: 24px;\n" +
    "  margin-bottom: 20px;\n" +
    "  box-shadow: 0 1px 2px rgba(15, 17, 17, 0.08);\n" +
    "}\n" +
    ".content-section h2.section-title {\n" +
    "  margin: 0 0 16px;\n" +
    "  padding-bottom: 10px;\n" +
    "  border-bottom: 1px solid #e7e7e7;\n" +
    "  font-size: 18px;\n" +
    "  font-weight: 700;\n" +
    "}\n" +
    "#productDescription, .aplus-v2, .aplus-content-wrapper {\n" +
    "  color: #0f1111;\n" +
    "  word-wrap: break-word;\n" +
    "}\n" +
    "#productDescription h3, .aplus-v2 h3, .aplus-content-wrapper h3,\n" +
    "#productDescription h4, .aplus-v2 h4, .aplus-content-wrapper h4 {\n" +
    "  margin: 18px 0 8px;\n" +
    "  font-size: 16px;\n" +
    "  font-weight: 700;\n" +
    "}\n" +
    "#productDescription p, .aplus-v2 p, .aplus-content-wrapper p {\n" +
    "  margin: 0 0 12px;\n" +
    "}\n" +
    "#productDescription ul, .aplus-v2 ul, .aplus-content-wrapper ul,\n" +
    "#productDescription ol, .aplus-v2 ol, .aplus-content-wrapper ol {\n" +
    "  margin: 0 0 12px 20px;\n" +
    "  padding: 0;\n" +
    "}\n" +
    "img {\n" +
    "  max-width: 100%;\n" +
    "  height: auto;\n" +
    "  display: block;\n" +
    "}\n" +
    "table {\n" +
    "  width: 100%;\n" +
    "  border-collapse: collapse;\n" +
    "  margin: 12px 0;\n" +
    "}\n" +
    "td, th {\n" +
    "  border: 1px solid #d5d9d9;\n" +
    "  padding: 8px 10px;\n" +
    "  vertical-align: top;\n" +
    "}\n" +
    ".a-expander-content, .a-expander-extend-content {\n" +
    "  display: block !important;\n" +
    "  height: auto !important;\n" +
    "  overflow: visible !important;\n" +
    "}\n" +
    ".a-expander-header, .a-expander-prompt, script, style {\n" +
    "  display: none !important;\n" +
    "}\n" +
    ".aplus-module img, .aplus-card img, .aplus-content-wrapper img {\n" +
    "  margin: 0 auto;\n" +
    "}\n" +
    ".aplus-module {\n" +
    "  margin-bottom: 16px;\n" +
    "}\n" +
    ".pure-html-label {\n" +
    "  display: block;\n" +
    "  margin: 20px 0 8px;\n" +
    "  font-size: 13px;\n" +
    "  font-weight: 700;\n" +
    "  color: #374151;\n" +
    "}\n" +
    ".pure-html-textarea {\n" +
    "  width: 100%;\n" +
    "  min-height: 240px;\n" +
    "  padding: 12px;\n" +
    '  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;\n' +
    "  font-size: 12px;\n" +
    "  line-height: 1.5;\n" +
    "  border: 1px solid #d5d9d9;\n" +
    "  border-radius: 6px;\n" +
    "  background: #fafafa;\n" +
    "  color: #111827;\n" +
    "  resize: vertical;\n" +
    "  white-space: pre-wrap;\n" +
    "  word-break: break-word;\n" +
    "  cursor: text;\n" +
    "  user-select: all;\n" +
    "}\n" +
    ".pure-html-textarea:focus {\n" +
    "  outline: 2px solid #2563eb;\n" +
    "  border-color: #2563eb;\n" +
    "  background: #fff;\n" +
    "}\n" +
    "</style>\n" +
    "</head>\n" +
    "<body>\n" +
    '<div class="page">\n' +
    '<header class="page-header"><h1>' + safeTitle + "</h1></header>\n" +
    sectionHtml +
    "\n</div>\n</body>\n</html>\n"
  );
};

const scrapeAmazonProductAssetsInTab = async (productUrl) => {
  const tab = await chrome.tabs.create({ url: productUrl, active: false });
  if (!tab || !tab.id) {
    throw new Error("Amazon urun sekmesi acilamadi.");
  }
  const tabId = tab.id;
  const waitMs = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  try {
    await waitForTabComplete(tabId, 30000);
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const readyResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const gallery = document.querySelector('ul[class*="desktop-media-mainView"]');
          const galleryImageCount = gallery
            ? gallery.querySelectorAll("[data-old-hires], [data-a-dynamic-image], img[src]").length
            : 0;
          const hasDescription = Boolean(
            document.querySelector(
              "#productDescription, .aplus-content-wrapper, #aplus_feature_div .aplus-v2, .aplus-v2"
            )
          );
          const hasTitle = Boolean(document.querySelector("#productTitle"));
          return galleryImageCount >= 2 || hasDescription || hasTitle;
        }
      }).catch(() => [{ result: false }]);
      if (readyResult && readyResult[0] && readyResult[0].result === true) break;
      await waitMs(1000);
    }
    await waitMs(1200);
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const gallery = document.querySelector('ul[class*="desktop-media-mainView"]');
        if (!gallery) return;
        gallery.querySelectorAll("li.image.item, li.item").forEach((li) => {
          li.scrollIntoView({ block: "nearest", inline: "nearest" });
        });
      }
    }).catch(() => {});
    await waitMs(700);

    const scrapeResult = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const toAbs = (href) => {
          if (!href) return "";
          try { return new URL(href, location.origin).href; } catch { return href; }
        };
        const pickBestAmazonImageUrl = (url) => {
          const raw = String(url || "").trim();
          if (!raw || raw.startsWith("data:")) return "";
          if (raw.includes("sprite") || raw.includes("transparent-pixel")) return "";
          if (
            raw.includes("aplus-media-library-service-media") ||
            raw.includes("/images/S/")
          ) {
            return raw;
          }
          return raw.replace(/\._[A-Z0-9_,]+_\./, "._AC_SL1500_.");
        };
        const amazonImageKey = (url) => {
          const text = String(url || "");
          const productMatch = text.match(/\/images\/I\/([^./?]+)/i);
          if (productMatch) return productMatch[1];
          const aplusMatch = text.match(/\/images\/S\/aplus-media-library-service-media\/([^.?]+)/i);
          if (aplusMatch) return aplusMatch[1];
          return text;
        };
        const isBadImageUrl = (url) => {
          const value = String(url || "").toLowerCase();
          return (
            !value ||
            value.includes("grey-pixel") ||
            value.includes("transparent-pixel") ||
            value.startsWith("data:image")
          );
        };
        const registerImageUrl = (url, bucket) => {
          const normalized = pickBestAmazonImageUrl(url);
          if (!normalized || isBadImageUrl(normalized)) return;
          const absolute = toAbs(normalized);
          if (!/^https?:\/\//i.test(absolute) || isBadImageUrl(absolute)) return;
          const key = amazonImageKey(absolute) || absolute;
          if (bucket.has(key)) return;
          bucket.set(key, absolute);
        };
        const collectFromElement = (el, bucket) => {
          if (!el) return;
          const hires =
            el.getAttribute("data-old-hires") ||
            el.getAttribute("data-a-hires") ||
            "";
          if (hires) registerImageUrl(hires, bucket);
          const dynamic = el.getAttribute("data-a-dynamic-image");
          if (dynamic) {
            try {
              const parsed = JSON.parse(dynamic);
              const urls = Object.keys(parsed || {});
              urls.sort((a, b) => {
                const aw = Array.isArray(parsed[a]) ? parsed[a][0] : 0;
                const bw = Array.isArray(parsed[b]) ? parsed[b][0] : 0;
                return bw - aw;
              });
              urls.forEach((dynamicUrl) => registerImageUrl(dynamicUrl, bucket));
            } catch (_) {}
          }
          if (el.tagName === "IMG") {
            const src = el.getAttribute("src") || "";
            if (src) registerImageUrl(src, bucket);
          }
        };
        const collectFromImgNode = (img, bucket) => {
          if (!img) return;
          collectFromElement(img, bucket);
          [
            "data-src",
            "data-lazy-src",
            "data-original",
            "data-old-hires",
            "data-a-hires"
          ].forEach((attr) => {
            const value = img.getAttribute(attr);
            if (value) registerImageUrl(value, bucket);
          });
          const srcset = img.getAttribute("srcset");
          if (srcset) {
            srcset.split(",").forEach((part) => {
              const url = part.trim().split(/\s+/)[0];
              if (url) registerImageUrl(url, bucket);
            });
          }
        };
        const collectFromSrcsetElement = (el, bucket) => {
          if (!el) return;
          const srcset = el.getAttribute("srcset");
          if (!srcset) return;
          srcset.split(",").forEach((part) => {
            const url = part.trim().split(/\s+/)[0];
            if (url) registerImageUrl(url, bucket);
          });
        };
        const expandHiddenDescriptionNodes = (root) => {
          if (!root) return root;
          root.querySelectorAll(".a-expander-content, .a-expander-extend-content, .aok-hidden, .a-hidden")
            .forEach((node) => {
              node.classList.remove("aok-hidden", "a-hidden");
              node.style.display = "block";
              node.style.visibility = "visible";
              node.style.height = "auto";
              node.style.overflow = "visible";
            });
          root.querySelectorAll("script, style, noscript").forEach((node) => node.remove());
          root
            .querySelectorAll(
              'a[data-action="a-expander-toggle"], a.a-expander-header, a.a-expander-extend-header, a[href^="javascript:"]'
            )
            .forEach((node) => node.remove());
          root.querySelectorAll(".a-expander-prompt, i.a-icon, i[class*='a-icon']").forEach((node) => node.remove());
          return root;
        };

        const galleryImageUrlMap = new Map();
        const aplusImageUrlMap = new Map();
        const gallery =
          document.querySelector(
            "ul.a-unordered-list.a-nostyle.a-horizontal.list.maintain-height.desktop-media-mainView"
          ) ||
          document.querySelector("ul.desktop-media-mainView") ||
          document.querySelector('ul[class*="desktop-media-mainView"]');
        if (gallery) {
          gallery.querySelectorAll("li").forEach((li) => {
            if (li.classList.contains("aok-hidden") || li.classList.contains("template")) return;
            li.querySelectorAll("[data-old-hires], [data-a-dynamic-image], img[src]").forEach((el) => {
              collectFromElement(el, galleryImageUrlMap);
            });
          });
        }

        const altImages = document.querySelector("#altImages");
        if (altImages) {
          altImages.querySelectorAll("[data-old-hires], [data-a-dynamic-image], img[src]").forEach((el) => {
            collectFromElement(el, galleryImageUrlMap);
          });
        }

        collectFromElement(document.querySelector("#landingImage"), galleryImageUrlMap);
        collectFromElement(document.querySelector("#imgTagWrapperId img"), galleryImageUrlMap);
        collectFromElement(document.querySelector("#imgTagWrapperId [data-old-hires]"), galleryImageUrlMap);

        const aplusImageRoots = [
          document.querySelector("#aplus_feature_div"),
          document.querySelector("#aplusBrandStory_feature_div"),
          document.querySelector(".aplus-v2")
        ].filter(Boolean);
        const uniqueAplusRoots = Array.from(new Set(aplusImageRoots));
        const imageSearchRoots = uniqueAplusRoots.length
          ? uniqueAplusRoots
          : Array.from(document.querySelectorAll(".aplus-content-wrapper"));

        imageSearchRoots.forEach((rootEl) => {
          rootEl.querySelectorAll("img").forEach((img) => collectFromImgNode(img, aplusImageUrlMap));
          rootEl.querySelectorAll("picture source[srcset]").forEach((source) => {
            collectFromSrcsetElement(source, aplusImageUrlMap);
          });
          rootEl.querySelectorAll("noscript img[src]").forEach((img) => collectFromImgNode(img, aplusImageUrlMap));
          rootEl.querySelectorAll("[style*='background-image']").forEach((node) => {
            const style = node.getAttribute("style") || "";
            const match = style.match(/url\((['"]?)(https?:\/\/[^'")]+)\1\)/i);
            if (match && match[2]) registerImageUrl(match[2], aplusImageUrlMap);
          });
        });

        const galleryImageUrls = Array.from(galleryImageUrlMap.values());
        const aplusImageUrls = [];
        aplusImageUrlMap.forEach((url, key) => {
          if (!galleryImageUrlMap.has(key)) {
            aplusImageUrls.push(url);
          }
        });

        const descriptionSections = [];
        const productDesc = document.querySelector("#productDescription");
        if (productDesc) {
          const clone = expandHiddenDescriptionNodes(productDesc.cloneNode(true));
          descriptionSections.push({
            title: "Ürün Açıklaması",
            html: clone.innerHTML
          });
        }

        const aplusFeature =
          document.querySelector("#aplus_feature_div .aplus-v2") ||
          document.querySelector("#aplusBrandStory_feature_div .aplus-v2") ||
          document.querySelector(".aplus-v2");
        if (aplusFeature) {
          const clone = expandHiddenDescriptionNodes(aplusFeature.cloneNode(true));
          descriptionSections.push({
            title: "A+ İçerik",
            html: clone.innerHTML
          });
        } else {
          document.querySelectorAll(".aplus-content-wrapper").forEach((wrapper, index) => {
            if (!(wrapper instanceof Element)) return;
            const clone = expandHiddenDescriptionNodes(wrapper.cloneNode(true));
            const wrapperCount = document.querySelectorAll(".aplus-content-wrapper").length;
            const title =
              wrapperCount > 1
                ? "A+ İçerik " + (index + 1)
                : "A+ İçerik";
            descriptionSections.push({
              title,
              html: clone.innerHTML
            });
          });
        }

        if (!descriptionSections.length) {
          const aplusRoot =
            document.querySelector("#aplus_feature_div .aplus-v2") ||
            document.querySelector("#aplusBrandStory_feature_div .aplus-v2") ||
            document.querySelector(".aplus-v2");
          if (aplusRoot) {
            const clone = expandHiddenDescriptionNodes(aplusRoot.cloneNode(true));
            descriptionSections.push({
              title: "A+ İçerik",
              html: clone.innerHTML
            });
          }
        }

        const titleEl = document.querySelector("#productTitle");
        const title = titleEl ? String(titleEl.textContent || "").replace(/\s+/g, " ").trim() : "";
        let asin = "";
        const asinInput = document.querySelector("input#ASIN, input[name='ASIN']");
        if (asinInput) {
          asin = String(asinInput.value || asinInput.getAttribute("value") || "").trim();
        }
        if (!asin) {
          const match = String(location.pathname || "").match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})\b/i);
          if (match) asin = match[1].toUpperCase();
        }

        return {
          galleryImageUrls,
          aplusImageUrls,
          descriptionSections,
          title,
          asin
        };
      }
    });

    return scrapeResult && scrapeResult[0] ? scrapeResult[0].result : null;
  } finally {
    chrome.tabs.remove(tabId).catch(() => {});
  }
};

const collectAmazonProductZipEntries = async (scraped, barcode, folderName) => {
  const zipEntries = [];
  const encoder = new TextEncoder();
  const descriptionSections = Array.isArray(scraped.descriptionSections)
    ? scraped.descriptionSections.filter((section) => section && section.html)
    : [];
  const imageUrlLookup = new Map();
  const galleryImageUrls = Array.isArray(scraped.galleryImageUrls)
    ? scraped.galleryImageUrls
    : (Array.isArray(scraped.imageUrls) ? scraped.imageUrls : []);
  const aplusImageUrls = Array.isArray(scraped.aplusImageUrls) ? scraped.aplusImageUrls : [];

  let galleryIndex = 0;
  for (const imageUrl of galleryImageUrls) {
    galleryIndex += 1;
    try {
      const image = await fetchAmazonImageBytes(imageUrl);
      const fileName =
        String(galleryIndex).padStart(2, "0") + "." + sanitizeZipSegment(image.ext, "jpg");
      const localPath = "images/product/" + fileName;
      zipEntries.push({
        path: folderName + "/" + localPath,
        data: image.bytes
      });
      registerImageLookup(imageUrlLookup, imageUrl, localPath);
    } catch (_) {
      // Tek gorsel hatasi tum paketi dusurmesin.
    }
  }

  let aplusIndex = 0;
  for (const imageUrl of aplusImageUrls) {
    aplusIndex += 1;
    try {
      const image = await fetchAmazonImageBytes(imageUrl);
      const fileName =
        String(aplusIndex).padStart(2, "0") + "." + sanitizeZipSegment(image.ext, "jpg");
      const localPath = "images/content/" + fileName;
      zipEntries.push({
        path: folderName + "/" + localPath,
        data: image.bytes
      });
      registerImageLookup(imageUrlLookup, imageUrl, localPath);
    } catch (_) {
      // Tek gorsel hatasi tum paketi dusurmesin.
    }
  }

  if (descriptionSections.length) {
    const pureHtmlDoc = buildAmazonPureHtmlDocument(descriptionSections, imageUrlLookup);
    if (pureHtmlDoc) {
      zipEntries.push({
        path: folderName + "/pure.html",
        data: encoder.encode(pureHtmlDoc + "\n")
      });
    }
  }

  return {
    zipEntries,
    imageCount: zipEntries.filter((entry) => entry.path.includes("/images/")).length,
    hasDescription: descriptionSections.length > 0
  };
};

const buildAmazonProductZipPackage = async (productUrl, barcode) => {
  const scraped = await scrapeAmazonProductAssetsInTab(productUrl);
  if (!scraped) {
    throw new Error("Amazon urun sayfasi okunamadi.");
  }

  const folderName = sanitizeZipSegment(scraped.asin || barcode || "amazon_product", "amazon_product");
  const collected = await collectAmazonProductZipEntries(scraped, barcode, folderName);
  if (!collected.zipEntries.length) {
    throw new Error("Indirilecek gorsel veya aciklama bulunamadi.");
  }

  const zipBytes = createStoredZipArchive(collected.zipEntries);
  const filename =
    "amazon_" +
    sanitizeZipSegment(barcode || scraped.asin || "product", "product") +
    "_" +
    folderName +
    ".zip";

  return {
    zipBase64: arrayBufferToBase64(zipBytes.buffer),
    filename,
    imageCount: collected.imageCount,
    hasDescription: collected.hasDescription
  };
};

const buildAmazonBulkZipPackage = async (items, onProgress) => {
  const list = Array.isArray(items) ? items : [];
  const allEntries = [];
  const results = [];

  for (let index = 0; index < list.length; index += 1) {
    const item = list[index] || {};
    const url = String(item.url || "").trim();
    const barcode = String(item.barcode || "").trim();
    if (onProgress) {
      onProgress({
        current: index + 1,
        total: list.length,
        barcode,
        url
      });
    }
    if (!url || !/amazon\.com\.tr/i.test(url)) {
      results.push({
        barcode,
        ok: false,
        error: "Gecersiz Amazon urun URL."
      });
      continue;
    }

    try {
      const scraped = await scrapeAmazonProductAssetsInTab(url);
      if (!scraped) {
        results.push({
          barcode,
          ok: false,
          error: "Amazon urun sayfasi okunamadi."
        });
        continue;
      }

      const folderName =
        sanitizeZipSegment(barcode || "barcode", "barcode") +
        "_" +
        sanitizeZipSegment(scraped.asin || barcode || "product", "product");
      const collected = await collectAmazonProductZipEntries(scraped, barcode, folderName);
      if (!collected.zipEntries.length) {
        results.push({
          barcode,
          ok: false,
          error: "Indirilecek gorsel veya aciklama bulunamadi."
        });
        continue;
      }

      allEntries.push(...collected.zipEntries);
      results.push({
        barcode,
        ok: true,
        folderName,
        imageCount: collected.imageCount,
        hasDescription: collected.hasDescription
      });
    } catch (err) {
      results.push({
        barcode,
        ok: false,
        error: err?.message || "Amazon urun paketi olusturulamadi."
      });
    }
  }

  if (!allEntries.length) {
    throw new Error("Hicbir Amazon urunu indirilemedi.");
  }

  const zipBytes = createStoredZipArchive(allEntries);
  const successCount = results.filter((row) => row.ok).length;
  const failCount = results.length - successCount;

  return {
    zipBase64: arrayBufferToBase64(zipBytes.buffer),
    filename: "amazon_products_bulk_" + new Date().toISOString().slice(0, 10) + ".zip",
    imageCount: allEntries.filter((entry) => entry.path.includes("/images/")).length,
    successCount,
    failCount,
    results
  };
};

/** Sayfada UI görünürlüğünü doğrudan uygular (content script yanıt vermediğinde yedek). */
const applyVisibilityInTab = (tabId, hidden) => {
  chrome.scripting.executeScript({
    target: { tabId },
    func: (containerId, modalIds, isHidden) => {
      const container = document.getElementById(containerId);
      if (container) {
        container.style.display = isHidden ? "none" : "";
      }
      if (document.body) {
        document.body.dataset.extensionHidden = isHidden ? "true" : "false";
      }
      if (isHidden) {
        modalIds.forEach((id) => {
          const el = document.getElementById(id);
          if (el && el.style.display !== "none") el.style.display = "none";
        });
      }
    },
    args: [CONTAINER_ID, TOGGLE_MODAL_IDS, hidden]
  }).catch(() => {});
};

const SELLER_PRODUCT_COUNT_KEYS = {
  sellers: "sellerProductCountSellers",
  results: "sellerProductCountResults"
};

const sellerProductCountExtractFirstInt = (text) => {
  if (!text) return null;
  const m = String(text).match(/\d[\d.,]*/);
  if (!m) return null;
  const n = parseInt(m[0].replace(/[.,]/g, ""), 10);
  return Number.isFinite(n) ? n : null;
};

const sellerProductCountFetch = (url) =>
  fetch(url, {
    method: "GET",
    headers: {
      Accept: "text/html,application/xhtml+xml,*/*;q=0.9",
      "Accept-Language": "tr-TR,tr;q=0.9"
    }
  }).then((r) => {
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.text();
  });

const sellerProductCountParseHtml = (html) => {
  try {
    if (typeof DOMParser === "undefined") return null;
    return new DOMParser().parseFromString(html, "text/html");
  } catch (_) {
    return null;
  }
};

const sellerProductCountScrapeN11 = async (url) => {
  const html = await sellerProductCountFetch(url);
  let count = null;
  const fromModel = html.match(/model\.sellerInfo\.sellerProductsCount\s*[=:]\s*(\d+)/) ||
    html.match(/"sellerProductsCount"\s*:\s*(\d+)/) ||
    html.match(/sellerInfo[\s\S]*?"sellerProductsCount"\s*:\s*(\d+)/);
  if (fromModel && fromModel[1]) {
    const n = parseInt(fromModel[1], 10);
    if (Number.isFinite(n)) return n;
  }
  const doc = sellerProductCountParseHtml(html);
  if (doc) {
    const el = doc.querySelector(".listingGroup .resultText strong");
    if (el) count = sellerProductCountExtractFirstInt(el.textContent);
  }
  if (count == null) {
    const m = html.match(/listingGroup[\s\S]*?resultText[\s\S]*?<strong[^>]*>([^<]+)/i);
    if (m && m[1]) count = sellerProductCountExtractFirstInt(m[1]);
  }
  if (count == null) throw new Error("Sonuç sayısı bulunamadı (n11)");
  return count;
};

const sellerProductCountScrapeHepsiburada = async (url) => {
  const html = await sellerProductCountFetch(url);
  const doc = sellerProductCountParseHtml(html);
  if (doc) {
    const el = doc.querySelector("#merchantSubInfos strong");
    if (el) {
      const c = sellerProductCountExtractFirstInt(el.textContent);
      if (c !== null) return c;
    }
  }
  const m = html.match(/"totalProductCount"\s*:\s*(\d+)/i);
  if (m && m[1]) return parseInt(m[1], 10);
  const scripts = doc ? doc.querySelectorAll("script") : [];
  for (const s of scripts) {
    const mm = (s.textContent || "").match(/"totalProductCount"\s*:\s*(\d+)/i);
    if (mm && mm[1]) return parseInt(mm[1], 10);
  }
  throw new Error("totalProductCount bulunamadı");
};

const sellerProductCountScrapeTrendyol = async (url) => {
  const html = await sellerProductCountFetch(url);
  const doc = sellerProductCountParseHtml(html);
  const re = /(\d[\d.,\s]*)\s*\+?\s*Ürün/gi;
  const nums = [];
  let match;
  while ((match = re.exec(html)) !== null) {
    const n = parseInt((match[1] || "").replace(/\D/g, ""), 10);
    if (Number.isFinite(n) && n > 10) nums.push(n);
  }
  if (nums.length > 0) return Math.max(...nums);
  const re2 = /"totalCount"\s*:\s*(\d+)/i;
  const m = html.match(re2);
  if (m && m[1]) return parseInt(m[1], 10);
  throw new Error("totalCount bulunamadı (Trendyol)");
};

const sellerProductCountGetSellers = () =>
  chrome.storage.local.get(SELLER_PRODUCT_COUNT_KEYS.sellers).then((o) => {
    const list = o[SELLER_PRODUCT_COUNT_KEYS.sellers];
    return Array.isArray(list) ? list : [];
  });

const sellerProductCountSaveSellers = (sellers) => {
  const clean = (Array.isArray(sellers) ? sellers : []).map((s) => {
    const brand = String(s.brand || "").trim();
    const n11Url = String(s.n11Url || "").trim();
    const trendyolUrl = String(s.trendyolUrl || "").trim();
    const hepsiburadaUrl = String(s.hepsiburadaUrl || "").trim();
    const id = s.id || (Date.now().toString(36) + Math.random().toString(36).slice(2));
    return { id, brand, n11Url, trendyolUrl, hepsiburadaUrl };
  });
  return chrome.storage.local.set({ [SELLER_PRODUCT_COUNT_KEYS.sellers]: clean }).then(() => clean);
};

const sellerProductCountGetResults = () =>
  chrome.storage.local.get(SELLER_PRODUCT_COUNT_KEYS.results).then((o) => {
    const list = o[SELLER_PRODUCT_COUNT_KEYS.results];
    return Array.isArray(list) ? list : [];
  });

const sellerProductCountSaveResults = (results) =>
  chrome.storage.local.set({
    [SELLER_PRODUCT_COUNT_KEYS.results]: Array.isArray(results) ? results : []
  });

const sellerProductCountClearData = () =>
  chrome.storage.local.remove([SELLER_PRODUCT_COUNT_KEYS.sellers, SELLER_PRODUCT_COUNT_KEYS.results]);

const sellerProductCountScrapeForSeller = async (seller) => {
  const out = {
    sellerId: seller.id,
    brand: seller.brand || "",
    n11: { ok: false, count: null, error: null },
    trendyol: { ok: false, count: null, error: null },
    hepsiburada: { ok: false, count: null, error: null }
  };
  const tasks = [];
  if (seller.n11Url) {
    tasks.push(
      sellerProductCountScrapeN11(seller.n11Url)
        .then((c) => { out.n11 = { ok: true, count: c, error: null }; })
        .catch((e) => { out.n11 = { ok: false, count: null, error: e && e.message ? e.message : String(e) }; })
    );
  }
  if (seller.trendyolUrl) {
    tasks.push(
      sellerProductCountScrapeTrendyol(seller.trendyolUrl)
        .then((c) => { out.trendyol = { ok: true, count: c, error: null }; })
        .catch((e) => { out.trendyol = { ok: false, count: null, error: e && e.message ? e.message : String(e) }; })
    );
  }
  if (seller.hepsiburadaUrl) {
    tasks.push(
      sellerProductCountScrapeHepsiburada(seller.hepsiburadaUrl)
        .then((c) => { out.hepsiburada = { ok: true, count: c, error: null }; })
        .catch((e) => { out.hepsiburada = { ok: false, count: null, error: e && e.message ? e.message : String(e) }; })
    );
  }
  if (tasks.length === 0) {
    return out;
  }
  await Promise.all(tasks);
  return out;
};

const sendToggleMessage = (tabId) => {
  if (!tabId) {
    return;
  }
  chrome.tabs.sendMessage(tabId, { type: "toggle-extension-ui" }, (response) => {
    if (chrome.runtime.lastError || !response) {
      chrome.storage.local.get(STORAGE_KEY_UI_HIDDEN, (result) => {
        const nextHidden = !Boolean(result[STORAGE_KEY_UI_HIDDEN]);
        chrome.storage.local.set({ [STORAGE_KEY_UI_HIDDEN]: nextHidden }, () => {
          applyVisibilityInTab(tabId, nextHidden);
        });
      });
    }
  });
};

chrome.runtime.onInstalled.addListener(() => {
  ensureContextMenu();
});

chrome.runtime.onStartup.addListener(() => {
  ensureContextMenu();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== TOGGLE_MENU_ID) {
    return;
  }
  if (tab && tab.id) {
    sendToggleMessage(tab.id);
    return;
  }
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].id) {
      sendToggleMessage(tabs[0].id);
    }
  });
});

chrome.commands.onCommand.addListener((command) => {
  if (command !== "toggle-extension-ui") {
    return;
  }
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].id) {
      sendToggleMessage(tabs[0].id);
    }
  });
});

const AKAKCE_THROTTLE_EVERY = 12;
const AKAKCE_THROTTLE_PAUSE_MS = 6500;
const STORAGE_KEY_AKAKCE_FLOW_COUNT = "akakceFlowCount";

/** Akakçe ürün sayfasında lazy/hydration için hafif rastgele scroll + bekleme (injected). */
function akakcePageWarmupScroll() {
  const delay = (ms) => new Promise((r) => setTimeout(r, ms));
  return (async () => {
    const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
    await delay(280 + Math.floor(Math.random() * 520));
    if (ul) {
      ul.scrollIntoView({ block: "center", behavior: "instant" });
      await delay(130 + Math.floor(Math.random() * 220));
    }
    const steps = 3 + Math.floor(Math.random() * 5);
    for (let i = 0; i < steps; i++) {
      window.scrollBy({ top: 65 + Math.random() * 95, left: 0, behavior: "instant" });
      await delay(65 + Math.floor(Math.random() * 110));
    }
    window.scrollTo({ top: 0, behavior: "instant" });
    await delay(160 + Math.floor(Math.random() * 240));
    if (ul) ul.scrollIntoView({ block: "start", behavior: "instant" });
    await delay(380 + Math.floor(Math.random() * 620));
    return true;
  })();
}

const awaitAkakceThrottle = (senderTabId) => {
  const jitterMs = 400 + Math.floor(Math.random() * 1100);
  return new Promise((resolve) => {
    setTimeout(() => {
      chrome.storage.local.get(STORAGE_KEY_AKAKCE_FLOW_COUNT, (data) => {
        const count = (data[STORAGE_KEY_AKAKCE_FLOW_COUNT] || 0) + 1;
        const longPauseMs = AKAKCE_THROTTLE_PAUSE_MS + Math.floor(Math.random() * 3500);
        chrome.storage.local.set({ [STORAGE_KEY_AKAKCE_FLOW_COUNT]: count }, () => {
          if (count % AKAKCE_THROTTLE_EVERY === 0 && count > 0) {
            if (senderTabId) {
              chrome.tabs
                .sendMessage(senderTabId, {
                  type: "akakce-throttle-wait",
                  every: AKAKCE_THROTTLE_EVERY,
                  seconds: Math.round(longPauseMs / 1000)
                })
                .catch(() => {});
            }
            setTimeout(resolve, longPauseMs);
          } else {
            resolve();
          }
        });
      });
    }, jitterMs);
  });
};

const decodeHtmlEntities = (value) => {
  if (!value) return "";
  return String(value)
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
};

const stripHtmlTags = (value) => {
  if (!value) return "";
  return decodeHtmlEntities(String(value).replace(/<[^>]*>/g, " "))
    .replace(/\s+/g, " ")
    .trim();
};

const parseFirstPriceFromText = (text) => {
  if (!text) return "";
  const m = String(text).match(/\d{1,3}(?:\.\d{3})*(?:,\d{2})?\s*TL|\d{1,3}(?:\.\d{3})*(?:,\d{2})?/i);
  return m && m[0] ? m[0].replace(/\s+/g, " ").trim() : "";
};

const extractAkakceSellerNameFromVendorText = (text) =>
  String(text || "").replace(/\s+/g, " ").trim().replace(/^\/+/, "");

const extractAkakceSellerNameFromLiHtml = (liHtml) => {
  if (!liHtml) return "";
  const spanRe = /<span[^>]+class=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi;
  let m;
  while ((m = spanRe.exec(liHtml)) !== null) {
    const classes = m[1].split(/\s+/);
    if (classes.includes("v_v8") || classes.includes("v_v9")) {
      return extractAkakceSellerNameFromVendorText(stripHtmlTags(m[2]));
    }
  }
  return "";
};

const buildAkakceBestPriceLabel = (brand, sellerName) => {
  const b = String(brand || "").trim();
  const s = extractAkakceSellerNameFromVendorText(sellerName);
  if (s && s.includes("/")) return s;
  if (b && s && s.toLowerCase() !== b.toLowerCase()) return `${b}/${s}`;
  return b || s || "?";
};

const extractAkakceUrlFromGoogleHtml = (html) => {
  if (!html) return "";
  const hrefMatches = html.match(/href="([^"]+)"/g) || [];
  for (const rawHref of hrefMatches) {
    const href = rawHref.slice(6, -1);
    const decoded = decodeHtmlEntities(href);
    let candidate = decoded;
    if (/^\/url\?/i.test(decoded)) {
      const qMatch = decoded.match(/[?&]q=([^&]+)/i);
      if (qMatch && qMatch[1]) {
        candidate = decodeURIComponent(qMatch[1].replace(/\+/g, " "));
      }
    }
    if (!candidate.includes("akakce.com")) {
      continue;
    }
    try {
      const u = new URL(candidate);
      if (!/(\.|^)akakce\.com$/i.test(u.hostname)) {
        continue;
      }
      if (u.pathname === "/" || u.pathname === "") {
        continue;
      }
      return u.toString();
    } catch {
      // ignore malformed candidate
    }
  }
  return "";
};

const parseAkakceListDataFromHtml = (html) => {
  if (!html) {
    return { items: [], title: "", n11Link: null, allPrices: [], bestPrice: "", redirectedToHome: false };
  }
  const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  const title = titleMatch ? stripHtmlTags(titleMatch[1]) : "";
  const ulMatch = html.match(/<ul[^>]+id=["']PL["'][^>]*>([\s\S]*?)<\/ul>/i);
  if (!ulMatch) {
    return { items: [], title, n11Link: null, allPrices: [], bestPrice: "", redirectedToHome: true };
  }

  const ulHtml = ulMatch[1];
  const liMatches = ulHtml.match(/<li\b[\s\S]*?<\/li>/gi) || [];
  const items = [];
  const allPrices = [];
  let n11Link = null;

  const domainToBrand = {
    "trendyol.com": "Trendyol",
    "n11.com": "n11",
    "hepsiburada.com": "Hepsiburada",
    "amazon.com.tr": "Amazon Türkiye",
    "pazarama.com": "Pazarama",
    "pttavm.com": "PttAVM",
    "idefix.com": "idefix"
  };

  for (const li of liMatches) {
    const hrefMatch = li.match(/<a[^>]+href=["']([^"']+)["']/i);
    const href = hrefMatch ? decodeHtmlEntities(hrefMatch[1]) : "";
    const altMatch = li.match(/<img[^>]+alt=["']([^"']+)["']/i);
    const rawAlt = altMatch ? stripHtmlTags(altMatch[1]) : "";
    const altKey = rawAlt.toLowerCase().replace(/\s+/g, "");
    const brandMap = {
      trendyol: "Trendyol",
      trendyolplus: "Trendyol",
      n11: "n11",
      "amazontürkiye": "Amazon Türkiye",
      amazonturkiye: "Amazon Türkiye",
      hepsiburada: "Hepsiburada",
      pazarama: "Pazarama",
      pttavm: "PttAVM",
      "pttavm.com": "PttAVM",
      idefix: "idefix"
    };
    let brand = brandMap[altKey] || null;
    if (!brand && href) {
      for (const [domain, b] of Object.entries(domainToBrand)) {
        if (href.includes(domain)) {
          brand = b;
          break;
        }
      }
    }
    if (!brand) {
      continue;
    }
    if (brand === "n11" && href && !n11Link) {
      n11Link = href;
    }
    const productNameMatch = li.match(/class=["'][^"']*(?:pn_v8|pn_v9)[^"']*["'][^>]*>([\s\S]*?)<\/[^>]+>/i);
    const productName = productNameMatch ? stripHtmlTags(productNameMatch[1]) : "";
    const price = parseFirstPriceFromText(stripHtmlTags(li));
    if (price) {
      allPrices.push(price);
    }
    items.push({ brand, productName, price });
  }

  let bestPrice = "";
  if (liMatches.length > 0 && items.length > 0) {
    const firstLi = liMatches[0];
    const first = items[0];
    let sellerName = "";
    sellerName = extractAkakceSellerNameFromLiHtml(firstLi);
    const label = buildAkakceBestPriceLabel(first.brand, sellerName);
    bestPrice = `${label} - ${first.price || "-"}`;
  }
  return { items, title, n11Link, allPrices, bestPrice, redirectedToHome: false };
};

const extractProductIdFromN11Html = (html) => {
  if (!html) return "";
  const patterns = [
    /window\.model\.product\.id\s*=\s*["']?(\d+)["']?/i,
    /model\.product\.id\s*=\s*["']?(\d+)["']?/i,
    /"productId"\s*:\s*["']?(\d+)["']?/i,
    /"id"\s*:\s*["']?(\d{7,})["']?\s*,\s*"sellerId"/i
  ];
  for (const re of patterns) {
    const m = html.match(re);
    if (m && m[1]) return String(m[1]).trim();
  }
  return "";
};

const tryAkakceFlowNoTab = async ({ googleUrl, productId, productName, productUrl, n11PriceFromContent, sellerNickName, idFromN11Url }) => {
  try {
    const googleResp = await fetch(googleUrl, { credentials: "omit" });
    if (!googleResp.ok) return { ok: false };
    const googleHtml = await googleResp.text();
    const akakceUrl = extractAkakceUrlFromGoogleHtml(googleHtml);
    if (!akakceUrl) return { ok: false };

    const akakceResp = await fetch(akakceUrl, { credentials: "omit" });
    if (!akakceResp.ok) return { ok: false };
    const akakceHtml = await akakceResp.text();
    const parsed = parseAkakceListDataFromHtml(akakceHtml);
    if (!Array.isArray(parsed.items) || parsed.items.length === 0) return { ok: false };

    let resolvedProductId = productId;
    if (!resolvedProductId && parsed.n11Link) {
      try {
        const n11Resp = await fetch(parsed.n11Link, { credentials: "omit" });
        if (n11Resp.ok) {
          const n11Html = await n11Resp.text();
          resolvedProductId = extractProductIdFromN11Html(n11Html) || resolvedProductId;
        }
      } catch {
        // no-op
      }
    }

    const payload = {
      productId: resolvedProductId,
      productName: parsed.title || productName,
      data: parsed.items,
      akakceUrl,
      akakceOriginalUrl: akakceUrl,
      allPrices: Array.isArray(parsed.allPrices) ? parsed.allPrices : [],
      bestPrice: parsed.bestPrice != null ? String(parsed.bestPrice).trim() : "",
      idFromN11Url
    };
    if (n11PriceFromContent) payload.n11Price = n11PriceFromContent;
    if (productUrl) payload.productUrl = productUrl;
    if (sellerNickName) payload.sellerNickName = sellerNickName;
    if (parsed.redirectedToHome) payload.redirectedToHome = true;
    return { ok: true, payload };
  } catch {
    return { ok: false };
  }
};

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "akakce-flow" && port.name !== "price-protector-flow") return;
  const resultMessageType = port.name === "price-protector-flow" ? "price-protector-page-data" : "akakce-page-data";
  port.onMessage.addListener((msg) => {
    const googleUrl = (msg.googleUrl || "").trim();
    const senderTabId = port.sender?.tab?.id || null;
    const productId = (msg.productId != null && msg.productId !== "") ? String(msg.productId) : "";
    const productName = (msg.productName != null) ? String(msg.productName) : "";
    const productUrl = (msg.productUrl || "").trim();
    const n11PriceFromContent = (msg.n11Price != null && String(msg.n11Price).trim() !== "") ? String(msg.n11Price).trim() : "";
    const sellerNickName = (msg.sellerNickName != null && String(msg.sellerNickName).trim() !== "") ? String(msg.sellerNickName).trim() : "";
    const idFromN11Url = msg.isFromN11Url === true;
    if (!googleUrl || !googleUrl.includes("google.com")) {
      port.postMessage({ error: "Geçersiz URL" });
      return;
    }
    awaitAkakceThrottle(senderTabId).then(() => {
      tryAkakceFlowNoTab({
        googleUrl,
        productId,
        productName,
        productUrl,
        n11PriceFromContent,
        sellerNickName,
        idFromN11Url
      }).then((noTabResult) => {
        if (noTabResult && noTabResult.ok && noTabResult.payload) {
          if (senderTabId) {
            chrome.tabs.sendMessage(senderTabId, {
              type: resultMessageType,
              ...noTabResult.payload
            }).catch(() => {});
          }
          port.postMessage({ ok: true });
          return;
        }
        chrome.tabs.create({ url: googleUrl, active: false }).then((tab) => {
        if (!tab || !tab.id) {
          port.postMessage({ error: "Sekme açılamadı." });
          return;
        }
        const tabId = tab.id;
        let listenerHandled = false;
        const listener = (updatedId, info) => {
          if (updatedId !== tabId || info.status !== "complete") return;
          if (listenerHandled) return;
          listenerHandled = true;
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.scripting
            .executeScript({
              target: { tabId },
              func: () => {
                const isProductUrl = (u) => {
                  try {
                    const url = new URL(u);
                    if (!/akakce\.com$/i.test(url.hostname)) return false;
                    if (url.pathname === "/" || url.pathname === "") return false;
                  } catch (e) {}
                  if (/,(\d+)\.html\b/i.test(u)) return true;
                  if (/en-ucuz/i.test(u)) return true;
                  return false;
                };
                const isGoogleAdResult = (anchor) => {
                  if (!anchor) return false;
                  const block =
                    anchor.closest("div[data-text-ad]") ||
                    anchor.closest("div[data-sokoban-container]") ||
                    anchor.closest("div[data-pla-slot-pos]") ||
                    anchor.closest("div.g") ||
                    anchor.parentElement;
                  const text = String(block?.innerText || "")
                    .replace(/\s+/g, " ")
                    .toLowerCase();
                  return (
                    text.includes("ücretli sponsorlu reklam") ||
                    text.includes("sponsorlu reklam") ||
                    text.includes("sponsorlu") ||
                    text.includes("sponsored")
                  );
                };

                const anchors = Array.from(
                  document.querySelectorAll('a[href*="akakce.com"]')
                );
                const seen = new Set();
                const candidates = anchors
                  .map((a) => {
                    const href = a && a.href ? a.href : "";
                    return {
                      href,
                      isSponsored: isGoogleAdResult(a)
                    };
                  })
                  .filter(
                    (x) =>
                      x.href &&
                      !x.href.includes("webcache") &&
                      !x.href.includes("translate.google")
                  )
                  .filter((x) => {
                    if (seen.has(x.href)) return false;
                    seen.add(x.href);
                    return true;
                  });
                if (!candidates.length) return null;

                const productCandidates = candidates.filter((x) =>
                  isProductUrl(x.href)
                );
                const pool = productCandidates.length ? productCandidates : candidates;

                // Google ilk sonucu sponsorlu reklamsa organik olan bir sonraki sonucu seç.
                if (pool[0]?.isSponsored && pool[1]) {
                  const nextOrganic = pool.find((x, idx) => idx > 0 && !x.isSponsored);
                  return (nextOrganic && nextOrganic.href) || pool[1].href;
                }
                return pool[0].href;
              }
            })
            .then((results) => {
              const akakceUrl = results && results[0] && results[0].result;
              if (!akakceUrl) {
                if (senderTabId) {
                  chrome.tabs.sendMessage(senderTabId, {
                    type: resultMessageType,
                    productId,
                    productName,
                    productUrl,
                    akakceUrl: "",
                    data: [],
                    allPrices: [],
                    n11Price: n11PriceFromContent,
                    sellerNickName,
                    idFromN11Url
                  }).catch(() => {});
                }
                port.postMessage({ ok: true });
                chrome.tabs.remove(tabId).catch(() => {});
                return;
              }
              chrome.tabs.update(tabId, { url: akakceUrl, active: false }).then((updatedTab) => {
                if (!updatedTab || !updatedTab.id) {
                  port.postMessage({ ok: true });
                  return;
                }
                const akakceTabId = tabId;
                let loadListenerHandled = false;
                const loadListener = (updatedId, info) => {
                  if (updatedId !== akakceTabId || info.status !== "complete") return;
                  if (loadListenerHandled) return;
                  loadListenerHandled = true;
                  chrome.tabs.onUpdated.removeListener(loadListener);
                  const isCloudflare = () => chrome.scripting.executeScript({
                    target: { tabId: akakceTabId },
                    func: () => /Performing security verification|security check|Cloudflare|Just a moment/i.test(document.body?.innerText || "")
                  }).then((r) => r && r[0] && r[0].result === true);
                  const waitForContent = (attempt = 0) => {
                    return new Promise((r) => setTimeout(r, 2100 + Math.floor(Math.random() * 900)))
                      .then(() => isCloudflare())
                      .then((cf) => (cf && attempt < 2) ? waitForContent(attempt + 1) : Promise.resolve());
                  };
                  const runAkakceTabExtract = () =>
                    chrome.scripting.executeScript({
                      target: { tabId: akakceTabId },
                      func: function extractAkakceListData() {
                        const brandMap = {
                          "trendyol": "Trendyol",
                          "trendyolplus": "Trendyol",
                          "n11": "n11",
                          "amazon türkiye": "Amazon Türkiye",
                          "amazon turkiye": "Amazon Türkiye",
                          "hepsiburada": "Hepsiburada",
                          "pazarama": "Pazarama",
                          "pttavm": "PttAVM",
                          "ptt avm": "PttAVM",
                          "idefix": "idefix"
                        };
                        const domainToBrand = {
                          "trendyol.com": "Trendyol",
                          "n11.com": "n11",
                          "hepsiburada.com": "Hepsiburada",
                          "amazon.com.tr": "Amazon Türkiye",
                          "pazarama.com": "Pazarama",
                          "pttavm.com": "PttAVM",
                          "idefix.com": "idefix"
                        };
                        const getSellerFromLi = (li) => {
                          const vendorEl = li.querySelector(".v_v8, .v_v9");
                          if (!vendorEl) return "";
                          return vendorEl.textContent.replace(/\s+/g, " ").trim().replace(/^\/+/, "");
                        };
                        const getBrandFromLi = (li) => {
                          const img = li.querySelector("img[alt]");
                          if (img && img.alt) {
                            const rawBrand = String(img.alt).trim();
                            const brandKey = rawBrand.toLowerCase().replace(/\s+/g, "");
                            const mapped =
                              brandMap[brandKey] ||
                              ([
                                "Trendyol",
                                "n11",
                                "Amazon Türkiye",
                                "Hepsiburada",
                                "Pazarama",
                                "PttAVM",
                                "idefix"
                              ].includes(rawBrand)
                                ? rawBrand
                                : null);
                            if (mapped) return mapped;
                            return rawBrand;
                          }
                          const link = li.querySelector("a[href]");
                          if (link && link.href) {
                            for (const [domain, b] of Object.entries(domainToBrand)) {
                              if (link.href.includes(domain)) return b;
                            }
                          }
                          return "";
                        };
                        const buildBestLabel = (brand, seller) => {
                          const b = (brand || "").trim();
                          const s = (seller || "").trim().replace(/^\/+/, "");
                          if (s && s.includes("/")) return s;
                          if (b && s && s.toLowerCase() !== b.toLowerCase()) return b + "/" + s;
                          return b || s || "?";
                        };
                        const path = (window.location && window.location.pathname) ? window.location.pathname : "";
                        const isHomeLike = path === "/" || path === "" || /^\/(anasayfa|home|index(\.php)?)$/i.test(path);
                        const titleEl = document.querySelector("#pd_v8 h1");
                        const pageTitle = titleEl ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
                        const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
                        let n11Link = null;
                        const allPrices = [];
                        if (!ul) return { items: [], title: pageTitle, n11Link: null, allPrices: [], bestPrice: "", redirectedToHome: isHomeLike };
                        const items = [];
                        ul.querySelectorAll("li").forEach((li) => {
                          let brand = null;
                          const link = li.querySelector("a[href]");
                          const img = li.querySelector("img");
                          if (img && img.alt) {
                            const rawBrand = (img.alt || "").trim();
                            const brandKey = rawBrand.toLowerCase().replace(/\s+/g, "");
                            brand =
                              brandMap[brandKey] ||
                              ([
                                "Trendyol",
                                "n11",
                                "Amazon Türkiye",
                                "Hepsiburada",
                                "Pazarama",
                                "PttAVM",
                                "idefix"
                              ].includes(rawBrand)
                                ? rawBrand
                                : null);
                          }
                          if (!brand && link && link.href) {
                            for (const [domain, b] of Object.entries(domainToBrand)) {
                              if (link.href.includes(domain)) { brand = b; break; }
                            }
                          }
                          if (brand === "n11" && link && link.href) n11Link = link.href;
                          const pb = li.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
                          let price = "";
                          if (pb) {
                            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
                            if (cmpgn) price = cmpgn.textContent.replace(/\s+/g, " ").trim();
                            else { const pt = pb.querySelector(".pt_v8, .pt_v9, [class*='pt_']"); if (pt) price = pt.textContent.replace(/\s+/g, " ").trim(); }
                          }
                          if (price && price.trim()) allPrices.push(price.trim());
                          if (!brand) return;
                          const nameEl = li.querySelector(".pn_v8, .pn_v9, [class*='pn_']");
                          const productName = nameEl ? nameEl.textContent.replace(/\s+/g, " ").trim() : "";
                          items.push({ brand, productName, price });
                        });
                        let bestPrice = "";
                        const firstLi = ul.querySelector("li");
                        if (firstLi) {
                          const pb = firstLi.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
                          let price = "";
                          if (pb) {
                            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
                            if (cmpgn) price = cmpgn.textContent.replace(/\s+/g, " ").trim();
                            else { const pt = pb.querySelector(".pt_v8, ".concat(".pt_v9, [class*='pt_']")); if (pt) price = pt.textContent.replace(/\s+/g, " ").trim(); }
                          }
                          const label = buildBestLabel(getBrandFromLi(firstLi), getSellerFromLi(firstLi));
                          bestPrice = label + " - " + (price && price.trim() ? price.trim() : "-");
                        }
                        return { items, title: pageTitle, n11Link, allPrices, bestPrice, redirectedToHome: false };
                      }
                    });
                  waitForContent(0)
                    .then(() =>
                      chrome.scripting.executeScript({
                        target: { tabId: akakceTabId },
                        func: akakcePageWarmupScroll
                      })
                    )
                    .then(() => runAkakceTabExtract())
                    .then((extractResults) => {
                      let raw = extractResults && extractResults[0] && extractResults[0].result;
                      const itemCount = raw && Array.isArray(raw.items) ? raw.items.length : 0;
                      const redirectedEarly = Boolean(raw && raw.redirectedToHome);
                      if (itemCount > 0 || redirectedEarly) return Promise.resolve(raw);
                      return chrome.scripting
                        .executeScript({
                          target: { tabId: akakceTabId },
                          func: akakcePageWarmupScroll
                        })
                        .then(() => new Promise((r) => setTimeout(r, 900 + Math.floor(Math.random() * 700))))
                        .then(() => runAkakceTabExtract())
                        .then((ex2) => {
                          const raw2 = ex2 && ex2[0] && ex2[0].result;
                          const count2 = raw2 && Array.isArray(raw2.items) ? raw2.items.length : 0;
                          if (count2 > itemCount) return raw2;
                          return raw;
                        });
                    })
                    .then((raw) => {
                      const data = raw && Array.isArray(raw.items) ? raw.items : [];
                      const akakceTitle = (raw && raw.title) ? String(raw.title).trim() : "";
                      const finalProductName = akakceTitle || productName;
                      let resolvedProductId = productId;
                      const n11Link = (raw && raw.n11Link) ? String(raw.n11Link).trim() : "";
                      const redirectedToHome = Boolean(raw && raw.redirectedToHome);
                      const fetchProductIdFromN11Link = (url) => {
                        if (!url || (!url.includes("akakce.com") && !url.includes("n11.com"))) return Promise.resolve("");
                        return chrome.tabs.create({ url, active: false }).then((tab) => {
                          if (!tab || !tab.id) return Promise.resolve("");
                          const n11TabId = tab.id;
                          const waitForN11 = (attempt) => {
                            if (attempt >= 12) return chrome.tabs.remove(n11TabId).then(() => "");
                            return new Promise((r) => setTimeout(r, attempt === 0 ? 2000 : 1500))
                              .then(() => chrome.tabs.get(n11TabId))
                              .then((t) => (t.url || "").includes("n11.com/urun/") ? n11TabId : null)
                              .catch(() => null)
                              .then((tid) => {
                                if (tid) return tid;
                                return waitForN11(attempt + 1);
                              });
                          };
                          return waitForN11(0)
                            .then((tid) => {
                              if (!tid) return "";
                              return new Promise((r) => setTimeout(r, 1500))
                                .then(() => chrome.scripting.executeScript({
                                  target: { tabId: tid },
                                  func: () => {
                                    try {
                                      if (window.model && window.model.product && window.model.product.id != null) return String(window.model.product.id);
                                      if (window.model && window.model.productMeta && window.model.productMeta.productId != null) return String(window.model.productMeta.productId);
                                    } catch (e) {}
                                    return "";
                                  }
                                }))
                                .then((res) => (res && res[0] && res[0].result) ? res[0].result : "")
                                .finally(() => chrome.tabs.remove(n11TabId).catch(() => {}));
                            });
                        });
                      };
                    const sendResult = () => {
                      const allPrices = (raw && Array.isArray(raw.allPrices)) ? raw.allPrices : [];
                      const bestPrice = (raw && raw.bestPrice != null) ? String(raw.bestPrice).trim() : "";
                      const payload = {
                        type: resultMessageType,
                        productId: resolvedProductId,
                        productName: finalProductName,
                        data,
                        akakceUrl,
                        akakceOriginalUrl: akakceUrl,
                        allPrices,
                        bestPrice,
                        idFromN11Url
                      };
                        if (redirectedToHome) payload.redirectedToHome = true;
                        if (n11PriceFromContent) payload.n11Price = n11PriceFromContent;
                        if (productUrl) payload.productUrl = productUrl;
                        if (sellerNickName) payload.sellerNickName = sellerNickName;
                        if (senderTabId) chrome.tabs.sendMessage(senderTabId, payload).catch(() => {});
                        chrome.tabs.remove(akakceTabId).catch(() => {});
                        port.postMessage({ ok: true });
                      };
                      if (!resolvedProductId && n11Link && productUrl) {
                        fetchProductIdFromN11Link(n11Link).then((id) => {
                          resolvedProductId = id || resolvedProductId;
                          sendResult();
                        }).catch(() => sendResult());
                      } else {
                        sendResult();
                      }
                    })
                    .catch(() => {
                      if (port.name === "price-protector-flow" && senderTabId) {
                        chrome.tabs.sendMessage(senderTabId, {
                          type: resultMessageType,
                          productId,
                          productName,
                          productUrl,
                          akakceUrl,
                          data: [],
                          allPrices: [],
                          bestPrice: "",
                          n11Price: n11PriceFromContent,
                          sellerNickName,
                          idFromN11Url
                        }).catch(() => {});
                      }
                      chrome.tabs.remove(akakceTabId).catch(() => {});
                      port.postMessage({ ok: true });
                    });
                };
                chrome.tabs.onUpdated.addListener(loadListener);
              });
            })
            .catch(() => port.postMessage({ error: "Google sonuçlarından akakce linki bulunamadı." }));
        };
        chrome.tabs.onUpdated.addListener(listener);
        }).catch(() => port.postMessage({ error: "Bağlantı hatası." }));
      });
    });
  });
});

const runManuelUpdateFlow = (message, sender, sendResponse, resultType) => {
  const productId = (message.productId != null) ? String(message.productId) : "";
  const productName = (message.productName != null) ? String(message.productName) : "";
  const akakceUrl = (message.akakceUrl || "").trim();
  const rowIndex = typeof message.rowIndex === "number" ? message.rowIndex : -1;
  const n11TabId = sender?.tab?.id || null;
  if (!akakceUrl || !akakceUrl.includes("akakce.com")) {
    sendResponse({ ok: false, error: "Geçersiz Akakce URL" });
    return;
  }
  if (!n11TabId) {
    sendResponse({ ok: false, error: "Tab bulunamadı" });
    return;
  }
  const base = (akakceUrl.split("#")[0] || akakceUrl).trim();
  const url = base + (base.includes("?") ? "&" : "?") + "n11_manuel=1";
  const openPassive = resultType === "akakce-manuel-update-result";
  chrome.tabs.create({ url, active: !openPassive }).then((tab) => {
    if (!tab || !tab.id) {
      sendResponse({ ok: false, error: "Sekme açılamadı" });
      return;
    }
    const akakceTabId = tab.id;
    const extractData = () => chrome.scripting.executeScript({
      target: { tabId: akakceTabId },
      func: function extractAkakceListData() {
        const brandMap = {
          "trendyol": "Trendyol",
          "trendyolplus": "Trendyol",
          "n11": "n11",
          "amazon türkiye": "Amazon Türkiye",
          "amazon turkiye": "Amazon Türkiye",
          "hepsiburada": "Hepsiburada",
          "pazarama": "Pazarama",
          "pttavm": "PttAVM",
          "ptt avm": "PttAVM",
          "idefix": "idefix"
        };
        const domainToBrand = {
          "trendyol.com": "Trendyol",
          "n11.com": "n11",
          "hepsiburada.com": "Hepsiburada",
          "amazon.com.tr": "Amazon Türkiye",
          "pazarama.com": "Pazarama",
          "pttavm.com": "PttAVM",
          "idefix.com": "idefix"
        };
        const getSellerFromLi = (li) => {
          const vendorEl = li.querySelector(".v_v8, .v_v9");
          if (!vendorEl) return "";
          return vendorEl.textContent.replace(/\s+/g, " ").trim().replace(/^\/+/, "");
        };
        const getBrandFromLi = (li) => {
          const img = li.querySelector("img[alt]");
          if (img && img.alt) {
            const rawBrand = String(img.alt).trim();
            const brandKey = rawBrand.toLowerCase().replace(/\s+/g, "");
            const mapped =
              brandMap[brandKey] ||
              ([
                "Trendyol",
                "n11",
                "Amazon Türkiye",
                "Hepsiburada",
                "Pazarama",
                "PttAVM",
                "idefix"
              ].includes(rawBrand)
                ? rawBrand
                : null);
            if (mapped) return mapped;
            return rawBrand;
          }
          const link = li.querySelector(
            "a[href*='trendyol'], a[href*='n11.com'], a[href*='hepsiburada'], a[href*='amazon.com.tr'], a[href*='pazarama.com'], a[href*='pttavm.com'], a[href*='idefix.com']"
          );
          if (link && link.href) {
            for (const [domain, b] of Object.entries(domainToBrand)) {
              if (link.href.includes(domain)) return b;
            }
          }
          return "";
        };
        const buildBestLabel = (brand, seller) => {
          const b = (brand || "").trim();
          const s = (seller || "").trim().replace(/^\/+/, "");
          if (s && s.includes("/")) return s;
          if (b && s && s.toLowerCase() !== b.toLowerCase()) return b + "/" + s;
          return b || s || "?";
        };
        const path = (window.location && window.location.pathname) ? window.location.pathname : "";
        const isHomeLike = path === "/" || path === "" || /^\/(anasayfa|home|index(\.php)?)$/i.test(path);
        const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
        if (!ul) return { items: [], allPrices: [], bestPrice: "", redirectedToHome: isHomeLike };
        const items = [];
        ul.querySelectorAll("li").forEach((li) => {
          let brand = null;
          const img = li.querySelector("img");
          if (img && img.alt) {
            const rawBrand = (img.alt || "").trim();
            const brandKey = rawBrand.toLowerCase().replace(/\s+/g, "");
            brand =
              brandMap[brandKey] ||
              ([
                "Trendyol",
                "n11",
                "Amazon Türkiye",
                "Hepsiburada",
                "Pazarama",
                "PttAVM",
                "idefix"
              ].includes(rawBrand)
                ? rawBrand
                : null);
          }
          if (!brand) {
            const link = li.querySelector(
              "a[href*='trendyol'], a[href*='n11.com'], a[href*='hepsiburada'], a[href*='amazon.com.tr'], a[href*='pazarama.com'], a[href*='pttavm.com'], a[href*='idefix.com']"
            );
            if (link && link.href) {
              for (const [domain, b] of Object.entries(domainToBrand)) {
                if (link.href.includes(domain)) { brand = b; break; }
              }
            }
          }
          if (!brand) return;
          const pb = li.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
          let price = "";
          if (pb) {
            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
            if (cmpgn) price = cmpgn.textContent.replace(/\s+/g, " ").trim();
            else { const pt = pb.querySelector(".pt_v8, .pt_v9, [class*='pt_']"); if (pt) price = pt.textContent.replace(/\s+/g, " ").trim(); }
          }
          items.push({ brand, price });
        });
        const allPrices = [];
        ul.querySelectorAll("li").forEach((li) => {
          const pb = li.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
          if (pb) {
            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
            const pt = !cmpgn ? pb.querySelector(".pt_v8, .pt_v9, [class*='pt_']") : null;
            const p = (cmpgn || pt) ? (cmpgn || pt).textContent.replace(/\s+/g, " ").trim() : "";
            if (p) allPrices.push(p);
          }
        });
        let bestPrice = "";
        const firstLi = ul.querySelector("li");
        if (firstLi) {
          const pb = firstLi.querySelector(".pb_v8, .pb_v9, [class*='pb_']");
          let price = "";
          if (pb) {
            const cmpgn = pb.querySelector(".cmpgn_pt_v8, .cmpgn_pt_v9, [class*='cmpgn_pt']");
            if (cmpgn) price = cmpgn.textContent.replace(/\s+/g, " ").trim();
            else { const pt = pb.querySelector(".pt_v8, .pt_v9, [class*='pt_']"); if (pt) price = pt.textContent.replace(/\s+/g, " ").trim(); }
          }
          const label = buildBestLabel(getBrandFromLi(firstLi), getSellerFromLi(firstLi));
          bestPrice = label + " - " + (price && price.trim() ? price.trim() : "-");
        }
        return { items, allPrices, bestPrice, redirectedToHome: false };
      }
    });
    const loadListener = (updatedId, info) => {
      if (updatedId !== akakceTabId || info.status !== "complete") return;
      chrome.tabs.onUpdated.removeListener(loadListener);
      const isCf = () => chrome.scripting.executeScript({
        target: { tabId: akakceTabId },
        func: () => /Performing security verification|security check|Cloudflare|Just a moment/i.test(document.body?.innerText || "")
      }).then((r) => r && r[0] && r[0].result === true);
      const hasContent = () => chrome.scripting.executeScript({
        target: { tabId: akakceTabId },
        func: () => Boolean(document.querySelector("ul#PL, [id='PL'], #pd_v8"))
      }).then((r) => r && r[0] && r[0].result === true);
      const waitReady = (n) => {
        if (n >= 5) return Promise.resolve();
        return new Promise((r) => setTimeout(r, n === 0 ? 1000 : 2500))
          .then(() => isCf())
          .then((cf) => cf ? waitReady(n + 1) : hasContent().then((ok) => ok ? Promise.resolve() : waitReady(n + 1)));
      };
      waitReady(0)
        .then(() => chrome.tabs.sendMessage(akakceTabId, { type: "akakce-manuel-update-mode" }).catch(() => {}))
        .then(() => chrome.scripting.executeScript({
          target: { tabId: akakceTabId },
          func: () => {
            const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
            return ul ? ul.querySelectorAll("li").length : 0;
          }
        }))
        .then((r) => {
          const initialCount = (r && r[0] && typeof r[0].result === "number") ? r[0].result : 0;
          const poll = (elapsed) => {
            if (elapsed >= 18000) return Promise.resolve();
            return new Promise((resolve) => setTimeout(resolve, 800))
              .then(() => chrome.scripting.executeScript({
                target: { tabId: akakceTabId },
                func: () => {
                  const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
                  return ul ? ul.querySelectorAll("li").length : 0;
                }
              }))
              .then((res) => {
                const cur = res && res[0] && typeof res[0].result === "number" ? res[0].result : 0;
                if (cur > initialCount) return Promise.resolve();
                return poll(elapsed + 800);
              });
          };
          return poll(0);
        })
        .then(() => chrome.tabs.sendMessage(akakceTabId, { type: "akakce-hide-manual-banner" }).catch(() => {}))
        .then(() => new Promise((r) => setTimeout(r, 400)))
        .then(() =>
          chrome.scripting.executeScript({
            target: { tabId: akakceTabId },
            func: akakcePageWarmupScroll
          })
        )
        .then(() => extractData())
        .then((extractResults) => {
          const raw = extractResults && extractResults[0] && extractResults[0].result;
          const data = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.items) ? raw.items : []);
          const allPrices = (raw && Array.isArray(raw.allPrices)) ? raw.allPrices : [];
          const redirectedToHome = Boolean(raw && raw.redirectedToHome);
          const msg = { type: resultType, productId, data, rowIndex };
          if (allPrices.length > 0) msg.allPrices = allPrices;
          if (raw && raw.bestPrice != null) msg.bestPrice = String(raw.bestPrice).trim();
          if (redirectedToHome) msg.redirectedToHome = true;
          chrome.tabs.sendMessage(n11TabId, msg).catch(() => {});
          chrome.tabs.remove(akakceTabId).catch(() => {});
        })
        .catch(() => {
          chrome.tabs.remove(akakceTabId).catch(() => {});
          chrome.tabs.sendMessage(n11TabId, { type: resultType, productId, data: [], rowIndex }).catch(() => {});
        });
    };
    chrome.tabs.onUpdated.addListener(loadListener);
  });
  sendResponse({ ok: true });
};

const DEEP_ANALYSIS_SYSTEM = `Sen bir e-ticaret fiyat analiz uzmanısın. Sana verilen n11 ürün bilgilerini kullanarak Google Search üzerinden Trendyol, Hepsiburada, Amazon Türkiye veya diğer güvenilir platformlarda bu ürünün fiyatlarını bul.

Kurallar:
- Sadece aynı model, aynı teknik özellik ve aynı kondisyondaki (sıfır ürün) fiyatları dikkate al.
- Mağaza/satıcı adı eşleşmese bile farklı mağazalardan ve satıcılardan aynı ürünü ara; herhangi bir satıcının fiyatını bulabilirsin.
- Farklı varyasyonları (renk, hafıza vb.) karıştırma.
- Sonucu SADECE aşağıdaki JSON formatında dön, başka hiçbir açıklama yapma:
{
  "found": true/false,
  "competitor_price": 0.0,
  "source_url": "link",
  "platform": "Hepsiburada/Trendyol/Amazon",
  "confidence_score": 0-100,
  "analysis_note": "Neden bu sonucu bulduğuna dair kısa not"
}`;

function runDeepAnalysis(message, sendResult) {
  const DEFAULT_GEMINI_API_KEY = "AIzaSyDskGFLy6Gs_gbn-1B-mG7rqIzt2SlMZmc";
  chrome.storage.local.get("geminiApiKey", async (stored) => {
    const apiKey = (stored.geminiApiKey || DEFAULT_GEMINI_API_KEY || "").trim();
    if (!apiKey) {
      sendResult(null, "Gemini API Key bulunamadı.");
      return;
    }
    const productUrl = (message.productUrl || "").trim();
    const n11Price = (message.n11Price || "").trim();
    const sellerNickName = (message.sellerNickName || "").trim();
    const productName = (message.productName || "").trim();
    const userContent = `n11 Ürün Linki: ${productUrl}\nn11 Fiyatı: ${n11Price}\nSatıcı Adı: ${sellerNickName}\nÜrün Adı: ${productName}`;
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(apiKey)}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userContent }] }],
          systemInstruction: { parts: [{ text: DEEP_ANALYSIS_SYSTEM }] },
          tools: [{ google_search: {} }],
          safetySettings: [
            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
          ]
        })
      });
      const json = await res.json();
      if (!res.ok) {
        const errMsg = json?.error?.message || json?.error || String(res.status);
        sendResult(null, errMsg);
        return;
      }
      const text = json?.candidates?.[0]?.content?.parts?.[0]?.text || "";
      let parsed = null;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          parsed = JSON.parse(jsonMatch[0]);
        } catch (e) {}
      }
      sendResult(parsed, null);
    } catch (err) {
      sendResult(null, err?.message || String(err));
    }
  });
}

/**
 * Hepsiburada ürün sayfası JSON-LD BreadcrumbList: position 2 ve son öğeden bir önceki kategori adı.
 */
const fetchHepsiburadaProductBreadcrumbInTab = async (productUrl) => {
  const tab = await chrome.tabs.create({ url: productUrl, active: false });
  if (!tab || !tab.id) {
    return { ok: false, categoryPos2: "", categoryParent: "" };
  }
  const tabId = tab.id;
  await new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      resolve();
    };
    const onUpdated = (id, info) => {
      if (id === tabId && info.status === "complete") finish();
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((t) => {
      if (t && t.status === "complete") finish();
    }).catch(() => {});
    setTimeout(finish, 26000);
  });
  await new Promise((r) => setTimeout(r, 750));
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      func: function extractHbBreadcrumbLdJson() {
        const out = { categoryPos2: "", categoryParent: "" };
        const walk = function (node) {
          if (!node || typeof node !== "object") return null;
          if (node["@type"] === "BreadcrumbList" && Array.isArray(node.itemListElement)) return node;
          if (Array.isArray(node)) {
            for (let i = 0; i < node.length; i++) {
              const w = walk(node[i]);
              if (w) return w;
            }
            return null;
          }
          const g = node["@graph"];
          if (Array.isArray(g)) {
            for (let i = 0; i < g.length; i++) {
              const w = walk(g[i]);
              if (w) return w;
            }
          }
          const keys = Object.keys(node);
          for (let i = 0; i < keys.length; i++) {
            const k = keys[i];
            if (k === "@context") continue;
            const w = walk(node[k]);
            if (w) return w;
          }
          return null;
        };
        const scripts = document.querySelectorAll('script[type="application/ld+json"]');
        for (let si = 0; si < scripts.length; si++) {
          try {
            const raw = (scripts[si].textContent || "").trim();
            if (!raw) continue;
            const j = JSON.parse(raw);
            const roots = Array.isArray(j) ? j : [j];
            for (let ri = 0; ri < roots.length; ri++) {
              const bl = walk(roots[ri]);
              if (!bl || !Array.isArray(bl.itemListElement)) continue;
              const items = bl.itemListElement
                .map(function (it) {
                  const pos = Number(it.position);
                  let name = "";
                  if (it.name) name = String(it.name).trim();
                  else if (it.item && typeof it.item === "string") name = String(it.item).trim();
                  else if (it.item && typeof it.item === "object" && it.item.name) name = String(it.item.name).trim();
                  return { position: pos, name: name };
                })
                .filter(function (x) {
                  return Boolean(x.name);
                })
                .sort(function (a, b) {
                  return (a.position || 0) - (b.position || 0);
                });
              if (items.length === 0) continue;
              const p2 = items.filter(function (x) {
                return x.position === 2;
              })[0];
              out.categoryPos2 = (p2 && p2.name) || (items[1] ? items[1].name : "") || "";
              if (items.length >= 2) {
                out.categoryParent = items[items.length - 2].name || "";
              }
              return out;
            }
          } catch (e) {}
        }
        return out;
      }
    });
    const r = res && res[0] && res[0].result ? res[0].result : { categoryPos2: "", categoryParent: "" };
    await chrome.tabs.remove(tabId).catch(() => {});
    return {
      ok: true,
      categoryPos2: r.categoryPos2 != null ? String(r.categoryPos2) : "",
      categoryParent: r.categoryParent != null ? String(r.categoryParent) : ""
    };
  } catch (e) {
    await chrome.tabs.remove(tabId).catch(() => {});
    return { ok: false, categoryPos2: "", categoryParent: "" };
  }
};

const fetchTrendyolProductDetailInTab = async (productUrl) => {
  const tab = await chrome.tabs.create({ url: productUrl, active: false });
  if (!tab || !tab.id) {
    return { ok: false, error: "Sekme açılamadı" };
  }
  const tabId = tab.id;
  await new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve();
    };
    const onUpdated = (id, info) => {
      if (id === tabId && info.status === "complete") finish();
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((t) => {
      if (t && t.status === "complete") finish();
    }).catch(() => {});
    setTimeout(finish, 30000);
  });
  await new Promise((r) => setTimeout(r, 1800));
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      func: function extractTrendyolProductDetail() {
        const clean = (v) => String(v == null ? "" : v).replace(/\s+/g, " ").trim();
        const extractImageCandidate = (val) => {
          if (val == null) return "";
          if (typeof val === "string") return val;
          if (Array.isArray(val)) {
            for (let i = 0; i < val.length; i += 1) {
              const picked = extractImageCandidate(val[i]);
              if (picked) return picked;
            }
            return "";
          }
          if (typeof val === "object") {
            const keys = ["url", "src", "path", "imageUrl", "image", "secure_url"];
            for (let i = 0; i < keys.length; i += 1) {
              const picked = extractImageCandidate(val[keys[i]]);
              if (picked) return picked;
            }
          }
          return "";
        };
        const pickSrcsetUrl = (srcset) => {
          const parts = clean(srcset).split(",").map((x) => clean(x).split(/\s+/)[0]).filter(Boolean);
          return parts.length ? parts[parts.length - 1] : "";
        };
        const toAbsImage = (v) => {
          let s = clean(extractImageCandidate(v));
          if (!s) return "";
          if (s.startsWith("//")) return `https:${s}`;
          if (/^https?:\/\//i.test(s)) return s;
          if (/^(ty|mnresize|web|assets)\//i.test(s) || /\.(jpe?g|png|webp)(?:\?|$)/i.test(s)) {
            return `https://cdn.dsmcdn.com/${s.replace(/^\/+/, "")}`;
          }
          try { return new URL(s, location.origin).href; } catch (e) { return s; }
        };
        const canonicalUrl = (() => {
          const href = document.querySelector('link[rel="canonical"]')?.href || location.href;
          try {
            const u = new URL(href);
            return `${u.origin}${u.pathname}`;
          } catch (e) {
            return String(href || "").split("?")[0];
          }
        })();
        const out = {
          id: "",
          contentId: "",
          name: "",
          brandName: "",
          categoryName: "",
          sellerName: "",
          image: "",
          url: canonicalUrl,
          sepettePriceText: "",
          normalPriceText: "",
          discountedPriceText: ""
        };
        const setIfEmpty = (key, val) => {
          const s = clean(val);
          if (s && !out[key]) out[key] = s;
        };
        const parseTrPrice = (val) => {
          if (val == null) return null;
          const raw = clean(val);
          if (!raw) return null;
          const m = raw.match(/(\d+(?:\.\d{3})*|\d+)(?:,(\d{1,2}))?/);
          if (!m) return null;
          const whole = String(m[1] || "").replace(/\./g, "");
          const frac = String(m[2] || "00").padEnd(2, "0").slice(0, 2);
          const num = Number(`${whole}.${frac}`);
          return Number.isFinite(num) && num > 0 ? num : null;
        };
        const formatTrPrice = (val) => {
          const num = typeof val === "number" ? val : parseTrPrice(val);
          if (!Number.isFinite(num) || num <= 0) return "";
          return `${num.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} TL`;
        };
        const extractPriceCandidate = (val) => {
          if (val == null) return "";
          if (typeof val === "number") return formatTrPrice(val);
          if (typeof val === "string") return val;
          if (typeof val === "object") {
            const keys = ["text", "formattedValue", "formattedPrice", "priceText", "discountedPriceText", "value", "price", "sellingPrice", "discountedPrice", "originalPrice", "tyPlusCouponApplicablePrice"];
            for (let i = 0; i < keys.length; i += 1) {
              const picked = extractPriceCandidate(val[keys[i]]);
              if (picked) return picked;
            }
          }
          return "";
        };
        const setPriceIfEmpty = (val) => {
          if (out.discountedPriceText) return;
          const raw = clean(extractPriceCandidate(val));
          if (!raw) return;
          const formatted = formatTrPrice(raw);
          out.discountedPriceText = formatted || raw;
        };
        const setImageIfEmpty = (val) => {
          const s = toAbsImage(val);
          if (s && !out.image) out.image = s;
        };
        const pickPriceText = (obj) => {
          if (!obj || typeof obj !== "object") return;
          setPriceIfEmpty(obj.discountedPriceText);
          setPriceIfEmpty(obj.priceText);
          setPriceIfEmpty(obj.salePrice);
          setPriceIfEmpty(obj.sellingPrice);
          setPriceIfEmpty(obj.discountedPrice);
          setPriceIfEmpty(obj.tyPlusCouponApplicablePrice);
          setPriceIfEmpty(obj.price);
          setPriceIfEmpty(obj?.price?.discountedPriceText);
          setPriceIfEmpty(obj?.price?.discountedPrice);
          setPriceIfEmpty(obj?.price?.sellingPrice);
          setPriceIfEmpty(obj?.price?.originalPrice);
          setPriceIfEmpty(obj?.price?.tyPlusCouponApplicablePrice);
        };
        const pickProductLike = (obj) => {
          if (!obj || typeof obj !== "object") return;
          setIfEmpty("name", obj.name);
          setIfEmpty("name", obj.title);
          setIfEmpty("brandName", obj.brandName);
          setIfEmpty("brandName", obj?.brand?.name);
          setIfEmpty("brandName", obj?.brandInfo?.name);
          if (typeof obj.brand === "string") setIfEmpty("brandName", obj.brand);
          setIfEmpty("categoryName", obj.categoryName);
          setIfEmpty("categoryName", obj?.category?.name);
          setIfEmpty("categoryName", obj?.categoryInfo?.name);
          setIfEmpty("id", obj.id);
          setIfEmpty("contentId", obj.contentId);
          setIfEmpty("contentId", obj.productContentId);
          setImageIfEmpty(obj.image);
          setImageIfEmpty(obj.imageUrl);
          setImageIfEmpty(obj.images);
          setImageIfEmpty(obj?.media?.images);
          setImageIfEmpty(obj?.product?.images);
          if (Array.isArray(obj.images) && obj.images.length) {
            const img = obj.images[0];
            setImageIfEmpty(typeof img === "string" ? img : (img && (img.url || img.path)));
          }
          pickPriceText(obj);
        };
        const scanObject = (root) => {
          const visited = new Set();
          const stack = [root];
          let guard = 0;
          while (stack.length && guard < 4000) {
            guard += 1;
            const cur = stack.pop();
            if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
            visited.add(cur);
            pickProductLike(cur);
            if (out.name && out.brandName && out.discountedPriceText && out.image && (out.id || out.contentId)) {
              return;
            }
            if (Array.isArray(cur)) {
              for (let i = 0; i < cur.length; i += 1) {
                if (cur[i] && typeof cur[i] === "object") stack.push(cur[i]);
              }
            } else {
              const vals = Object.values(cur);
              for (let i = 0; i < vals.length; i += 1) {
                if (vals[i] && typeof vals[i] === "object") stack.push(vals[i]);
              }
            }
          }
        };
        const parseJsonFromScriptText = (text) => {
          const raw = clean(text);
          if (!raw) return null;
          try { return JSON.parse(raw); } catch (e) {}
          const stateMatch = raw.match(/window\.__PRODUCT_DETAIL_APP_INITIAL_STATE__\s*=\s*(\{[\s\S]*?\});/);
          if (stateMatch && stateMatch[1]) {
            try { return JSON.parse(stateMatch[1]); } catch (e) {}
          }
          return null;
        };
        const scripts = document.querySelectorAll("script");
        for (let i = 0; i < scripts.length; i += 1) {
          const text = scripts[i].textContent || "";
          if (!/PRODUCT_DETAIL|product|discountedPrice|BreadcrumbList/i.test(text)) continue;
          const parsed = parseJsonFromScriptText(text);
          if (parsed) scanObject(parsed);
          if (!out.discountedPriceText) {
            const pricePatterns = [
              /"discountedPriceText"\s*:\s*"([^"]+)"/i,
              /"discountedPrice"\s*:\s*\{[\s\S]{0,240}?"text"\s*:\s*"([^"]+)"/i,
              /"sellingPrice"\s*:\s*\{[\s\S]{0,240}?"text"\s*:\s*"([^"]+)"/i,
              /"tyPlusCouponApplicablePrice"\s*:\s*\{[\s\S]{0,240}?"text"\s*:\s*"([^"]+)"/i,
              /"price"\s*:\s*\{[\s\S]{0,240}?"text"\s*:\s*"([^"]+)"/i
            ];
            for (let pi = 0; pi < pricePatterns.length && !out.discountedPriceText; pi += 1) {
              const match = text.match(pricePatterns[pi]);
              if (match && match[1]) setPriceIfEmpty(match[1].replace(/\\"/g, '"'));
            }
          }
        }
        Object.keys(window || {}).forEach((key) => {
          if (!/PRODUCT|PROPS|STATE/i.test(key)) return;
          try { scanObject(window[key]); } catch (e) {}
        });
        const domBrand = clean(document.querySelector(".product-brand-name, .product-brand, .pr-new-br a, .pr-new-br span")?.textContent);
        const domName = clean(document.querySelector("h1 .pr-new-br + span, h1 span, h1, .product-name")?.textContent);
        if (domBrand) out.brandName = domBrand;
        if (domName) out.name = domName;
        const priceSelectors = [
          ".prc-dsc",
          ".prc-slg",
          ".price-information",
          ".product-price-container",
          ".pr-bx-w",
          "[class*='price']",
          "[class*='prc']"
        ];
        for (let i = 0; i < priceSelectors.length && !out.discountedPriceText; i += 1) {
          const nodes = Array.from(document.querySelectorAll(priceSelectors[i]));
          for (let ni = 0; ni < nodes.length && !out.discountedPriceText; ni += 1) {
            const txt = clean(nodes[ni].textContent);
            if (txt && parseTrPrice(txt) != null) setPriceIfEmpty(txt);
          }
        }
        setImageIfEmpty(document.querySelector('meta[property="og:image"], meta[name="twitter:image"], link[rel="image_src"]')?.content || document.querySelector('link[rel="image_src"]')?.href);
        const imageSelectors = [
          "img.base-product-image",
          ".base-product-image img",
          ".gallery-modal-content img",
          ".product-slide img",
          ".product-image-container img",
          ".product-detail-container img",
          "img[src*='cdn.dsmcdn.com']",
          "img[srcset*='cdn.dsmcdn.com']"
        ];
        for (let i = 0; i < imageSelectors.length && !out.image; i += 1) {
          const imgEl = document.querySelector(imageSelectors[i]);
          if (!imgEl) continue;
          setImageIfEmpty(imgEl.currentSrc || imgEl.src || imgEl.getAttribute("data-src") || imgEl.getAttribute("data-original"));
          if (!out.image) setImageIfEmpty(pickSrcsetUrl(imgEl.getAttribute("srcset")));
        }
        const crumbs = Array.from(document.querySelectorAll(".breadcrumb a, .product-detail-breadcrumb a, nav a"))
          .map((a) => clean(a.textContent))
          .filter(Boolean);
        if (crumbs.length >= 2) out.categoryName = crumbs[crumbs.length - 2] || crumbs[crumbs.length - 1] || "";
        const domSeller = clean(
          document.querySelector(
            'div.merchant-title-header > a[data-testid="store-link"] > div.merchant-name'
          )?.textContent
        );
        if (domSeller) out.sellerName = domSeller;
        if (!out.sellerName) {
          const sellerFallback = clean(
            document.querySelector(".merchant-name, [data-testid='store-link'] .merchant-name")?.textContent
          );
          if (sellerFallback) out.sellerName = sellerFallback;
        }
        if (!out.id && !out.contentId) {
          const m = String(location.pathname || "").match(/-p-(\d+)/i);
          if (m && m[1]) out.contentId = m[1];
        }
        const resolvePricePairFromScriptText = (text) => {
          const pickText = (pattern) => {
            const m = text.match(pattern);
            return m && m[1] ? String(m[1]).replace(/\\"/g, '"') : "";
          };
          return {
            selling: pickText(/"sellingPrice"\s*:\s*\{[\s\S]{0,320}?"text"\s*:\s*"([^"]+)"/i),
            discounted: pickText(/"discountedPrice"\s*:\s*\{[\s\S]{0,320}?"text"\s*:\s*"([^"]+)"/i),
            original: pickText(/"originalPrice"\s*:\s*\{[\s\S]{0,320}?"text"\s*:\s*"([^"]+)"/i)
          };
        };
        if (!out.sepettePriceText || !out.normalPriceText) {
          const scripts = Array.from(document.querySelectorAll("script"));
          for (let si = 0; si < scripts.length; si += 1) {
            const text = String(scripts[si].textContent || "");
            if (!text.includes("sellingPrice") && !text.includes("discountedPrice")) continue;
            const pair = resolvePricePairFromScriptText(text);
            const normalRaw = pair.selling || pair.original;
            const basketRaw = pair.discounted;
            if (normalRaw && !out.normalPriceText) {
              out.normalPriceText = formatTrPrice(normalRaw) || normalRaw;
            }
            if (basketRaw && !out.sepettePriceText) {
              out.sepettePriceText = formatTrPrice(basketRaw) || basketRaw;
            }
            if (out.sepettePriceText && out.normalPriceText) break;
          }
        }
        const basketNum = parseTrPrice(out.sepettePriceText);
        const normalNum = parseTrPrice(out.normalPriceText);
        if (basketNum != null && normalNum != null && basketNum >= normalNum) {
          out.sepettePriceText = "";
        }
        if (!out.normalPriceText && out.sepettePriceText) {
          out.normalPriceText = out.sepettePriceText;
          out.sepettePriceText = "";
        }
        if (!out.normalPriceText && out.discountedPriceText) {
          out.normalPriceText = out.discountedPriceText;
        }
        out.discountedPriceText = out.sepettePriceText || out.normalPriceText || out.discountedPriceText;
        return out;
      }
    });
    const product = res && res[0] && res[0].result ? res[0].result : null;
    await chrome.tabs.remove(tabId).catch(() => {});
    if (!product || (!product.name && !product.brandName)) {
      return { ok: false, error: "Ürün bilgisi bulunamadı" };
    }
    return { ok: true, product };
  } catch (e) {
    await chrome.tabs.remove(tabId).catch(() => {});
    return { ok: false, error: e?.message || "Ürün sayfası okunamadı" };
  }
};

async function extractTrendyolSellerScrapingFromPage() {
  const decodeEscapes = (val) => {
    let s = String(val == null ? "" : val);
    s = s.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
    s = s.replace(/\\\//g, "/");
    return s;
  };
  const clean = (v) => decodeEscapes(v).replace(/\s+/g, " ").trim();
  const toAbs = (v) => {
    const s = clean(v);
    if (!s) return "";
    if (s.startsWith("//")) return `https:${s}`;
    if (/^https?:\/\//i.test(s)) return s;
    if (/^(ty|mnresize|web|assets|prod)\//i.test(s) || /\.(jpe?g|png|webp)(?:\?|$)/i.test(s)) {
      return `https://cdn.dsmcdn.com/${s.replace(/^\/+/, "")}`;
    }
    try { return new URL(s, location.origin).href; } catch (e) { return s; }
  };
  const toOrgZoom = (raw) => {
    let s = toAbs(raw);
    if (!s) return "";
    s = s.replace(/\/mnresize\/\d+\/\d+\//gi, "/");
    if (/_org_zoom\.(jpe?g|png|webp)/i.test(s)) return s.split("?")[0];
    s = s.replace(/_org\.(jpe?g|png|webp)/i, "_org_zoom.$1");
    return s.split("?")[0];
  };
  const isProductImageUrl = (url) => {
    const s = clean(url);
    if (!s) return false;
    if (!/^https?:\/\//i.test(s)) return false;
    if (/\.svg(?:\?|$)/i.test(s) || /image\/svg/i.test(s)) return false;
    if (!/cdn\.dsmcdn\.com/i.test(s)) return false;
    if (!/\.(jpe?g|png|webp)(?:\?|$)/i.test(s)) return false;
    if (/\/(web|sfint|sfweb|mobile|assets|static|logo|icons?|badge|sprite|favicon|payment)\//i.test(s)) return false;
    if (/(favicon|logo[-_]|icon[-_]|sprite|badge)/i.test(s)) return false;
    return /_org_zoom\.|_org\.|\/prod\/|\/product\/media\//i.test(s);
  };
  const parseJsonByBraces = (source, fromIdx) => {
    const start = source.indexOf("{", fromIdx);
    if (start < 0) return null;
    let depth = 0;
    let inStr = false;
    let esc = false;
    for (let i = start; i < source.length; i += 1) {
      const ch = source[i];
      if (inStr) {
        if (esc) { esc = false; continue; }
        if (ch === "\\") { esc = true; continue; }
        if (ch === '"') inStr = false;
        continue;
      }
      if (ch === '"') { inStr = true; continue; }
      if (ch === "{") depth += 1;
      else if (ch === "}") {
        depth -= 1;
        if (depth === 0) {
          try { return JSON.parse(source.slice(start, i + 1)); } catch (e) { return null; }
        }
      }
    }
    return null;
  };
  const collectStates = () => {
    const states = [];
    const push = (obj) => {
      if (obj && typeof obj === "object") states.push(obj);
    };
    try { push(window.__PRODUCT_DETAIL_APP_INITIAL_STATE__); } catch (e) {}
    try { push(window.__PRODUCT_DETAIL_APP_INITIAL_STATE_V2__); } catch (e) {}
    try { push(window.__PRELOADED_STATE__); } catch (e) {}
    try { push(window.__envoy__SHARED_PROPS__); } catch (e) {}
    const parseInitialStateScript = (text) => {
      const prefixes = [
        "window.__PRODUCT_DETAIL_APP_INITIAL_STATE__=",
        "window.__PRODUCT_DETAIL_APP_INITIAL_STATE__ =",
        "window.__PRODUCT_DETAIL_APP_INITIAL_STATE_V2__=",
        "window.__PRODUCT_DETAIL_APP_INITIAL_STATE_V2__ ="
      ];
      for (let p = 0; p < prefixes.length; p += 1) {
        const start = text.indexOf(prefixes[p]);
        if (start < 0) continue;
        const jsonStart = start + prefixes[p].length;
        let end = text.indexOf(";window.TYPageName", jsonStart);
        if (end < 0) end = text.indexOf(";window.", jsonStart);
        if (end < 0) end = text.length;
        try {
          const parsed = JSON.parse(text.slice(jsonStart, end).trim());
          if (parsed && typeof parsed === "object") return parsed;
        } catch (e) {}
        const parsed = parseJsonByBraces(text, jsonStart);
        if (parsed) return parsed;
      }
      return null;
    };
    const scripts = document.querySelectorAll("script");
    for (let i = 0; i < scripts.length; i += 1) {
      const text = scripts[i].textContent || "";
      if (!text) continue;
      const type = (scripts[i].getAttribute("type") || "").toLowerCase();
      if (type === "application/ld+json") {
        try { push(JSON.parse(text)); } catch (e) {}
        continue;
      }
      const initialFromScript = parseInitialStateScript(text);
      if (initialFromScript) push(initialFromScript);
      const markers = [
        "__PRODUCT_DETAIL_APP_INITIAL_STATE__",
        "__PRODUCT_DETAIL_APP_INITIAL_STATE_V2__",
        "__envoy__SHARED_PROPS__",
        "productDetail"
      ];
      for (let m = 0; m < markers.length; m += 1) {
        const idx = text.indexOf(markers[m]);
        if (idx < 0) continue;
        const parsed = parseJsonByBraces(text, idx);
        if (parsed) push(parsed);
      }
    }
    return states;
  };
  const visited = new Set();
  const walk = (root, visit) => {
    const stack = [root];
    let guard = 0;
    while (stack.length && guard < 8000) {
      guard += 1;
      const cur = stack.pop();
      if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
      visited.add(cur);
      visit(cur);
      if (Array.isArray(cur)) {
        for (let i = 0; i < cur.length; i += 1) {
          if (cur[i] && typeof cur[i] === "object") stack.push(cur[i]);
        }
      } else {
        const vals = Object.values(cur);
        for (let i = 0; i < vals.length; i += 1) {
          if (vals[i] && typeof vals[i] === "object") stack.push(vals[i]);
        }
      }
    }
  };
  const isBarcodeLike = (val) => {
    const s = clean(val);
    if (!s || s.length < 3 || s.length > 64) return false;
    if (/^https?:\/\//i.test(s)) return false;
    if (/^\d{8,14}$/.test(s)) return true;
    return /[A-Za-z]/.test(s) && /[0-9\-_]/.test(s);
  };
  const normalizeBarcode = (val) => {
    const s = clean(val);
    if (!s) return "";
    if (/^\d{8,14}$/.test(s)) return s;
    const labeled = s.match(/(?:barkod\s*)?no\s*[:：]?\s*([0-9A-Za-z\-_]{8,20})/i)
      || s.match(/barkod\s*[:：]\s*([0-9A-Za-z\-_]{8,20})/i)
      || s.match(/(\d{8,14})/);
    if (labeled) return clean(labeled[1]);
    return s.replace(/^(?:barkod\s*)?no\s*[:：]\s*/i, "").trim();
  };
  const knownProductIds = () => {
    const ids = new Set();
    [out.productContentId, out.productCode, out.productMainId, out.merchantId].forEach((val) => {
      if (val != null && String(val).trim() !== "") ids.add(String(val).trim());
    });
    out.variants.forEach((v) => {
      if (v && v.productCode != null && String(v.productCode).trim() !== "") {
        ids.add(String(v.productCode).trim());
      }
    });
    if (Array.isArray(out.skuVariants)) {
      out.skuVariants.forEach((v) => {
        if (v && v.productContentId != null && String(v.productContentId).trim() !== "") {
          ids.add(String(v.productContentId).trim());
        }
      });
    }
    return ids;
  };
  const isPlausibleBarcode = (val, relatedId) => {
    const s = normalizeBarcode(val);
    if (!s || !isBarcodeLike(s)) return false;
    if (relatedId != null && s === String(relatedId)) return false;
    if (knownProductIds().has(s)) return false;
    if (/^\d+$/.test(s)) {
      return s.length === 8 || s.length === 12 || s.length === 13 || s.length === 14;
    }
    return true;
  };
  const isProductMainIdLike = (val) => {
    const s = clean(val);
    if (!s || s.length < 3 || s.length > 40) return false;
    if (/^https?:\/\//i.test(s) || /\s/.test(s)) return false;
    if (/^BNPR/i.test(s)) return false;
    if (isKnownVariantBarcode(s)) return false;
    if (/^\d{6,12}$/.test(s) && !/^\d{8}$/.test(s) && !/^\d{12,14}$/.test(s)) return true;
    if (/[A-Za-z]/.test(s) && /[0-9]/.test(s)) return true;
    return false;
  };
  const out = {
    title: "",
    brand: "",
    brandId: "",
    barcode: "",
    productMainId: "",
    productContentId: "",
    productCode: "",
    categoryName: "",
    pimCategoryId: "",
    description: "",
    origin: "",
    salePrice: "",
    listPrice: "",
    images: [],
    attributes: [],
    gender: "",
    fashionAgeGroup: "",
    isFashion: false,
    variants: [],
    skuVariants: [],
    barcodeMap: {},
    stockCode: "",
    merchantId: ""
  };
  const contentIdFromUrl = () => {
    const m = String(location.pathname || "").match(/-p-(\d+)/i);
    return m ? Number(m[1]) : "";
  };
  if (!out.productContentId) out.productContentId = contentIdFromUrl();
  const isKnownVariantBarcode = (val) => {
    const s = clean(val);
    if (!s) return false;
    if (out.barcode && s === out.barcode) return true;
    return out.variants.some((x) => x && x.barcode === s);
  };
  const setProductMainId = (val) => {
    if (out.productMainId) return;
    const s = clean(val);
    if (!isProductMainIdLike(s) || isKnownVariantBarcode(s)) return;
    out.productMainId = s;
  };
  const applyTrendyolProductGroupId = (stateList, source) => {
    const take = (val) => {
      const s = clean(val);
      if (!/^\d{6,14}$/.test(s) || isKnownVariantBarcode(s)) return false;
      out.productMainId = s;
      return true;
    };
    const currentId = String(out.productContentId || contentIdFromUrl() || "").trim();
    if (/^\d+$/.test(currentId)) {
      const activeProduct = String(source || "").match(new RegExp(
        '"(?:id|contentId|productContentId)"\\s*:\\s*' + currentId
        + '[\\s\\S]{0,2000}?"productGroupId"\\s*:\\s*"?(\\d{6,14})"?'
      ));
      if (activeProduct && take(activeProduct[1])) return;
    }
    const fromNode = (obj, depth) => {
      if (!obj || typeof obj !== "object" || depth > 8) return false;
      const nodeIds = [obj.id, obj.contentId, obj.productContentId]
        .filter((value) => value != null && value !== "")
        .map(String);
      if (obj.productGroupId && (!currentId || nodeIds.includes(currentId)) && take(obj.productGroupId)) {
        return true;
      }
      if (Array.isArray(obj["@graph"])) {
        for (let g = 0; g < obj["@graph"].length; g += 1) {
          if (fromNode(obj["@graph"][g], depth + 1)) return true;
        }
      }
      const values = Object.values(obj);
      for (let i = 0; i < values.length; i += 1) {
        if (values[i] && typeof values[i] === "object" && fromNode(values[i], depth + 1)) return true;
      }
      return false;
    };
    const list = Array.isArray(stateList) ? stateList : [];
    for (let i = 0; i < list.length; i += 1) {
      if (fromNode(list[i], 0)) return;
    }
    const m = String(source || "").match(/"productGroupId"\s*:\s*"?(\d{6,14})"?/);
    if (m) take(m[1]);
  };
  const applySchemaProductGroupImages = (stateList) => {
    const seen = new Set();
    const next = [];
    const pushUrl = (val) => {
      const url = toOrgZoom(val);
      if (!url || !isProductImageUrl(url) || seen.has(url)) return;
      seen.add(url);
      next.push({ url });
    };
    const takeUrls = (urls) => {
      const list = Array.isArray(urls) ? urls : (urls ? [urls] : []);
      list.forEach(pushUrl);
      return next.length > 0;
    };
    const fromProductGroupImage = (image) => {
      if (!image) return false;
      if (typeof image === "string") return takeUrls(image);
      if (Array.isArray(image)) return takeUrls(image);
      if (typeof image !== "object") return false;
      if (Array.isArray(image.contentUrl) && image.contentUrl.length) return takeUrls(image.contentUrl);
      if (image.contentUrl) return takeUrls(image.contentUrl);
      if (image.url) return takeUrls(image.url);
      return false;
    };
    const fromNode = (obj, depth) => {
      if (!obj || typeof obj !== "object" || depth > 10) return false;
      const typeValues = Array.isArray(obj["@type"])
        ? obj["@type"].map(String)
        : [String(obj["@type"] || obj.type || "")];
      const isProductSchema = typeValues.some((type) =>
        /^Product(?:Group)?$/i.test(type.trim())
      );
      if (isProductSchema && fromProductGroupImage(obj.image)) return true;
      if (Array.isArray(obj["@graph"])) {
        for (let g = 0; g < obj["@graph"].length; g += 1) {
          if (fromNode(obj["@graph"][g], depth + 1)) return true;
        }
      }
      return false;
    };
    const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (let i = 0; i < ldScripts.length; i += 1) {
      try {
        if (fromNode(JSON.parse(ldScripts[i].textContent || ""), 0)) break;
      } catch (e) {}
    }
    if (!next.length) {
      const list = Array.isArray(stateList) ? stateList : [];
      for (let i = 0; i < list.length; i += 1) {
        if (fromNode(list[i], 0)) break;
      }
    }
    if (next.length) {
      next.forEach((item) => {
        if (item && item.url && !out.images.some((img) => img && img.url === item.url)) {
          out.images.push(item);
        }
      });
    }
  };
  const attrKey = (item) => `${item.attributeId || ""}|${item.attributeName}|${item.attributeValue}`;
  const attrSet = new Set();
  const attrText = (val) => {
    if (val == null || val === "") return "";
    if (typeof val === "string" || typeof val === "number") return clean(val);
    if (typeof val !== "object") return "";
    return clean(
      val.attributeName || val.attributeValue || val.name || val.valueName ||
      val.title || val.label || (typeof val.value === "string" || typeof val.value === "number" ? val.value : "")
    );
  };
  const attrId = (...cands) => {
    for (let i = 0; i < cands.length; i += 1) {
      const val = cands[i];
      if (val == null || val === "") continue;
      if (typeof val === "number" && Number.isFinite(val) && val >= 1) return val;
      if (typeof val === "string" && /^\d+$/.test(val.trim())) {
        const n = Number(val);
        if (n >= 1) return n;
        continue;
      }
      if (typeof val === "object") {
        const nested = val.id != null ? val.id : (val.attributeValueId != null ? val.attributeValueId : val.attributeId);
        if (typeof nested === "number" && Number.isFinite(nested) && nested >= 1) return nested;
        if (typeof nested === "string" && /^\d+$/.test(nested.trim())) {
          const n = Number(nested);
          if (n >= 1) return n;
        }
      }
    }
    return null;
  };
  const normalizeAttrPair = (name, value) => {
    let n = clean(name);
    let v = clean(value);
    const m = n.match(/^([^:]{1,80}):\s*(.+)$/);
    if (m) {
      n = clean(m[1]);
      const embedded = clean(m[2]);
      if (!v || v === name || v === embedded) v = embedded;
    }
    return { name: n, value: v };
  };
  const addAttribute = (raw) => {
    if (!raw || typeof raw !== "object") return;
    const name = attrText(raw.attributeName) || attrText(raw.name) || attrText(raw.keyName) ||
      attrText(raw.key) || attrText(raw.attribute);
    const value = attrText(raw.attributeValue) || attrText(raw.valueName) || attrText(raw.customAttributeValue) ||
      attrText(raw.value) || attrText(raw.attributeValueObj) || attrText(raw.unitText);
    if (!name || !value) return;
    const normalized = normalizeAttrPair(name, value);
    if (!normalized.name || !normalized.value) return;
    const item = { attributeName: normalized.name, attributeValue: normalized.value };
    const k = attrKey(item);
    if (attrSet.has(k)) return;
    attrSet.add(k);
    out.attributes.push(item);
    if (!out.origin && /men[sş]ei/i.test(normalized.name)) out.origin = normalized.value;
    if (!out.gender && /cinsiyet/i.test(normalized.name)) setGender(normalized.value);
    if (/model\s*kodu|ana\s*ürün\s*kodu|ana\s*urun\s*kodu|ürün\s*kodu|urun\s*kodu/i.test(normalized.name)) {
      setProductMainId(normalized.value);
    }
  };
  const applySchemaProductGroupAttributes = (stateList) => {
    const built = [];
    const seen = new Set();
    const pushAttr = (name, value) => {
      const pair = normalizeAttrPair(name, value);
      if (!pair.name || !pair.value) return;
      const k = `${pair.name}|${pair.value}`;
      if (seen.has(k)) return;
      seen.add(k);
      built.push({ attributeName: pair.name, attributeValue: pair.value });
      if (!out.origin && /men[sş]ei/i.test(pair.name)) out.origin = pair.value;
      if (!out.gender && /cinsiyet/i.test(pair.name)) setGender(pair.value);
    };
    const findProductGroup = (obj, depth) => {
      if (!obj || typeof obj !== "object" || depth > 8) return null;
      const typeVal = String(obj["@type"] || obj.type || "");
      if (/ProductGroup/i.test(typeVal)) return obj;
      if (Array.isArray(obj["@graph"])) {
        for (let g = 0; g < obj["@graph"].length; g += 1) {
          const found = findProductGroup(obj["@graph"][g], depth + 1);
          if (found) return found;
        }
      }
      return null;
    };
    const parseProductGroup = (root) => {
      const pg = findProductGroup(root, 0);
      if (!pg) return false;
      const colorValue = clean(pg.color);
      const props = Array.isArray(pg.additionalProperty) ? pg.additionalProperty : [];
      props.forEach((p) => {
        if (!p || typeof p !== "object") return;
        const propName = clean(p.name);
        if (!propName) return;
        if (colorValue && /^renk$/i.test(propName)) return;
        pushAttr(propName, p.unitText || p.value || p.propertyID);
      });
      if (colorValue) pushAttr("Renk", colorValue);
      if (pg.audience && pg.audience.suggestedGender) setGender(pg.audience.suggestedGender);
      return built.length > 0;
    };
    const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (let i = 0; i < ldScripts.length; i += 1) {
      try {
        if (parseProductGroup(JSON.parse(ldScripts[i].textContent || ""))) break;
      } catch (e) {}
    }
    if (!built.length) {
      const list = Array.isArray(stateList) ? stateList : [];
      for (let i = 0; i < list.length; i += 1) {
        if (parseProductGroup(list[i])) break;
      }
    }
    if (!built.length) return;
    const fashionAttrs = out.attributes.filter((a) =>
      a && /ya[sş]\s*grubu|cinsiyet/i.test(String(a.attributeName || ""))
    );
    out.attributes = fashionAttrs.concat(built);
    attrSet.clear();
    out.attributes.forEach((a) => attrSet.add(attrKey(a)));
  };
  const applySchemaProductGroupSkuVariants = (stateList) => {
    const built = [];
    const seen = new Set();
    const pushSku = (sku, color, url, image) => {
      const id = clean(sku);
      if (!id || !/^\d{5,}$/.test(id) || seen.has(id)) return;
      seen.add(id);
      const n = Number(id);
      built.push({
        productContentId: Number.isFinite(n) ? n : id,
        color: clean(color),
        productUrl: clean(url),
        image: toOrgZoom(image)
      });
    };
    const findProductGroup = (obj, depth) => {
      if (!obj || typeof obj !== "object" || depth > 8) return null;
      const typeVal = String(obj["@type"] || obj.type || "");
      if (/ProductGroup/i.test(typeVal)) return obj;
      if (Array.isArray(obj["@graph"])) {
        for (let g = 0; g < obj["@graph"].length; g += 1) {
          const found = findProductGroup(obj["@graph"][g], depth + 1);
          if (found) return found;
        }
      }
      return null;
    };
    const parseFromProductGroup = (pg) => {
      if (!pg || typeof pg !== "object") return;
      const list = Array.isArray(pg.hasVariant) ? pg.hasVariant : [];
      list.forEach((v) => {
        if (!v || typeof v !== "object") return;
        const img = typeof v.image === "string"
          ? v.image
          : (v.image && (v.image.contentUrl || v.image.url));
        pushSku(
          v.sku,
          v.color,
          (v.offers && v.offers.url) || v.url || v["@id"],
          img
        );
      });
      const currentId = out.productContentId || contentIdFromUrl();
      const currentColor = clean(pg.color);
      let currentUrl = clean(pg["@id"]);
      if (!currentUrl) {
        try { currentUrl = `${location.origin}${location.pathname}`; } catch (e) { currentUrl = ""; }
      }
      if (currentId) pushSku(currentId, currentColor, currentUrl, "");
    };
    const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (let i = 0; i < ldScripts.length; i += 1) {
      try {
        const pg = findProductGroup(JSON.parse(ldScripts[i].textContent || ""), 0);
        if (pg) {
          parseFromProductGroup(pg);
          break;
        }
      } catch (e) {}
    }
    if (!built.length) {
      const list = Array.isArray(stateList) ? stateList : [];
      for (let i = 0; i < list.length; i += 1) {
        const pg = findProductGroup(list[i], 0);
        if (pg) {
          parseFromProductGroup(pg);
          break;
        }
      }
    }
    if (built.length) out.skuVariants = built;
  };
  const harvestSizeVariantsFromSchemaAndDom = (stateList) => {
    const seen = new Set();
    out.variants.forEach((v) => {
      const val = clean(v && (v.value || v.size || v.attributeValue));
      if (val) seen.add(val.toLocaleUpperCase("tr-TR"));
    });
    const pushSize = (raw) => {
      const value = clean(raw);
      if (!value) return;
      const key = value.toLocaleUpperCase("tr-TR");
      if (seen.has(key)) return;
      seen.add(key);
      out.variants.push({
        barcode: "",
        stockCode: "",
        productCode: "",
        value,
        attributeName: "Beden",
        attributeId: 338,
        attributeValueId: "",
        salePrice: ""
      });
    };
    const takeSizes = (val) => {
      if (val == null || val === "") return;
      if (Array.isArray(val)) {
        val.forEach(takeSizes);
        return;
      }
      if (typeof val === "object") {
        takeSizes(val.value || val.size || val.name || val.attributeValue || val.beautifiedValue);
        return;
      }
      String(val).split(",").forEach((part) => pushSize(part));
    };
    const findProductGroup = (obj, depth) => {
      if (!obj || typeof obj !== "object" || depth > 8) return null;
      const typeVal = String(obj["@type"] || obj.type || "");
      if (/ProductGroup/i.test(typeVal)) return obj;
      if (Array.isArray(obj["@graph"])) {
        for (let g = 0; g < obj["@graph"].length; g += 1) {
          const found = findProductGroup(obj["@graph"][g], depth + 1);
          if (found) return found;
        }
      }
      return null;
    };
    const parseFromProductGroup = (pg) => {
      if (!pg || typeof pg !== "object") return;
      takeSizes(pg.size);
      const list = Array.isArray(pg.hasVariant) ? pg.hasVariant : [];
      list.forEach((v) => {
        if (v && typeof v === "object") takeSizes(v.size);
      });
    };
    const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (let i = 0; i < ldScripts.length; i += 1) {
      try {
        const pg = findProductGroup(JSON.parse(ldScripts[i].textContent || ""), 0);
        if (pg) {
          parseFromProductGroup(pg);
          break;
        }
      } catch (e) {}
    }
    if (!seen.size && Array.isArray(stateList)) {
      for (let i = 0; i < stateList.length; i += 1) {
        const pg = findProductGroup(stateList[i], 0);
        if (pg) {
          parseFromProductGroup(pg);
          break;
        }
      }
    }
    try {
      document.querySelectorAll("button.size-box").forEach((btn) => {
        takeSizes(String(btn.textContent || "").replace(/\s+/g, " ").trim());
      });
    } catch (e) {}
  };
  const normalizeGender = (raw) => {
    if (raw == null || raw === "") return "";
    if (typeof raw === "object") {
      const named = normalizeGender(
        raw.name || raw.genderName || raw.value || raw.title || raw.code || raw.webGenderName
      );
      if (named) return named;
      return normalizeGender(raw.id != null ? raw.id : raw.webGenderId);
    }
    const s = String(raw).trim();
    if (!s) return "";
    if (/^\d+$/.test(s)) {
      return ({ "1": "Kadın / Kız", "2": "Erkek", "3": "Unisex" })[s] || "";
    }
    const k = s.toLocaleLowerCase("tr-TR");
    if (["female", "woman", "women", "kadın", "kadin", "bayan", "kız", "kiz", "girl", "girls", "kadın / kız", "kadin / kiz"].includes(k)) return "Kadın / Kız";
    if (["male", "man", "men", "erkek"].includes(k)) return "Erkek";
    if (["unisex", "uniseks"].includes(k)) return "Unisex";
    if (["kids", "kid", "child", "children", "çocuk", "cocuk"].includes(k)) return "Çocuk";
    return "";
  };
  const mapFashionAgeGroup = (name) => {
    const n = clean(name);
    if (!n) return "";
    const k = n.toLocaleLowerCase("tr-TR");
    if (k === "çocuk" || k === "cocuk") return "Çocuk";
    if (k === "anne & bebek & çocuk" || k === "anne & bebek & cocuk" || k === "anne & bebek") return "Çocuk";
    if (k === "kadın" || k === "kadin" || k === "erkek") return "Yetişkin";
    return "";
  };
  const mapFashionAgeGroupFromHref = (href) => {
    const s = String(href || "").toLocaleLowerCase("tr-TR");
    if (!s) return "";
    if (/anne-bebek/.test(s) || /\/cocuk(?:-x-g\d+)?(?:\/|$|\?)/.test(s)) return "Çocuk";
    if (/\/kadin(?:-x-g\d+)?(?:\/|$|\?)/.test(s) || /\/erkek(?:-x-g\d+)?(?:\/|$|\?)/.test(s)) return "Yetişkin";
    return "";
  };
  const mapGenderFromBreadcrumbName = (name) => {
    const n = clean(name);
    if (!n) return "";
    const k = n.toLocaleLowerCase("tr-TR");
    if (k === "erkek") return "Erkek";
    if (k === "kadın" || k === "kadin") return "Kadın / Kız";
    if (k === "çocuk" || k === "cocuk") return "Çocuk";
    if (/anne\s*&\s*bebek/i.test(n)) return "Çocuk";
    return "";
  };
  const mapGenderFromBreadcrumbHref = (href) => {
    const s = String(href || "").toLocaleLowerCase("tr-TR");
    if (!s) return "";
    if (/anne-bebek/.test(s) || /\/cocuk(?:-x-g\d+)?(?:\/|$|\?)/.test(s)) return "Çocuk";
    if (/\/erkek(?:-x-g\d+)?(?:\/|$|\?)/.test(s)) return "Erkek";
    if (/\/kadin(?:-x-g\d+)?(?:\/|$|\?)/.test(s)) return "Kadın / Kız";
    return "";
  };
  const pickGenderFromBreadcrumb = (items) => {
    const preferred = items.find((c) => Number(c.position) === 2) || items[1] || items[0];
    const candidates = preferred ? [preferred].concat(items) : items;
    for (let i = 0; i < candidates.length; i += 1) {
      const mapped = mapGenderFromBreadcrumbName(candidates[i].name)
        || mapGenderFromBreadcrumbHref(candidates[i].href);
      if (mapped) return mapped;
    }
    return "";
  };
  const setGender = (raw) => {
    if (out.gender) return;
    const g = normalizeGender(raw);
    if (g) out.gender = g;
  };
  const pickGenderFromProduct = (product) => {
    if (!product || typeof product !== "object") return;
    setGender(product.gender);
    setGender(product.genderName);
    setGender(product.webGender);
    setGender(product.webGenderName);
    setGender(product.webGenderId);
    setGender(product.suggestedGender);
    if (product.audience && typeof product.audience === "object") {
      setGender(product.audience.suggestedGender || product.audience.gender);
    }
  };
  const setIfEmpty = (key, val) => {
    const s = clean(val);
    if (s && (out[key] === "" || out[key] == null)) out[key] = s;
  };
  const setIdIfEmpty = (key, val) => {
    if (out[key] !== "") return;
    if (val == null || val === "") return;
    const n = Number(val);
    if (Number.isFinite(n) && n >= 1) {
      out[key] = n;
      return;
    }
    const s = clean(val);
    if (s) out[key] = s;
  };
  const setPriceIfEmpty = (key, val) => {
    if (out[key] !== "") return;
    if (typeof val === "number" && Number.isFinite(val) && val > 0) {
      out[key] = val;
      return;
    }
    if (val && typeof val === "object") {
      if (typeof val.value === "number" && val.value > 0) {
        out[key] = val.value;
        return;
      }
      val = val.text || val.formattedValue || val.value;
    }
    const raw = clean(val).replace(/[^\d,.-]/g, "");
    if (!raw) return;
    const lastComma = raw.lastIndexOf(",");
    const lastDot = raw.lastIndexOf(".");
    let num = NaN;
    if (lastComma >= 0 && lastDot >= 0) {
      num = lastComma > lastDot
        ? parseFloat(raw.replace(/\./g, "").replace(",", "."))
        : parseFloat(raw.replace(/,/g, ""));
    } else if (lastComma >= 0) {
      num = parseFloat(raw.replace(",", "."));
    } else {
      num = parseFloat(raw);
    }
    if (Number.isFinite(num) && num > 0) out[key] = num;
  };
  const readPricesFromDom = () => {
    const saleEl = document.querySelector(".new-price, .campaign-price-wrapper .new-price");
    const listEl = document.querySelector(".old-price, .campaign-price-wrapper .old-price");
    setPriceIfEmpty("salePrice", saleEl && saleEl.textContent);
    setPriceIfEmpty("listPrice", listEl && listEl.textContent);
  };
  const applyBrandAndCategoryFromPageSource = (source) => {
    if (!source) return;
    if (!out.brandId) {
      let m = source.match(/"brand"\s*:\s*\{[^}]*"id"\s*:\s*(\d+)[^}]*"name"\s*:\s*"([^"]+)"/);
      if (!m) {
        const m2 = source.match(/"brand"\s*:\s*\{[^}]*"name"\s*:\s*"([^"]+)"[^}]*"id"\s*:\s*(\d+)/);
        if (m2) m = [m2[0], m2[2], m2[1]];
      }
      if (m) {
        setIdIfEmpty("brandId", m[1]);
        setIfEmpty("brand", m[2]);
      }
    }
    const currentId = String(out.productContentId || contentIdFromUrl() || "").trim();
    let m = null;
    if (/^\d+$/.test(currentId)) {
      m = source.match(new RegExp(
        '"id"\\s*:\\s*' + currentId
        + '[\\s\\S]{0,5000}?"category"\\s*:\\s*\\{[^}]*?"id"\\s*:\\s*(\\d+)[^}]*?"name"\\s*:\\s*"([^"]+)"'
      ));
      if (!m) {
        const reverse = source.match(new RegExp(
          '"id"\\s*:\\s*' + currentId
          + '[\\s\\S]{0,5000}?"category"\\s*:\\s*\\{[^}]*?"name"\\s*:\\s*"([^"]+)"[^}]*?"id"\\s*:\\s*(\\d+)'
        ));
        if (reverse) m = [reverse[0], reverse[2], reverse[1]];
      }
    }
    if (!m) {
      m = source.match(/"category"\s*:\s*\{[^}]*?"id"\s*:\s*(\d+)[^}]*?"name"\s*:\s*"([^"]+)"/);
      if (!m) {
        const reverse = source.match(/"category"\s*:\s*\{[^}]*?"name"\s*:\s*"([^"]+)"[^}]*?"id"\s*:\s*(\d+)/);
        if (reverse) m = [reverse[0], reverse[2], reverse[1]];
      }
    }
    if (m) {
      const categoryId = Number(m[1]);
      out.pimCategoryId = Number.isFinite(categoryId) ? categoryId : clean(m[1]);
      out.categoryName = clean(m[2]);
    }
  };
  const applyPricesFromPageSource = (source) => {
    if (!source) return;
    if (!out.salePrice) {
      let m = source.match(/"discountedPrice"\s*:\s*\{\s*"value"\s*:\s*(\d+(?:\.\d+)?)/);
      if (!m) m = source.match(/"discountedPrice"\s*:\s*\{\s*"text"\s*:\s*"([^"]+)"/);
      if (!m) m = source.match(/"tyPlusCouponApplicablePrice"\s*:\s*\{\s*"value"\s*:\s*(\d+(?:\.\d+)?)/);
      if (m) setPriceIfEmpty("salePrice", m[1]);
    }
    if (!out.listPrice) {
      let m = source.match(/"sellingPrice"\s*:\s*\{\s*"value"\s*:\s*(\d+(?:\.\d+)?)/);
      if (!m) m = source.match(/"originalPrice"\s*:\s*\{\s*"value"\s*:\s*(\d+(?:\.\d+)?)/);
      if (!m) m = source.match(/"sellingPrice"\s*:\s*\{\s*"text"\s*:\s*"([^"]+)"/);
      if (m) setPriceIfEmpty("listPrice", m[1]);
    }
  };
  const considerBarcode = (val) => {
    const normalized = normalizeBarcode(val);
    if (!normalized) return;
    if (!out.stockCode) out.stockCode = normalized;
    if (!out.barcode && isPlausibleBarcode(normalized)) out.barcode = normalized;
  };
  const htmlToText = (html) => {
    const s = clean(html);
    if (!s || !/<[a-z][\s\S]*>/i.test(s)) return s;
    try {
      const el = document.createElement("div");
      el.innerHTML = s;
      return clean(el.textContent || el.innerText || "");
    } catch (e) {
      return s.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
    }
  };
  const isTrendyolSeoDescription = (text) => {
    const s = String(text || "");
    return /yorumlar(?:ı|i)n[ıi]\s*inceleyin/i.test(s)
      || /trendyol[''\u2019]a\s+özel/i.test(s)
      || /n11[''\u2019]e\s+özel/i.test(s)
      || /indirimli\s+fiyat(?:a|la)\s+sat[ıi]n\s+al[ıi]n/i.test(s);
  };
  const sanitizeTrendyolSeoDescription = (text) => {
    let s = clean(text);
    if (!s || !isTrendyolSeoDescription(s)) return s;
    return s.replace(/Trendyol[''\u2019]a/gi, "n11'e");
  };
  const normalizeDescriptionText = (text) => sanitizeTrendyolSeoDescription(text);
  const readDescriptionFromReactComponentData = () => {
    const seeds = Array.from(document.querySelectorAll(
      "p.product-description-content, .content-description-container, [data-fragment*='product'], [data-testid*='product-info']"
    )).slice(0, 8);
    for (let s = 0; s < seeds.length; s += 1) {
      const el = seeds[s];
      const fiberKey = Object.keys(el).find((k) => (
        k.startsWith("__reactFiber") || k.startsWith("__reactInternalInstance")
      ));
      if (!fiberKey) continue;
      let cur = el[fiberKey];
      for (let i = 0; i < 45 && cur; i += 1) {
        const props = cur.memoizedProps;
        const list = props && (
          (props.componentData && props.componentData.descriptions)
          || props.descriptions
        );
        if (Array.isArray(list) && list.length) {
          const paras = list
            .filter((item) => item && Number(item.priority) === 0 && item.text)
            .map((item) => clean(String(item.text)
              .replace(/\[page="[^"]*"\][\s\S]*?\[\/page\]/g, " ")
              .replace(/\[[^\]]*\]/g, " ")))
            .filter((text) => text && text.length > 15 && !isTrendyolSeoDescription(text));
          if (paras.length) return normalizeDescriptionText(paras.join(" "));
        }
        cur = cur.return;
      }
    }
    return "";
  };
  const readDescriptionFromHeadingSection = () => {
    const headings = Array.from(document.querySelectorAll("h2, h3, h4"));
    for (let i = 0; i < headings.length; i += 1) {
      const heading = headings[i];
      if (!/^ürün açıklaması$/i.test(clean(heading.textContent))) continue;
      const section = heading.closest('[class*="product-content"], [class*="description"], section, article, div');
      if (section) {
        let text = normalizeDescriptionText(section.innerText || section.textContent || "");
        text = text.replace(/^ürün açıklaması\s*/i, "").trim();
        if (text.length > 20) return text;
      }
      let el = heading.nextElementSibling;
      while (el && /^(H2|H3|H4)$/i.test(el.tagName)) el = el.nextElementSibling;
      if (el) {
        const text = normalizeDescriptionText(el.innerText || el.textContent || "");
        if (text.length > 20) return text;
      }
    }
    return "";
  };
  const readDescriptionFromDom = () => {
    const containers = Array.from(document.querySelectorAll(".content-description-container"));
    for (let i = 0; i < containers.length; i += 1) {
      const container = containers[i];
      const titleEl = container.querySelector(".product-description-title");
      const title = clean(titleEl && titleEl.textContent);
      if (!/^ürün açıklaması$/i.test(title)) continue;
      const paras = Array.from(container.querySelectorAll("p.product-description-content"))
        .map((p) => clean(p.textContent))
        .filter(Boolean);
      if (paras.length) return normalizeDescriptionText(paras.join(" "));
      let text = normalizeDescriptionText(container.innerText || container.textContent || "");
      text = text.replace(/^ürün açıklaması\s*/i, "").trim();
      if (text.length > 20) return text;
    }
    const selectors = [
      "#rich-content-wrapper",
      "#product-content-wrapper",
      '[id*="product-content-wrapper"]',
      ".content-description-main-container",
      ".content-description-wrapper",
      ".content-description-container"
    ];
    for (let i = 0; i < selectors.length; i += 1) {
      const el = document.querySelector(selectors[i]);
      if (!el) continue;
      let text = normalizeDescriptionText(el.innerText || el.textContent || "");
      text = text.replace(/^ürün açıklaması\s*/i, "").trim();
      if (text.length > 20) return text;
    }
    return readDescriptionFromHeadingSection();
  };
  const clickProductInfoTab = () => {
    const candidates = Array.from(document.querySelectorAll(
      "button, [role='tab'], [role='button'], a, li, span"
    ));
    for (let i = 0; i < candidates.length; i += 1) {
      const t = clean(candidates[i].textContent);
      if (!t || t.length > 32) continue;
      if (/^ürün bilgileri$/i.test(t)) {
        try { candidates[i].click(); return true; } catch (e) {}
      }
    }
    return false;
  };
  const clickDescriptionTab = () => {
    const candidates = Array.from(document.querySelectorAll(
      "button, [role='tab'], [role='button'], a, li, span, div"
    ));
    for (let i = 0; i < candidates.length; i += 1) {
      const t = clean(candidates[i].textContent);
      if (!t || t.length > 48) continue;
      if (/^ürün açıklaması$/i.test(t) || /^product description$/i.test(t)) {
        try { candidates[i].click(); return true; } catch (e) {}
      }
    }
    const tabRoots = document.querySelectorAll(
      ".product-info-tabs button, .product-info-tabs a, [class*='product-info'] button, [class*='info-tab'] button, [data-testid*='tab']"
    );
    for (let i = 0; i < tabRoots.length; i += 1) {
      const t = clean(tabRoots[i].textContent);
      if (/ürün açıklaması|product description/i.test(t)) {
        try { tabRoots[i].click(); return true; } catch (e) {}
      }
    }
    return false;
  };
  const scrollPageForLazyBlocks = async () => {
    const ratios = [0.2, 0.4, 0.6, 0.8, 1, 0.7];
    for (let i = 0; i < ratios.length; i += 1) {
      try {
        const height = Math.max(
          document.body ? document.body.scrollHeight : 0,
          document.documentElement ? document.documentElement.scrollHeight : 0
        );
        window.scrollTo(0, Math.floor(height * ratios[i]));
        window.dispatchEvent(new Event("scroll"));
      } catch (e) {}
      await new Promise((r) => setTimeout(r, 160));
    }
    const targets = document.querySelectorAll(
      ".product-description-title, .content-description-container, .product-description-content, [class*='product-content-tabs'], [data-testid*='product-info']"
    );
    for (let i = 0; i < Math.min(targets.length, 8); i += 1) {
      try {
        targets[i].scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" });
      } catch (e) {
        try { targets[i].scrollIntoView(false); } catch (e2) {}
      }
    }
  };
  const scrollToDescriptionSection = () => {
    const richContent = document.querySelector(
      "#rich-content-wrapper, .content-description-container, .content-description-main-container, .product-description-content, .product-description-title"
    );
    if (richContent) {
      try {
        richContent.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" });
        return;
      } catch (e) {
        try { richContent.scrollIntoView(false); } catch (e2) {}
      }
    }
    try {
      const height = Math.max(
        document.body ? document.body.scrollHeight : 0,
        document.documentElement ? document.documentElement.scrollHeight : 0
      );
      window.scrollTo(0, Math.floor(height * 0.85));
      window.dispatchEvent(new Event("scroll"));
    } catch (e) {}
  };
  const waitForDescriptionFromDom = async (timeoutMs = 12000) => {
    const textNow = readDescriptionFromDom();
    if (textNow) return textNow;
    let resolved = "";
    const tryRead = () => {
      const text = readDescriptionFromDom();
      if (text) resolved = text;
      return text;
    };
    const observer = new MutationObserver(() => {
      tryRead();
    });
    try {
      observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    } catch (e) {}
    const deadline = Date.now() + timeoutMs;
    clickProductInfoTab();
    clickDescriptionTab();
    await scrollPageForLazyBlocks();
    while (Date.now() < deadline && !resolved) {
      tryRead();
      if (resolved) break;
      clickProductInfoTab();
      clickDescriptionTab();
      scrollToDescriptionSection();
      await new Promise((r) => setTimeout(r, 250));
    }
    observer.disconnect();
    return resolved || readDescriptionFromDom();
  };
  const expandProductInfoSections = () => {
    clickProductInfoTab();
    clickDescriptionTab();
    const nodes = Array.from(document.querySelectorAll("button, [role='button'], a, span, div"));
    for (let i = 0; i < nodes.length; i += 1) {
      const t = clean(nodes[i].textContent);
      if (!t || t.length > 48) continue;
      if (/tüm özellikler|ürün bilgileri|ürün özellikleri|ürün açıklaması|product description|^özellikler$/i.test(t)) {
        try { nodes[i].click(); } catch (e) {}
      }
    }
    scrollToDescriptionSection();
  };
  const readBarcodeFromLabeledDom = () => {
    const isBarkodLabel = (s) => /^barkod(?:\s*no)?$/i.test(clean(s).replace(/[:：]/g, "").trim());
    const els = document.querySelectorAll("span, div, p, dt, dd, th, td, li, strong, label, h3, h4, b");
    for (let i = 0; i < els.length; i += 1) {
      const el = els[i];
      const t = clean(el.textContent);
      if (!t || t.length > 24 || !isBarkodLabel(t)) continue;
      const next = el.nextElementSibling;
      if (next) {
        const v = clean(next.textContent);
        const normalized = normalizeBarcode(v);
        if (isPlausibleBarcode(normalized)) return normalized;
      }
      const parent = el.parentElement;
      if (!parent) continue;
      const children = Array.from(parent.children);
      const idx = children.indexOf(el);
      if (idx >= 0 && children[idx + 1]) {
        const v = normalizeBarcode(children[idx + 1].textContent);
        if (isPlausibleBarcode(v)) return v;
      }
      const pm = clean(parent.textContent).match(/barkod(?:\s*no)?\s*[:：]?\s*([0-9A-Za-z\-_]{8,20})/i);
      if (pm && isPlausibleBarcode(pm[1])) return normalizeBarcode(pm[1]);
    }
    const attrRows = document.querySelectorAll(
      ".detail-attr-item, .attribute-item, .detail-attr-container li, [class*='attribute'], li, tr"
    );
    for (let i = 0; i < attrRows.length; i += 1) {
      const row = attrRows[i];
      const name = clean(
        row.querySelector(".attr-key, .attr-name, .name, dt, [class*='name'], [class*='label'], [class*='key']")?.textContent || ""
      );
      const value = clean(
        row.querySelector(".attr-value, .value, dd, [class*='value']")?.textContent || ""
      );
      if (isBarkodLabel(name) && isPlausibleBarcode(value)) return normalizeBarcode(value);
      const m = clean(row.textContent).match(/^barkod(?:\s*no)?\s*[:：]?\s*([0-9A-Za-z\-_]{8,20})$/i);
      if (m && isPlausibleBarcode(m[1])) return normalizeBarcode(m[1]);
    }
    const body = document.body ? String(document.body.innerText || "") : "";
    const bm = body.match(/Barkod(?:\s*No)?\s*[:：]?\s*(\d{8,14})/i);
    return bm && isPlausibleBarcode(bm[1]) ? normalizeBarcode(bm[1]) : "";
  };
  const collectPageSource = () => {
    const parts = [];
    const scripts = document.querySelectorAll("script");
    for (let i = 0; i < scripts.length; i += 1) {
      parts.push(scripts[i].textContent || "");
    }
    try { parts.push(document.documentElement ? document.documentElement.innerHTML : ""); } catch (e) {}
    return parts.join("\n");
  };
  const variantSet = new Set();
  const addVariant = (v) => {
    if (!v || typeof v !== "object") return;
    const stockCode = normalizeBarcode(
      v.barcode || v.barkod || v.gtin || v.ean || v.listingBarcode || v.merchantBarcode
    );
    if (!stockCode || variantSet.has(stockCode)) return;
    variantSet.add(stockCode);
    const barcode = isPlausibleBarcode(stockCode) ? stockCode : "";
    const value = clean(v.value || v.size || v.attributeValue || v.beautifiedValue || v.name);
    const itemNumber = v.itemNumber != null ? v.itemNumber : v.productCode;
    const n = Number(itemNumber);
    const salePrice = typeof v.price === "number" && Number.isFinite(v.price) && v.price > 0
      ? v.price
      : "";
    out.variants.push({
      barcode,
      stockCode,
      productCode: Number.isFinite(n) && String(itemNumber).trim() !== "" ? n : (itemNumber || ""),
      value,
      attributeName: clean(v.attributeName || v.attributeType || v.type) || "Beden",
      attributeId: v.attributeId != null ? v.attributeId : 338,
      attributeValueId: v.attributeValueId != null ? v.attributeValueId : "",
      salePrice
    });
  };
  const parseArrayByBrackets = (source, fromIdx) => {
    const start = source.indexOf("[", fromIdx);
    if (start < 0) return null;
    let depth = 0;
    let inStr = false;
    let esc = false;
    for (let i = start; i < source.length; i += 1) {
      const ch = source[i];
      if (inStr) {
        if (esc) { esc = false; continue; }
        if (ch === "\\") { esc = true; continue; }
        if (ch === '"') inStr = false;
        continue;
      }
      if (ch === '"') { inStr = true; continue; }
      if (ch === "[") depth += 1;
      else if (ch === "]") {
        depth -= 1;
        if (depth === 0) {
          try { return JSON.parse(source.slice(start, i + 1)); } catch (e) { return null; }
        }
      }
    }
    return null;
  };
  const extractVariantsWithRegex = (text) => {
    if (!text || text.indexOf("itemNumber") < 0 || text.indexOf("barcode") < 0) return;
    const patterns = [
      /"itemNumber"\s*:\s*(\d{5,})\s*,\s*"value"\s*:\s*"((?:\\.|[^"\\])*)"\s*,\s*"inStock"\s*:\s*(?:true|false)\s*,\s*"currency"\s*:\s*"[^"]*"\s*,\s*"barcode"\s*:\s*"([^"]+)"/g,
      /"itemNumber"\s*:\s*(\d{5,})\s*,\s*"value"\s*:\s*"((?:\\.|[^"\\])*)"[\s\S]{0,500}?"barcode"\s*:\s*"([^"]+)"/g,
      /"barcode"\s*:\s*"([^"]+)"[\s\S]{0,500}?"itemNumber"\s*:\s*(\d{5,})\s*,\s*"value"\s*:\s*"((?:\\.|[^"\\])*)"/g
    ];
    patterns.forEach((re, idx) => {
      let m;
      while ((m = re.exec(text)) !== null) {
        if (idx === 2) {
          addVariant({ barcode: m[1], itemNumber: Number(m[2]), value: m[3] });
        } else {
          addVariant({ itemNumber: Number(m[1]), value: m[2], barcode: m[3] });
        }
      }
    });
  };
  const harvestVariantsFromScripts = () => {
    const scripts = document.querySelectorAll("script");
    for (let si = 0; si < scripts.length; si += 1) {
      const text = scripts[si].textContent || "";
      if (!text || text.indexOf("allVariants") < 0) continue;
      if (out.productContentId) {
        const scopeRe = new RegExp(
          '"contentId"\\s*:\\s*' + out.productContentId + '[\\s\\S]{0,80000}?"allVariants"\\s*:\\s*',
          "i"
        );
        const scopeMatch = scopeRe.exec(text);
        if (scopeMatch) {
          const arr = parseArrayByBrackets(text, scopeMatch.index + scopeMatch[0].length - 1);
          if (Array.isArray(arr)) arr.forEach(addVariant);
        }
      }
      let idx = 0;
      while (idx >= 0) {
        idx = text.indexOf('"allVariants"', idx);
        if (idx < 0) break;
        const arr = parseArrayByBrackets(text, idx);
        if (Array.isArray(arr) && arr.length) arr.forEach(addVariant);
        idx += 1;
      }
      extractVariantsWithRegex(text);
    }
  };
  const harvestVariantsFromStates = (states) => {
    if (!Array.isArray(states)) return;
    const stack = [];
    states.forEach((state) => { if (state) stack.push(state); });
    let guard = 0;
    while (stack.length && guard < 4000) {
      guard += 1;
      const cur = stack.pop();
      if (!cur || typeof cur !== "object") continue;
      if (Array.isArray(cur.allVariants) && cur.allVariants.length) {
        const pid = cur.contentId != null ? cur.contentId : cur.productContentId;
        if (pid == null || !out.productContentId || Number(pid) === Number(out.productContentId)) {
          cur.allVariants.forEach(addVariant);
        }
      }
      if (cur.product) collectProductVariants(cur.product);
      const vals = Object.values(cur);
      for (let i = 0; i < vals.length; i += 1) {
        if (vals[i] && typeof vals[i] === "object") stack.push(vals[i]);
      }
    }
  };
  const collectProductVariants = (product) => {
    if (!product || typeof product !== "object") return;
    const pid = product.contentId != null ? product.contentId : product.productContentId;
    if (pid != null && out.productContentId && Number(pid) !== Number(out.productContentId)) return;
    const lists = [
      product.allVariants,
      product.variants,
      product.merchantListing && product.merchantListing.allVariants,
      product.merchantListing && product.merchantListing.variants,
      product.merchant && product.merchant.allVariants,
      product.merchant && product.merchant.variants,
      product.listing && product.listing.allVariants,
      product.listing && product.listing.variants
    ];
    lists.forEach((list) => {
      if (!Array.isArray(list)) return;
      list.forEach((v) => {
        if (v && typeof v === "object" && (v.barcode || v.itemNumber || v.value)) addVariant(v);
      });
    });
  };
  const applyVariantIdentifiers = (product) => {
    if (!product || typeof product !== "object") return;
    const pid = product.contentId != null ? product.contentId : product.productContentId;
    if (pid != null && out.productContentId && Number(pid) !== Number(out.productContentId)) return;
    if (product.merchant && product.merchant.itemNumber != null && String(product.merchant.itemNumber).trim() !== "") {
      const n = Number(product.merchant.itemNumber);
      out.productCode = Number.isFinite(n) ? n : clean(product.merchant.itemNumber);
    }
    if (product.itemNumber != null && String(product.itemNumber).trim() !== "") {
      const n = Number(product.itemNumber);
      out.productCode = Number.isFinite(n) ? n : clean(product.itemNumber);
    }
    const variantSources = []
      .concat(Array.isArray(product.allVariants) ? product.allVariants : [])
      .concat(Array.isArray(product.variants) ? product.variants : []);
    collectProductVariants(product);
    const wantedCode = out.productCode != null && out.productCode !== "" ? String(out.productCode) : "";
    const wantedContentId = out.productContentId != null && out.productContentId !== ""
      ? String(out.productContentId)
      : "";
    let chosen = null;
    for (let i = 0; i < variantSources.length; i += 1) {
      const v = variantSources[i];
      if (!v || typeof v !== "object") continue;
      const bc = v.barcode || v.barkod || v.gtin || v.ean;
      const variantIds = [v.itemNumber, v.contentId, v.productContentId, v.id]
        .filter((x) => x != null && x !== "")
        .map(String);
      const matchesWanted = (wantedCode && variantIds.includes(wantedCode))
        || (wantedContentId && variantIds.includes(wantedContentId));
      if (matchesWanted && isPlausibleBarcode(bc, wantedContentId || wantedCode)) {
        chosen = v;
        break;
      }
      if (!chosen && isPlausibleBarcode(bc)) chosen = v;
    }
    if (chosen) {
      const bc = chosen.barcode || chosen.barkod || chosen.gtin || chosen.ean;
      if (isPlausibleBarcode(bc, wantedContentId || wantedCode)) out.barcode = normalizeBarcode(bc);
      if (chosen.itemNumber != null && (out.productCode === "" || out.productCode == null)) {
        const n = Number(chosen.itemNumber);
        out.productCode = Number.isFinite(n) ? n : chosen.itemNumber;
      }
    }
    if (!out.barcode && isPlausibleBarcode(product.barcode, wantedContentId || wantedCode)) {
      out.barcode = normalizeBarcode(product.barcode);
    }
    if (product.brand && typeof product.brand === "object") {
      setIdIfEmpty("brandId", product.brand.id || product.brand.brandId);
      setIfEmpty("brand", product.brand.name);
    } else if (typeof product.brand === "string") {
      setIfEmpty("brand", product.brand);
    }
    setIdIfEmpty("brandId", product.brandId);
    if (product.category && typeof product.category === "object") {
      setIdIfEmpty("pimCategoryId", product.category.id || product.category.categoryId);
      setIfEmpty("categoryName", product.category.name);
    }
    if (product.categoryInfo && typeof product.categoryInfo === "object") {
      setIdIfEmpty("pimCategoryId", product.categoryInfo.id || product.categoryInfo.categoryId);
      setIfEmpty("categoryName", product.categoryInfo.name);
    }
    setIdIfEmpty("pimCategoryId", product.pimCategoryId || product.categoryId);
    setIfEmpty("categoryName", product.categoryName);
    setProductMainId(product.productGroupID);
    setProductMainId(product.productMainId);
    setProductMainId(product.modelCode);
    setProductMainId(product.mainProductCode);
    setProductMainId(product.itemNumber);
    if (product.merchant && product.merchant.itemNumber != null) setProductMainId(product.merchant.itemNumber);
    if (typeof product.productCode === "number" || /^\d{6,}$/.test(String(product.productCode || ""))) {
      setProductMainId(product.productCode);
    }
    pickGenderFromProduct(product);
    const attrLists = []
      .concat(Array.isArray(product.attributes) ? product.attributes : [])
      .concat(Array.isArray(product.starredAttributes) ? product.starredAttributes : [])
      .concat(Array.isArray(product.slicerAttributes) ? product.slicerAttributes : [])
      .concat(Array.isArray(product.varianterAttributes) ? product.varianterAttributes : []);
    attrLists.forEach(addAttribute);
    if (chosen && chosen.value) {
      addAttribute({
        attributeName: chosen.attributeName || chosen.attributeType || chosen.type || "Beden",
        attributeValue: chosen.value,
        attributeId: chosen.attributeId,
        attributeValueId: chosen.attributeValueId
      });
    } else if (chosen && isBarcodeLike(chosen.barcode || chosen.barkod)) {
      addVariant(chosen);
    }
  };
  const harvestBarcodeMapFromPageSource = (source) => {
    const map = Object.create(null);
    if (!source) return map;
    const patterns = [
      /"(?:contentId|productContentId|itemNumber)"\s*:\s*"?(\d{6,})"?[\s\S]{0,4000}?"barcode"\s*:\s*"(\d{8,14})"/g,
      /"barcode"\s*:\s*"(\d{8,14})"[\s\S]{0,4000}?"(?:contentId|productContentId|itemNumber)"\s*:\s*"?(\d{6,})"?/g,
      /"id"\s*:\s*"?(\d{8,})"?[\s\S]{0,6000}?"barcode"\s*:\s*"(\d{8,14})"/g,
      /"barcode"\s*:\s*"(\d{8,14})"[\s\S]{0,6000}?"id"\s*:\s*"?(\d{8,})"?/g
    ];
    let m;
    for (let p = 0; p < patterns.length; p += 1) {
      const re = patterns[p];
      while ((m = re.exec(source))) {
        const id = p % 2 === 0 ? m[1] : m[2];
        const bc = clean(p % 2 === 0 ? m[2] : m[1]);
        if (!isPlausibleBarcode(bc, id)) continue;
        if (!map[id]) map[id] = bc;
      }
    }
    return map;
  };
  const lookupBarcodeForProductId = (source, productId) => {
    if (!source || productId == null || productId === "") return "";
    const wanted = String(productId);
    const patterns = [
      new RegExp('"id"\\s*:\\s*' + wanted + '[\\s\\S]{0,6000}?"barcode"\\s*:\\s*"?([0-9]{8,14})"?'),
      new RegExp('"id"\\s*:\\s*"' + wanted + '"[\\s\\S]{0,6000}?"barcode"\\s*:\\s*"?([0-9]{8,14})"?'),
      new RegExp('"contentId"\\s*:\\s*' + wanted + '[\\s\\S]{0,6000}?"barcode"\\s*:\\s*"?([0-9]{8,14})"?'),
      new RegExp('"productContentId"\\s*:\\s*' + wanted + '[\\s\\S]{0,6000}?"barcode"\\s*:\\s*"?([0-9]{8,14})"?'),
      new RegExp('"itemNumber"\\s*:\\s*' + wanted + '[\\s\\S]{0,800}?"barcode"\\s*:\\s*"?([0-9]{8,14})"?'),
      new RegExp('"barcode"\\s*:\\s*"?([0-9]{8,14})"?' + '[\\s\\S]{0,6000}?"id"\\s*:\\s*' + wanted),
      new RegExp('"barcode"\\s*:\\s*"?([0-9]{8,14})"?' + '[\\s\\S]{0,6000}?"id"\\s*:\\s*"' + wanted + '"')
    ];
    for (let i = 0; i < patterns.length; i += 1) {
      const match = source.match(patterns[i]);
      if (match && isPlausibleBarcode(match[1], wanted)) return normalizeBarcode(match[1]);
    }
    const barcodeMap = harvestBarcodeMapFromPageSource(source);
    return barcodeMap[wanted] || "";
  };
  const applyBarcodeFromPageSource = (source) => {
    if (!source || out.barcode) return;
    const wantedIds = [];
    if (out.productContentId != null && out.productContentId !== "") wantedIds.push(String(out.productContentId));
    if (out.productCode != null && out.productCode !== "") wantedIds.push(String(out.productCode));
    for (let w = 0; w < wantedIds.length; w += 1) {
      const wanted = wantedIds[w];
      const patterns = [
        new RegExp('"itemNumber"\\s*:\\s*' + wanted + '[\\s\\S]{0,500}?"barcode"\\s*:\\s*"?([A-Za-z0-9\\-_]{8,24})"?'),
        new RegExp('"barcode"\\s*:\\s*"?([A-Za-z0-9\\-_]{8,24})"?' + '[\\s\\S]{0,500}?"itemNumber"\\s*:\\s*' + wanted),
        new RegExp('"id"\\s*:\\s*' + wanted + '[\\s\\S]{0,4000}?"barcode"\\s*:\\s*"?([A-Za-z0-9\\-_]{8,24})"?'),
        new RegExp('"id"\\s*:\\s*"' + wanted + '"[\\s\\S]{0,4000}?"barcode"\\s*:\\s*"?([A-Za-z0-9\\-_]{8,24})"?'),
        new RegExp('"contentId"\\s*:\\s*' + wanted + '[\\s\\S]{0,4000}?"barcode"\\s*:\\s*"?([A-Za-z0-9\\-_]{8,24})"?'),
        new RegExp('"productContentId"\\s*:\\s*' + wanted + '[\\s\\S]{0,4000}?"barcode"\\s*:\\s*"?([A-Za-z0-9\\-_]{8,24})"?'),
        new RegExp('"barcode"\\s*:\\s*"?([A-Za-z0-9\\-_]{8,24})"?' + '[\\s\\S]{0,4000}?"id"\\s*:\\s*' + wanted),
        new RegExp('"barcode"\\s*:\\s*"?([A-Za-z0-9\\-_]{8,24})"?' + '[\\s\\S]{0,4000}?"id"\\s*:\\s*"' + wanted + '"')
      ];
      for (let pi = 0; pi < patterns.length; pi += 1) {
        const match = source.match(patterns[pi]);
        if (match && isPlausibleBarcode(match[1], wanted)) {
          out.barcode = normalizeBarcode(match[1]);
          return;
        }
      }
    }
    const barcodeMap = harvestBarcodeMapFromPageSource(source);
    const currentId = out.productContentId != null && out.productContentId !== ""
      ? String(out.productContentId)
      : "";
    if (currentId && barcodeMap[currentId]) {
      out.barcode = barcodeMap[currentId];
      return;
    }
    const pair = source.match(/"itemNumber"\s*:\s*(\d{5,})[\s\S]{0,500}?"barcode"\s*:\s*"?([A-Za-z0-9\-_]{8,24})"?/);
    if (pair && isPlausibleBarcode(pair[2], pair[1])) {
      out.barcode = normalizeBarcode(pair[2]);
      if (out.productCode === "" || out.productCode == null) out.productCode = Number(pair[1]);
      return;
    }
    const pair2 = source.match(/"barcode"\s*:\s*"?([A-Za-z0-9\-_]{8,24})"[\s\S]{0,500}?"itemNumber"\s*:\s*(\d{5,})/);
    if (pair2 && isPlausibleBarcode(pair2[1], pair2[2])) {
      out.barcode = normalizeBarcode(pair2[1]);
      if (out.productCode === "" || out.productCode == null) out.productCode = Number(pair2[2]);
      return;
    }
    const fromBlock = source.match(/"allVariants"\s*:\s*\[[\s\S]{0,8000}?"barcode"\s*:\s*"?([A-Za-z0-9\-_]{8,24})"?/);
    if (fromBlock && isPlausibleBarcode(fromBlock[1])) {
      out.barcode = normalizeBarcode(fromBlock[1]);
    }
  };
  const finalizeBarcode = (source) => {
    const currentId = out.productContentId != null && out.productContentId !== ""
      ? String(out.productContentId)
      : "";
    if (out.barcode) out.barcode = normalizeBarcode(out.barcode);
    if (out.barcode && !out.stockCode) out.stockCode = out.barcode;
    if (out.barcode && !isPlausibleBarcode(out.barcode, currentId)) out.barcode = "";
    if (!out.barcode) applyBarcodeFromPageSource(source);
    const barcodeMap = harvestBarcodeMapFromPageSource(source);
    if (!out.barcode && currentId && barcodeMap[currentId]) out.barcode = barcodeMap[currentId];
    const authoritativeBarcode = currentId ? lookupBarcodeForProductId(source, currentId) : "";
    if (authoritativeBarcode) out.barcode = authoritativeBarcode;
    if (out.barcode && currentId) barcodeMap[currentId] = out.barcode;
    out.barcodeMap = barcodeMap;
    if (Array.isArray(out.skuVariants) && out.skuVariants.length) {
      out.skuVariants.forEach((sku) => {
        if (!sku || typeof sku !== "object") return;
        const id = sku.productContentId != null ? String(sku.productContentId) : "";
        if (!id) return;
        const mapped = barcodeMap[id] || lookupBarcodeForProductId(source, id);
        if (mapped) sku.barcode = mapped;
        else if (!sku.barcode && id === currentId && out.barcode) sku.barcode = out.barcode;
      });
    }
    if (!out.barcode && out.variants.length) {
      const variantBarcode = out.variants.find((v) => {
        if (!v || !isPlausibleBarcode(v.barcode)) return false;
        const variantIds = [v.itemNumber, v.contentId, v.productContentId, v.id, v.productCode]
          .filter((x) => x != null && x !== "")
          .map(String);
        return !currentId || variantIds.includes(currentId);
      })?.barcode;
      if (variantBarcode) out.barcode = normalizeBarcode(variantBarcode);
    }
  };
  expandProductInfoSections();
  await new Promise((r) => setTimeout(r, 500));

  try {
    const initialState = window.__PRODUCT_DETAIL_APP_INITIAL_STATE__ || window.__PRODUCT_DETAIL_APP_INITIAL_STATE_V2__;
    const initialProduct = initialState && initialState.product;
    if (initialProduct) collectProductVariants(initialProduct);
    applyVariantIdentifiers(initialProduct);
  } catch (e) {}
  try {
    applyVariantIdentifiers(window.__PRELOADED_STATE__ && window.__PRELOADED_STATE__.product);
  } catch (e) {}

  const states = collectStates();
  states.forEach((state) => {
    applyVariantIdentifiers(state && state.product);
    applyVariantIdentifiers(state && state.productDetail && state.productDetail.product);
    walk(state, (obj) => {
      if (obj && obj.suggestedGender) setGender(obj.suggestedGender);
      if (obj && obj.audience && typeof obj.audience === "object") {
        setGender(obj.audience.suggestedGender || obj.audience.gender);
      }
      const looksLikeProduct = Boolean(
        obj && (obj.contentId || obj.productContentId || (obj.name && (obj.images || obj.brand || obj.productCode)))
      );
      if (looksLikeProduct) {
        setIfEmpty("title", obj.name || obj.title);
        if (typeof obj.brand === "string") setIfEmpty("brand", obj.brand);
        setIfEmpty("brand", obj.brandName || (obj.brand && obj.brand.name) || (obj.brandInfo && obj.brandInfo.name));
        setIdIfEmpty("brandId", obj.brandId || (obj.brand && obj.brand.id) || (obj.brandInfo && obj.brandInfo.id));
        setIfEmpty("categoryName", obj.categoryName || (obj.category && obj.category.name));
        setIdIfEmpty("pimCategoryId", obj.pimCategoryId || obj.categoryId || (obj.category && obj.category.id));
        setIdIfEmpty("productContentId", obj.contentId || obj.productContentId || obj.id);
        if (obj.itemNumber != null && String(obj.itemNumber).trim() !== "") {
          const n = Number(obj.itemNumber);
          out.productCode = Number.isFinite(n) ? n : clean(obj.itemNumber);
        } else {
          setIdIfEmpty("productCode", obj.productCode);
        }
        setProductMainId(obj.productGroupID);
        setProductMainId(obj.productMainId);
        setProductMainId(obj.modelCode);
        setProductMainId(obj.mainProductCode);
        setProductMainId(obj.itemNumber);
        const productIds = [obj.id, obj.contentId, obj.productContentId, obj.itemNumber]
          .filter((x) => x != null && x !== "")
          .map(String);
        const wantedProductId = out.productContentId != null && out.productContentId !== ""
          ? String(out.productContentId)
          : String(contentIdFromUrl() || "");
        if (wantedProductId && productIds.includes(wantedProductId)) {
          considerBarcode(obj.barcode || obj.barkod || obj.gtin || obj.ean);
          if (Array.isArray(obj.images)) {
            obj.images.forEach((img) => {
              const url = toOrgZoom(typeof img === "string" ? img : (img && (img.url || img.imageUrl || img.contentUrl)));
              if (url && isProductImageUrl(url) && !out.images.some((item) => item && item.url === url)) {
                out.images.push({ url });
              }
            });
          }
          const winner = obj.merchantListing && obj.merchantListing.winnerVariant;
          if (winner && winner.barcode) considerBarcode(winner.barcode);
          if (winner && winner.itemNumber != null && String(winner.itemNumber).trim() !== "") {
            const n = Number(winner.itemNumber);
            if (Number.isFinite(n)) out.productCode = n;
          }
        }
        setIfEmpty("origin", obj.origin);
        pickGenderFromProduct(obj);
        setPriceIfEmpty("salePrice", obj.salePrice || obj.discountedPrice || obj.sellingPrice || (obj.price && (obj.price.discountedPrice || obj.price.sellingPrice)));
        setPriceIfEmpty("listPrice", obj.listPrice || obj.originalPrice || (obj.price && (obj.price.originalPrice || obj.price.sellingPrice)));
      }
      if (obj && typeof obj === "object") {
        if (obj.discountedPrice || obj.sellingPrice || obj.originalPrice || obj.tyPlusCouponApplicablePrice) {
          setPriceIfEmpty("salePrice", obj.discountedPrice || obj.salePrice || obj.tyPlusCouponApplicablePrice);
          setPriceIfEmpty("listPrice", obj.sellingPrice || obj.originalPrice || obj.listPrice);
        }
        if (obj.price && typeof obj.price === "object") {
          setPriceIfEmpty("salePrice", obj.price.discountedPrice || obj.price.sellingPrice || obj.price.tyPlusCouponApplicablePrice);
          setPriceIfEmpty("listPrice", obj.price.originalPrice || obj.price.sellingPrice);
        }
        const wantedContentId = out.productContentId != null && out.productContentId !== ""
          ? String(out.productContentId)
          : "";
        const objIds = [obj.id, obj.contentId, obj.productContentId]
          .filter((x) => x != null && x !== "")
          .map(String);
        if (!out.barcode && wantedContentId && objIds.includes(wantedContentId) && isPlausibleBarcode(obj.barcode, wantedContentId)) {
          out.barcode = normalizeBarcode(obj.barcode);
        }
        if (!out.merchantId) {
          const merchantId = obj.merchantId
            || (obj.merchant && (obj.merchant.id || obj.merchant.merchantId))
            || (obj.winningMerchant && (obj.winningMerchant.id || obj.winningMerchant.merchantId));
          if (merchantId != null && String(merchantId).trim() !== "") {
            out.merchantId = String(merchantId).trim();
          }
        }
        if (obj.brand && typeof obj.brand === "object") {
          setIdIfEmpty("brandId", obj.brand.id || obj.brand.brandId);
          setIfEmpty("brand", obj.brand.name);
        }
        if (obj.brandInfo && typeof obj.brandInfo === "object") {
          setIdIfEmpty("brandId", obj.brandInfo.id || obj.brandInfo.brandId);
          setIfEmpty("brand", obj.brandInfo.name);
        }
        if (obj.category && typeof obj.category === "object") {
          setIdIfEmpty("pimCategoryId", obj.category.id || obj.category.categoryId);
          setIfEmpty("categoryName", obj.category.name);
        }
        if (obj.categoryInfo && typeof obj.categoryInfo === "object") {
          setIdIfEmpty("pimCategoryId", obj.categoryInfo.id || obj.categoryInfo.categoryId);
          setIfEmpty("categoryName", obj.categoryInfo.name);
        }
      }
      const walkIds = [obj.id, obj.contentId, obj.productContentId, obj.itemNumber]
        .filter((x) => x != null && x !== "")
        .map(String);
      const wantedWalkId = out.productContentId != null && out.productContentId !== ""
        ? String(out.productContentId)
        : String(contentIdFromUrl() || "");
      if (wantedWalkId && walkIds.includes(wantedWalkId)) {
        considerBarcode(obj.barcode || obj.barkod || obj.gtin || obj.ean);
      }
      if (obj.itemNumber != null && String(obj.itemNumber).trim() !== "") {
        const n = Number(obj.itemNumber);
        out.productCode = Number.isFinite(n) ? n : clean(obj.itemNumber);
      }
      if (Array.isArray(obj.attributes)) obj.attributes.forEach(addAttribute);
      else if (obj.attributes && typeof obj.attributes === "object") {
        Object.values(obj.attributes).forEach((val) => {
          if (Array.isArray(val)) val.forEach(addAttribute);
          else addAttribute(val);
        });
      }
    });
  });

  const attrRows = document.querySelectorAll(
    ".detail-attr-item, .attribute-item, li[class*='attr'], [class*='product-attribute'], [data-testid*='attribute']"
  );
  attrRows.forEach((row) => {
    const name = clean(
      row.querySelector(".attr-key, .attr-name, .name, dt, [class*='name']")?.textContent ||
      row.childNodes[0]?.textContent
    );
    const value = clean(
      row.querySelector(".attr-value, .value, dd, [class*='value']")?.textContent ||
      (row.children[1] && row.children[1].textContent)
    );
    if (name && value) {
      addAttribute({ attributeName: name, attributeValue: value });
      if (/barkod/i.test(name)) considerBarcode(value);
      if (/model\s*kodu|ana\s*ürün\s*kodu|ürün\s*kodu|urun\s*kodu/i.test(name)) setProductMainId(value);
    }
  });

  const infoItems = document.querySelectorAll("li, tr, div");
  for (let i = 0; i < infoItems.length && (!out.barcode || !out.productMainId); i += 1) {
    const text = clean(infoItems[i].textContent);
    const m = text.match(/^(Barkod(?:\s*No)?|Ürün Kodu|Urun Kodu|Stok Kodu|Model Kodu|Ana Ürün Kodu)\s*[:：\-]?\s*(.+)$/i);
    if (!m) continue;
    if (/barkod/i.test(m[1])) considerBarcode(m[2]);
    else setProductMainId(m[2]);
  }

  if (!out.title) {
    setIfEmpty("title", document.querySelector("h1")?.textContent);
  }
  if (!out.brand) {
    setIfEmpty("brand", document.querySelector(".product-brand-name, .pr-new-br a, .pr-new-br span")?.textContent);
  }
  if (!out.productContentId) {
    const m = String(location.pathname || "").match(/-p-(\d+)/i);
    if (m) out.productContentId = Number(m[1]);
  }
  if (out.productCode === "" || out.productCode == null) {
    const scripts = document.querySelectorAll("script");
    for (let i = 0; i < scripts.length; i += 1) {
      const text = scripts[i].textContent || "";
      if (!text || text.indexOf("itemNumber") < 0) continue;
      const match = text.match(/"itemNumber"\s*:\s*"?(\d{5,})"?/);
      if (match && match[1]) {
        out.productCode = Number(match[1]);
        break;
      }
    }
  }
  readPricesFromDom();
  const labeledBarcode = readBarcodeFromLabeledDom();
  if (labeledBarcode) out.barcode = normalizeBarcode(labeledBarcode);
  const pageSource = collectPageSource();
  applyBrandAndCategoryFromPageSource(pageSource);
  applyPricesFromPageSource(pageSource);
  if (!out.listPrice && out.salePrice) out.listPrice = out.salePrice;
  if (!out.salePrice && out.listPrice) out.salePrice = out.listPrice;
  if (!out.barcode) applyBarcodeFromPageSource(pageSource);
  try {
    const winState = window.__PRODUCT_DETAIL_APP_INITIAL_STATE__ || window.__PRODUCT_DETAIL_APP_INITIAL_STATE_V2__;
    if (winState && winState.product) collectProductVariants(winState.product);
  } catch (e) {}
  harvestVariantsFromStates(states);
  harvestVariantsFromScripts();
  if (!out.variants.length && pageSource) extractVariantsWithRegex(pageSource);
  if (!out.barcode && out.variants.length) out.barcode = out.variants[0].barcode;
  if ((out.productCode === "" || out.productCode == null) && out.variants.length && out.variants[0].productCode) {
    out.productCode = out.variants[0].productCode;
  }
  if (!out.productMainId && pageSource) {
    const mainIdMatch = pageSource.match(/"productGroupID"\s*:\s*"(\d{6,14})"/)
      || pageSource.match(/"productMainId"\s*:\s*"([^"]+)"/i)
      || pageSource.match(/"modelCode"\s*:\s*"([^"]+)"/i)
      || pageSource.match(/"mainProductCode"\s*:\s*"([^"]+)"/i)
      || pageSource.match(/"mpn"\s*:\s*"([^"]+)"/i);
    if (mainIdMatch) setProductMainId(mainIdMatch[1]);
    if (!out.productMainId) {
      const labelMatch = pageSource.match(/Ürün\s*Kodu\s*[:：]?\s*(\d{6,12})/i)
        || pageSource.match(/Model\s*Kodu\s*[:：]?\s*([A-Za-z0-9][A-Za-z0-9\-_]{2,39})/i)
        || pageSource.match(/Ana\s*Ürün\s*Kodu\s*[:：]?\s*([A-Za-z0-9][A-Za-z0-9\-_]{2,39})/i);
      if (labelMatch) setProductMainId(labelMatch[1]);
    }
  }
  if (!out.gender && pageSource) {
    const genderMatch = pageSource.match(/"suggestedGender"\s*:\s*"([^"]+)"/i)
      || pageSource.match(/"webGenderName"\s*:\s*"([^"]+)"/i)
      || pageSource.match(/"gender"\s*:\s*"(FEMALE|MALE|UNISEX|Kadın|Erkek)"/i)
      || pageSource.match(/"webGender"\s*:\s*"(FEMALE|MALE|UNISEX|Kadın|Erkek)"/i);
    if (genderMatch) setGender(genderMatch[1]);
    if (!out.gender) {
      const idMatch = pageSource.match(/"gender"\s*:\s*\{\s*"id"\s*:\s*(\d+)/);
      if (idMatch) setGender(idMatch[1]);
    }
  }
  const breadcrumbItems = [];
  const takeBreadcrumb = (obj) => {
    if (!obj || typeof obj !== "object") return;
    if (Array.isArray(obj)) {
      obj.forEach(takeBreadcrumb);
      return;
    }
    if (Array.isArray(obj["@graph"])) obj["@graph"].forEach(takeBreadcrumb);
    if (Array.isArray(obj.itemListElement)) obj.itemListElement.forEach(takeBreadcrumb);
    const typeVal = String(obj["@type"] || obj.type || "");
    const nested = obj.item && typeof obj.item === "object" ? obj.item : null;
    const isListItem = /ListItem/i.test(typeVal) || (obj.position != null && nested && (nested.name || obj.name));
    if (isListItem) {
      const name = (nested && nested.name) || obj.name;
      const href = (nested && (nested["@id"] || nested.url || nested.id)) || obj["@id"] || obj.url || "";
      if (name || href) {
        breadcrumbItems.push({
          position: Number(obj.position) || 0,
          name: clean(name),
          href: String(href || "")
        });
      }
    }
  };
  states.forEach(takeBreadcrumb);
  document.querySelectorAll('script[type="application/ld+json"]').forEach((el) => {
    try { takeBreadcrumb(JSON.parse(el.textContent || "")); } catch (e) {}
  });
  if (!breadcrumbItems.length) {
    Array.from(document.querySelectorAll(
      ".product-detail-breadcrumb a, .breadcrumb a, nav[class*='breadcrumb'] a"
    )).forEach((a, idx) => {
      breadcrumbItems.push({
        position: idx + 1,
        name: clean(a.textContent),
        href: a.href || ""
      });
    });
  }
  breadcrumbItems.sort((a, b) => (a.position || 0) - (b.position || 0));
  if (!out.categoryName && breadcrumbItems.length) {
    let crumbs = breadcrumbItems.map((c) => clean(c.name)).filter(Boolean);
    if (crumbs[0] && /^trendyol$/i.test(crumbs[0])) crumbs = crumbs.slice(1);
    if (crumbs.length >= 2) setIfEmpty("categoryName", crumbs[crumbs.length - 2]);
    else if (crumbs.length === 1) setIfEmpty("categoryName", crumbs[0]);
  }
  if (!out.categoryName && pageSource) {
    const hierarchyMatch = pageSource.match(/"hierarchy"\s*:\s*"([^"]+)"/);
    if (hierarchyMatch) {
      const parts = hierarchyMatch[1]
        .replace(/\\u002F/gi, "/")
        .split("/")
        .map((part) => clean(part))
        .filter(Boolean);
      if (parts.length) setIfEmpty("categoryName", parts[parts.length - 1]);
    }
  }
  const pickFashionAgeGroup = (items) => {
    const preferred = items.find((c) => Number(c.position) === 2) || items[1] || items[0];
    const candidates = preferred ? [preferred].concat(items) : items;
    for (let i = 0; i < candidates.length; i += 1) {
      const mapped = mapFashionAgeGroup(candidates[i].name) || mapFashionAgeGroupFromHref(candidates[i].href);
      if (mapped) return mapped;
    }
    return "";
  };
  const breadcrumbRoot = breadcrumbItems.find((c) => Number(c.position) === 2)
    || breadcrumbItems[1]
    || breadcrumbItems[0];
  if (breadcrumbRoot && breadcrumbRoot.name) out.breadcrumbName = clean(breadcrumbRoot.name);
  const breadcrumbGender = pickGenderFromBreadcrumb(breadcrumbItems);
  if (breadcrumbGender) out.gender = breadcrumbGender;
  out.fashionAgeGroup = pickFashionAgeGroup(breadcrumbItems);
  out.isFashion = Boolean(out.fashionAgeGroup);
  if (!out.productMainId && out.productCode) out.productMainId = String(out.productCode);
  applyTrendyolProductGroupId(states, pageSource);
  try {
    Object.getOwnPropertyNames(window).forEach((key) => {
      if (!/__envoy_.*PROPS$/.test(key)) return;
      const product = window[key] && window[key].product;
      if (!product || typeof product !== "object") return;
      const pid = product.id || product.contentId || product.productContentId;
      const currentId = String(out.productContentId || contentIdFromUrl() || "");
      if (pid != null && currentId && String(pid) !== currentId) return;
      const imgs = Array.isArray(product.images) ? product.images : [];
      imgs.forEach((img) => {
        const url = toOrgZoom(typeof img === "string" ? img : (img && (img.url || img.imageUrl)));
        if (url && isProductImageUrl(url) && !out.images.some((item) => item && item.url === url)) {
          out.images.push({ url });
        }
      });
      const winner = product.merchantListing && product.merchantListing.winnerVariant;
      if (winner && winner.barcode) considerBarcode(winner.barcode);
      if (winner && winner.itemNumber != null && String(winner.itemNumber).trim() !== "") {
        const n = Number(winner.itemNumber);
        if (Number.isFinite(n)) out.productCode = n;
      }
    });
  } catch (e) {}
  applySchemaProductGroupImages(states);
  applySchemaProductGroupAttributes(states);
  applySchemaProductGroupSkuVariants(states);
  harvestSizeVariantsFromSchemaAndDom(states);
  finalizeBarcode(pageSource);
  applyBrandAndCategoryFromPageSource(pageSource);
  if (!out.merchantId && pageSource) {
    const merchantPatterns = [
      /"merchantId"\s*:\s*(\d{3,})/,
      /"merchant"\s*:\s*\{[\s\S]{0,600}?"id"\s*:\s*(\d{3,})/,
      /"winningMerchant"\s*:\s*\{[\s\S]{0,600}?"id"\s*:\s*(\d{3,})/
    ];
    for (let i = 0; i < merchantPatterns.length; i += 1) {
      const m = pageSource.match(merchantPatterns[i]);
      if (m && m[1]) {
        out.merchantId = m[1];
        break;
      }
    }
  }
  if (!out.description || isTrendyolSeoDescription(out.description)) {
    const fromReact = readDescriptionFromReactComponentData();
    if (fromReact) out.description = fromReact;
  }
  if (!out.description || isTrendyolSeoDescription(out.description)) {
    const fromDom = await waitForDescriptionFromDom(10000);
    if (fromDom) out.description = fromDom;
  }
  if (!out.description || isTrendyolSeoDescription(out.description)) {
    const fromReactLate = readDescriptionFromReactComponentData();
    if (fromReactLate) out.description = fromReactLate;
  }
  if (!out.barcode) {
    const lateSource = collectPageSource();
    finalizeBarcode(lateSource);
    if (!out.barcode) {
      const fromLabel = readBarcodeFromLabeledDom();
      if (fromLabel) out.barcode = fromLabel;
    }
  }
  if (!out.stockCode) out.stockCode = out.barcode || "";
  return out;
}

async function primeTrendyolPdpBeforeExtract() {
  const clean = (v) => String(v == null ? "" : v).replace(/\s+/g, " ").trim();
  const dismissConsent = () => {
    const nodes = Array.from(document.querySelectorAll("button, [role='button'], a"));
    for (let i = 0; i < nodes.length; i += 1) {
      const t = clean(nodes[i].textContent);
      if (!t || t.length > 48) continue;
      // "tamam" çok geniş — form submit / ID validasyon alert'ine basıyor.
      if (/tümünü reddet|reject all|accept all|kabul et ve kapat|çerezleri kabul/i.test(t)) {
        try { nodes[i].click(); return true; } catch (e) {}
      }
    }
    return false;
  };
  const clickProductInfoTab = () => {
    const nodes = Array.from(document.querySelectorAll(
      "button, [role='tab'], [role='button'], a, li, span"
    ));
    for (let i = 0; i < nodes.length; i += 1) {
      const t = clean(nodes[i].textContent);
      if (/^ürün bilgileri$/i.test(t)) {
        try { nodes[i].click(); return true; } catch (e) {}
      }
    }
    return false;
  };
  const clickDescriptionTab = () => {
    const nodes = Array.from(document.querySelectorAll(
      "button, [role='tab'], [role='button'], a, li, span"
    ));
    for (let i = 0; i < nodes.length; i += 1) {
      const t = clean(nodes[i].textContent);
      if (/^ürün açıklaması$/i.test(t) || /^product description$/i.test(t)) {
        try { nodes[i].click(); return true; } catch (e) {}
      }
    }
    return false;
  };
  const scrollPageForLazyBlocks = async () => {
    const ratios = [0.2, 0.45, 0.7, 0.9, 1, 0.65];
    for (let i = 0; i < ratios.length; i += 1) {
      try {
        const h = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, 0);
        window.scrollTo(0, Math.floor(h * ratios[i]));
        window.dispatchEvent(new Event("scroll"));
      } catch (e) {}
      await new Promise((r) => setTimeout(r, 160));
    }
  };
  const scrollToDescriptionAnchor = () => {
    const richContent = document.querySelector(
      "#rich-content-wrapper, .content-description-container, .content-description-main-container, .product-description-content, .product-description-title"
    );
    if (richContent) {
      try {
        richContent.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" });
      } catch (e) {
        try { richContent.scrollIntoView(false); } catch (e2) {}
      }
      return true;
    }
    const h = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, 0);
    try {
      window.scrollTo(0, Math.floor(h * 0.85));
      window.dispatchEvent(new Event("scroll"));
    } catch (e) {}
    return false;
  };
  const hasDescription = () => {
    const paras = document.querySelectorAll(".content-description-container p.product-description-content");
    for (let i = 0; i < paras.length; i += 1) {
      if (clean(paras[i].textContent).length > 15) return true;
    }
    const richContent = document.querySelector("#rich-content-wrapper");
    if (richContent && clean(richContent.innerText || richContent.textContent).length > 20) return true;
    const fallback = document.querySelector(
      "#product-content-wrapper, [id*='product-content-wrapper'], .content-description-main-container, .content-description-container, .product-description-content"
    );
    return Boolean(fallback && clean(fallback.innerText || fallback.textContent).length > 20);
  };
  dismissConsent();
  clickProductInfoTab();
  clickDescriptionTab();
  await scrollPageForLazyBlocks();
  scrollToDescriptionAnchor();
  const deadline = Date.now() + 9000;
  while (Date.now() < deadline) {
    if (hasDescription()) break;
    clickProductInfoTab();
    clickDescriptionTab();
    scrollToDescriptionAnchor();
    await new Promise((r) => setTimeout(r, 250));
  }
}

function nudgeTrendyolPdpOnce() {
  const clean = (v) => String(v == null ? "" : v).replace(/\s+/g, " ").trim();
  const clickByText = (re, maxLen) => {
    const nodes = Array.from(document.querySelectorAll("button, [role='tab'], [role='button'], a, li, span"));
    for (let i = 0; i < nodes.length; i += 1) {
      const t = clean(nodes[i].textContent);
      if (!t || (maxLen && t.length > maxLen)) continue;
      if (re.test(t)) {
        try { nodes[i].click(); return true; } catch (e) {}
      }
    }
    return false;
  };
  Array.from(document.querySelectorAll("button, [role='button'], a")).some((node) => {
    const t = clean(node.textContent);
    if (!t || t.length > 48) return false;
    // "tamam" / genel "kabul et" tıklama — Trendyol form validasyon alert'i açıyor.
    if (/tümünü reddet|reject all|accept all|kabul et ve kapat|çerezleri kabul/i.test(t)) {
      try { node.click(); return true; } catch (e) {}
    }
    return false;
  });
  clickByText(/^ürün bilgileri$/i, 32);
  clickByText(/^ürün açıklaması$|^product description$/i, 48);
  // Tek geçiş: alta inip açıklama bloğuna odaklan (her poll'da tekrarlanma).
  try {
    const height = Math.max(
      document.body ? document.body.scrollHeight : 0,
      document.documentElement ? document.documentElement.scrollHeight : 0
    );
    window.scrollTo(0, Math.floor(height * 0.75));
    window.dispatchEvent(new Event("scroll"));
  } catch (e) {}
  const richContent = document.querySelector(
    "#rich-content-wrapper, .content-description-container, .content-description-main-container, .product-description-content, .product-description-title"
  );
  if (richContent) {
    try { richContent.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" }); } catch (e) {
      try { richContent.scrollIntoView(false); } catch (e2) {}
    }
  }
}

function trendyolPdpHasDescription() {
  const clean = (v) => String(v == null ? "" : v).replace(/\s+/g, " ").trim();
  const paras = document.querySelectorAll(".content-description-container p.product-description-content");
  for (let i = 0; i < paras.length; i += 1) {
    if (clean(paras[i].textContent).length > 15) return true;
  }
  const richContent = document.querySelector("#rich-content-wrapper");
  if (richContent && clean(richContent.innerText || richContent.textContent).length > 20) return true;
  const fallback = document.querySelector(
    "#product-content-wrapper, [id*='product-content-wrapper'], .content-description-main-container, .content-description-container, .product-description-content"
  );
  return Boolean(fallback && clean(fallback.innerText || fallback.textContent).length > 20);
}

function unfreezeTrendyolHiddenTab() {
  try {
    Object.defineProperty(document, "hidden", { configurable: true, get: () => false });
    Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "visible" });
    Object.defineProperty(document, "webkitHidden", { configurable: true, get: () => false });
    document.hasFocus = () => true;
  } catch (e) {}
  try {
    const nativeSetTimeout = window.setTimeout.bind(window);
    window.requestAnimationFrame = (cb) => nativeSetTimeout(() => {
      try { cb(typeof performance !== "undefined" ? performance.now() : Date.now()); } catch (err) {}
    }, 16);
    window.cancelAnimationFrame = (id) => window.clearTimeout(id);
  } catch (e) {}
  try {
    window.IntersectionObserver = class {
      constructor(callback) { this._cb = callback; }
      observe(target) {
        if (typeof this._cb !== "function") return;
        const rect = target && target.getBoundingClientRect
          ? target.getBoundingClientRect()
          : { top: 0, left: 0, bottom: 1, right: 1, width: 1, height: 1 };
        try {
          this._cb([{
            target,
            isIntersecting: true,
            intersectionRatio: 1,
            boundingClientRect: rect,
            intersectionRect: rect,
            rootBounds: null,
            time: Date.now()
          }], this);
        } catch (err) {}
      }
      unobserve() {}
      disconnect() {}
      takeRecords() { return []; }
    };
  } catch (e) {}
  try {
    document.dispatchEvent(new Event("visibilitychange"));
    window.dispatchEvent(new Event("focus"));
    window.dispatchEvent(new Event("pageshow"));
  } catch (e) {}
}

const trendyolVariantDetailCache = new Map();

const extractTrendyolProductGroupFromHtml = (html) => {
  const source = String(html || "");
  const scripts = Array.from(
    source.matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi),
    (match) => match[1]
  );
  const findProductGroup = (obj, depth = 0) => {
    if (!obj || typeof obj !== "object" || depth > 10) return null;
    const typeValues = Array.isArray(obj["@type"])
      ? obj["@type"].map(String)
      : [String(obj["@type"] || obj.type || "")];
    if (typeValues.some((type) => /^Product(?:Group)?$/i.test(type.trim()))) return obj;
    if (Array.isArray(obj)) {
      for (let i = 0; i < obj.length; i += 1) {
        const found = findProductGroup(obj[i], depth + 1);
        if (found) return found;
      }
    }
    if (Array.isArray(obj["@graph"])) {
      for (let i = 0; i < obj["@graph"].length; i += 1) {
        const found = findProductGroup(obj["@graph"][i], depth + 1);
        if (found) return found;
      }
    }
    return null;
  };
  for (let i = 0; i < scripts.length; i += 1) {
    try {
      const productGroup = findProductGroup(JSON.parse(scripts[i]));
      if (productGroup) return productGroup;
    } catch (e) {}
  }
  return null;
};

const extractTrendyolProductGroupImagesFromHtml = (html) => {
  const productGroup = extractTrendyolProductGroupFromHtml(html);
  const image = productGroup && productGroup.image;
  let values = [];
  if (typeof image === "string") values = [image];
  else if (Array.isArray(image)) values = image;
  else if (image && typeof image === "object") {
    values = Array.isArray(image.contentUrl)
      ? image.contentUrl
      : [image.contentUrl || image.url];
  }
  return Array.from(new Set(
    values
      .map((value) => String(value || "").trim())
      .filter((value) => /^https?:\/\//i.test(value))
  ));
};

const extractTrendyolBarcodeFromHtml = (html, productId) => {
  const source = String(html || "");
  const id = String(productId || "").trim();
  if (!source || !/^\d{6,}$/.test(id)) return "";
  const patterns = [
    new RegExp('"id"\\s*:\\s*' + id + '\\s*,[\\s\\S]{0,2500}?"barcode"\\s*:\\s*"(\\d{8,14})"'),
    new RegExp('"id"\\s*:\\s*"' + id + '"\\s*,[\\s\\S]{0,2500}?"barcode"\\s*:\\s*"(\\d{8,14})"'),
    new RegExp('"contentId"\\s*:\\s*' + id + '\\s*,[\\s\\S]{0,2500}?"barcode"\\s*:\\s*"(\\d{8,14})"'),
    new RegExp('"productContentId"\\s*:\\s*' + id + '\\s*,[\\s\\S]{0,2500}?"barcode"\\s*:\\s*"(\\d{8,14})"'),
    new RegExp('"barcode"\\s*:\\s*"(\\d{8,14})"[\\s\\S]{0,1200}?"(?:id|contentId|productContentId)"\\s*:\\s*"?' + id + '"?')
  ];
  for (let i = 0; i < patterns.length; i += 1) {
    const match = source.match(patterns[i]);
    if (match && /^(?:\d{8}|\d{12,14})$/.test(match[1])) return match[1];
  }
  const unique = Array.from(new Set(
    Array.from(source.matchAll(/"barcode"\s*:\s*"(\d{8,14})"/g), (match) => match[1])
      .filter((barcode) => /^(?:\d{8}|\d{12,14})$/.test(barcode))
  ));
  return unique.length === 1 ? unique[0] : "";
};

const extractTrendyolStockCodeFromHtml = (html, productId) => {
  const source = String(html || "");
  const id = String(productId || "").trim();
  if (!source || !/^\d{6,}$/.test(id)) return "";
  const patterns = [
    new RegExp('"(?:id|contentId|productContentId)"\\s*:\\s*"?'
      + id + '"?\\s*,[\\s\\S]{0,2500}?"barcode"\\s*:\\s*"([^"]+)"'),
    new RegExp('"barcode"\\s*:\\s*"([^"]+)"[\\s\\S]{0,1200}?"(?:id|contentId|productContentId)"\\s*:\\s*"?'
      + id + '"?')
  ];
  for (let i = 0; i < patterns.length; i += 1) {
    const match = source.match(patterns[i]);
    if (match && String(match[1]).trim()) return String(match[1]).trim();
  }
  const unique = Array.from(new Set(
    Array.from(source.matchAll(/"barcode"\s*:\s*"([^"]+)"/g), (match) => String(match[1]).trim())
      .filter(Boolean)
  ));
  return unique.length === 1 ? unique[0] : "";
};

const rewriteTrendyolProductUrlForContentId = (productUrl, productId) => {
  const id = String(productId || "").trim();
  let url = String(productUrl || "").trim();
  if (!id) return url;
  if (/-p-\d+/i.test(url)) return url.replace(/-p-\d+/i, `-p-${id}`);
  if (url) return url;
  return `https://www.trendyol.com/urun-p-${id}`;
};

const stripTrendyolHtmlText = (value) => String(value == null ? "" : value)
  .replace(/<script[\s\S]*?<\/script>/gi, " ")
  .replace(/<style[\s\S]*?<\/style>/gi, " ")
  .replace(/<[^>]+>/g, " ")
  .replace(/&nbsp;/gi, " ")
  .replace(/&amp;/gi, "&")
  .replace(/&quot;/gi, "\"")
  .replace(/&#39;/gi, "'")
  .replace(/&lt;/gi, "<")
  .replace(/&gt;/gi, ">")
  .replace(/\s+/g, " ")
  .trim();

const extractTrendyolSimpleDescriptionFromHtml = (html) => {
  const source = String(html || "");
  if (!source) return "";
  const titleIdx = source.search(/product-description-title[^>]*>\s*Ürün\s*Açıklaması/i);
  if (titleIdx < 0) return "";
  const afterTitle = source.slice(titleIdx);
  const ekIdx = afterTitle.search(/product-description-title[^>]*>\s*Ek\s*Bilgiler/i);
  const slice = ekIdx >= 0 ? afterTitle.slice(0, ekIdx) : afterTitle.slice(0, 12000);
  const paras = [];
  const re = /<p\b[^>]*class=["'][^"']*product-description-content[^"']*["'][^>]*>([\s\S]*?)<\/p>/gi;
  let match;
  while ((match = re.exec(slice))) {
    const text = stripTrendyolHtmlText(match[1]);
    if (text) paras.push(text);
  }
  if (paras.length) return paras.join(" ").replace(/\s+/g, " ").trim();
  const containerText = stripTrendyolHtmlText(slice)
    .replace(/^Ürün\s*Açıklaması\s*/i, "")
    .trim();
  return containerText.length > 20 ? containerText : "";
};

const flattenTrendyolSizeValues = (value, acc = []) => {
  if (value == null || value === "") return acc;
  if (Array.isArray(value)) {
    value.forEach((item) => flattenTrendyolSizeValues(item, acc));
    return acc;
  }
  if (typeof value === "object") {
    flattenTrendyolSizeValues(
      value.value || value.size || value.name || value.attributeValue || value.beautifiedValue,
      acc
    );
    return acc;
  }
  String(value).split(",").forEach((part) => {
    const size = String(part || "").replace(/\s+/g, " ").trim();
    if (size) acc.push(size);
  });
  return acc;
};

const extractTrendyolSellerScrapingFromHtml = (html, pageUrl) => {
  const source = String(html || "");
  if (!source) return null;
  const clean = (val) => stripTrendyolHtmlText(val);
  const productGroup = extractTrendyolProductGroupFromHtml(source);
  const out = {
    title: "",
    brand: "",
    brandId: "",
    barcode: "",
    productMainId: "",
    productContentId: "",
    productCode: "",
    categoryName: "",
    pimCategoryId: "",
    description: "",
    origin: "",
    salePrice: "",
    listPrice: "",
    images: [],
    attributes: [],
    gender: "",
    fashionAgeGroup: "",
    isFashion: false,
    variants: [],
    skuVariants: [],
    barcodeMap: {},
    stockCode: "",
    merchantId: "",
    productUrl: String(pageUrl || "").trim()
  };
  const urlMatch = String(pageUrl || "").match(/-p-(\d+)/i)
    || String(pageUrl || "").match(/\/p-(\d+)/i);
  if (urlMatch) out.productContentId = Number(urlMatch[1]);
  if (productGroup) {
    out.title = clean(productGroup.name);
    if (productGroup.brand && typeof productGroup.brand === "object") {
      out.brand = clean(productGroup.brand.name);
    } else if (typeof productGroup.brand === "string") {
      out.brand = clean(productGroup.brand);
    }
    const sku = clean(productGroup.sku);
    if (/^\d{5,}$/.test(sku) && !out.productContentId) out.productContentId = Number(sku);
    const offers = productGroup.offers && typeof productGroup.offers === "object" ? productGroup.offers : {};
    const price = Number(offers.price || offers.lowPrice || "");
    if (Number.isFinite(price) && price > 0) {
      out.salePrice = price;
      out.listPrice = price;
    }
    const attrs = Array.isArray(productGroup.additionalProperty) ? productGroup.additionalProperty : [];
    attrs.forEach((attr) => {
      if (!attr || typeof attr !== "object") return;
      const name = clean(attr.name);
      const value = clean(attr.unitText || attr.value);
      if (!name || !value) return;
      if (!out.attributes.some((item) => item.attributeName === name && item.attributeValue === value)) {
        out.attributes.push({ attributeName: name, attributeValue: value });
      }
      if (!out.origin && /men[sş]ei/i.test(name)) out.origin = value;
    });
    const seenSku = new Set();
    const pushSku = (skuId, color, url, image) => {
      const id = clean(skuId);
      if (!id || !/^\d{5,}$/.test(id) || seenSku.has(id)) return;
      seenSku.add(id);
      const n = Number(id);
      out.skuVariants.push({
        productContentId: Number.isFinite(n) ? n : id,
        color: clean(color),
        productUrl: clean(url),
        image: clean(image)
      });
    };
    const variants = Array.isArray(productGroup.hasVariant) ? productGroup.hasVariant : [];
    variants.forEach((variant) => {
      if (!variant || typeof variant !== "object") return;
      const image = typeof variant.image === "string"
        ? variant.image
        : (variant.image && (variant.image.contentUrl || variant.image.url));
      pushSku(
        variant.sku,
        variant.color,
        (variant.offers && variant.offers.url) || variant.url || variant["@id"],
        image
      );
    });
    if (out.productContentId) {
      pushSku(out.productContentId, productGroup.color, pageUrl, productGroup.image);
    }
    const seenSizes = new Set();
    flattenTrendyolSizeValues(productGroup.size)
      .concat(variants.flatMap((variant) => flattenTrendyolSizeValues(variant && variant.size)))
      .forEach((size) => {
        const key = size.toLocaleUpperCase("tr-TR");
        if (seenSizes.has(key)) return;
        seenSizes.add(key);
        out.variants.push({
          barcode: "",
          stockCode: "",
          productCode: "",
          value: size,
          attributeName: "Beden",
          attributeId: 338,
          attributeValueId: "",
          salePrice: ""
        });
      });
  }
  if (!out.title) {
    const ogTitle = source.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)
      || source.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']/i);
    if (ogTitle) out.title = clean(ogTitle[1]);
  }
  if (!out.brand) {
    const brandMatch = source.match(/"brand"\s*:\s*\{\s*"@type"\s*:\s*"Brand"\s*,\s*"name"\s*:\s*"([^"]+)"/i)
      || source.match(/"brandName"\s*:\s*"([^"]+)"/i);
    if (brandMatch) out.brand = clean(brandMatch[1]);
  }
  const images = extractTrendyolProductGroupImagesFromHtml(source);
  out.images = images.map((url) => ({ url }));
  const merchantMatch = String(pageUrl || "").match(/[?&]merchantId=(\d+)/i)
    || source.match(/"merchantId"\s*:\s*(\d{3,})/);
  if (merchantMatch) out.merchantId = merchantMatch[1];
  const currentId = String(out.productContentId || "").trim();
  out.barcode = extractTrendyolBarcodeFromHtml(source, currentId);
  out.stockCode = extractTrendyolStockCodeFromHtml(source, currentId) || out.barcode;
  const groupIdMatch = source.match(/"productGroupId"\s*:\s*"?(\d{6,14})"?/i)
    || source.match(/"productMainId"\s*:\s*"([^"]+)"/i);
  if (groupIdMatch) out.productMainId = clean(groupIdMatch[1]);
  if (!out.description) {
    out.description = extractTrendyolSimpleDescriptionFromHtml(source);
  }
  if (!out.description) {
    const descMatch = source.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i)
      || source.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i);
    if (descMatch) out.description = clean(descMatch[1]);
    if (productGroup && productGroup.description) {
      const groupDesc = clean(productGroup.description);
      if (groupDesc.length > out.description.length) out.description = groupDesc;
    }
    if (out.description && isTrendyolSeoDescriptionText(out.description)) {
      out.description = "";
    }
  }
  const saleMatch = source.match(/"discountedPrice"\s*:\s*\{\s*"value"\s*:\s*(\d+(?:\.\d+)?)/)
    || source.match(/"sellingPrice"\s*:\s*\{\s*"value"\s*:\s*(\d+(?:\.\d+)?)/);
  const listMatch = source.match(/"originalPrice"\s*:\s*\{\s*"value"\s*:\s*(\d+(?:\.\d+)?)/)
    || source.match(/"sellingPrice"\s*:\s*\{\s*"value"\s*:\s*(\d+(?:\.\d+)?)/);
  if (saleMatch && !out.salePrice) out.salePrice = Number(saleMatch[1]);
  if (listMatch && !out.listPrice) out.listPrice = Number(listMatch[1]);
  if (!out.listPrice && out.salePrice) out.listPrice = out.salePrice;
  if (!out.salePrice && out.listPrice) out.salePrice = out.listPrice;
  if (!out.title && !out.productContentId) return null;
  return out;
};

const fetchTrendyolSellerScrapingHtml = async (productUrl) => {
  let url = String(productUrl || "").trim();
  if (!url || !/^https?:\/\//i.test(url)) return "";
  try {
    const parsed = new URL(url);
    parsed.searchParams.set("filterOverPriceListings", "false");
    url = parsed.toString();
  } catch (e) {}
  const response = await fetch(url, {
    credentials: "include",
    headers: { Accept: "text/html,application/xhtml+xml" }
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.text();
};

const trendyolHtmlContentToText = (html) => {
  let s = String(html == null ? "" : html);
  if (!s) return "";
  s = s.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
  s = s.replace(/\\\//g, "/");
  s = s.replace(/<br\s*\/?>/gi, " ");
  s = s.replace(/<\/(p|div|li|h[1-6]|tr)>/gi, " ");
  s = s.replace(/<[^>]+>/g, " ");
  s = s
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, "\"")
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
  return s.replace(/\s+/g, " ").trim();
};

const fetchTrendyolHtmlContentDescription = async (productId) => {
  const id = String(productId || "").trim();
  if (!/^\d{6,}$/.test(id)) return "";
  try {
    const url = `https://apigw.trendyol.com/discovery-storefront-trproductgw-service/api/html-content/${encodeURIComponent(id)}?channelId=1`;
    const response = await fetch(url, {
      credentials: "include",
      headers: {
        Accept: "application/json",
        "x-channelid": "1",
        "x-storefrontid": "1",
        "x-language": "tr"
      }
    });
    if (!response.ok) return "";
    const data = await response.json();
    const html = data && (
      data.content ||
      (data.result && (data.result.content || data.result.htmlContent || data.result.html)) ||
      data.htmlContent ||
      data.html
    );
    return trendyolHtmlContentToText(html);
  } catch (e) {
    return "";
  }
};

const isTrendyolSeoDescriptionText = (text) => {
  const s = String(text || "");
  return /yorumlar(?:ı|i)n[ıi]\s*inceleyin/i.test(s)
    || /trendyol[''\u2019]a\s+özel/i.test(s)
    || /n11[''\u2019]e\s+özel/i.test(s)
    || /indirimli\s+fiyat(?:a|la)\s+sat[ıi]n\s+al[ıi]n/i.test(s);
};

const hasRealTrendyolSellerDescription = (productOrText) => {
  const text = typeof productOrText === "string"
    ? productOrText
    : String((productOrText && productOrText.description) || "");
  const d = text.replace(/\s+/g, " ").trim();
  return Boolean(d) && !isTrendyolSeoDescriptionText(d);
};

const normalizeTrendyolContentImages = (images) => {
  const list = Array.isArray(images) ? images : [];
  return Array.from(new Set(
    list.map((img) => {
      if (typeof img === "string") return img.split("?")[0];
      if (img && typeof img === "object") {
        return String(img.url || img.imageUrl || img.contentUrl || "").split("?")[0];
      }
      return "";
    }).filter((url) => /^https?:\/\//i.test(url))
  ));
};

const fetchTrendyolProductContentDetails = async (productId) => {
  const id = String(productId || "").trim();
  const details = { barcode: "", stockCode: "", images: [], productCode: "", description: "" };
  if (!/^\d{6,}$/.test(id)) return details;
  try {
    const url = `https://apigw.trendyol.com/discovery-storefront-trproductgw-service/api/product-detail/content?contentId=${encodeURIComponent(id)}&culture=tr-TR`;
    const response = await fetch(url, {
      credentials: "include",
      headers: {
        Accept: "application/json",
        "x-channelid": "1",
        "x-storefrontid": "1",
        "x-language": "tr"
      }
    });
    if (!response.ok) return details;
    const data = await response.json();
    const result = data && (data.result || data);
    if (!result || typeof result !== "object") return details;
    details.images = normalizeTrendyolContentImages(result.images);
    const winner = result.merchantListing && result.merchantListing.winnerVariant;
    const barcode = winner && winner.barcode;
    if (barcode) {
      details.barcode = String(barcode).trim();
      details.stockCode = details.barcode;
    }
    if (winner && winner.itemNumber != null && String(winner.itemNumber).trim() !== "") {
      const n = Number(winner.itemNumber);
      details.productCode = Number.isFinite(n) ? n : String(winner.itemNumber).trim();
    }
  } catch (e) {}
  return details;
};

const applyTrendyolContentDetailsToProduct = (product, details) => {
  if (!product || !details) return product;
  if (details.barcode) product.barcode = details.barcode;
  if (details.stockCode) product.stockCode = details.stockCode;
  if (details.productCode) {
    const currentCode = product.productCode;
    if (currentCode == null || currentCode === "" || String(currentCode) === String(product.productContentId)) {
      product.productCode = details.productCode;
    }
  }
  const incoming = Array.isArray(details.images) ? details.images : [];
  const existing = Array.isArray(product.images) ? product.images : [];
  if (incoming.length > existing.length) {
    product.images = incoming.map((url) => ({ url: typeof url === "string" ? url : (url && url.url) })).filter((item) => item.url);
  }
  if (!product.stockCode) product.stockCode = product.barcode || "";
  return product;
};

const fetchTrendyolVariantDetails = async (productId, productUrl) => {
  const id = String(productId || "").trim();
  if (!/^\d{6,}$/.test(id)) return { barcode: "", stockCode: "", images: [], description: "" };
  const details = { barcode: "", stockCode: "", images: [], description: "", productCode: "" };
  if (trendyolVariantDetailCache.has(id)) {
    const cached = trendyolVariantDetailCache.get(id);
    if (cached && cached.barcode && cached.images && cached.images.length && hasRealTrendyolSellerDescription(cached.description)) {
      return cached;
    }
    if (cached) {
      details.barcode = cached.barcode || "";
      details.stockCode = cached.stockCode || "";
      details.images = Array.isArray(cached.images) ? cached.images.slice() : [];
      details.description = cached.description || "";
      details.productCode = cached.productCode || "";
    }
  }
  try {
    const contentDetails = await fetchTrendyolProductContentDetails(id);
    if (contentDetails.barcode) details.barcode = contentDetails.barcode;
    if (contentDetails.stockCode) details.stockCode = contentDetails.stockCode;
    if (contentDetails.productCode) details.productCode = contentDetails.productCode;
    if (Array.isArray(contentDetails.images) && contentDetails.images.length > details.images.length) {
      details.images = contentDetails.images.slice();
    }
  } catch (e) {}
  let url = rewriteTrendyolProductUrlForContentId(productUrl, id);
  if (!hasRealTrendyolSellerDescription(details.description)) {
    try {
      details.description = await fetchTrendyolHtmlContentDescription(id);
    } catch (e) {}
  }
  if (details.barcode && details.images.length && hasRealTrendyolSellerDescription(details.description)) {
    trendyolVariantDetailCache.set(id, details);
    return details;
  }
  if (!url || !/-p-\d+/i.test(url)) {
    if (details.barcode || details.stockCode || details.images.length || details.description) {
      trendyolVariantDetailCache.set(id, details);
    }
    return details;
  }
  try {
    const parsed = new URL(url);
    parsed.searchParams.set("filterOverPriceListings", "false");
    url = parsed.toString();
    const response = await fetch(url, {
      credentials: "include",
      headers: { Accept: "text/html,application/xhtml+xml" }
    });
    if (!response.ok) {
      if (details.barcode || details.stockCode || details.images.length || details.description) {
        trendyolVariantDetailCache.set(id, details);
      }
      return details;
    }
    const html = await response.text();
    if (!details.barcode) details.barcode = extractTrendyolBarcodeFromHtml(html, id);
    if (!details.stockCode) details.stockCode = extractTrendyolStockCodeFromHtml(html, id);
    if (!details.images.length) details.images = extractTrendyolProductGroupImagesFromHtml(html);
    if (!hasRealTrendyolSellerDescription(details.description)) {
      details.description = extractTrendyolSimpleDescriptionFromHtml(html);
    }
    if (details.barcode || details.stockCode || details.images.length || details.description) {
      trendyolVariantDetailCache.set(id, details);
    }
    return details;
  } catch (e) {
    if (details.barcode || details.stockCode || details.images.length || details.description) {
      trendyolVariantDetailCache.set(id, details);
    }
    return details;
  }
};

const enrichTrendyolSellerScrapingVariantBarcodes = async (product, options = {}) => {
  if (!product || typeof product !== "object") return product;
  const variants = Array.isArray(product.skuVariants) ? product.skuVariants : [];
  const currentId = String(product.productContentId || "").trim();
  const includeSiblings = Boolean(options && options.includeSiblings);
  let candidates = variants
    .filter((variant) => variant && variant.productContentId && variant.productUrl)
    .filter((variant) => includeSiblings || String(variant.productContentId) === currentId)
    .map((variant) => ({
      id: String(variant.productContentId),
      url: variant.productUrl,
      variant
    }));
  if (currentId && product.productUrl && !candidates.some((entry) => entry.id === currentId)) {
    candidates.push({ id: currentId, url: product.productUrl, variant: null });
  }
  let cursor = 0;
  const workers = Array.from(
    { length: Math.min(4, candidates.length) },
    async () => {
      while (cursor < candidates.length) {
        const entry = candidates[cursor];
        cursor += 1;
        const variantUrl = rewriteTrendyolProductUrlForContentId(entry.url, entry.id);
        const details = await fetchTrendyolVariantDetails(entry.id, variantUrl);
        if (entry.variant && details.barcode) entry.variant.barcode = details.barcode;
        if (entry.variant && details.stockCode) entry.variant.stockCode = details.stockCode;
        if (entry.variant && details.productCode) entry.variant.productCode = details.productCode;
        if (entry.variant && hasRealTrendyolSellerDescription(details.description)) {
          entry.variant.description = details.description;
        }
        if (entry.variant && details.images.length > ((entry.variant.images && entry.variant.images.length) || 0)) {
          entry.variant.images = details.images.map((url) => ({ url }));
        }
        if (entry.variant && variantUrl) entry.variant.productUrl = variantUrl;
        if (entry.id === currentId) {
          applyTrendyolContentDetailsToProduct(product, details);
          if (hasRealTrendyolSellerDescription(details.description)) {
            product.description = details.description;
          }
        }
        if (details.barcode) {
          if (!product.barcodeMap || typeof product.barcodeMap !== "object") product.barcodeMap = {};
          product.barcodeMap[entry.id] = details.barcode;
        }
      }
    }
  );
  await Promise.all(workers);
  if (!product.stockCode) product.stockCode = product.barcode || "";
  return product;
};

const extractTrendyolSellerScrapingFromTabId = async (tabId, options = {}) => {
  try {
    const winId = trendyolSellerScrapingWork && trendyolSellerScrapingWork.windowId;
    if (winId) await chrome.windows.update(winId, { focused: true, state: "normal" }).catch(() => {});
    await chrome.tabs.update(tabId, { active: true, autoDiscardable: false }).catch(() => {});
  } catch (e) {}
  const expectedId = options && options.expectedContentId
    ? String(options.expectedContentId).trim()
    : "";
  const readPageContentId = async () => {
    try {
      const res = await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: () => {
          const m = String(location.pathname || "").match(/-p-(\d+)/i);
          return m ? m[1] : "";
        }
      });
      return res && res[0] && res[0].result ? String(res[0].result) : "";
    } catch (e) {
      return "";
    }
  };
  if (expectedId) {
    const urlDeadline = Date.now() + 12000;
    while (Date.now() < urlDeadline) {
      const pageId = await readPageContentId();
      if (pageId && pageId === expectedId) break;
      await new Promise((r) => setTimeout(r, 250));
    }
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      injectImmediately: true,
      func: unfreezeTrendyolHiddenTab
    });
  } catch (e) {}
  await new Promise((r) => setTimeout(r, 200));
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      injectImmediately: true,
      func: unfreezeTrendyolHiddenTab
    });
  } catch (e) {}
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: nudgeTrendyolPdpOnce
    });
  } catch (e) {}
  // Açıklama için en fazla 3 scroll; sonra sadece poll (30+ scroll spam olmasın).
  let nudgeCount = 1;
  const deadline = Date.now() + 12000;
  while (Date.now() < deadline) {
    if (expectedId) {
      const pageId = await readPageContentId();
      if (pageId && pageId !== expectedId) {
        await new Promise((r) => setTimeout(r, 300));
        continue;
      }
    }
    try {
      const check = await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: trendyolPdpHasDescription
      });
      if (check && check[0] && check[0].result) break;
    } catch (e) {}
    if (nudgeCount < 3) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          injectImmediately: true,
          func: unfreezeTrendyolHiddenTab
        });
      } catch (e) {}
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          func: nudgeTrendyolPdpOnce
        });
      } catch (e) {}
      nudgeCount += 1;
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  const runExtract = async (world) => chrome.scripting.executeScript({
    target: { tabId },
    world,
    func: extractTrendyolSellerScrapingFromPage
  });
  let res = null;
  try {
    res = await runExtract("MAIN");
  } catch (e) {
    res = await runExtract("ISOLATED");
  }
  const product = res && res[0] && res[0].result ? res[0].result : null;
  if (!product || (!product.title && !product.barcode && !product.productContentId)) {
    return { ok: false, error: "Ürün detayı bulunamadı" };
  }
  await enrichTrendyolSellerScrapingVariantBarcodes(product, {
    includeSiblings: Boolean(options && options.includeSiblings)
  });
  // Description kardeş SKU'lara kopyalanmaz — her contentId kendi açıklamasını taşır.
  if (expectedId && String(product.productContentId || "") !== expectedId) {
    product.description = "";
  }
  // İkinci şans: bir kez daha scroll, sonra sadece poll
  if (
    !hasRealTrendyolSellerDescription(product) &&
    (!expectedId || String(product.productContentId || "") === expectedId)
  ) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: nudgeTrendyolPdpOnce
      });
    } catch (e) {}
    const extraDeadline = Date.now() + 6000;
    while (Date.now() < extraDeadline) {
      try {
        const check = await chrome.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          func: trendyolPdpHasDescription
        });
        if (check && check[0] && check[0].result) break;
      } catch (e) {}
      await new Promise((r) => setTimeout(r, 500));
    }
    try {
      const retry = await runExtract("MAIN");
      const again = retry && retry[0] && retry[0].result;
      if (
        again &&
        hasRealTrendyolSellerDescription(again.description) &&
        (!expectedId || String(again.productContentId || "") === expectedId)
      ) {
        product.description = again.description;
      }
    } catch (e) {}
  }
  return { ok: true, product };
};

let trendyolSellerScrapingWork = { windowId: null, tabId: null };

const waitForTrendyolSellerScrapingTab = (tabId, expectNavigation) => new Promise((resolve) => {
  let done = false;
  let sawLoading = !expectNavigation;
  const finish = () => {
    if (done) return;
    done = true;
    chrome.tabs.onUpdated.removeListener(onUpdated);
    resolve();
  };
  const onUpdated = (id, info) => {
    if (id !== tabId) return;
    if (info.status === "loading") {
      sawLoading = true;
      chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        injectImmediately: true,
        func: unfreezeTrendyolHiddenTab
      }).catch(() => {});
    }
    if (info.status === "complete" && sawLoading) finish();
  };
  chrome.tabs.onUpdated.addListener(onUpdated);
  chrome.tabs.get(tabId).then((tab) => {
    if (!expectNavigation && tab && tab.status === "complete") finish();
  }).catch(() => finish());
  setTimeout(finish, 25000);
});

const closeTrendyolSellerScrapingWorkTab = async () => {
  const { tabId, windowId } = trendyolSellerScrapingWork;
  trendyolSellerScrapingWork = { windowId: null, tabId: null };
  if (tabId) await chrome.tabs.remove(tabId).catch(() => {});
  if (windowId) await chrome.windows.remove(windowId).catch(() => {});
};

const ensureTrendyolSellerScrapingWorkTab = async (productUrl) => {
  const existingId = trendyolSellerScrapingWork.tabId;
  if (existingId) {
    try {
      await chrome.tabs.get(existingId);
      const wait = waitForTrendyolSellerScrapingTab(existingId, true);
      await chrome.tabs.update(existingId, { url: productUrl, autoDiscardable: false });
      await wait;
      await new Promise((r) => setTimeout(r, 1800));
      return existingId;
    } catch (e) {
      trendyolSellerScrapingWork = { windowId: null, tabId: null };
    }
  }
  const win = await chrome.windows.create({
    url: productUrl,
    focused: true,
    type: "popup",
    width: 1280,
    height: 900,
    left: 60,
    top: 60
  });
  const tab = win && Array.isArray(win.tabs) ? win.tabs[0] : null;
  if (!tab || !tab.id) {
    if (win && win.id) await chrome.windows.remove(win.id).catch(() => {});
    throw new Error("Sekme açılamadı");
  }
  trendyolSellerScrapingWork = { windowId: win.id, tabId: tab.id };
  await chrome.tabs.update(tab.id, { autoDiscardable: false }).catch(() => {});
  await waitForTrendyolSellerScrapingTab(tab.id, false);
  await new Promise((r) => setTimeout(r, 1800));
  return tab.id;
};

/**
 * Açıklama SSR/API'de yok; her contentId için work-tab ile PDP açılır.
 * Yavaş ama doğru — kardeş varyantlara description kopyalanmaz.
 */
const fillTrendyolSellerScrapingDescriptionsViaWorkTab = async (product, options = {}) => {
  if (!product || typeof product !== "object") return product;
  const includeSiblings = Boolean(options && options.includeSiblings);
  const currentId = String(product.productContentId || "").trim();
  const jobs = [];
  const seen = new Set();
  const queue = (id, url, apply) => {
    const cid = String(id || "").trim();
    const rawUrl = String(url || "").trim();
    if (!cid || !rawUrl) return;
    if (seen.has(cid)) return;
    seen.add(cid);
    jobs.push({
      id: cid,
      url: rewriteTrendyolProductUrlForContentId(rawUrl, cid),
      apply
    });
  };

  if (!hasRealTrendyolSellerDescription(product)) {
    queue(currentId, product.productUrl, (desc) => {
      product.description = desc;
    });
  }

  const skus = Array.isArray(product.skuVariants) ? product.skuVariants : [];
  skus.forEach((sku) => {
    if (!sku || sku.productContentId == null || sku.productContentId === "") return;
    const skuId = String(sku.productContentId);
    if (!includeSiblings && skuId !== currentId) return;
    if (hasRealTrendyolSellerDescription(sku.description)) return;
    if (skuId === currentId && hasRealTrendyolSellerDescription(product)) {
      sku.description = product.description;
      return;
    }
    queue(skuId, sku.productUrl || product.productUrl, (desc) => {
      sku.description = desc;
    });
  });

  for (let i = 0; i < jobs.length; i += 1) {
    const job = jobs[i];
    try {
      const tabId = await ensureTrendyolSellerScrapingWorkTab(job.url);
      const result = await extractTrendyolSellerScrapingFromTabId(tabId, {
        expectedContentId: job.id,
        includeSiblings: false
      });
      if (result && result.ok && result.product && hasRealTrendyolSellerDescription(result.product)) {
        job.apply(result.product.description);
      }
    } catch (e) {}
  }
  return product;
};

const fetchTrendyolSellerScrapingDetailInTab = async (productUrl) => {
  try {
    const tabId = await ensureTrendyolSellerScrapingWorkTab(productUrl);
    const expectedContentId = (String(productUrl || "").match(/-p-(\d+)/i) || [])[1] || "";
    const result = await extractTrendyolSellerScrapingFromTabId(tabId, { expectedContentId });
    if (result && result.ok && result.product && !hasRealTrendyolSellerDescription(result.product)) {
      await fillTrendyolSellerScrapingDescriptionsViaWorkTab(result.product, { includeSiblings: false });
    }
    return result;
  } catch (e) {
    return { ok: false, error: e?.message || "Ürün sayfası okunamadı" };
  }
};

const isUsefulTrendyolSellerScrapingProduct = (product) => Boolean(
  product && (product.title || product.barcode || product.productContentId)
);

const mergeTrendyolSellerScrapingDetailParts = (primary, fallback) => {
  if (!primary) return fallback || null;
  if (!fallback) return primary;
  if (!hasRealTrendyolSellerDescription(primary) && hasRealTrendyolSellerDescription(fallback.description)) {
    const primaryId = String(primary.productContentId || "");
    const fallbackId = String(fallback.productContentId || "");
    if (!primaryId || !fallbackId || primaryId === fallbackId) {
      primary.description = fallback.description;
    }
  }
  if (!primary.barcode && fallback.barcode) primary.barcode = fallback.barcode;
  if (!primary.stockCode && fallback.stockCode) primary.stockCode = fallback.stockCode || fallback.barcode || "";
  if ((!primary.images || !primary.images.length) && Array.isArray(fallback.images) && fallback.images.length) {
    primary.images = fallback.images;
  } else if (Array.isArray(fallback.images) && Array.isArray(primary.images) && fallback.images.length > primary.images.length) {
    primary.images = fallback.images;
  }
  if (fallback.barcodeMap && typeof fallback.barcodeMap === "object") {
    primary.barcodeMap = Object.assign({}, fallback.barcodeMap, primary.barcodeMap || {});
  }
  if (!primary.stockCode) primary.stockCode = primary.barcode || "";
  return primary;
};

const fetchTrendyolSellerScrapingDetail = async (productUrl) => {
  let htmlProduct = null;
  try {
    const html = await fetchTrendyolSellerScrapingHtml(productUrl);
    const product = extractTrendyolSellerScrapingFromHtml(html, productUrl);
    if (isUsefulTrendyolSellerScrapingProduct(product)) {
      const contentId = product.productContentId || "";
      if (contentId) {
        const contentDetails = await fetchTrendyolProductContentDetails(contentId);
        applyTrendyolContentDetailsToProduct(product, contentDetails);
      }
      await enrichTrendyolSellerScrapingVariantBarcodes(product);
      htmlProduct = product;
      if (hasRealTrendyolSellerDescription(product) && product.barcode) {
        return { ok: true, product };
      }
    }
  } catch (e) {}
  const tabResult = await fetchTrendyolSellerScrapingDetailInTab(productUrl);
  if (tabResult && tabResult.ok && tabResult.product) {
    return { ok: true, product: mergeTrendyolSellerScrapingDetailParts(tabResult.product, htmlProduct) };
  }
  if (htmlProduct) {
    return { ok: true, product: htmlProduct };
  }
  return tabResult;
};

const buildHepsiburadaMoriaProductUrl = (merchantName, page) => {
  const p = Math.max(1, parseInt(String(page), 10) || 1);
  const filter = `VariantList.VariantListing.MerchantName:${encodeURIComponent(merchantName)}`;
  return `https://blackgate.hepsiburada.com/moriaapi/api/product?filter=${filter}&page=${p}&pageType=Merchant&size=36`;
};

/** blackgate fetch bazen SW içinde başarısız olur; API URL sekmede açılıp sayfadaki JSON parse edilir (çerezler dahil). */
const fetchHepsiburadaSellerProductsViaBackgroundTab = async (merchantName, page) => {
  const url = buildHepsiburadaMoriaProductUrl(merchantName, page);
  const tab = await chrome.tabs.create({ url, active: false });
  if (!tab || !tab.id) {
    throw new Error("Sekme açılamadı");
  }
  const tabId = tab.id;
  await new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      resolve();
    };
    const onUpdated = (id, info) => {
      if (id === tabId && info.status === "complete") finish();
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((t) => {
      if (t && t.status === "complete") finish();
    }).catch(() => {});
    setTimeout(finish, 38000);
  });
  await new Promise((r) => setTimeout(r, 800));
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      func: function parseMoriaJsonPage() {
        return (async () => {
          try {
            const pre = document.querySelector("pre");
            const raw = (pre ? pre.textContent : document.body && document.body.innerText) || "";
            const t = String(raw).trim();
            if (t) {
              const data = JSON.parse(t);
              if (data && Array.isArray(data.products)) {
                return { ok: true, products: data.products };
              }
            }
          } catch (e) {}
          try {
            const r = await fetch(String(location.href), {
              credentials: "include",
              headers: { Accept: "application/json" }
            });
            if (!r.ok) return { ok: false, error: "HTTP " + r.status };
            const data = await r.json();
            return { ok: true, products: Array.isArray(data.products) ? data.products : [] };
          } catch (e2) {
            return { ok: false, error: (e2 && e2.message) || "fetch" };
          }
        })();
      }
    });
    const payload = res && res[0] && res[0].result ? res[0].result : { ok: false, error: "Sonuç yok" };
    if (payload && payload.ok) {
      return { ok: true, products: payload.products || [] };
    }
    throw new Error((payload && payload.error) || "Sunucu yanıtı sekmede okunamadı");
  } finally {
    await chrome.tabs.remove(tabId).catch(() => {});
  }
};

const tryHepsiburadaSellerProductsFetch = async (merchantName, page) => {
  const url = buildHepsiburadaMoriaProductUrl(merchantName, page);
  const headers = {
    Accept: "application/json",
    Referer: "https://www.hepsiburada.com/",
    Origin: "https://www.hepsiburada.com",
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
  };
  for (const credentials of ["omit", "include"]) {
    try {
      const res = await fetch(url, {
        method: "GET",
        headers,
        credentials
      });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const data = await res.json();
      return { ok: true, products: data.products || [] };
    } catch {
      // try include or tab fallback
    }
  }
  return fetchHepsiburadaSellerProductsViaBackgroundTab(merchantName, page);
};

const extractN11ProductPagePriceInPage = () => {
  const normalizeNumeric = (value) => {
    if (value == null) return null;
    const raw = String(value).replace(/[^\d,.]/g, "").replace(/\s/g, "");
    if (!raw) return null;
    const lastComma = raw.lastIndexOf(",");
    const lastDot = raw.lastIndexOf(".");
    if (lastComma >= 0 && lastDot >= 0) {
      if (lastComma > lastDot) return parseFloat(raw.replace(/\./g, "").replace(",", "."));
      return parseFloat(raw.replace(/,/g, ""));
    }
    if (lastDot >= 0 && lastComma < 0) {
      const afterDot = raw.slice(lastDot + 1);
      if (afterDot.length === 3) return parseFloat(raw.replace(/\./g, ""));
      return parseFloat(raw);
    }
    if (lastComma >= 0 && lastDot < 0) {
      const afterComma = raw.slice(lastComma + 1);
      if (afterComma.length === 3) return parseFloat(raw.replace(/,/g, ""));
      return parseFloat(raw.replace(",", "."));
    }
    return parseFloat(raw);
  };
  const formatPrice = (num) =>
    num != null && !Number.isNaN(num)
      ? `${num.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} TL`
      : "";
  const tryFormat = (value) => {
    const n = normalizeNumeric(value);
    return n != null && !Number.isNaN(n) && n > 0 ? formatPrice(n) : "";
  };

  try {
    const finalPrice = window?.model?.product?.personalizedData?.product?.finalPrice;
    const formatted = tryFormat(finalPrice);
    if (formatted) return formatted;
  } catch (e) {}

  try {
    const discountedPrice = window?.model?.product?.discountedPrice;
    const formatted = tryFormat(discountedPrice);
    if (formatted) return formatted;
  } catch (e) {}

  const scripts = document.querySelectorAll("script");
  for (let i = 0; i < scripts.length; i += 1) {
    const text = scripts[i].textContent || "";
    if (!text || !/finalPrice|discountedPrice/i.test(text)) continue;
    const fromPersonalized = text.match(
      /"personalizedData"\s*:\s*\{[\s\S]*?"product"\s*:\s*\{[\s\S]*?"finalPrice"\s*:\s*"([^"]+)"/i
    );
    if (fromPersonalized && fromPersonalized[1]) {
      const formatted = tryFormat(fromPersonalized[1]);
      if (formatted) return formatted;
    }
    const discountedMatches = text.matchAll(/"discountedPrice"\s*:\s*"([^"]+)"/gi);
    for (const match of discountedMatches) {
      if (!match || !match[1]) continue;
      const formatted = tryFormat(match[1]);
      if (formatted) return formatted;
    }
    const fromAnyFinal = text.match(/"finalPrice"\s*:\s*"([^"]+)"/i);
    if (fromAnyFinal && fromAnyFinal[1] && fromAnyFinal[1].toLowerCase() !== "null") {
      const formatted = tryFormat(fromAnyFinal[1]);
      if (formatted) return formatted;
    }
  }

  const domSelectors = [
    ".product-summary ins",
    ".product-summary .newPrice",
    ".unf-p-summary-price .newPrice",
    "[class*='newPrice']"
  ];
  for (let i = 0; i < domSelectors.length; i += 1) {
    const el = document.querySelector(domSelectors[i]);
    if (!el) continue;
    const formatted = tryFormat(el.textContent);
    if (formatted) return formatted;
  }

  const metaAmount = document.querySelector('meta[property="product:price:amount"]')?.getAttribute("content");
  const metaFormatted = tryFormat(metaAmount);
  if (metaFormatted) return metaFormatted;

  try {
    const adDataPrice = window?.model?.adData?.price;
    const formatted = tryFormat(adDataPrice);
    if (formatted) return formatted;
  } catch (e) {}

  for (let i = 0; i < scripts.length; i += 1) {
    const text = scripts[i].textContent || "";
    if (!text || !/adData/i.test(text) || !/price/i.test(text)) continue;
    const patterns = [
      /model\.adData\.price\s*[=:]\s*["']?([\d.,]+)["']?/i,
      /model\[['"]adData['"]\]\[['"]price['"]\]\s*[=:]\s*["']?([\d.,]+)["']?/i,
      /"adData"\s*:\s*\{[\s\S]*?"price"\s*:\s*["']?([\d.,]+)["']?/i
    ];
    for (let pi = 0; pi < patterns.length; pi += 1) {
      const match = text.match(patterns[pi]);
      if (!match || !match[1]) continue;
      const formatted = tryFormat(match[1]);
      if (formatted) return formatted;
    }
  }

  return "";
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "seller-product-count-getData") {
    Promise.all([sellerProductCountGetSellers(), sellerProductCountGetResults()])
      .then(([sellers, results]) => sendResponse({ ok: true, sellers, results }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-saveUrls") {
    const sellers = Array.isArray(message.sellers) ? message.sellers : [];
    sellerProductCountSaveSellers(sellers)
      .then((saved) => sendResponse({ ok: true, sellers: saved }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-scrape") {
    const sellers = Array.isArray(message.sellers) ? message.sellers : [];
    Promise.all(sellers.map((s) => sellerProductCountScrapeForSeller(s)))
      .then((results) => sellerProductCountSaveResults(results).then(() => sendResponse({ ok: true, results })))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-getResults") {
    sellerProductCountGetResults()
      .then((results) => sendResponse({ ok: true, results }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-clearData") {
    sellerProductCountClearData()
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "seller-product-count-restore") {
    const sellersList = Array.isArray(message.sellers) ? message.sellers : [];
    const resultsList = Array.isArray(message.results) ? message.results : [];
    Promise.all([
      sellerProductCountSaveSellers(sellersList),
      sellerProductCountSaveResults(resultsList)
    ])
      .then(([savedSellers]) => sendResponse({ ok: true, sellers: savedSellers, results: resultsList }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
  if (message && message.type === "trendyol-seller-products") {
    const mid = message.mid != null ? String(message.mid) : "";
    const pi = Math.max(1, parseInt(message.pi, 10) || 1);
    if (!mid) {
      sendResponse({ ok: false, error: "mid gerekli" });
      return true;
    }
    const url = `https://apigw.trendyol.com/discovery-sfint-search-service/api/search/products?mid=${encodeURIComponent(mid)}&os=1&pathModel=sr&pi=${pi}`;
    fetch(url)
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        sendResponse({ ok: true, products: data.products || [], totalCount: data.totalCount });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "İstek başarısız" });
      });
    return true;
  }
  if (message && message.type === "trendyol-product-detail-crawl") {
    const url = (message.url || "").trim();
    if (!url || !/^https?:\/\/([^/]+\.)?trendyol\.com\//i.test(url)) {
      sendResponse({ ok: false, error: "Geçersiz Trendyol ürün linki" });
      return true;
    }
    fetchTrendyolProductDetailInTab(url)
      .then((result) => sendResponse(result))
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "Ürün sayfası okunamadı" });
      });
    return true;
  }
  if (message && message.type === "trendyol-seller-scraping-detail") {
    const url = (message.url || "").trim();
    if (!url || !/^https?:\/\/([^/]+\.)?trendyol\.com\//i.test(url)) {
      sendResponse({ ok: false, error: "Geçersiz Trendyol ürün linki" });
      return true;
    }
    fetchTrendyolSellerScrapingDetail(url)
      .then((result) => sendResponse(result))
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "Ürün sayfası okunamadı" });
      });
    return true;
  }
  if (message && message.type === "trendyol-seller-scraping-finish") {
    closeTrendyolSellerScrapingWorkTab()
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: true }));
    return true;
  }
  if (message && message.type === "trendyol-seller-scraping-detail-current") {
    const tabId = sender && sender.tab && sender.tab.id;
    if (!tabId) {
      sendResponse({ ok: false, error: "Aktif sekme bulunamadı" });
      return true;
    }
    const expectedContentId = (String((sender.tab && sender.tab.url) || "").match(/-p-(\d+)/i) || [])[1] || "";
    extractTrendyolSellerScrapingFromTabId(tabId, { includeSiblings: true, expectedContentId })
      .then(async (result) => {
        if (result && result.ok && result.product) {
          await fillTrendyolSellerScrapingDescriptionsViaWorkTab(result.product, { includeSiblings: true });
        }
        sendResponse(result);
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "Ürün sayfası okunamadı" });
      });
    return true;
  }
  if (message && message.type === "trendyol-bestsellers-products") {
    const page = Math.max(1, parseInt(message.page, 10) || 1);
    const pageSize = Math.max(1, Math.min(100, parseInt(message.pageSize, 10) || 20));
    const incomingUserId = message.userId != null ? String(message.userId).trim() : "";
    const categoryId = message.categoryId != null ? String(message.categoryId).trim() : "";
    const rankingType = message.rankingType != null ? String(message.rankingType).trim() : "";
    const webGenderId = message.webGenderId != null ? String(message.webGenderId).trim() : "";

    const tryExtractUserIdFromHtml = (html) => {
      if (!html) return "";
      const patterns = [
        /"userId"\s*:\s*"?(\d{5,})"?/i,
        /"userid"\s*:\s*"?(\d{5,})"?/i,
        /userId\s*[:=]\s*"?(\d{5,})"?/i,
        /user_id\s*[:=]\s*"?(\d{5,})"?/i
      ];
      for (const pattern of patterns) {
        const match = html.match(pattern);
        if (match && match[1]) return String(match[1]);
      }
      return "";
    };

    const resolveUserId = async () => {
      if (/^\d{5,}$/.test(incomingUserId)) {
        return incomingUserId;
      }
      const htmlResponse = await fetch("https://www.trendyol.com/cok-satanlar");
      if (!htmlResponse.ok) {
        throw new Error(`userId alınamadı (HTTP ${htmlResponse.status})`);
      }
      const html = await htmlResponse.text();
      const found = tryExtractUserIdFromHtml(html);
      if (!found) {
        throw new Error("Trendyol userId bulunamadı");
      }
      return found;
    };

    const rankingTypeValue = rankingType || "bestSeller";
    const senderTabId = sender?.tab?.id;

    const extractProductsFromPayload = (data) => {
      if (!data || typeof data !== "object") return [];
      if (Array.isArray(data.products)) return data.products;
      if (Array.isArray(data.contents)) return data.contents;
      if (Array.isArray(data.items)) return data.items;
      if (Array.isArray(data.result?.products)) return data.result.products;
      if (Array.isArray(data.result?.contents)) return data.result.contents;
      if (Array.isArray(data.data?.products)) return data.data.products;
      if (Array.isArray(data.data?.contents)) return data.data.contents;
      return [];
    };

    const hasProductList = (data) => extractProductsFromPayload(data).length > 0 || (
      !!data && typeof data === "object" && (
        Array.isArray(data.products) ||
        Array.isArray(data.contents) ||
        Array.isArray(data.items) ||
        Array.isArray(data.result?.products) ||
        Array.isArray(data.result?.contents) ||
        Array.isArray(data.data?.products) ||
        Array.isArray(data.data?.contents)
      )
    );

    const extractCategoryNameFromPayload = (data) => {
      const name =
        data?.categoryInfo?.name ||
        data?.result?.categoryInfo?.name ||
        data?.data?.categoryInfo?.name ||
        data?.category?.name ||
        "";
      return name ? String(name) : "";
    };

    const fetchJsonFromUrl = async (url) => {
      const res = await fetch(url, {
        method: "GET",
        headers: {
          Accept: "application/json, text/plain, */*",
          language: "tr",
          storefrontid: "1",
          platform: "web"
        },
        credentials: "omit"
      });
      if (res.ok) {
        return res.json();
      }
      const err = new Error(`HTTP ${res.status}`);
      err.status = res.status;
      throw err;
    };

    const fetchJsonFromTab = async (url) => {
      if (!senderTabId) {
        throw new Error("HTTP 404");
      }
      const injected = await chrome.scripting.executeScript({
        target: { tabId: senderTabId },
        world: "MAIN",
        func: async (apiUrl) => {
          const res = await fetch(apiUrl, {
            method: "GET",
            credentials: "include",
            headers: {
              Accept: "application/json, text/plain, */*"
            }
          });
          if (!res.ok) {
            const error = new Error(`HTTP ${res.status}`);
            error.status = res.status;
            throw error;
          }
          return res.json();
        },
        args: [url]
      });
      const result = injected && injected[0] ? injected[0].result : null;
      if (!result) {
        const execError = injected && injected[0] ? injected[0].error : null;
        throw new Error(execError?.message || "HTTP 404");
      }
      return result;
    };

    const fetchJsonWithPageFallback = async (url) => {
      try {
        return await fetchJsonFromUrl(url);
      } catch (err) {
        const status = Number(err?.status) || 0;
        if (status === 404) {
          throw err;
        }
        if (status !== 403 && status !== 0) {
          throw err;
        }
        return fetchJsonFromTab(url);
      }
    };

    const buildCategoryRankingUrls = () => {
      const common = {
        categoryId,
        page: String(page),
        pageSize: String(pageSize),
        channelId: "1",
        storefrontId: "1",
        language: "tr",
        countryCode: "TR"
      };
      const withGender = (params) => {
        const search = new URLSearchParams(params);
        if (/^\d+$/.test(webGenderId)) search.set("webGenderId", webGenderId);
        return search.toString();
      };
      const hosts = [
        "https://apigw.trendyol.com/discovery-sfint-browsing-service",
        "https://apigw.trendyol.com/discovery-web-websfxbrowsinggw-santral"
      ];
      const paths = [
        "/api/top-rankings/top-ranking-contents",
        "/api/v2/top-rankings/top-ranking-contents",
        "/api/category-top-ranking/top-ranking-contents"
      ];
      const urls = [];
      hosts.forEach((host) => {
        paths.forEach((path) => {
          urls.push(
            `${host}${path}?${withGender({
              ...common,
              rankingType: rankingTypeValue
            })}`
          );
          urls.push(
            `${host}${path}?${withGender({
              ...common,
              type: rankingTypeValue
            })}`
          );
        });
      });
      const searchParams = new URLSearchParams({
        wc: categoryId,
        sst: "BEST_SELLER",
        os: "1",
        pathModel: "sr",
        pi: String(page),
        culture: "tr-TR",
        storefrontId: "1"
      });
      if (/^\d+$/.test(webGenderId)) searchParams.set("webGenderId", webGenderId);
      urls.push(
        `https://apigw.trendyol.com/discovery-sfint-search-service/api/search/products?${searchParams.toString()}`
      );
      return urls;
    };

    const fetchFirstWorkingProductUrl = async (urls) => {
      let lastError = new Error("HTTP 404");
      for (let i = 0; i < urls.length; i += 1) {
        try {
          const data = await fetchJsonWithPageFallback(urls[i]);
          if (!hasProductList(data)) {
            continue;
          }
          return {
            ok: true,
            userId: "",
            products: extractProductsFromPayload(data),
            categoryInfoName: extractCategoryNameFromPayload(data)
          };
        } catch (err) {
          lastError = err;
        }
      }
      throw lastError;
    };

    const withPageOnUrl = (rawUrl) => {
      try {
        const parsed = new URL(rawUrl);
        if (parsed.searchParams.has("page")) parsed.searchParams.set("page", String(page));
        if (parsed.searchParams.has("pi")) parsed.searchParams.set("pi", String(page));
        if (parsed.searchParams.has("pageIndex")) parsed.searchParams.set("pageIndex", String(page));
        if (parsed.searchParams.has("pageSize")) parsed.searchParams.set("pageSize", String(pageSize));
        return parsed.href;
      } catch {
        return "";
      }
    };

    const buildSearchBestSellerUrls = () => {
      const searchParams = new URLSearchParams({
        sst: "BEST_SELLER",
        os: "1",
        pathModel: "sr",
        pi: String(page),
        culture: "tr-TR",
        storefrontId: "1"
      });
      if (/^\d+$/.test(categoryId)) searchParams.set("wc", categoryId);
      if (/^\d+$/.test(webGenderId)) searchParams.set("webGenderId", webGenderId);
      return [
        `https://apigw.trendyol.com/discovery-sfint-search-service/api/search/products?${searchParams.toString()}`
      ];
    };

    const fetchCategoryTopRanking = async () =>
      fetchFirstWorkingProductUrl(buildCategoryRankingUrls());

    const fetchDiscoveredAndSearchRanking = async () => {
      const discovered = Array.isArray(message.discoveredApiUrls)
        ? message.discoveredApiUrls.map(withPageOnUrl).filter(Boolean)
        : [];
      const urls = [...new Set([...discovered, ...buildSearchBestSellerUrls()])];
      return fetchFirstWorkingProductUrl(urls);
    };

    const fetchPersonalizedTopRanking = () =>
      resolveUserId().then((resolvedUserId) => {
        const params = new URLSearchParams({
          page: String(page),
          pageSize: String(pageSize),
          userId: String(resolvedUserId),
          channelId: "1",
          storefrontId: "1",
          language: "tr",
          countryCode: "TR"
        });
        if (/^\d+$/.test(categoryId)) params.set("categoryId", categoryId);
        if (rankingTypeValue) params.set("type", rankingTypeValue);
        if (/^\d+$/.test(webGenderId)) params.set("webGenderId", webGenderId);
        const url = `https://apigw.trendyol.com/discovery-sfint-browsing-service/api/category-top-ranking/personalized-top-ranking-contents?${params.toString()}`;
        return fetchJsonWithPageFallback(url).then((data) => ({
          ok: true,
          userId: resolvedUserId,
          products: extractProductsFromPayload(data),
          categoryInfoName: extractCategoryNameFromPayload(data)
        }));
      });

    const requestPromise = /^\d+$/.test(categoryId)
      ? fetchCategoryTopRanking()
          .catch(() => fetchDiscoveredAndSearchRanking())
          .catch(() => fetchPersonalizedTopRanking())
      : fetchDiscoveredAndSearchRanking().catch(() => fetchPersonalizedTopRanking());

    requestPromise
      .then((result) => {
        sendResponse(result);
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "İstek başarısız" });
      });
    return true;
  }
  if (message && message.type === "hepsiburada-seller-products") {
    const merchantName = (message.merchantName != null && message.merchantName !== "") ? String(message.merchantName).trim() : "";
    const page = Math.max(1, parseInt(message.page, 10) || 1);
    if (!merchantName) {
      sendResponse({ ok: false, error: "merchantName gerekli" });
      return true;
    }
    tryHepsiburadaSellerProductsFetch(merchantName, page)
      .then((result) => sendResponse(result))
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "İstek başarısız" });
      });
    return true;
  }
  if (message && message.type === "hepsiburada-product-breadcrumb") {
    const u = (message.url || "").trim();
    if (!u || !/^https?:\/\/(www\.)?hepsiburada\.com\//i.test(u)) {
      sendResponse({ ok: false, categoryPos2: "", categoryParent: "", error: "Geçersiz URL" });
      return true;
    }
    fetchHepsiburadaProductBreadcrumbInTab(u)
      .then((result) => sendResponse(result))
      .catch(() => sendResponse({ ok: false, categoryPos2: "", categoryParent: "" }));
    return true;
  }
  if (message && message.type === "barcode-products-crawl") {
    const barcodes = Array.isArray(message.barcodes)
      ? message.barcodes.map((x) => String(x || "").trim()).filter((x) => /^\d{8,14}$/.test(x))
      : [];
    const uniqueBarcodes = Array.from(new Set(barcodes));
    if (!uniqueBarcodes.length) {
      sendResponse({ ok: false, error: "Gecerli barkod bulunamadi." });
      return true;
    }

    const waitComplete = (tabId, timeoutMs) => new Promise((resolve) => {
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      };
      const onUpdated = (updatedId, info) => {
        if (updatedId === tabId && info && info.status === "complete") finish();
      };
      chrome.tabs.onUpdated.addListener(onUpdated);
      chrome.tabs.get(tabId).then((tab) => {
        if (tab && tab.status === "complete") finish();
      }).catch(() => {});
      setTimeout(finish, timeoutMs || 20000);
    });

    const scrapeInNewTab = (url, scrapeFn, readyFn) =>
      chrome.tabs.create({ url, active: false }).then((tab) => {
        if (!tab || !tab.id) return [];
        const tabId = tab.id;
        const waitMs = (ms) => new Promise((r) => setTimeout(r, ms));
        const waitUntilReady = () => {
          if (typeof readyFn !== "function") return Promise.resolve();
          const maxTry = 12;
          let attempt = 0;
          const step = () => {
            attempt += 1;
            return chrome.scripting.executeScript({
              target: { tabId },
              func: readyFn
            })
              .then((r) => Boolean(r && r[0] && r[0].result === true))
              .catch(() => false)
              .then((isReady) => {
                if (isReady) return Promise.resolve();
                if (attempt >= maxTry) return Promise.resolve();
                return waitMs(1200).then(step);
              });
          };
          return step();
        };
        return waitComplete(tabId, 25000)
          .then(() => waitUntilReady())
          .then(() => waitMs(600))
          .then(() =>
            chrome.scripting.executeScript({
              target: { tabId },
              func: scrapeFn
            })
          )
          .then((result) => (result && result[0] && Array.isArray(result[0].result) ? result[0].result : []))
          .catch(() => [])
          .finally(() => {
            chrome.tabs.remove(tabId).catch(() => {});
          });
      });

    const scrapeHepsiburada = () => {
      const toAbs = (href) => {
        if (!href) return "";
        try { return new URL(href, location.origin).href; } catch { return href; }
      };
      const normalizePriceText = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d{1,3}(?:\.\d{3})*|\d+)(?:,(\d{2}))?/);
        if (!m) return "";
        const whole = (m[1] || "").replace(/\./g, "");
        const frac = (m[2] || "00");
        const n = Number.parseFloat(whole + "." + frac);
        if (!Number.isFinite(n) || n <= 0) return "";
        return n.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
      };
      const normalizeRating = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d+(?:[.,]\d+)?)/);
        if (!m) return "";
        return String(m[1]).replace(".", ",");
      };
      const normalizeReviewCount = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d[\d.]*)/);
        if (!m) return "";
        return String(m[1]).replace(/\./g, "");
      };
      const normalizeReviewCountFromAria = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim().toLowerCase();
        if (!raw) return "";
        // Sadece "164 derecelendirme" gibi formati kabul et; "5 yildiz uzerinden..." kabul etme.
        const m = raw.match(/^(\d[\d.]*)\s*(?:değerlendirme|degerlendirme)\b/i);
        if (!m) return "";
        return String(m[1]).replace(/\./g, "");
      };
      const cards = Array.from(
        document.querySelectorAll(
          'li.productListContent-zAP0Y5msy8OHn5z7T_K_, [data-test-id="product-card"], [data-listingid], li[class*="productListContent"], div[class*="productListContent"]'
        )
      );
      const uniq = new Set();
      const out = [];
      cards.forEach((card) => {
        const a =
          card.querySelector('a[data-test-id="product-card-name"]') ||
          card.querySelector('a[href*="-p-"]') ||
          card.querySelector("a[href]");
        const href = toAbs(a && a.getAttribute("href"));
        if (!href || uniq.has(href)) return;
        uniq.add(href);
        const titleEl =
          card.querySelector('h2[data-test-id^="title-"] a, h2 a, h2') ||
          card.querySelector('[data-test-id="title-1"], [data-test-id^="title-"]') ||
          a;
        const finalPriceEl =
          card.querySelector('[data-test-id^="final-price-"], .price-module_finalPrice__LtjvY');
        const titleContainer = card.querySelector('h2[data-test-id^="title-"], h2');
        const ratingEl =
          card.querySelector('.rate-module_rating__19oVu, [data-test-id^="rating-"] .rate-module_rating__19oVu');
        const reviewCountEl =
          card.querySelector('.rate-module_count__fjUng, [data-test-id^="rating-"] .rate-module_count__fjUng');
        const srOnlyRatingEl =
          card.querySelector('[data-test-id^="rating-"] .rate-module_srOnly__oeW3d');
        const imgEl = card.querySelector("img");
        const title = (titleEl && titleEl.textContent ? titleEl.textContent : "").replace(/\s+/g, " ").trim();
        let price = normalizePriceText(finalPriceEl && finalPriceEl.textContent ? finalPriceEl.textContent : "");
        if (!price && titleContainer) {
          const aria = String(titleContainer.getAttribute("aria-label") || "");
          const ariaMatch = aria.match(/fiyat:\s*([\d.,]+)\s*TL/i);
          if (ariaMatch && ariaMatch[1]) price = normalizePriceText(ariaMatch[1] + " TL");
        }
        let rating = normalizeRating(ratingEl && ratingEl.textContent ? ratingEl.textContent : "");
        let reviewCount = normalizeReviewCount(reviewCountEl && reviewCountEl.textContent ? reviewCountEl.textContent : "");
        if (srOnlyRatingEl) {
          const sr = String(srOnlyRatingEl.textContent || "");
          const rm = sr.match(/ürün puanı\s*([\d.,]+)\s*,\s*(\d[\d.]*)\s*değerlendirme/i);
          if (rm) {
            rating = normalizeRating(rm[1]) || rating;
            reviewCount = normalizeReviewCount(rm[2]) || reviewCount;
          }
        }
        if (!rating || !reviewCount) {
          const cardText = String(card.textContent || "").replace(/\s+/g, " ").trim();
          const rm = cardText.match(/ürün puanı\s*([\d.,]+)\s*,\s*(\d[\d.]*)\s*değerlendirme/i);
          if (rm) {
            rating = normalizeRating(rm[1]) || rating;
            reviewCount = normalizeReviewCount(rm[2]) || reviewCount;
          }
        }
        const image = imgEl ? (imgEl.getAttribute("src") || imgEl.getAttribute("data-src") || "") : "";
        if (!title && !price && !image) return;
        out.push({ link: href, title, price, image, rating, reviewCount });
      });
      return out.slice(0, 40);
    };

    const scrapeAmazon = () => {
      const toAbs = (href) => {
        if (!href) return "";
        try { return new URL(href, location.origin).href; } catch { return href; }
      };
      const normalizeRating = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d+(?:[.,]\d+)?)/);
        if (!m) return "";
        return String(m[1]).replace(".", ",");
      };
      const normalizeReviewCount = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim();
        if (!raw) return "";
        const m = raw.match(/(\d[\d.]*)/);
        if (!m) return "";
        return String(m[1]).replace(/\./g, "");
      };
      const normalizeReviewCountFromAria = (text) => {
        const raw = String(text || "").replace(/\s+/g, " ").trim().toLowerCase();
        if (!raw) return "";
        // Sadece "164 derecelendirme" formatini kabul et.
        const m = raw.match(/(^|\s)(\d[\d.]*)\s*(?:değerlendirme|degerlendirme)\b/i);
        if (!m) return "";
        return String(m[2]).replace(/\./g, "");
      };
      const cards = Array.from(document.querySelectorAll('div[data-component-type="s-search-result"]'));
      const uniq = new Set();
      const out = [];
      cards.forEach((card) => {
        const a = card.querySelector("h2 a.a-link-normal") || card.querySelector("a.a-link-normal[href]");
        const href = toAbs(a && a.getAttribute("href"));
        if (!href || uniq.has(href)) return;
        uniq.add(href);
        const titleEl = card.querySelector("h2 span") || a;
        const priceEl = card.querySelector(".a-price .a-offscreen, .a-price-whole");
        const imgEl = card.querySelector("img.s-image, img");
        const ratingEl =
          card.querySelector('[data-cy="reviews-block"] span.a-size-small.a-color-base') ||
          card.querySelector("i.a-icon-star-small span.a-icon-alt, i.a-icon-star-mini span.a-icon-alt");
        const reviewCountLink =
          card.querySelector('a[href*="#customerReviews"][aria-label]') ||
          card.querySelector('[data-cy="reviews-block"] a[href*="#customerReviews"][aria-label]') ||
          card.querySelector('[data-cy="reviews-block"] a[aria-label*="değerlendirme"]:not([aria-label*="yıldız"]):not([aria-label*="yildiz"])');
        const reviewCountTextEl =
          (reviewCountLink && reviewCountLink.querySelector("span")) ||
          card.querySelector('a[href*="#customerReviews"] span') ||
          card.querySelector('[data-cy="reviews-block"] a[aria-label*="değerlendirme"] span');
        const ratingAriaEl =
          card.querySelector('i.a-icon-star-mini span.a-icon-alt, i.a-icon-star-small span.a-icon-alt');
        const reviewsBlockEl = card.querySelector('[data-cy="reviews-block"]');
        const title = (titleEl && titleEl.textContent ? titleEl.textContent : "").replace(/\s+/g, " ").trim();
        const price = (priceEl && priceEl.textContent ? priceEl.textContent : "").replace(/\s+/g, " ").trim();
        let rating = normalizeRating(ratingEl && ratingEl.textContent ? ratingEl.textContent : "");
        let reviewCount = "";
        if (reviewCountLink) {
          // Örn: aria-label="164 derecelendirme"
          reviewCount = normalizeReviewCountFromAria(reviewCountLink.getAttribute("aria-label") || "") || "";
        }
        if (!reviewCount && reviewCountTextEl) {
          // Örn: "(164)"
          reviewCount = normalizeReviewCount(reviewCountTextEl.textContent || "");
        }
        if (!rating && ratingAriaEl) {
          rating = normalizeRating(ratingAriaEl.textContent || "");
        }
        if ((!rating || !reviewCount) && reviewsBlockEl) {
          const blockText = String(reviewsBlockEl.textContent || "").replace(/\s+/g, " ").trim();
          const rm = blockText.match(/(\d+(?:[.,]\d+)?)\s*(?:_)?\s*5 yıldız üzerinden/i);
          const cm = blockText.match(/\(?\s*(\d[\d.]*)\s*\)?\s*(?:değerlendirme|degerlendirme)\b/i) || blockText.match(/\((\d[\d.]*)\)/);
          if (!rating && rm) rating = normalizeRating(rm[1]);
          if (!reviewCount && cm) reviewCount = normalizeReviewCount(cm[1]);
        }
        const image = imgEl ? (imgEl.getAttribute("src") || "") : "";
        if (!title && !price && !image) return;
        out.push({ link: href, title, price, image, rating, reviewCount });
      });
      return out.slice(0, 40);
    };

    (async () => {
      const rows = [];
      for (const barcode of uniqueBarcodes) {
        const hbUrl = "https://www.hepsiburada.com/ara?q=" + encodeURIComponent(barcode);
        const amzUrl = "https://www.amazon.com.tr/s?k=" + encodeURIComponent(barcode);

        const hbProducts = await scrapeInNewTab(
          hbUrl,
          scrapeHepsiburada,
          () => {
            const hasProducts = document.querySelectorAll(
              'li.productListContent-zAP0Y5msy8OHn5z7T_K_, [data-test-id="product-card"], [data-listingid], li[class*="productListContent"], div[class*="productListContent"]'
            ).length > 0;
            const hasRating = document.querySelectorAll(
              '.rate-module_rating__19oVu, .rate-module_count__fjUng, [data-test-id^="rating-"]'
            ).length > 0;
            if (hasProducts && hasRating) return true;
            // "Aramana uygun ürün bulunamadı" ekranında hemen bitirme, beklemeye devam et.
            const noResultText = (document.body && document.body.innerText ? document.body.innerText : "")
              .toLowerCase();
            const noResultVisible =
              noResultText.includes("aramana uygun ürün bulunamadı") ||
              noResultText.includes("aramana uygun urun bulunamadi") ||
              Boolean(document.querySelector('[class*="no-result-view"]'));
            if (noResultVisible) return false;
            return false;
          }
        );
        hbProducts.forEach((p) => {
          rows.push({
            barcode,
            platform: "Hepsiburada",
            queryUrl: hbUrl,
            link: p.link || "",
            title: p.title || "",
            price: p.price || "",
            image: p.image || "",
            rating: p.rating || "",
            reviewCount: p.reviewCount || ""
          });
        });

        const amzProducts = await scrapeInNewTab(amzUrl, scrapeAmazon);
        amzProducts.forEach((p) => {
          rows.push({
            barcode,
            platform: "Amazon.com.tr",
            queryUrl: amzUrl,
            link: p.link || "",
            title: p.title || "",
            price: p.price || "",
            image: p.image || "",
            rating: p.rating || "",
            reviewCount: p.reviewCount || ""
          });
        });
      }
      sendResponse({ ok: true, rows });
    })().catch((err) => {
      sendResponse({ ok: false, error: err && err.message ? err.message : "Tarama hatasi" });
    });
    return true;
  }
  if (message && message.type === "barcode-products-download-amazon") {
    const url = String(message.url || "").trim();
    const barcode = String(message.barcode || "").trim();
    if (!url || !/amazon\.com\.tr/i.test(url)) {
      sendResponse({ ok: false, error: "Gecersiz Amazon urun URL." });
      return true;
    }

    buildAmazonProductZipPackage(url, barcode)
      .then((result) => {
        sendResponse({ ok: true, ...result });
      })
      .catch((err) => {
        sendResponse({
          ok: false,
          error: err?.message || "Amazon urun paketi olusturulamadi."
        });
      });
    return true;
  }
  if (message && message.type === "barcode-products-download-amazon-bulk") {
    const items = Array.isArray(message.items)
      ? message.items
          .map((item) => ({
            url: String(item?.url || "").trim(),
            barcode: String(item?.barcode || "").trim()
          }))
          .filter((item) => item.url && /amazon\.com\.tr/i.test(item.url))
      : [];
    if (!items.length) {
      sendResponse({ ok: false, error: "Indirilecek Amazon urunu bulunamadi." });
      return true;
    }

    const tabId = sender?.tab?.id || null;
    buildAmazonBulkZipPackage(items, (progress) => {
      if (!tabId) return;
      chrome.tabs.sendMessage(tabId, {
        type: "barcode-products-bulk-download-progress",
        ...progress
      }).catch(() => {});
    })
      .then((result) => {
        sendResponse({ ok: true, ...result });
      })
      .catch((err) => {
        sendResponse({
          ok: false,
          error: err?.message || "Toplu Amazon indirme basarisiz."
        });
      });
    return true;
  }
  if (message && message.type === "ty-seller-follower-scrape") {
    const rawInput = String(message.brand || "").trim();
    if (!rawInput) {
      sendResponse({ ok: false, error: "Marka adi bos." });
      return true;
    }

    const TY_SELLER_FOLLOWER_CACHE_KEY = "tySellerFollowerMagazaCache";

    const waitComplete = (tabId, timeoutMs = 25000) =>
      new Promise((resolve) => {
        let done = false;
        const finish = () => {
          if (done) return;
          done = true;
          chrome.tabs.onUpdated.removeListener(onUpdated);
          resolve();
        };
        const onUpdated = (updatedId, info) => {
          if (updatedId === tabId && info && info.status === "complete") finish();
        };
        chrome.tabs.onUpdated.addListener(onUpdated);
        chrome.tabs
          .get(tabId)
          .then((t) => {
            if (t && t.status === "complete") finish();
          })
          .catch(() => {});
        setTimeout(finish, timeoutMs);
      });

    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    const isTyMagazaUrl = (value) => /trendyol\.com\/magaza\//i.test(String(value || ""));

    const normalizeBrandKey = (value) =>
      String(value || "")
        .trim()
        .toLocaleLowerCase("tr-TR")
        .replace(/\s+/g, " ");

    const slugifyTyBrand = (value) => {
      const map = {
        ç: "c",
        Ç: "c",
        ğ: "g",
        Ğ: "g",
        ı: "i",
        I: "i",
        İ: "i",
        ö: "o",
        Ö: "o",
        ş: "s",
        Ş: "s",
        ü: "u",
        Ü: "u"
      };
      return String(value || "")
        .split("")
        .map((ch) => map[ch] || ch)
        .join("")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "");
    };

    const extractDirectMagazaUrl = (value) => {
      const text = String(value || "").trim();
      if (!text) return "";
      try {
        const u = new URL(text);
        if (/trendyol\.com$/i.test(u.hostname) && /\/magaza\//i.test(u.pathname)) {
          return u.origin + u.pathname.replace(/\/+$/, "");
        }
      } catch {
        /* ignore */
      }
      return "";
    };

    const readCache = () =>
      new Promise((resolve) => {
        chrome.storage.local.get(TY_SELLER_FOLLOWER_CACHE_KEY, (result) => {
          const cache =
            result && result[TY_SELLER_FOLLOWER_CACHE_KEY] && typeof result[TY_SELLER_FOLLOWER_CACHE_KEY] === "object"
              ? result[TY_SELLER_FOLLOWER_CACHE_KEY]
              : {};
          resolve(cache);
        });
      });

    const writeCache = async (brandKey, magazaUrl) => {
      if (!brandKey || !magazaUrl) return;
      const cache = await readCache();
      cache[brandKey] = {
        magazaUrl,
        updatedAt: new Date().toISOString()
      };
      await chrome.storage.local.set({ [TY_SELLER_FOLLOWER_CACHE_KEY]: cache });
    };

    const scrapeFollowersInTab = async (tabId) => {
      let followerText = "";
      let pageUrl = "";
      for (let attempt = 0; attempt < 8; attempt += 1) {
        const scrape = await chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const el =
              document.querySelector("div.header-card__follow-wrapper__follow-text") ||
              document.querySelector(".header-card__follow-wrapper__follow-text");
            const text = el
              ? String(el.textContent || "")
                  .replace(/\s+/g, " ")
                  .trim()
              : "";
            return {
              followerText: text,
              pageUrl: location.href,
              hasMagazaPath: /\/magaza\//i.test(location.pathname || "")
            };
          }
        });
        const raw = scrape && scrape[0] && scrape[0].result ? scrape[0].result : null;
        if (raw && raw.pageUrl) pageUrl = String(raw.pageUrl);
        if (raw && raw.followerText) {
          followerText = String(raw.followerText).trim();
          break;
        }
        await sleep(700 + attempt * 150);
      }
      return { followerText, pageUrl };
    };

    const findMagazaUrlFromTrendyolSearch = async (tabId, brand) => {
      await waitComplete(tabId);
      await sleep(1800);
      for (let attempt = 0; attempt < 5; attempt += 1) {
        const extracted = await chrome.scripting.executeScript({
          target: { tabId },
          args: [brand],
          func: (brandName) => {
            const normalize = (value) =>
              String(value || "")
                .toLocaleLowerCase("tr-TR")
                .replace(/[^a-z0-9ğüşıöç]+/gi, " ")
                .replace(/\s+/g, " ")
                .trim();
            const brandNorm = normalize(brandName);
            const brandTokens = brandNorm.split(" ").filter(Boolean);
            const scoreUrl = (url, contextText) => {
              let score = 0;
              const path = String(url || "").toLowerCase();
              const ctx = normalize(contextText);
              if (/\/magaza\//i.test(path)) score += 10;
              if (/-m-\d+/i.test(path)) score += 4;
              if (brandNorm && path.includes(brandNorm.replace(/\s+/g, "-"))) score += 8;
              if (brandNorm && ctx.includes(brandNorm)) score += 6;
              brandTokens.forEach((token) => {
                if (token.length >= 3 && path.includes(token)) score += 2;
                if (token.length >= 3 && ctx.includes(token)) score += 1;
              });
              return score;
            };
            const seen = new Set();
            const candidates = [];
            const pushCandidate = (href, contextText) => {
              if (!href) return;
              let abs = String(href);
              try {
                abs = new URL(abs, location.origin).href;
              } catch {
                return;
              }
              if (!/trendyol\.com\/magaza\//i.test(abs)) return;
              const clean = abs.split("?")[0].split("#")[0].replace(/\/+$/, "");
              if (seen.has(clean)) return;
              seen.add(clean);
              candidates.push({
                url: clean,
                score: scoreUrl(clean, contextText)
              });
            };

            document.querySelectorAll('a[href*="/magaza/"]').forEach((a) => {
              pushCandidate(a.getAttribute("href") || a.href || "", a.textContent || "");
            });

            const html = document.documentElement ? document.documentElement.innerHTML : "";
            const re = /https?:\/\/(?:www\.)?trendyol\.com\/magaza\/[a-zA-Z0-9\-_%]+/gi;
            let m;
            while ((m = re.exec(html)) !== null) {
              pushCandidate(m[0], brandName);
            }
            const reRel = /\/magaza\/[a-zA-Z0-9\-_%]+/gi;
            while ((m = reRel.exec(html)) !== null) {
              pushCandidate(m[0], brandName);
            }

            candidates.sort((a, b) => b.score - a.score);
            return candidates.length ? candidates[0].url : "";
          }
        });
        const url =
          extracted && extracted[0] && extracted[0].result
            ? String(extracted[0].result).trim()
            : "";
        if (url && isTyMagazaUrl(url)) return url;
        await sleep(900);
      }
      return "";
    };

    const brandKey = normalizeBrandKey(
      extractDirectMagazaUrl(rawInput) ? extractDirectMagazaUrl(rawInput) : rawInput
    );

    chrome.tabs
      .create({ url: "about:blank", active: false })
      .then(async (tab) => {
        if (!tab || !tab.id) {
          sendResponse({ ok: false, brand: rawInput, error: "Sekme acilamadi." });
          return;
        }
        const tabId = tab.id;
        const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
        try {
          let magazaUrl = extractDirectMagazaUrl(rawInput);

          if (!magazaUrl) {
            const cache = await readCache();
            const cached = cache[brandKey];
            if (cached && cached.magazaUrl && isTyMagazaUrl(cached.magazaUrl)) {
              magazaUrl = String(cached.magazaUrl).trim();
            }
          }

          if (!magazaUrl) {
            const searchUrl =
              "https://www.trendyol.com/sr?q=" + encodeURIComponent(rawInput);
            await chrome.tabs.update(tabId, { url: searchUrl });
            magazaUrl = await findMagazaUrlFromTrendyolSearch(tabId, rawInput);
          }

          if (!magazaUrl) {
            const slug = slugifyTyBrand(rawInput);
            if (slug) {
              const slugUrl = "https://www.trendyol.com/magaza/" + slug;
              await chrome.tabs.update(tabId, { url: slugUrl });
              await waitComplete(tabId);
              await sleep(1600);
              const probe = await scrapeFollowersInTab(tabId);
              if (probe.pageUrl && isTyMagazaUrl(probe.pageUrl)) {
                magazaUrl = probe.pageUrl.split("?")[0].replace(/\/+$/, "");
                if (probe.followerText) {
                  await writeCache(brandKey, magazaUrl);
                  cleanup();
                  sendResponse({
                    ok: true,
                    brand: rawInput,
                    magazaUrl,
                    followerText: probe.followerText
                  });
                  return;
                }
              }
            }
          }

          if (!magazaUrl || !isTyMagazaUrl(magazaUrl)) {
            cleanup();
            sendResponse({
              ok: false,
              brand: rawInput,
              magazaUrl: "",
              followerText: "",
              error: "Trendyol magaza linki bulunamadi. Magaza URL'sini direkt yapistirabilirsiniz."
            });
            return;
          }

          await chrome.tabs.update(tabId, { url: magazaUrl });
          await waitComplete(tabId);
          await sleep(1800);
          const scraped = await scrapeFollowersInTab(tabId);
          const finalUrl = (scraped.pageUrl && isTyMagazaUrl(scraped.pageUrl)
            ? scraped.pageUrl
            : magazaUrl
          )
            .split("?")[0]
            .replace(/\/+$/, "");

          cleanup();
          if (!scraped.followerText) {
            sendResponse({
              ok: false,
              brand: rawInput,
              magazaUrl: finalUrl,
              followerText: "",
              error: "Takipci bilgisi bulunamadi."
            });
            return;
          }

          await writeCache(brandKey, finalUrl);
          sendResponse({
            ok: true,
            brand: rawInput,
            magazaUrl: finalUrl,
            followerText: scraped.followerText
          });
        } catch (err) {
          cleanup();
          sendResponse({
            ok: false,
            brand: rawInput,
            magazaUrl: "",
            followerText: "",
            error: err?.message || "TY Seller Follower hatasi."
          });
        }
      })
      .catch((err) => {
        sendResponse({
          ok: false,
          brand: rawInput,
          magazaUrl: "",
          followerText: "",
          error: err?.message || "Sekme acilamadi."
        });
      });
    return true;
  }
  if (message && message.type === "logo-list-fetch") {
    const url = String(message.url || "").trim();
    if (!url || !/^https?:\/\/mobileapi\.n11\.com\//i.test(url)) {
      sendResponse({ ok: false, error: "Gecersiz logo list URL." });
      return true;
    }
    fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Accept-Language": "tr-TR,tr;q=0.9"
      }
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        sendResponse({ ok: true, data });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "Logo listesi alinamadi." });
      });
    return true;
  }
  if (message && message.type === "product-mailing-fetch-html") {
    const url = String(message.url || "").trim();
    // product sayfasi veya extension template dosyasi: chrome-extension://... da gelebilir.
    if (!/^https?:\/\/.+/i.test(url) && !/^chrome-extension:\/\//i.test(url)) {
      sendResponse({ ok: false, error: "Gecersiz urun URL." });
      return true;
    }
    const isExtensionResource = /^chrome-extension:\/\//i.test(url);
    const fetchOptions = {
      method: "GET",
      headers: {
        Accept: "text/html,application/xhtml+xml,*/*;q=0.9"
      },
      credentials: "omit"
    };
    if (!isExtensionResource) {
      fetchOptions.headers["Accept-Language"] = "tr-TR,tr;q=0.9";
      fetchOptions.headers.Referer = "https://www.n11.com/";
      fetchOptions.headers.Origin = "https://www.n11.com/";
      fetchOptions.headers["User-Agent"] =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    }
    fetch(url, fetchOptions)
      .then((res) => {
        if (!res.ok) {
          throw new Error(isExtensionResource ? "Template dosyasi bulunamadi." : `HTTP ${res.status}`);
        }
        return res.text();
      })
      .then((html) => {
        sendResponse({ ok: true, html });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "Urun sayfasi alinamadi." });
      });
    return true;
  }
  if (message && message.type === "product-match-score-fetch-image-data-url") {
    const url = String(message.url || "").trim();
    if (!/^https?:\/\/.+/i.test(url)) {
      sendResponse({ ok: false, error: "Gecersiz gorsel URL." });
      return true;
    }
    fetchImageAsDataUrl(url)
      .then((dataUrl) => {
        sendResponse({ ok: true, dataUrl });
      })
      .catch((err) => {
        sendResponse({
          ok: false,
          error: err?.message || "Gorsel alinamadi."
        });
      });
    return true;
  }
  if (message && message.type === "price-protector-deep-analysis") {
    const tabId = sender?.tab?.id || null;
    const sendResult = (result, error) => {
      if (tabId) {
        chrome.tabs.sendMessage(tabId, {
          type: "price-protector-deep-analysis-result",
          result,
          error,
          rowIndex: message.rowIndex
        }).catch(() => {});
      }
      sendResponse({ ok: !error });
    };
    runDeepAnalysis(message, sendResult);
    return true;
  }
  if (message && message.type === "akakce-deep-analysis") {
    const tabId = sender?.tab?.id || null;
    const sendResult = (result, error) => {
      if (tabId) {
        chrome.tabs.sendMessage(tabId, {
          type: "akakce-deep-analysis-result",
          result,
          error,
          rowIndex: message.rowIndex
        }).catch(() => {});
      }
      sendResponse({ ok: !error });
    };
    runDeepAnalysis(message, sendResult);
    return true;
  }
  if (message && message.type === "akakce-manuel-update") {
    runManuelUpdateFlow(message, sender, sendResponse, "akakce-manuel-update-result");
    return true;
  }
  if (message && message.type === "price-protector-manuel-update") {
    runManuelUpdateFlow(message, sender, sendResponse, "price-protector-manuel-update-result");
    return true;
  }
  if (message && message.type === "akakce-id-to-n11") {
    const akakceUrl = (message.akakceUrl || "").trim();
    if (!akakceUrl || !akakceUrl.includes("akakce.com")) {
      sendResponse({ ok: false, error: "Geçersiz Akakce URL" });
      return true;
    }
    chrome.tabs.create({ url: akakceUrl, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı" });
        return;
      }
      const tabId = tab.id;
      const extractN11Link = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
          if (!ul) return null;
          const items = ul.querySelectorAll("li");
          for (const li of items) {
            const link = li.querySelector("a[href*='n11.com']");
            if (link && link.href && link.href.includes("n11.com/urun/")) return link.href;
          }
          return null;
        }
      });
      const isCf = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => /Performing security verification|security check|Cloudflare|Just a moment/i.test(document.body?.innerText || "")
      }).then((r) => r && r[0] && r[0].result === true);
      const hasContent = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => Boolean(document.querySelector("ul#PL, [id='PL'], #pd_v8"))
      }).then((r) => r && r[0] && r[0].result === true);
      const waitReady = (n) => {
        if (n >= 5) return Promise.resolve();
        return new Promise((r) => setTimeout(r, n === 0 ? 1000 : 2500))
          .then(() => isCf())
          .then((cf) => cf ? waitReady(n + 1) : hasContent().then((ok) => ok ? Promise.resolve() : waitReady(n + 1)));
      };
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        waitReady(0)
          .then(() => extractN11Link())
          .then((r) => {
            const n11Link = (r && r[0] && r[0].result) ? String(r[0].result).trim() : null;
            chrome.tabs.remove(tabId).catch(() => {});
            sendResponse(n11Link ? { ok: true, n11Link } : { ok: false, error: "n11 linki bulunamadı" });
          })
          .catch((err) => {
            chrome.tabs.remove(tabId).catch(() => {});
            sendResponse({ ok: false, error: err?.message || "Hata" });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    });
    return true;
  }
  if (message && message.type === "akakce-id-to-link") {
    const akakceId = (message.akakceId || "").trim();
    if (!akakceId || !/^\d+$/.test(akakceId)) {
      sendResponse({ ok: false, error: "Geçersiz Akakce ID" });
      return true;
    }
    const googleUrl = "https://www.google.com/search?q=akakce+" + encodeURIComponent(akakceId);
    chrome.tabs.create({ url: googleUrl, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı" });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => { chrome.tabs.remove(tabId).catch(() => {}); };
      const waitComplete = () => new Promise((resolve) => {
        const check = (id, info) => {
          if (id === tabId && info && info.status === "complete") {
            chrome.tabs.onUpdated.removeListener(check);
            resolve();
          }
        };
        chrome.tabs.onUpdated.addListener(check);
        chrome.tabs.get(tabId).then((t) => {
          if (t && t.status === "complete") {
            chrome.tabs.onUpdated.removeListener(check);
            resolve();
          }
        }).catch(() => {});
        setTimeout(() => { chrome.tabs.onUpdated.removeListener(check); resolve(); }, 15000);
      });
      const isCf = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => /Performing security verification|security check|Cloudflare|Just a moment/i.test(document.body?.innerText || "")
      }).then((r) => r && r[0] && r[0].result === true);
      const hasPl = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => Boolean(document.querySelector("ul#PL, [id='PL']"))
      }).then((r) => r && r[0] && r[0].result === true);
      const waitAkakceReady = (n) => {
        if (n >= 5) return Promise.resolve();
        return new Promise((r) => setTimeout(r, n === 0 ? 1500 : 2500))
          .then(() => isCf())
          .then((cf) => cf ? waitAkakceReady(n + 1) : hasPl().then((ok) => ok ? Promise.resolve() : waitAkakceReady(n + 1)));
      };
      waitComplete()
        .then(() => new Promise((r) => setTimeout(r, 2000)))
        .then(() => chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const decodeGoogleRedirect = (href) => {
              let url = String(href || "");
              if (!url) return "";
              if (url.includes("google.com/url")) {
                const m = url.match(/[?&]q=([^&]+)/);
                if (m) url = decodeURIComponent(m[1].replace(/\+/g, " "));
              }
              return url;
            };
            const isGoogleAdResult = (anchor) => {
              if (!anchor) return false;
              const block =
                anchor.closest("div[data-text-ad]") ||
                anchor.closest("div[data-sokoban-container]") ||
                anchor.closest("div[data-pla-slot-pos]") ||
                anchor.closest("div.g") ||
                anchor.parentElement;
              const text = String(block?.innerText || "")
                .replace(/\s+/g, " ")
                .toLowerCase();
              return (
                text.includes("ücretli sponsorlu reklam") ||
                text.includes("sponsorlu reklam") ||
                text.includes("sponsorlu") ||
                text.includes("sponsored")
              );
            };

            const seen = new Set();
            const candidates = Array.from(document.querySelectorAll('a[href*="akakce.com"]'))
              .map((a) => ({
                url: decodeGoogleRedirect(a.href),
                isSponsored: isGoogleAdResult(a)
              }))
              .filter((x) => x.url && x.url.includes("akakce.com"))
              .filter((x) => {
                if (seen.has(x.url)) return false;
                seen.add(x.url);
                return true;
              });

            if (candidates.length > 0) {
              if (candidates[0].isSponsored && candidates[1]) {
                const nextOrganic = candidates.find((x, idx) => idx > 0 && !x.isSponsored);
                return (nextOrganic && nextOrganic.url) || candidates[1].url;
              }
              return candidates[0].url;
            }
            return null;
          }
        }))
        .then((r) => {
          const akakcePageUrl = r && r[0] && r[0].result ? String(r[0].result).trim() : null;
          if (!akakcePageUrl || !akakcePageUrl.includes("akakce.com")) {
            cleanup();
            sendResponse({ ok: false, error: "Akakce sayfası bulunamadı" });
            return;
          }
          return chrome.tabs.update(tabId, { url: akakcePageUrl }).then(() => waitComplete()).then(() => waitAkakceReady(0));
        })
        .then(() => Promise.all([
          chrome.tabs.get(tabId).then((t) => (t && t.url) || null),
          chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const ul = document.querySelector("ul#PL") || document.querySelector("[id='PL']");
              if (!ul) return null;
              const lis = ul.querySelectorAll("li");
              for (const li of lis) {
                const imgs = li.querySelectorAll("img[alt]");
                let hasN11Badge = false;
                let n11Img = null;
                for (const img of imgs) {
                  const alt = (img.getAttribute("alt") || "").trim().toLowerCase();
                  if (alt === "n11") {
                    hasN11Badge = true;
                    n11Img = img;
                    break;
                  }
                }
                const sellerText = (li.querySelector(".v_v8")?.textContent || "").trim();
                const hasN11SellerText = /\bn11\b/i.test(sellerText);
                if (!hasN11Badge && !hasN11SellerText) continue;

                if (n11Img) {
                  const a = n11Img.closest("a");
                  if (a && a.href) return a.href;
                }

                const a = li.querySelector("a[href]");
                if (a && a.href) return a.href;
              }
              return null;
            }
          })
        ]))
        .then(([akakcePageUrl, r]) => {
          let redirectUrl = r && r[0] && r[0].result ? String(r[0].result).trim() : null;
          cleanup();
          if (!redirectUrl || !redirectUrl.includes("akakce.com")) {
            sendResponse({ ok: false, error: "sayfada n11'e ait ürün bulunamadı" });
            return;
          }
          if (!/akakce\.com\/c\/\?/.test(redirectUrl)) {
            try {
              const u = new URL(redirectUrl);
              let qs = u.search ? u.search.slice(1) : "";
              if (u.hash && u.hash.includes("?")) {
                const afterQ = u.hash.split("?")[1] || "";
                if (afterQ) qs = afterQ;
              }
              if (qs) {
                redirectUrl = "https://www.akakce.com/c/?" + qs;
              }
            } catch (e) {}
          }
          sendResponse({
            ok: true,
            akakceUrl: akakcePageUrl || "",
            redirectUrl: redirectUrl
          });
        })
        .catch((err) => {
          cleanup();
          sendResponse({ ok: false, error: err?.message || "Hata" });
        });
    });
    return true;
  }
  if (message && message.type === "akakce-resolve-redirect-to-n11") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("akakce.com")) {
      sendResponse({ ok: false, error: "Geçersiz redirect URL" });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı" });
        return;
      }
      const tabId = tab.id;
      let done = false;
      const finish = (finalUrl) => {
        if (done) return;
        done = true;
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        sendResponse({ ok: true, url: finalUrl || "" });
        chrome.tabs.remove(tabId).catch(() => {});
      };
      const timeout = setTimeout(() => finish(""), 20000);
      const listener = (updatedId, changeInfo, t) => {
        if (updatedId !== tabId) return;
        const u = (changeInfo && changeInfo.url) || (t && t.url) || "";
        if (u && u.includes("n11.com/urun/")) {
          finish(u);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
      const poll = (n) => {
        if (done || n >= 25) return;
        chrome.tabs.get(tabId).then((t) => {
          if (done) return;
          const u = (t && t.url) || "";
          if (u.includes("n11.com/urun/")) {
            finish(u);
          } else {
            setTimeout(() => poll(n + 1), 800);
          }
        }).catch(() => setTimeout(() => poll(n + 1), 800));
      };
      setTimeout(() => poll(0), 1000);
    });
    return true;
  }
  if (message && message.type === "akakce-get-product-id-from-n11") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("n11.com/urun/")) {
      sendResponse({ ok: false, productId: null });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, productId: null });
        return;
      }
      const tabId = tab.id;
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 2500))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              try {
                if (window.model && window.model.product != null && window.model.product.id != null) {
                  return String(window.model.product.id);
                }
                if (window.model && window.model.productMeta != null && window.model.productMeta.productId != null) {
                  return String(window.model.productMeta.productId);
                }
              } catch (e) {}
              return null;
            }
          }))
          .then((r) => {
            const id = r && r[0] && r[0].result ? String(r[0].result) : null;
            chrome.tabs.remove(tabId).catch(() => {});
            sendResponse({ ok: true, productId: id });
          })
          .catch(() => {
            chrome.tabs.remove(tabId).catch(() => {});
            sendResponse({ ok: false, productId: null });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    });
    return true;
  }
  if (message && message.type === "akakce-custom-deal-open-tab-and-select-hepsiburada") {
    const url = String(message.url || "").trim();
    if (!url || !url.includes("akakce.com")) {
      sendResponse({ ok: false, error: "Gecersiz Akakce URL" });
      return true;
    }
    const AKAKCE_DEAL_ALLOWED_PLATFORMS = new Set([
      "tumu",
      "hepsiburada",
      "n11",
      "trendyol",
      "trendyol_plus",
      "amazon",
      "pazarama",
      "pttavm",
      "idefix",
      "teknosa"
    ]);
    const AKAKCE_LIST_FILTER_ID_BY_PLATFORM = {
      hepsiburada: 1195915,
      trendyol: 1207553,
      trendyol_plus: 1235722,
      pttavm: 1196733,
      amazon: 1198774,
      idefix: 1223236,
      teknosa: 1204735
    };
    const AKAKCE_DEAL_FILTER_PASS_ORDER = [
      "hepsiburada",
      "trendyol",
      "trendyol_plus",
      "pttavm",
      "amazon",
      "idefix",
      "teknosa"
    ];
    const rawPlat = message.platforms;
    let finalPlatforms = Array.isArray(rawPlat) && rawPlat.length
      ? rawPlat.map((p) => String(p || "").trim().toLowerCase()).filter((p) => AKAKCE_DEAL_ALLOWED_PLATFORMS.has(p))
      : [];
    if (!finalPlatforms.length) finalPlatforms = ["hepsiburada"];
    finalPlatforms = Array.from(
      new Set(
        finalPlatforms.map((p) => (p === "trendyol_plus" ? "trendyol" : p))
      )
    );
    const knownAkakceFilterIds = Object.values(AKAKCE_LIST_FILTER_ID_BY_PLATFORM);
    const stripAkakceListFilterSuffix = (rawUrl) => {
      try {
        const p = new URL(rawUrl);
        let path = String(p.pathname || "").replace(/\/+$/, "");
        for (let i = 0; i < knownAkakceFilterIds.length; i++) {
          const id = String(knownAkakceFilterIds[i]);
          if (path.endsWith("/" + id)) {
            path = path.slice(0, -(id.length + 1));
            break;
          }
        }
        p.pathname = path;
        return p.toString();
      } catch (e) {
        return rawUrl;
      }
    };
    const withAkakceListFilterSuffix = (rawUrl, filterId) => {
      try {
        const parsed = new URL(rawUrl);
        let path = String(parsed.pathname || "").replace(/\/+$/, "");
        const sid = String(filterId);
        for (let i = 0; i < knownAkakceFilterIds.length; i++) {
          const id = String(knownAkakceFilterIds[i]);
          if (path.endsWith("/" + id)) {
            path = path.slice(0, -(id.length + 1));
            break;
          }
        }
        parsed.pathname = path + "/" + sid;
        return parsed.toString();
      } catch (e) {
        return rawUrl;
      }
    };
    const baseListUrl = stripAkakceListFilterSuffix(url);
    const passes = [];
    const AKAKCE_TUMU_FILL_PLATFORMS = [
      "hepsiburada",
      "trendyol",
      "pttavm",
      "amazon",
      "idefix",
      "teknosa",
      "n11",
      "pazarama",
      "other"
    ];
    if (finalPlatforms.includes("tumu")) {
      finalPlatforms = ["tumu", "n11"];
      passes.push({
        url: baseListUrl,
        fill: AKAKCE_TUMU_FILL_PLATFORMS,
        useFirstRankedPrice: false,
        firstRankedPlatform: "",
        tumuMode: true
      });
    } else {
      AKAKCE_DEAL_FILTER_PASS_ORDER.forEach((plat) => {
        if (plat === "trendyol_plus") {
          if (!finalPlatforms.includes("trendyol")) return;
        } else if (!finalPlatforms.includes(plat)) return;
        const fid = AKAKCE_LIST_FILTER_ID_BY_PLATFORM[plat];
        if (fid == null) return;
        passes.push({
          url: withAkakceListFilterSuffix(baseListUrl, fid),
          fill: [plat, "n11"],
          useFirstRankedPrice: true,
          firstRankedPlatform: plat,
          tumuMode: false
        });
      });
      const platformsNeedingBaseList = finalPlatforms.filter(
        (p) => AKAKCE_LIST_FILTER_ID_BY_PLATFORM[p] == null
      );
      if (platformsNeedingBaseList.length) {
        const baseFillSet = new Set(platformsNeedingBaseList);
        baseFillSet.add("n11");
        passes.push({
          url: baseListUrl,
          fill: Array.from(baseFillSet),
          useFirstRankedPrice: false,
          firstRankedPlatform: "",
          tumuMode: false
        });
      }
      if (passes.length === 0) {
        passes.push({
          url: baseListUrl,
          fill: finalPlatforms,
          useFirstRankedPrice: false,
          firstRankedPlatform: "",
          tumuMode: false
        });
      }
    }
    const firstTabUrl = passes[0].url;
    const senderTabId = sender && sender.tab && sender.tab.id;
    chrome.tabs.create({ url: firstTabUrl, active: true }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Yeni sekme acilamadi." });
        return;
      }
      const tabId = tab.id;
      const mergeFieldByPlatform = {
        tumu: "tumuPrice",
        hepsiburada: "hepsiburadaPrice",
        n11: "n11Price",
        trendyol: "trendyolPrice",
        trendyol_plus: "trendyolPlusPrice",
        amazon: "amazonPrice",
        pazarama: "pazaramaPrice",
        pttavm: "pttavmPrice",
        idefix: "idefixPrice",
        teknosa: "teknosaPrice",
        other: "otherPrice"
      };
      const mergedById = new Map();
      let currentPassFill = passes[0] ? passes[0].fill : finalPlatforms;
      let currentPassOpts = passes[0]
        ? {
            useFirstRankedPrice: !!passes[0].useFirstRankedPrice,
            firstRankedPlatform: passes[0].firstRankedPlatform
              ? String(passes[0].firstRankedPlatform)
              : "",
            tumuMode: !!passes[0].tumuMode
          }
        : { useFirstRankedPrice: false, firstRankedPlatform: "", tumuMode: false };
      let totalPageCountAllPasses = 0;
      const parseAkakcePriceNumberMerge = (raw) => {
        const text = String(raw || "").trim();
        if (!text || text === "-") return null;
        const normalized = text
          .replace(/TL/gi, "")
          .replace(/[^\d,.\-]/g, "")
          .replace(/\./g, "")
          .replace(",", ".");
        const value = Number.parseFloat(normalized);
        return Number.isFinite(value) ? value : null;
      };
      const mergeTrendyolPriceMin = (row, incoming) => {
        const s = String(incoming || "").trim();
        if (!s || s === "-") return;
        const prev = String(row.trendyolPrice || "").trim();
        if (!prev || prev === "-") {
          row.trendyolPrice = s;
          return;
        }
        const nNew = parseAkakcePriceNumberMerge(s);
        const nOld = parseAkakcePriceNumberMerge(prev);
        if (nNew != null && (nOld == null || nNew < nOld)) row.trendyolPrice = s;
      };
      const mergeRowsIntoMap = (rows, fillKeys) => {
        if (!Array.isArray(rows) || !fillKeys || !fillKeys.length) return;
        rows.forEach((r) => {
          const id = String(r.akakceId || "").trim();
          if (!id) return;
          if (!mergedById.has(id)) {
            mergedById.set(id, {
              imageUrl: r.imageUrl || "",
              title: r.title || "",
              url: r.url || "",
              akakceId: id,
              tumuPrice: "-",
              hepsiburadaPrice: "-",
              n11Price: "-",
              trendyolPrice: "-",
              trendyolPlusPrice: "-",
              amazonPrice: "-",
              pazaramaPrice: "-",
              pttavmPrice: "-",
              idefixPrice: "-",
              teknosaPrice: "-",
              otherPrice: "-"
            });
          }
          const row = mergedById.get(id);
          fillKeys.forEach((pk) => {
            const fk = mergeFieldByPlatform[pk];
            if (!fk) return;
            const v = r[fk];
            const s = v != null ? String(v).trim() : "";
            if (!s || s === "-") return;
            if (pk === "trendyol" || pk === "trendyol_plus") {
              mergeTrendyolPriceMin(row, s);
              return;
            }
            row[fk] = s;
          });
          row.trendyolPlusPrice = "-";
          if (r.imageUrl && !row.imageUrl) row.imageUrl = r.imageUrl;
          if (r.title && !row.title) row.title = r.title;
          if (r.url && !row.url) row.url = r.url;
        });
      };
      let finished = false;
      let timeoutId;
      let loadListener = null;
      let lastWasChallenge = false;
      let crawlFlowStarted = false;
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const resetTimeout = (msFromNow) => {
        clearTimeout(timeoutId);
        const ms = typeof msFromNow === "number" ? msFromNow : 120000;
        timeoutId = setTimeout(() => {
          const err = lastWasChallenge
            ? "Guvenlik veya Captcha zaman asimina ugradi. Acik birakilan Akakce sekmesinde dogrulamayi tamamlayip tekrar deneyin."
            : "Sayfa zaman asimina ugradi.";
          finish({ ok: false, error: err }, { keepTabOpen: lastWasChallenge });
        }, ms);
      };
      const finish = (payload, opts) => {
        if (finished) return;
        finished = true;
        clearTimeout(timeoutId);
        if (loadListener) chrome.tabs.onUpdated.removeListener(loadListener);
        sendResponse(payload);
        const keepOpen = opts && opts.keepTabOpen === true;
        if (!keepOpen) chrome.tabs.remove(tabId).catch(() => {});
      };
      const detectAkakceCrawlPageState = () =>
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const cpl = document.querySelector("ul#CPL");
            const liCount = document.querySelectorAll("ul#CPL > li[data-pr]").length;
            const cplExists = !!cpl;
            const hasCpl = liCount > 0;
            const title = (document.title || "").trim();
            if (cplExists || hasCpl) {
              return { isChallenge: false, hasCpl, cplExists, liCount, title };
            }
            const href = String(location.href || "");
            const t = document.body && document.body.innerText ? document.body.innerText : "";
            const tShort = t.length > 4000 ? t.slice(0, 4000) : t;
            let isChallenge = false;
            if (/__cf_chl|__cf_bm=/.test(href)) isChallenge = true;
            if (!isChallenge && /^just a moment\b/i.test(title)) isChallenge = true;
            if (!isChallenge && /^attention required\b|^sorry, you have been blocked\b/i.test(title)) isChallenge = true;
            if (
              !isChallenge &&
              document.querySelector(
                "iframe[src*='challenges.cloudflare.com'], iframe[src*='challenges.cloudflare']"
              )
            ) {
              isChallenge = true;
            }
            if (!isChallenge && document.querySelector("#cf-challenge-running, #challenge-running, .cf-browser-verification")) {
              isChallenge = true;
            }
            if (
              !isChallenge &&
              tShort.length < 900 &&
              /checking your browser|one more step|confirm you are a human|ddos protection by cloudflare/i.test(tShort) &&
              !/akakce|ürün|urun|fiyat|kategori/i.test(tShort)
            ) {
              isChallenge = true;
            }
            return { isChallenge, hasCpl, cplExists, liCount, title };
          }
        });
      const waitUntilAkakceListReady = async (maxMs) => {
        const pollMs = 2000;
        const deadline = Date.now() + maxMs;
        let captchaNotified = false;
        while (Date.now() < deadline) {
          let s = null;
          try {
            const r = await detectAkakceCrawlPageState();
            s = r && r[0] && r[0].result ? r[0].result : null;
          } catch (e) {
            await sleep(pollMs);
            continue;
          }
          if (!s) {
            await sleep(pollMs);
            continue;
          }
          if (s.cplExists || s.hasCpl) {
            lastWasChallenge = false;
            return;
          }
          if (s.isChallenge) {
            lastWasChallenge = true;
            resetTimeout(600000);
            if (!captchaNotified && senderTabId) {
              captchaNotified = true;
              chrome.tabs
                .sendMessage(senderTabId, {
                  type: "akakce-custom-deal-captcha-wait",
                  hint:
                    "Akakce guvenlik dogrulamasi: Acilan sekmede Captcha / robot kontrolunu tamamlayin. Dogrulama bitince liste otomatik devam eder (yaklasik 10 dk beklenir)."
                })
                .catch(() => {});
            }
            await sleep(pollMs);
            continue;
          }
          lastWasChallenge = false;
          await sleep(pollMs);
        }
        throw new Error(
          "Akakce liste alani (ul#CPL) zaman asimina ugradi. Guvenlik sayfasi, captcha veya sayfa yapisi degismis olabilir."
        );
      };
      const waitForCplPricesReady = async () => {
        for (let iter = 0; iter < 45; iter++) {
          try {
            const r = await chrome.scripting.executeScript({
              target: { tabId },
              args: [iter],
              func: (iteration) => {
                const lis = document.querySelectorAll("ul#CPL > li[data-pr]");
                const n = lis.length;
                if (n === 0) return { ok: true, priced: 0, total: 0 };
                let priced = 0;
                lis.forEach((li) => {
                  const a = li.querySelector("a[href]");
                  if (!a) return;
                  const el =
                    a.querySelector("[class*='cmpgn_pt']") ||
                    a.querySelector(".pt_v8, .pt_v9, [class*='pt_v']");
                  const txt = el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : "";
                  if (txt && /\d/.test(txt)) priced++;
                });
                const enough = priced >= n || (priced > 0 && iteration >= 12);
                return { ok: enough, priced, total: n };
              }
            });
            const res = r && r[0] && r[0].result;
            if (res && res.ok) return;
          } catch (e) {}
          await sleep(280);
        }
      };
      const collectCurrentPageRows = (persistentVendorHints) =>
        chrome.scripting.executeScript({
        target: { tabId },
        args: [
          persistentVendorHints && typeof persistentVendorHints === "object" ? persistentVendorHints : {},
          currentPassFill,
          currentPassOpts && typeof currentPassOpts === "object" ? currentPassOpts : {}
        ],
        func: (persistentVendorHints, fillPlatforms, passOpts) => {
          const normalizeUrl = (raw) => {
            const s = String(raw || "").trim();
            if (!s) return "";
            if (s.startsWith("//")) return "https:" + s;
            try {
              return new URL(s, location.origin).href;
            } catch (e) {
              return s;
            }
          };
          const parseAkakceId = (href) => {
            const m = String(href || "").match(/,(\d+)\.html(?:$|\?)/);
            return m && m[1] ? m[1] : "";
          };
          const isAkakceCategoryCQueryUrl = (href) => {
            try {
              const u = new URL(String(href || "").trim(), location.origin);
              if (!/(\.|^)akakce\.com$/i.test(u.hostname)) return false;
              const path = String(u.pathname || "/").replace(/\/+$/, "") || "/";
              return path === "/c" && u.searchParams.has("c");
            } catch (e) {
              return false;
            }
          };
          const looksLikeAkakceProductHref = (href) =>
            /fiyati|,\d+\.html/i.test(String(href || ""));
          const pickMainProductAnchorAndHref = (li) => {
            const candidates = [
              ...li.querySelectorAll("a.iC[href*='fiyati'], a[href*='fiyati']"),
              li.querySelector("a.iC[href]"),
              ...li.querySelectorAll(".w_v8 a[href]")
            ];
            const scan = (requireProductShape) => {
              const seen = new Set();
              for (let i = 0; i < candidates.length; i++) {
                const a = candidates[i];
                if (!a || seen.has(a)) continue;
                seen.add(a);
                const abs = normalizeUrl(a.getAttribute("href") || a.href || "");
                if (!abs || isAkakceCategoryCQueryUrl(abs)) continue;
                if (requireProductShape) {
                  if (!looksLikeAkakceProductHref(abs)) continue;
                } else if (!parseAkakceId(abs)) continue;
                return { anchor: a, href: abs };
              }
              return null;
            };
            return scan(true) || scan(false) || { anchor: null, href: "" };
          };
          const cleanText = (value) => String(value || "").replace(/\s+/g, " ").trim();
          const AKAKCE_N11_VENDOR_IDS = new Set(["11070"]);
          const isAkakceVendorIdN11 = (vid) => AKAKCE_N11_VENDOR_IDS.has(String(vid || "").trim());
          const AKAKCE_VENDOR_ID_PLATFORM = Object.assign(Object.create(null), {
            "11070": "n11",
            "10001": "amazon",
            "10402": "teknosa",
            "10694": "pazarama",
            "11281": "pttavm",
            "11707": "trendyol",
            "12088": "hepsiburada",
            "13275": "idefix",
            "14770": "trendyol"
          });
          const pickAkakceOfferPriceElement = (anchor) => {
            const selGroups = [
              "span.cmpgn_pt_v8, span.cmpgn_pt_v9, [class*='cmpgn_pt']",
              "span.pt_v8, .pt_v8, span.pt_v9, .pt_v9, [class*='pt_v']"
            ];
            for (const sel of selGroups) {
              const nodes = anchor.querySelectorAll(sel);
              for (let i = 0; i < nodes.length; i++) {
                const t = cleanText(nodes[i].textContent);
                if (t && /\d/.test(t)) return nodes[i];
              }
            }
            return null;
          };
          const getAkakceOfferFromAnchor = (anchor) => {
            const priceEl = pickAkakceOfferPriceElement(anchor);
            const priceText = cleanText(priceEl ? priceEl.textContent : "");
            if (!priceText) return null;
            const img = anchor.querySelector("span.l img, i img, img");
            if (!img) return null;
            const alt = cleanText(img.getAttribute("alt") || "");
            const srcRaw = String(img.getAttribute("src") || "").trim();
            const srcNorm = normalizeUrl(srcRaw);
            const hrefRaw = String(anchor.getAttribute("href") || anchor.href || "").trim();
            let v = "";
            try {
              const u = new URL(hrefRaw, location.origin);
              if (/akakce\.com$/i.test(u.hostname)) v = u.searchParams.get("v") || "";
            } catch (e) {}
            const hasM6 = /\/im\/m6\//i.test(srcRaw) || /\/im\/m6\//i.test(srcNorm);
            const mSvg = srcRaw.match(/\/im\/m6\/(\d+)\.svg/i) || srcNorm.match(/\/im\/m6\/(\d+)\.svg/i);
            if (!v && mSvg && mSvg[1]) v = mSvg[1];
            const digitAlt = /^\d+$/.test(alt) || (hasM6 && /^\d+$/.test(v));
            return { priceText, alt, srcRaw, hrefRaw, v, hasM6, digitAlt };
          };
          const getFirstRankedSellerPriceForLi = (li) => {
            const firstAnchor =
              li.querySelector(".p_w_v9 > a:first-child") ||
              li.querySelector(".p_w_v9 > a:first-of-type") ||
              li.querySelector(".p_w_v9 > a");
            if (!firstAnchor) return "-";
            const offer = getAkakceOfferFromAnchor(firstAnchor);
            if (offer && offer.priceText) return offer.priceText;
            const pel = pickAkakceOfferPriceElement(firstAnchor);
            return pel ? cleanText(pel.textContent) : "-";
          };
          const buildAkakceVendorPlatformHints = () => {
            const hints = Object.create(null);
            document.querySelectorAll("a[href*='akakce.com/c/']").forEach((anchor) => {
              const img = anchor.querySelector("img[alt]");
              if (!img) return;
              const alt = cleanText(img.getAttribute("alt") || "");
              let v = "";
              try {
                const u = new URL(anchor.getAttribute("href") || anchor.href, location.origin);
                if (!/akakce\.com$/i.test(u.hostname)) return;
                v = u.searchParams.get("v") || "";
              } catch (e) {
                return;
              }
              if (!v) return;
              const altLow = alt.toLowerCase();
              if (altLow.includes("hepsiburada")) hints[v] = "hb";
              else if (altLow === "n11" || /\bn11\b/.test(altLow)) hints[v] = "n11";
              else if (altLow.includes("trendyol") && altLow.includes("plus")) hints[v] = "trendyol_plus";
              else if (altLow.includes("trendyol")) hints[v] = "trendyol";
              else if (altLow.includes("amazon")) hints[v] = "amazon";
              else if (altLow.includes("pazarama")) hints[v] = "pazarama";
              else if (altLow.includes("ptt") && altLow.includes("avm")) hints[v] = "pttavm";
              else if (altLow.includes("idefix")) hints[v] = "idefix";
              else if (altLow.includes("teknosa")) hints[v] = "teknosa";
              if (!hints[v] && isAkakceVendorIdN11(v)) hints[v] = "n11";
            });
            return hints;
          };
          const isHepsiburadaFilteredListPath = () =>
            /\/1195915(?:\/|$|\?)/.test(String(location.pathname || ""));
          const getHbAndN11PricesForLi = (li, vendorHints) => {
            const hintsEmpty = !vendorHints || Object.keys(vendorHints).length === 0;
            let hb = "-";
            let n11 = "-";
            if (isHepsiburadaFilteredListPath()) {
              const hbAnchor =
                li.querySelector(".p_w_v9 > a:first-child") ||
                li.querySelector(".p_w_v9 > a:first-of-type") ||
                li.querySelector(".p_w_v9 > a");
              if (hbAnchor) {
                const hbOffer = getAkakceOfferFromAnchor(hbAnchor);
                if (hbOffer) hb = hbOffer.priceText;
                else {
                  const pel = pickAkakceOfferPriceElement(hbAnchor);
                  if (pel) hb = cleanText(pel.textContent);
                }
              }
              const pv9Anchors = Array.from(li.querySelectorAll(".p_w_v9 > a"));
              const n11Candidates = hbAnchor ? pv9Anchors.filter((a) => a !== hbAnchor) : pv9Anchors.slice(1);
              const offersHbFilter = [];
              for (let ai = 0; ai < n11Candidates.length; ai++) {
                const o = getAkakceOfferFromAnchor(n11Candidates[ai]);
                if (o) offersHbFilter.push(o);
              }
              const ambiguousHb = [];
              for (let oi = 0; oi < offersHbFilter.length; oi++) {
                const o = offersHbFilter[oi];
                const hrefNorm = normalizeUrl(o.hrefRaw);
                let kind = null;
                if (/^n11$/i.test(o.alt) || /\bn11\b/.test(o.alt) || /n11\.com/i.test(o.hrefRaw) || /n11\.com/i.test(hrefNorm)) {
                  kind = "n11";
                } else if (o.digitAlt && o.hasM6 && o.v && (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v))) {
                  kind = "n11";
                } else if (o.digitAlt && o.hasM6) {
                  ambiguousHb.push(o);
                  continue;
                }
                if (kind === "n11" && n11 === "-") n11 = o.priceText;
              }
              for (let ai = 0; ai < ambiguousHb.length; ai++) {
                const o = ambiguousHb[ai];
                if (
                  o.v &&
                  (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v)) &&
                  n11 === "-"
                ) {
                  n11 = o.priceText;
                }
              }
              if (ambiguousHb.length === 1 && n11 === "-" && hintsEmpty) n11 = ambiguousHb[0].priceText;
              if (ambiguousHb.length >= 2 && n11 === "-") n11 = ambiguousHb[0].priceText;
              return { hb, n11 };
            }
            let anchors = Array.from(
              li.querySelectorAll('a.iC[href*="/c/?"], a.iC[href*="akakce.com/c/?"]')
            );
            if (anchors.length === 0) {
              anchors = Array.from(li.querySelectorAll("div.p_w_v9 a, a"));
            }
            const offers = [];
            for (const anchor of anchors) {
              const o = getAkakceOfferFromAnchor(anchor);
              if (o) offers.push(o);
            }
            hb = "-";
            n11 = "-";
            const ambiguous = [];
            for (const o of offers) {
              const hrefNorm = normalizeUrl(o.hrefRaw);
              let kind = null;
              if (/hepsiburada/i.test(o.alt) || /hepsiburada\.com/i.test(o.hrefRaw) || /hepsiburada\.com/i.test(hrefNorm)) {
                kind = "hb";
              } else if (/^n11$/i.test(o.alt) || /\bn11\b/i.test(o.alt) || /n11\.com/i.test(o.hrefRaw) || /n11\.com/i.test(hrefNorm)) {
                kind = "n11";
              } else if (o.digitAlt && o.hasM6 && o.v && vendorHints[o.v] === "hb") {
                kind = "hb";
              } else if (
                o.digitAlt &&
                o.hasM6 &&
                o.v &&
                (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v))
              ) {
                kind = "n11";
              } else if (o.digitAlt && o.hasM6) {
                ambiguous.push(o);
                continue;
              }
              if (kind === "hb" && hb === "-") hb = o.priceText;
              else if (kind === "n11" && n11 === "-") n11 = o.priceText;
            }
            for (const o of ambiguous) {
              if (o.v && vendorHints[o.v] === "hb" && hb === "-") hb = o.priceText;
              else if (o.v && (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v)) && n11 === "-") {
                n11 = o.priceText;
              }
            }
            if (ambiguous.length === 2 && (hb === "-" || n11 === "-")) {
              if (n11 === "-") n11 = ambiguous[0].priceText;
              if (hb === "-") hb = ambiguous[1].priceText;
            } else if (ambiguous.length > 2 && (hb === "-" || n11 === "-")) {
              ambiguous.forEach((o) => {
                if (o.v && (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v)) && n11 === "-") {
                  n11 = o.priceText;
                }
                if (o.v && vendorHints[o.v] === "hb" && hb === "-") hb = o.priceText;
              });
            } else if (hintsEmpty && ambiguous.length === 1 && hb === "-" && n11 === "-") {
              hb = ambiguous[0].priceText;
            }
            return { hb, n11 };
          };
          const fp = Array.isArray(fillPlatforms) && fillPlatforms.length
            ? fillPlatforms
            : ["hepsiburada", "n11"];
          const firstRanked = !!(passOpts && passOpts.useFirstRankedPrice);
          const tumuMode = !!(passOpts && passOpts.tumuMode);
          const firstRankedPk = passOpts && passOpts.firstRankedPlatform
            ? String(passOpts.firstRankedPlatform).trim()
            : "";
          const firstRankedWithN11 =
            !tumuMode &&
            firstRanked &&
            firstRankedPk &&
            fp.includes(firstRankedPk) &&
            fp.includes("n11");
          const fieldMap = {
            tumu: "tumuPrice",
            hepsiburada: "hepsiburadaPrice",
            n11: "n11Price",
            trendyol: "trendyolPrice",
            trendyol_plus: "trendyolPlusPrice",
            amazon: "amazonPrice",
            pazarama: "pazaramaPrice",
            pttavm: "pttavmPrice",
            idefix: "idefixPrice",
            teknosa: "teknosaPrice",
            other: "otherPrice"
          };
          const emptyPrices = () => ({
            tumuPrice: "-",
            hepsiburadaPrice: "-",
            n11Price: "-",
            trendyolPrice: "-",
            trendyolPlusPrice: "-",
            amazonPrice: "-",
            pazaramaPrice: "-",
            pttavmPrice: "-",
            idefixPrice: "-",
            teknosaPrice: "-",
            otherPrice: "-"
          });
          const buildOffersFromLi = (li) => {
            let anchors = Array.from(
              li.querySelectorAll('a.iC[href*="/c/?"], a.iC[href*="akakce.com/c/?"]')
            );
            if (anchors.length === 0) anchors = Array.from(li.querySelectorAll("div.p_w_v9 a, a"));
            const arr = [];
            for (let i = 0; i < anchors.length; i++) {
              const o = getAkakceOfferFromAnchor(anchors[i]);
              if (o) arr.push(o);
            }
            return arr;
          };
          const assignPricesFromOffers = (offers, vendorHints, want) => {
            const out = emptyPrices();
            const hrefNormFor = (hrefRaw) => normalizeUrl(hrefRaw);
            for (let oi = 0; oi < offers.length; oi++) {
              const o = offers[oi];
              const hrefNorm = hrefNormFor(o.hrefRaw);
              for (let wi = 0; wi < want.length; wi++) {
                const p = want[wi];
                const fk = fieldMap[p];
                if (!fk || out[fk] !== "-") continue;
                let hit = false;
                if (p === "hepsiburada")
                  hit =
                    /hepsiburada/i.test(o.alt) ||
                    /hepsiburada\.com/i.test(o.hrefRaw) ||
                    /hepsiburada\.com/i.test(hrefNorm);
                else if (p === "n11")
                  hit =
                    /^n11$/i.test(o.alt) ||
                    /\bn11\b/.test(o.alt) ||
                    /n11\.com/i.test(o.hrefRaw) ||
                    /n11\.com/i.test(hrefNorm) ||
                    isAkakceVendorIdN11(o.v);
                else if (p === "trendyol")
                  hit =
                    /trendyol/i.test(o.alt) ||
                    /trendyol\.com/i.test(o.hrefRaw) ||
                    /trendyol\.com/i.test(hrefNorm);
                else if (p === "trendyol_plus")
                  hit =
                    (/trendyol/i.test(o.alt) && /plus/i.test(o.alt)) ||
                    /typlus|trendyol.*plus/i.test(o.hrefRaw) ||
                    /typlus|trendyol.*plus/i.test(hrefNorm);
                else if (p === "amazon")
                  hit =
                    /amazon/i.test(o.alt) ||
                    /amazon\.com\.tr/i.test(o.hrefRaw) ||
                    /amazon\.com\.tr/i.test(hrefNorm);
                else if (p === "pazarama")
                  hit =
                    /pazarama/i.test(o.alt) ||
                    /pazarama\.com/i.test(o.hrefRaw) ||
                    /pazarama\.com/i.test(hrefNorm);
                else if (p === "pttavm")
                  hit =
                    /ptt\s*avm/i.test(o.alt) ||
                    /pttavm\.com/i.test(o.hrefRaw) ||
                    /pttavm\.com/i.test(hrefNorm);
                else if (p === "idefix")
                  hit =
                    /idefix/i.test(o.alt) ||
                    /idefix\.com/i.test(o.hrefRaw) ||
                    /idefix\.com/i.test(hrefNorm);
                else if (p === "teknosa")
                  hit =
                    /teknosa/i.test(o.alt) ||
                    /teknosa\.com/i.test(o.hrefRaw) ||
                    /teknosa\.com/i.test(hrefNorm);
                if (hit) out[fk] = o.priceText;
              }
            }
            for (let oi = 0; oi < offers.length; oi++) {
              const o = offers[oi];
              if (!o.digitAlt || !o.hasM6 || !o.v) continue;
              for (let wi = 0; wi < want.length; wi++) {
                const p = want[wi];
                const fk = fieldMap[p];
                if (!fk || out[fk] !== "-") continue;
                if (p === "hepsiburada" && vendorHints[o.v] === "hb") out[fk] = o.priceText;
                else if (
                  p === "n11" &&
                  (vendorHints[o.v] === "n11" || isAkakceVendorIdN11(o.v))
                ) {
                  out[fk] = o.priceText;
                } else if (
                  p !== "hepsiburada" &&
                  p !== "n11" &&
                  p !== "trendyol_plus" &&
                  vendorHints[o.v] === p
                ) {
                  out[fk] = o.priceText;
                } else if (p === "trendyol_plus" && vendorHints[o.v] === "trendyol_plus") {
                  out[fk] = o.priceText;
                }
              }
            }
            return out;
          };
          const normalizeHintToTumuPlatform = (h) => {
            if (!h) return null;
            if (h === "hb") return "hepsiburada";
            if (h === "trendyol_plus") return "trendyol";
            if (
              h === "n11" ||
              h === "trendyol" ||
              h === "amazon" ||
              h === "pazarama" ||
              h === "pttavm" ||
              h === "idefix" ||
              h === "teknosa"
            ) {
              return h;
            }
            return null;
          };
          const classifyTumuPlatform = (o, vendorHints) => {
            if (!o) return null;
            const hrefNorm = normalizeUrl(o.hrefRaw);
            const v = String(o.v || "").trim();
            if (
              /^n11$/i.test(o.alt) ||
              /\bn11\b/.test(o.alt) ||
              /n11\.com/i.test(o.hrefRaw) ||
              /n11\.com/i.test(hrefNorm) ||
              isAkakceVendorIdN11(v)
            ) {
              return "n11";
            }
            if (
              /hepsiburada/i.test(o.alt) ||
              /hepsiburada\.com/i.test(o.hrefRaw) ||
              /hepsiburada\.com/i.test(hrefNorm)
            ) {
              return "hepsiburada";
            }
            if (
              (/trendyol/i.test(o.alt) && /plus/i.test(o.alt)) ||
              /typlus|trendyol.*plus/i.test(o.hrefRaw) ||
              /typlus|trendyol.*plus/i.test(hrefNorm)
            ) {
              return "trendyol";
            }
            if (
              /trendyol/i.test(o.alt) ||
              /trendyol\.com/i.test(o.hrefRaw) ||
              /trendyol\.com/i.test(hrefNorm)
            ) {
              return "trendyol";
            }
            if (
              /amazon/i.test(o.alt) ||
              /amazon\.com\.tr/i.test(o.hrefRaw) ||
              /amazon\.com\.tr/i.test(hrefNorm)
            ) {
              return "amazon";
            }
            if (
              /pazarama/i.test(o.alt) ||
              /pazarama\.com/i.test(o.hrefRaw) ||
              /pazarama\.com/i.test(hrefNorm)
            ) {
              return "pazarama";
            }
            if (
              /ptt\s*avm/i.test(o.alt) ||
              /pttavm\.com/i.test(o.hrefRaw) ||
              /pttavm\.com/i.test(hrefNorm)
            ) {
              return "pttavm";
            }
            if (
              /idefix/i.test(o.alt) ||
              /idefix\.com/i.test(o.hrefRaw) ||
              /idefix\.com/i.test(hrefNorm)
            ) {
              return "idefix";
            }
            if (
              /teknosa/i.test(o.alt) ||
              /teknosa\.com/i.test(o.hrefRaw) ||
              /teknosa\.com/i.test(hrefNorm)
            ) {
              return "teknosa";
            }
            const fromVid = AKAKCE_VENDOR_ID_PLATFORM[v];
            if (fromVid) return fromVid;
            const fromHint = normalizeHintToTumuPlatform(vendorHints[v]);
            if (fromHint) return fromHint;
            return null;
          };
          const parsePriceNumTumu = (text) => {
            const t = cleanText(String(text || ""));
            if (!t || t === "-") return null;
            const normalized = t
              .replace(/TL/gi, "")
              .replace(/[^\d,.\-]/g, "")
              .replace(/\./g, "")
              .replace(",", ".");
            const value = Number.parseFloat(normalized);
            return Number.isFinite(value) ? value : null;
          };
          const offerMatchesAnyTumuTrackedRetailer = (o, vendorHints) =>
            classifyTumuPlatform(o, vendorHints) != null;
          const rows = [];
          const baseHints =
            persistentVendorHints && typeof persistentVendorHints === "object" ? persistentVendorHints : {};
          const localHints = buildAkakceVendorPlatformHints();
          const vendorHints = Object.assign(Object.create(null), baseHints, localHints);
          const hintsThisPage = localHints;
          const items = Array.from(document.querySelectorAll("ul#CPL > li[data-pr]"));
          const wantHbN11 = fp.includes("hepsiburada") || fp.includes("n11");
          const singleFirstRanked =
            !tumuMode && firstRanked && fp.length === 1 && !firstRankedWithN11;
          items.forEach((li) => {
            const picked = pickMainProductAnchorAndHref(li);
            const anchor = picked.anchor;
            const href = picked.href || "";
            if (!anchor || !href) return;
            const img = li.querySelector("figure img");
            const imageUrl = normalizeUrl((img && (img.getAttribute("src") || img.getAttribute("data-src"))) || "");
            const title = String(
              (anchor && (anchor.getAttribute("title") || anchor.textContent)) ||
              (li.querySelector("h3.pn_v8") && li.querySelector("h3.pn_v8").textContent) ||
              (img && img.getAttribute("alt")) ||
              ""
            ).trim();
            const akakceId = parseAkakceId(href) || String(li.getAttribute("data-pr") || "").trim();
            const prices = emptyPrices();
            if (tumuMode) {
              const anchorsPw = li.querySelectorAll(".p_w_v9 > a");
              const bestByField = Object.create(null);
              for (let ai = 0; ai < anchorsPw.length; ai++) {
                const o = getAkakceOfferFromAnchor(anchorsPw[ai]);
                if (!o || !o.priceText) continue;
                const num = parsePriceNumTumu(o.priceText);
                if (num == null) continue;
                const plat = classifyTumuPlatform(o, vendorHints);
                if (!plat) continue;
                const fk = fieldMap[plat];
                if (!fk) continue;
                if (!bestByField[fk] || num < bestByField[fk].num) {
                  bestByField[fk] = { num, text: o.priceText };
                }
              }
              Object.keys(bestByField).forEach((fk) => {
                prices[fk] = bestByField[fk].text;
              });
              const firstPv9 =
                li.querySelector(".p_w_v9 > a:first-child") ||
                li.querySelector(".p_w_v9 > a:first-of-type") ||
                li.querySelector(".p_w_v9 > a");
              if (firstPv9) {
                const firstOffer = getAkakceOfferFromAnchor(firstPv9);
                if (
                  firstOffer &&
                  firstOffer.priceText &&
                  firstOffer.priceText !== "-" &&
                  !offerMatchesAnyTumuTrackedRetailer(firstOffer, vendorHints)
                ) {
                  prices.otherPrice = firstOffer.priceText;
                }
              }
            } else if (firstRankedWithN11) {
              const frfk = fieldMap[firstRankedPk];
              if (frfk) prices[frfk] = getFirstRankedSellerPriceForLi(li);
              const { n11: n11P } = getHbAndN11PricesForLi(li, vendorHints);
              prices.n11Price = n11P;
            } else if (singleFirstRanked) {
              const pk = fp[0];
              const fk = fieldMap[pk];
              if (fk) prices[fk] = getFirstRankedSellerPriceForLi(li);
            } else {
              if (wantHbN11) {
                const { hb: hbP, n11: n11P } = getHbAndN11PricesForLi(li, vendorHints);
                if (fp.includes("hepsiburada")) prices.hepsiburadaPrice = hbP;
                if (fp.includes("n11")) prices.n11Price = n11P;
              }
              const offers = buildOffersFromLi(li);
              const fromOffers = assignPricesFromOffers(offers, vendorHints, fp);
              fp.forEach((p) => {
                const fk = fieldMap[p];
                if (!fk) return;
                if (fromOffers[fk] && fromOffers[fk] !== "-") prices[fk] = fromOffers[fk];
              });
            }
            rows.push({
              imageUrl,
              title,
              akakceId,
              url: href,
              tumuPrice: prices.tumuPrice,
              hepsiburadaPrice: prices.hepsiburadaPrice,
              n11Price: prices.n11Price,
              trendyolPrice: prices.trendyolPrice,
              trendyolPlusPrice: prices.trendyolPlusPrice,
              amazonPrice: prices.amazonPrice,
              pazaramaPrice: prices.pazaramaPrice,
              pttavmPrice: prices.pttavmPrice,
              idefixPrice: prices.idefixPrice,
              teknosaPrice: prices.teknosaPrice,
              otherPrice: prices.otherPrice
            });
          });
          return { rows, hints: hintsThisPage };
        }
      });
      const getNextPageUrl = () => chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const toAbs = (href) => {
            const h = String(href || "").trim();
            if (!h) return "";
            try {
              return new URL(href, location.origin).href;
            } catch (e) {
              return h;
            }
          };
          const nextSelectors = [
            "p.pager_v9 a.p.l[title='Sonraki']",
            "p.pager_v9 a[title='Sonraki']",
            ".pager_w_v9 a.p.l[title='Sonraki']",
            ".pager_w_v9 a[title='Sonraki']",
            "p.pager_v8 a.p[title='Sonraki']",
            "p.pager_v8 a[title='Sonraki']",
            "a.p.l[title='Sonraki']"
          ];
          for (let si = 0; si < nextSelectors.length; si += 1) {
            const next = document.querySelector(nextSelectors[si]);
            if (!next) continue;
            const href = next.getAttribute("href") || next.href || "";
            const abs = toAbs(href);
            if (abs) return abs;
          }
          const path = String(location.pathname || "");
          const cur = path.match(/^(.+?)(?:,(\d+))?\.html$/);
          if (!cur) return "";
          const baseWithSlash = cur[1];
          const curNum = cur[2] ? parseInt(cur[2], 10) : 1;
          if (!Number.isFinite(curNum) || curNum < 1) return "";
          let maxPage = curNum;
          const pagerAnchors = document.querySelectorAll(
            ".pager_v9 a[href], .pager_w_v9 a[href], .pager_v8 a[href], .pager_w_v8 a[href]"
          );
          const baseTail = baseWithSlash.replace(/^\/+/, "");
          pagerAnchors.forEach((a) => {
            const raw = String(a.getAttribute("href") || "").trim().replace(/^\//, "");
            const m = raw.match(/^(.+?),(\d+)\.html(?:$|[?#])/);
            if (!m) return;
            if (m[1] !== baseTail) return;
            const n = parseInt(m[2], 10);
            if (Number.isFinite(n) && n > maxPage) maxPage = n;
          });
          if (curNum >= maxPage) return "";
          const nextPath = `${baseWithSlash},${curNum + 1}.html`;
          try {
            return new URL(nextPath, location.origin).href;
          } catch (e2) {
            return "";
          }
        }
      });
      const waitForTabComplete = () =>
        new Promise((resolve) => {
          const onUpdate = (updatedId, info) => {
            if (updatedId !== tabId || info.status !== "complete") return;
            chrome.tabs.onUpdated.removeListener(onUpdate);
            resolve();
          };
          chrome.tabs.onUpdated.addListener(onUpdate);
          chrome.tabs.get(tabId).then((t) => {
            if (t && t.status === "complete") {
              chrome.tabs.onUpdated.removeListener(onUpdate);
              resolve();
            }
          }).catch(() => {});
        });
      const mergedRowsArray = () => Array.from(mergedById.values());
      const collectPagesForCurrentPass = async () => {
        const maxPages = 120;
        const progressEveryPages = 5;
        const vendorHintsAcc = {};
        for (let i = 0; i < maxPages; i++) {
          resetTimeout(180000);
          await waitForCplPricesReady();
          const pageRowsResult = await collectCurrentPageRows(vendorHintsAcc);
          const pack = pageRowsResult && pageRowsResult[0] ? pageRowsResult[0].result : null;
          const pageRows = pack && Array.isArray(pack.rows) ? pack.rows : [];
          if (pack && pack.hints && typeof pack.hints === "object") {
            Object.assign(vendorHintsAcc, pack.hints);
          }
          const fillKeys =
            currentPassFill && currentPassFill.length ? currentPassFill : finalPlatforms;
          mergeRowsIntoMap(pageRows, fillKeys);
          totalPageCountAllPasses += 1;
          if (senderTabId && totalPageCountAllPasses % progressEveryPages === 0) {
            chrome.tabs.sendMessage(senderTabId, {
              type: "akakce-custom-deal-progress",
              rows: mergedRowsArray(),
              pageCount: totalPageCountAllPasses
            }).catch(() => {});
          }
          const nextResult = await getNextPageUrl();
          const nextUrl = nextResult && nextResult[0] && nextResult[0].result
            ? String(nextResult[0].result).trim()
            : "";
          if (!nextUrl) break;
          await chrome.tabs.update(tabId, { url: nextUrl });
          await waitForTabComplete();
          await sleep(500);
          await waitUntilAkakceListReady(240000);
        }
      };
      const runAllPasses = async () => {
        for (let pi = 0; pi < passes.length; pi++) {
          currentPassFill =
            passes[pi].fill && passes[pi].fill.length ? passes[pi].fill : finalPlatforms;
          currentPassOpts = {
            useFirstRankedPrice: !!passes[pi].useFirstRankedPrice,
            firstRankedPlatform: passes[pi].firstRankedPlatform
              ? String(passes[pi].firstRankedPlatform)
              : "",
            tumuMode: !!passes[pi].tumuMode
          };
          if (pi > 0) {
            resetTimeout(180000);
            await chrome.tabs.update(tabId, { url: passes[pi].url });
            await waitForTabComplete();
            await sleep(500);
            await waitUntilAkakceListReady(240000);
          }
          await collectPagesForCurrentPass();
        }
        if (senderTabId) {
          chrome.tabs
            .sendMessage(senderTabId, {
              type: "akakce-custom-deal-progress",
              rows: mergedRowsArray(),
              pageCount: totalPageCountAllPasses
            })
            .catch(() => {});
        }
        finish({
          ok: true,
          rows: mergedRowsArray(),
          pageCount: Number(totalPageCountAllPasses || 0)
        });
      };
      const startFlow = () => {
        if (crawlFlowStarted) return;
        crawlFlowStarted = true;
        resetTimeout(120000);
        lastWasChallenge = false;
        sleep(800)
          .then(() => waitUntilAkakceListReady(600000))
          .then(() => runAllPasses())
          .catch((err) => {
            finish(
              { ok: false, error: err?.message || "Liste toplama sirasinda hata olustu." },
              { keepTabOpen: lastWasChallenge }
            );
          });
      };
      loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        loadListener = null;
        startFlow();
      };
      resetTimeout(120000);
      chrome.tabs.onUpdated.addListener(loadListener);
      chrome.tabs.get(tabId).then((currentTab) => {
        if (currentTab && currentTab.status === "complete") {
          chrome.tabs.onUpdated.removeListener(loadListener);
          loadListener = null;
          startFlow();
        }
      }).catch(() => {});
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme acma hatasi." });
    });
    return true;
  }
  if (message && message.type === "akakce-full-category-crawl") {
    const rawUrl = String(message.url || "").trim();
    if (!rawUrl || !rawUrl.includes("akakce.com")) {
      sendResponse({ ok: false, error: "Gecersiz Akakce URL" });
      return true;
    }
    let normalizedUrl = rawUrl;
    if (!/^https?:\/\//i.test(normalizedUrl)) normalizedUrl = "https://" + normalizedUrl;
    try {
      const p = new URL(normalizedUrl);
      if (!/(\.|^)akakce\.com$/i.test(p.hostname)) {
        sendResponse({ ok: false, error: "Sadece akakce.com" });
        return true;
      }
    } catch (e) {
      sendResponse({ ok: false, error: "Gecersiz URL" });
      return true;
    }
    const senderTabId = sender && sender.tab && sender.tab.id;
    const notifyStatus = (statusText) => {
      if (!senderTabId || !statusText) return;
      chrome.tabs
        .sendMessage(senderTabId, {
          type: "akakce-full-category-update",
          statusText: String(statusText)
        })
        .catch(() => {});
    };
    chrome.tabs.create({ url: normalizedUrl, active: true }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme acilamadi" });
        return;
      }
      const tabId = tab.id;
      let finished = false;
      let timeoutId;
      let loadListener = null;
      let lastWasChallenge = false;
      let crawlStarted = false;
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const finish = (payload, opts) => {
        if (finished) return;
        finished = true;
        clearTimeout(timeoutId);
        if (loadListener) chrome.tabs.onUpdated.removeListener(loadListener);
        sendResponse(payload);
        const keepOpen = opts && opts.keepTabOpen === true;
        if (!keepOpen) chrome.tabs.remove(tabId).catch(() => {});
      };
      const resetTimeout = (msFromNow) => {
        clearTimeout(timeoutId);
        const ms = typeof msFromNow === "number" ? msFromNow : 300000;
        timeoutId = setTimeout(() => {
          const err = lastWasChallenge
            ? "Captcha zaman asimi. Akakce sekmesinde dogrulamayi tamamlayip tekrar deneyin."
            : "Zaman asimi.";
          finish({ ok: false, error: err }, { keepTabOpen: lastWasChallenge });
        }, ms);
      };
      const detectAkakceCrawlPageState = () =>
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const cpl = document.querySelector("ul#CPL");
            const liCount = document.querySelectorAll("ul#CPL > li[data-pr]").length;
            const cplExists = !!cpl;
            const hasCpl = liCount > 0;
            const title = (document.title || "").trim();
            if (cplExists || hasCpl) {
              return { isChallenge: false, hasCpl, cplExists, liCount, title };
            }
            const href = String(location.href || "");
            const t = document.body && document.body.innerText ? document.body.innerText : "";
            const tShort = t.length > 4000 ? t.slice(0, 4000) : t;
            let isChallenge = false;
            if (/__cf_chl|__cf_bm=/.test(href)) isChallenge = true;
            if (!isChallenge && /^just a moment\b/i.test(title)) isChallenge = true;
            if (!isChallenge && /^attention required\b|^sorry, you have been blocked\b/i.test(title)) {
              isChallenge = true;
            }
            if (
              !isChallenge &&
              document.querySelector(
                "iframe[src*='challenges.cloudflare.com'], iframe[src*='challenges.cloudflare']"
              )
            ) {
              isChallenge = true;
            }
            if (!isChallenge && document.querySelector("#cf-challenge-running, #challenge-running, .cf-browser-verification")) {
              isChallenge = true;
            }
            if (
              !isChallenge &&
              tShort.length < 900 &&
              /checking your browser|one more step|confirm you are a human|ddos protection by cloudflare/i.test(tShort) &&
              !/akakce|ürün|urun|fiyat|kategori/i.test(tShort)
            ) {
              isChallenge = true;
            }
            return { isChallenge, hasCpl, cplExists, liCount, title };
          }
        });
      const waitUntilAkakceListReady = async (maxMs) => {
        const pollMs = 2000;
        const deadline = Date.now() + maxMs;
        let captchaNotified = false;
        while (Date.now() < deadline) {
          let s = null;
          try {
            const r = await detectAkakceCrawlPageState();
            s = r && r[0] && r[0].result ? r[0].result : null;
          } catch (e) {
            await sleep(pollMs);
            continue;
          }
          if (!s) {
            await sleep(pollMs);
            continue;
          }
          if (s.cplExists || s.hasCpl) {
            lastWasChallenge = false;
            return;
          }
          if (s.isChallenge) {
            lastWasChallenge = true;
            resetTimeout(600000);
            if (!captchaNotified) {
              captchaNotified = true;
              notifyStatus(
                "Akakce guvenlik: Acilan sekmede Captcha tamamlayin; liste hazir olunca tarama devam eder."
              );
            }
            await sleep(pollMs);
            continue;
          }
          lastWasChallenge = false;
          await sleep(pollMs);
        }
        throw new Error("Akakce liste (ul#CPL) zaman asimina ugradi.");
      };
      const collectCategoryProducts = () =>
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const normalizeUrl = (raw) => {
              const s = String(raw || "").trim();
              if (!s) return "";
              if (s.startsWith("//")) return "https:" + s;
              try {
                return new URL(s, location.origin).href;
              } catch (e) {
                return s;
              }
            };
            const parseAkakceIdFromHref = (href) => {
              const m = String(href || "").match(/,(\d+)\.html(?:$|\?)/);
              return m && m[1] ? m[1] : "";
            };
            const isAkakceCategoryCQueryUrl = (href) => {
              try {
                const u = new URL(String(href || "").trim(), location.origin);
                if (!/(\.|^)akakce\.com$/i.test(u.hostname)) return false;
                const path = String(u.pathname || "/").replace(/\/+$/, "") || "/";
                return path === "/c" && u.searchParams.has("c");
              } catch (e) {
                return false;
              }
            };
            const looksLikeAkakceProductHref = (href) =>
              /fiyati|,\d+\.html/i.test(String(href || ""));
            const pickMainProductAnchorAndHref = (li) => {
              const candidates = [
                ...li.querySelectorAll("a.iC[href*='fiyati'], a[href*='fiyati']"),
                li.querySelector("a.iC[href]"),
                ...li.querySelectorAll(".w_v8 a[href]")
              ];
              const scan = (requireProductShape) => {
                const seen = new Set();
                for (let i = 0; i < candidates.length; i++) {
                  const a = candidates[i];
                  if (!a || seen.has(a)) continue;
                  seen.add(a);
                  const abs = normalizeUrl(a.getAttribute("href") || a.href || "");
                  if (!abs || isAkakceCategoryCQueryUrl(abs)) continue;
                  if (requireProductShape) {
                    if (!looksLikeAkakceProductHref(abs)) continue;
                  } else if (!parseAkakceIdFromHref(abs)) continue;
                  return { anchor: a, href: abs };
                }
                return null;
              };
              return scan(true) || scan(false) || { anchor: null, href: "" };
            };
            const items = Array.from(document.querySelectorAll("ul#CPL > li[data-pr]"));
            const products = [];
            items.forEach((li) => {
              const picked = pickMainProductAnchorAndHref(li);
              const anchor = picked.anchor;
              if (!anchor) return;
              const hrefRaw = anchor.getAttribute("href") || anchor.href || "";
              const href = normalizeUrl(hrefRaw);
              if (!href || isAkakceCategoryCQueryUrl(href)) return;
              let akakceId = parseAkakceIdFromHref(href);
              if (!akakceId) akakceId = String(li.getAttribute("data-pr") || "").trim();
              const img = li.querySelector("figure img");
              const imageSrc = normalizeUrl(
                (img && (img.getAttribute("src") || img.getAttribute("data-src"))) || ""
              );
              const titleAttr = String(anchor.getAttribute("title") || "").replace(/\s+/g, " ").trim();
              const h3El = li.querySelector("h3.pn_v8");
              const titleH3 = h3El
                ? String(h3El.textContent || "").replace(/\s+/g, " ").trim()
                : "";
              const titleText = String(anchor.textContent || "").replace(/\s+/g, " ").trim();
              const title = titleAttr || titleH3 || titleText;
              if (!href && !akakceId) return;
              products.push({
                akakceId: akakceId || "",
                title: title || "",
                href: href || "",
                imageSrc: imageSrc || ""
              });
            });
            return products;
          }
        });
      const getNextPageUrl = () =>
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const next = document.querySelector(
              "p.pager_v8 a.p[title='Sonraki'], p.pager_v8 a[title='Sonraki']"
            );
            if (!next) return "";
            const href = next.getAttribute("href") || next.href || "";
            if (!href) return "";
            try {
              return new URL(href, location.origin).href;
            } catch (e) {
              return href;
            }
          }
        });
      const waitForTabComplete = () =>
        new Promise((resolve) => {
          const onUpdate = (updatedId, info) => {
            if (updatedId !== tabId || info.status !== "complete") return;
            chrome.tabs.onUpdated.removeListener(onUpdate);
            resolve();
          };
          chrome.tabs.onUpdated.addListener(onUpdate);
          chrome.tabs
            .get(tabId)
            .then((t) => {
              if (t && t.status === "complete") {
                chrome.tabs.onUpdated.removeListener(onUpdate);
                resolve();
              }
            })
            .catch(() => {});
        });
      const runCrawl = async () => {
        const allProducts = [];
        const seenIds = new Set();
        const maxPages = 100;
        let pagesDone = 0;
        notifyStatus("Liste bekleniyor...");
        await sleep(600);
        await waitUntilAkakceListReady(600000);
        for (let pageIdx = 0; pageIdx < maxPages; pageIdx++) {
          resetTimeout(180000);
          const execResult = await collectCategoryProducts();
          const pageList =
            execResult && execResult[0] && Array.isArray(execResult[0].result)
              ? execResult[0].result
              : [];
          for (let pi = 0; pi < pageList.length; pi++) {
            const p = pageList[pi];
            const id = String(p.akakceId || "").trim();
            const dedupeKey = id || String(p.href || "");
            if (!dedupeKey) continue;
            if (seenIds.has(dedupeKey)) continue;
            seenIds.add(dedupeKey);
            allProducts.push(p);
          }
          pagesDone = pageIdx + 1;
          notifyStatus(
            "Sayfa " + pagesDone + " — " + allProducts.length + " urun (benzersiz ID/link)"
          );
          const nextResult = await getNextPageUrl();
          const nextUrl =
            nextResult && nextResult[0] && nextResult[0].result
              ? String(nextResult[0].result).trim()
              : "";
          if (!nextUrl) break;
          await chrome.tabs.update(tabId, { url: nextUrl });
          await waitForTabComplete();
          await sleep(500);
          await waitUntilAkakceListReady(240000);
        }
        finish({
          ok: true,
          products: allProducts,
          pageCount: pagesDone,
          sourceUrl: normalizedUrl
        });
      };
      const startFlow = () => {
        if (crawlStarted || finished) return;
        crawlStarted = true;
        resetTimeout(120000);
        lastWasChallenge = false;
        sleep(800)
          .then(() => runCrawl())
          .catch((err) => {
            finish(
              { ok: false, error: err?.message || "Kategori tarama hatasi." },
              { keepTabOpen: lastWasChallenge }
            );
          });
      };
      loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        loadListener = null;
        startFlow();
      };
      resetTimeout(120000);
      chrome.tabs.onUpdated.addListener(loadListener);
      chrome.tabs.get(tabId).then((currentTab) => {
        if (currentTab && currentTab.status === "complete") {
          chrome.tabs.onUpdated.removeListener(loadListener);
          loadListener = null;
          startFlow();
        }
      }).catch(() => {});
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme acma hatasi." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-n11-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("n11.com")) {
      sendResponse({ ok: false, error: "Geçersiz n11 linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 2600))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: extractN11ProductPagePriceInPage
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "n11 indirimli fiyat bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Fiyat okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "listing-crawler-get-trendyol-price-by-title") {
    const title = (message.title || "").trim();
    if (!title) {
      sendResponse({ ok: false, error: "Ürün adı gerekli." });
      return true;
    }
    const readFirstTrendyolSearchProductUrl = (tabId) =>
      chrome.scripting
        .executeScript({
          target: { tabId },
          func: () => {
            const clean = (v) => String(v == null ? "" : v).replace(/\s+/g, " ").trim();
            const toAbs = (href) => {
              const h = clean(href);
              if (!h) return "";
              if (/^https?:\/\//i.test(h)) return h.split("?")[0];
              if (h.startsWith("//")) return `https:${h}`.split("?")[0];
              try {
                return new URL(h, "https://www.trendyol.com").href.split("?")[0];
              } catch (e) {
                return "";
              }
            };
            const isProductHref = (href) => /-p-\d+/i.test(String(href || ""));
            const selectors = [
              '[data-testid="product-card"] a[href*="-p-"]',
              ".p-card-wrppr a[href*='-p-']",
              ".product-card a[href*='-p-']",
              "div[class*='product-listing'] a[href*='-p-']",
              "a[href*='-p-']"
            ];
            for (let s = 0; s < selectors.length; s += 1) {
              const nodes = Array.from(document.querySelectorAll(selectors[s]));
              for (let i = 0; i < nodes.length; i += 1) {
                const href = nodes[i].getAttribute("href") || nodes[i].href || "";
                if (!isProductHref(href)) continue;
                const abs = toAbs(href);
                if (abs) return { url: abs };
              }
            }
            return { url: "" };
          }
        })
        .then((result) => {
          const data = result && result[0] ? result[0].result : null;
          return data && data.url ? String(data.url).trim() : "";
        });
    const query = encodeURIComponent(title).replace(/%20/g, "+");
    const searchUrl = `https://www.trendyol.com/sr?q=${query}`;
    chrome.tabs
      .create({ url: searchUrl, active: false })
      .then((tab) => {
        if (!tab || !tab.id) {
          sendResponse({ ok: false, error: "Sekme açılamadı." });
          return;
        }
        const searchTabId = tab.id;
        const cleanupSearch = () => chrome.tabs.remove(searchTabId).catch(() => {});
        const searchLoadListener = (updatedId, info) => {
          if (updatedId !== searchTabId || info.status !== "complete") return;
          chrome.tabs.onUpdated.removeListener(searchLoadListener);
          new Promise((r) => setTimeout(r, 2400))
            .then(() => readFirstTrendyolSearchProductUrl(searchTabId))
            .then((productUrl) => {
              cleanupSearch();
              if (!productUrl) {
                sendResponse({ ok: false, error: "Trendyol aramasında ürün bulunamadı." });
                return null;
              }
              return fetchTrendyolProductDetailInTab(productUrl).then((detail) => ({
                productUrl,
                detail
              }));
            })
            .then((payload) => {
              if (!payload) return;
              const detail = payload.detail;
              if (!detail || !detail.ok || !detail.product) {
                sendResponse({
                  ok: false,
                  error: (detail && detail.error) || "Trendyol ürün fiyatı okunamadı.",
                  url: payload.productUrl
                });
                return;
              }
              const product = detail.product;
              const price =
                product.sepettePriceText ||
                product.discountedPriceText ||
                product.normalPriceText ||
                "";
              if (!price) {
                sendResponse({
                  ok: false,
                  error: "Trendyol fiyatı ürün sayfasında bulunamadı.",
                  url: product.url || payload.productUrl
                });
                return;
              }
              sendResponse({
                ok: true,
                price: String(price).trim(),
                url: product.url || payload.productUrl,
                name: product.name || ""
              });
            })
            .catch((err) => {
              cleanupSearch().finally(() => {
                sendResponse({
                  ok: false,
                  error: err?.message || "Trendyol fiyatı okunamadı."
                });
              });
            });
        };
        chrome.tabs.onUpdated.addListener(searchLoadListener);
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
      });
    return true;
  }
  if (message && message.type === "trendyol-bestsellers-get-n11-price-by-title") {
    const title = (message.title || "").trim();
    if (!title) {
      sendResponse({ ok: false, error: "Ürün adı gerekli." });
      return true;
    }
    const readFirstSearchResult = (tabId) => chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        if (document.querySelector(".empty-search-result")) return { url: "" };
        const searchRoot = document.querySelector("div.searchResults");
        if (!searchRoot) return { url: "" };
        const links = Array.from(searchRoot.querySelectorAll("a[href*='/urun/']"))
          .filter((a) => !a.closest(".emptySearchResult-productSlider"));
        const linkEl = links[0] || null;
        if (!linkEl) return { url: "" };
        const href = linkEl ? (linkEl.getAttribute("href") || "") : "";
        const abs = href
          ? (href.startsWith("http") ? href : `https://www.n11.com${href.startsWith("/") ? "" : "/"}${href}`)
          : "";
        return { url: abs };
      }
    }).then((result) => {
      const data = result && result[0] ? result[0].result : null;
      return data && data.url ? String(data.url).trim() : "";
    });
    const readPriceFromProductPage = (tabId) => chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: extractN11ProductPagePriceInPage
    }).then((result) => {
      return result && result[0] && result[0].result ? String(result[0].result).trim() : "";
    });
    const query = encodeURIComponent(title).replace(/%20/g, "+");
    const url = `https://www.n11.com/arama?q=${query}`;
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const searchTabId = tab.id;
      let productTabId = null;
      const cleanup = () => {
        const tasks = [chrome.tabs.remove(searchTabId).catch(() => {})];
        if (productTabId != null) tasks.push(chrome.tabs.remove(productTabId).catch(() => {}));
        return Promise.all(tasks);
      };
      const searchLoadListener = (updatedId, info) => {
        if (updatedId !== searchTabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(searchLoadListener);
        new Promise((r) => setTimeout(r, 2600))
          .then(() => readFirstSearchResult(searchTabId))
          .then((productUrl) => {
            if (!productUrl) throw new Error("n11 ürün linki bulunamadı.");
            return chrome.tabs.create({ url: productUrl, active: false }).then((productTab) => ({ productUrl, productTab }));
          })
          .then(({ productUrl, productTab }) => {
            if (!productTab || !productTab.id) throw new Error("Ürün sekmesi açılamadı.");
            productTabId = productTab.id;
            return new Promise((resolve, reject) => {
              const productLoadListener = (updatedProductId, productInfo) => {
                if (updatedProductId !== productTabId || productInfo.status !== "complete") return;
                chrome.tabs.onUpdated.removeListener(productLoadListener);
                new Promise((r) => setTimeout(r, 1400))
                  .then(() => readPriceFromProductPage(productTabId))
                  .then((price) => resolve({ price, productUrl }))
                  .catch(reject);
              };
              chrome.tabs.onUpdated.addListener(productLoadListener);
            });
          })
          .then(({ price, productUrl }) => {
            cleanup().finally(() => {
              if (!price) {
                sendResponse({ ok: false, error: "n11 fiyatı ürün sayfasında bulunamadı." });
                return;
              }
              sendResponse({ ok: true, price, url: productUrl });
            });
          })
          .catch((err) => {
            cleanup().finally(() => {
              sendResponse({ ok: false, error: err?.message || "n11 fiyatı okunamadı." });
            });
          });
      };
      chrome.tabs.onUpdated.addListener(searchLoadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-trendyol-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("trendyol.com")) {
      sendResponse({ ok: false, error: "Geçersiz Trendyol linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1200))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const discountedCandidates = [];
              const tyPlusCandidates = [];
              const parseTrPrice = (val) => {
                if (val == null) return null;
                let s = String(val).trim();
                if (!s) return null;
                s = s.replace(/TL/gi, "").replace(/\s+/g, "").replace(/\./g, "").replace(/,/g, ".");
                const n = Number(s);
                return Number.isFinite(n) ? n : null;
              };
              const pushCandidate = (arr, val) => {
                if (val == null) return;
                const s = String(val).trim();
                if (!s) return;
                arr.push(s);
              };
              const pickFromObject = (obj) => {
                try {
                  pushCandidate(discountedCandidates, obj?.price?.discountedPrice?.text);
                  pushCandidate(tyPlusCandidates, obj?.price?.tyPlusCouponApplicablePrice?.text);
                } catch (e) {}
              };
              const pickBestPrice = () => {
                const discounted = discountedCandidates
                  .map((v) => ({ raw: v, num: parseTrPrice(v) }))
                  .filter((x) => x.num != null);
                const tyPlus = tyPlusCandidates
                  .map((v) => ({ raw: v, num: parseTrPrice(v) }))
                  .filter((x) => x.num != null);
                const discountedMin = discounted.length
                  ? discounted.reduce((a, b) => (a.num <= b.num ? a : b))
                  : null;
                const tyPlusMin = tyPlus.length
                  ? tyPlus.reduce((a, b) => (a.num <= b.num ? a : b))
                  : null;
                if (tyPlusMin && (!discountedMin || tyPlusMin.num < discountedMin.num)) {
                  return tyPlusMin.raw;
                }
                if (discountedMin) return discountedMin.raw;
                return null;
              };
              const scanObject = (root) => {
                const visited = new Set();
                const stack = [root];
                while (stack.length) {
                  const cur = stack.pop();
                  if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
                  visited.add(cur);
                  pickFromObject(cur);
                  if (Array.isArray(cur)) {
                    for (const item of cur) stack.push(item);
                  } else {
                    for (const val of Object.values(cur)) {
                      if (val && typeof val === "object") stack.push(val);
                    }
                  }
                }
              };

              const winKeys = Object.keys(window || {});
              for (const k of winKeys) {
                if (!k || !k.includes("PROPS")) continue;
                try {
                  const v = window[k];
                  scanObject(v);
                } catch (e) {}
              }

              const scripts = document.querySelectorAll("script");
              for (const scriptEl of scripts) {
                const text = scriptEl.textContent || "";
                if (!text || !text.includes("price")) continue;
                const discountedMatches = text.matchAll(/"discountedPrice"\s*:\s*\{[\s\S]*?"text"\s*:\s*"([^"]+)"/gi);
                for (const m of discountedMatches) {
                  if (m && m[1]) pushCandidate(discountedCandidates, m[1]);
                }
                const tyPlusMatches = text.matchAll(/"tyPlusCouponApplicablePrice"\s*:\s*\{[\s\S]*?"text"\s*:\s*"([^"]+)"/gi);
                for (const m of tyPlusMatches) {
                  if (m && m[1]) pushCandidate(tyPlusCandidates, m[1]);
                }
              }
              return pickBestPrice();
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "price.discountedPrice.text / tyPlusCouponApplicablePrice.text bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Trendyol fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-hepsiburada-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("hepsiburada.com")) {
      sendResponse({ ok: false, error: "Geçersiz Hepsiburada linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 2600))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: async () => {
              const parseTrPrice = (val) => {
                if (val == null) return null;
                let s = String(val).trim();
                if (!s) return null;
                s = s.replace(/TL/gi, "").replace(/\s+/g, "").replace(/\./g, "").replace(/,/g, ".");
                const n = Number(s);
                return Number.isFinite(n) ? n : null;
              };
              const formatPrice = (val) => {
                const n = parseTrPrice(val);
                if (n == null) return null;
                return n.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
              };
              const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
              const pushCandidate = (val) => {
                if (val == null) return;
                const s = String(val).trim();
                return s || null;
              };
              const extractPremiumPrice = () => {
                const roots = [];
                const nonPremiumRoot = document.querySelector('[data-test-id="non-premium-price"]');
                if (nonPremiumRoot) roots.push(nonPremiumRoot);
                roots.push(document.body);
                const priceRegex = /premium\s*ile[\s\S]{0,80}?(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL/i;
                for (const root of roots) {
                  if (!root) continue;
                  const nodes = Array.from(root.querySelectorAll("span,div,p,b,strong"));
                  for (const node of nodes) {
                    const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
                    if (!text) continue;
                    const m = text.match(priceRegex);
                    if (m && m[1]) return `${m[1]} TL`;
                  }
                }
                return null;
              };
              const extractCheckoutPrice = () => {
                const boxes = Array.from(document.querySelectorAll('[data-test-id="checkout-price"]'));
                if (!boxes.length) return null;
                const labelRegex = /sepete\s*ozel\s*fiyat|sepete\s*özel\s*fiyat/i;
                const priceRegexWithTl = /(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL/gi;
                const priceRegexPlain = /\d{1,3}(?:\.\d{3})*(?:,\d{2})?/g;
                const strictPriceOnly = /^\s*(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL\s*$/i;
                for (const box of boxes) {
                  const boxText = String(box.textContent || "").trim();
                  if (!boxText) continue;
                  const normalized = boxText.toLocaleLowerCase("tr-TR");
                  if (!labelRegex.test(normalized)) continue;

                  // Prefer exact value nodes inside checkout-price (avoids campaign/earning numbers).
                  const valueNodes = Array.from(box.querySelectorAll("div,span,p,b,strong"))
                    .map((node) => String(node.textContent || "").replace(/\s+/g, " ").trim())
                    .filter(Boolean);
                  for (const nodeText of valueNodes) {
                    const strictMatch = nodeText.match(strictPriceOnly);
                    if (strictMatch && strictMatch[1]) {
                      return `${strictMatch[1]} TL`;
                    }
                  }

                  const withTlMatches = Array.from(boxText.matchAll(priceRegexWithTl));
                  if (withTlMatches.length) {
                    const raw = withTlMatches[0][1];
                    if (raw) return `${raw} TL`;
                  }
                  const plainMatches = boxText.match(priceRegexPlain) || [];
                  if (plainMatches.length) return `${plainMatches[0]} TL`;
                }
                return null;
              };
              const extractPriceBlockPrice = () => {
                const priceBlocks = Array.from(document.querySelectorAll('[data-test-id="price"]'));
                const strictPriceOnly = /^\s*(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL\s*$/i;
                for (const block of priceBlocks) {
                  const checkout = block.querySelector('[data-test-id="checkout-price"]');
                  const scope = checkout || block;
                  const nodes = Array.from(scope.querySelectorAll("div,span,p,b,strong"));
                  for (const node of nodes) {
                    const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
                    if (!text) continue;
                    const m = text.match(strictPriceOnly);
                    if (m && m[1]) return `${m[1]} TL`;
                  }
                }
                return null;
              };
              const extractVariantBoxPrice = () => {
                const direct = document.querySelector('[data-test-id="variant-box-price"]');
                if (direct) {
                  const text = String(direct.textContent || "").trim();
                  const m = text.match(/(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL/i);
                  if (m && m[1]) return `${m[1]} TL`;
                }
                const defaultPrice = document.querySelector('[data-test-id="default-price"]');
                if (defaultPrice) {
                  const text = String(defaultPrice.textContent || "").trim();
                  const m = text.match(/(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*TL/i);
                  if (m && m[1]) return `${m[1]} TL`;
                }
                return null;
              };
              const extractFromMetaAndSchema = () => {
                const metaAmount = document.querySelector('meta[property="product:price:amount"]');
                if (metaAmount) {
                  const fromMeta = formatPrice(metaAmount.getAttribute("content") || "");
                  if (fromMeta) return fromMeta;
                }
                const itemPropPrice = document.querySelector('[itemprop="price"]');
                if (itemPropPrice) {
                  const fromItemProp = formatPrice(itemPropPrice.getAttribute("content") || itemPropPrice.textContent || "");
                  if (fromItemProp) return fromItemProp;
                }
                const scriptEls = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
                for (const scriptEl of scriptEls) {
                  const text = (scriptEl.textContent || "").trim();
                  if (!text) continue;
                  try {
                    const data = JSON.parse(text);
                    const stack = [data];
                    while (stack.length) {
                      const cur = stack.pop();
                      if (!cur) continue;
                      if (Array.isArray(cur)) {
                        cur.forEach((item) => stack.push(item));
                        continue;
                      }
                      if (typeof cur !== "object") continue;
                      const typeVal = Array.isArray(cur["@type"]) ? cur["@type"].join(",") : String(cur["@type"] || "");
                      const isProduct = /product/i.test(typeVal);
                      if (isProduct) {
                        const offerObj = cur.offers;
                        const offerList = Array.isArray(offerObj) ? offerObj : (offerObj ? [offerObj] : []);
                        for (const offer of offerList) {
                          if (!offer || typeof offer !== "object") continue;
                          const fromOffer = formatPrice(offer.price || offer.lowPrice || offer.highPrice);
                          if (fromOffer) return fromOffer;
                        }
                        const fromProduct = formatPrice(cur.price || cur.lowPrice || cur.highPrice);
                        if (fromProduct) return fromProduct;
                      }
                      Object.values(cur).forEach((v) => {
                        if (v && typeof v === "object") stack.push(v);
                      });
                    }
                  } catch (e) {}
                }
                return null;
              };
              const extractStructuredFallbackPrice = () => {
                const candidates = [];
                const blockedPathRe = /(cargo|kargo|shipping|delivery|freight|installment|taksit|fee|commission|wallet|coupon|discount|sepet|basket)/i;
                const preferredPathRe = /(product|variant|offer|merchant|buybox|priceInfo|sale|final|list|current|sku)/i;
                const addCandidateWithPath = (val, path) => {
                  const s = pushCandidate(val);
                  if (!s) return;
                  const cleanPath = String(path || "");
                  if (blockedPathRe.test(cleanPath)) return;
                  const n = parseTrPrice(s);
                  if (n == null) return;
                  candidates.push({ raw: s, num: n, score: preferredPathRe.test(cleanPath) ? 2 : 1 });
                };
                const scanObject = (root) => {
                  const visited = new Set();
                  const stack = [{ value: root, path: "" }];
                  while (stack.length) {
                    const entry = stack.pop();
                    const cur = entry && entry.value;
                    const currentPath = entry && entry.path ? entry.path : "";
                    if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
                    visited.add(cur);
                    if (Object.prototype.hasOwnProperty.call(cur, "formattedPrice")) {
                      addCandidateWithPath(cur.formattedPrice, currentPath + ".formattedPrice");
                    }
                    if (Array.isArray(cur)) {
                      for (let i = 0; i < cur.length; i++) {
                        stack.push({ value: cur[i], path: `${currentPath}[${i}]` });
                      }
                    } else {
                      for (const [key, val] of Object.entries(cur)) {
                        if (/(^|_)(price|fiyat|amount|value)$/i.test(key) || /(price|fiyat|amount|value)/i.test(key)) {
                          addCandidateWithPath(val, `${currentPath}.${key}`);
                        }
                        if (val && typeof val === "object") {
                          stack.push({ value: val, path: `${currentPath}.${key}` });
                        }
                      }
                    }
                  }
                };
                try {
                  if (window.__INITIAL_STATE__) scanObject(window.__INITIAL_STATE__);
                } catch (e) {}
                try {
                  const keys = Object.keys(window || {});
                  for (const k of keys) {
                    if (!k || !/STATE|PROPS|DATA|PRODUCT/i.test(k)) continue;
                    const v = window[k];
                    if (v && typeof v === "object") scanObject(v);
                  }
                } catch (e) {}
                const scripts = document.querySelectorAll("script");
                for (const scriptEl of scripts) {
                  const text = scriptEl.textContent || "";
                  if (!text || (!text.includes("formattedPrice") && !text.includes("\"price\""))) continue;
                  const matches = text.matchAll(/"formattedPrice"\s*:\s*"([^"]+)"/gi);
                  for (const m of matches) {
                    if (m && m[1]) addCandidateWithPath(m[1], "script.formattedPrice");
                  }
                  const explicitPriceMatches = text.matchAll(/"(?:finalPrice|salePrice|currentPrice|listingPrice|discountedPrice|price)"\s*:\s*"?(\d{1,3}(?:\.\d{3})*(?:,\d{2})?|\d+(?:[.,]\d+)?)"?/gi);
                  for (const m of explicitPriceMatches) {
                    if (m && m[1]) addCandidateWithPath(m[1], "script.explicitPrice");
                  }
                }
                const parsed = candidates
                  .map((entry) => {
                    if (typeof entry === "string") {
                      const num = parseTrPrice(entry);
                      return num == null ? null : { raw: entry, num, score: 0 };
                    }
                    return entry && entry.num != null ? entry : null;
                  })
                  .filter(Boolean);
                if (!parsed.length) return null;
                parsed.sort((a, b) => {
                  if (b.score !== a.score) return b.score - a.score;
                  return b.num - a.num;
                });
                return formatPrice(parsed[0].raw);
              };

              let fallbackPrice = null;
              for (let attempt = 0; attempt < 14; attempt++) {
                const checkoutPrice = extractCheckoutPrice();
                if (checkoutPrice) return checkoutPrice;

                const priceBlockPrice = extractPriceBlockPrice();
                if (priceBlockPrice) return priceBlockPrice;

                const variantBoxPrice = extractVariantBoxPrice();
                if (variantBoxPrice) return variantBoxPrice;

                const premiumPrice = extractPremiumPrice();
                if (premiumPrice) return premiumPrice;

                const schemaPrice = extractFromMetaAndSchema();
                if (schemaPrice) return schemaPrice;

                const structuredFallback = extractStructuredFallbackPrice();
                if (structuredFallback) fallbackPrice = structuredFallback;
                if (attempt < 13) await sleep(500);
              }
              return fallbackPrice;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "formattedPrice bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Hepsiburada fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-amazon-price") {
    const url = (message.url || "").trim();
    if (!url || !/amazon\./i.test(url)) {
      sendResponse({ ok: false, error: "Geçersiz Amazon linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1400))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const prices = [];
              const parsePriceNum = (raw) => {
                if (raw == null) return null;
                let s = String(raw).trim();
                if (!s) return null;
                s = s.replace(/TL/gi, "").replace(/\s+/g, "").replace(/\./g, "").replace(/,/g, ".");
                const n = Number(s);
                return Number.isFinite(n) ? n : null;
              };
              const isUnavailableState = () => {
                const selectors = [
                  "#availability",
                  "#outOfStock",
                  "#availabilityInsideBuyBox_feature_div",
                  ".primary-availability-message",
                  "[data-feature-name='availabilityInsideBuyBox']",
                  "[data-csa-c-type='availability']"
                ];
                const unavailableRe = /şu anda mevcut değil|stokta yok|tükendi|currently unavailable|temporarily out of stock|out of stock|unavailable/i;
                for (const sel of selectors) {
                  const nodes = document.querySelectorAll(sel);
                  for (const node of nodes) {
                    const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
                    if (text && unavailableRe.test(text)) return true;
                  }
                }
                const bodyText = String(document.body?.innerText || "").replace(/\s+/g, " ").trim();
                return unavailableRe.test(bodyText);
              };
              const addCandidate = (whole, fraction) => {
                const w = (whole || "").replace(/[^\d.]/g, "").trim();
                const f = (fraction || "").replace(/[^\d]/g, "").trim();
                if (!w) return;
                const text = f ? `${w},${f}` : w;
                const num = parsePriceNum(text);
                if (num == null) return;
                prices.push({ raw: text, num });
              };

              const addRawCandidate = (raw) => {
                if (raw == null) return;
                const sourceText = String(raw).replace(/\s+/g, " ").trim();
                if (/\/\s*ay|ayda|taksit|installment/i.test(sourceText)) return;
                const s = sourceText.replace(/TL/gi, "").trim();
                if (!s) return;
                const num = parsePriceNum(s);
                if (num == null) return;
                prices.push({ raw: s, num });
              };

              if (isUnavailableState()) return null;

              // Prefer Amazon's "price to pay" block first.
              const apexBlocks = document.querySelectorAll(
                "#corePrice_feature_div .a-price, " +
                "#corePriceDisplay_desktop_feature_div .a-price, " +
                "#apex_desktop .a-price, " +
                "#tp_price_block_total_price_ww .a-price, " +
                "#exports_desktop_qualifiedBuyBox .a-price, " +
                ".apex-core-price-identifier .apex-pricetopay-value, " +
                ".apex-core-price-identifier .a-price"
              );
              for (const block of apexBlocks) {
                const offscreen = block.querySelector(".a-offscreen")?.textContent || "";
                if (offscreen) {
                  addRawCandidate(offscreen);
                }
                const whole = block.querySelector(".a-price-whole")?.textContent || "";
                const fraction = block.querySelector(".a-price-fraction")?.textContent || "";
                addCandidate(whole, fraction);
              }
              if (prices.length) {
                const minApex = prices.reduce((a, b) => (a.num <= b.num ? a : b));
                return minApex.raw;
              }

              const directPriceNodes = document.querySelectorAll(
                "#priceblock_ourprice, #priceblock_dealprice, #priceblock_saleprice, #corePriceDisplay_desktop_feature_div .a-offscreen, #corePrice_feature_div .a-offscreen"
              );
              for (const node of directPriceNodes) {
                addRawCandidate(node.textContent || "");
              }
              if (!prices.length) return null;
              const min = prices.reduce((a, b) => (a.num <= b.num ? a : b));
              return min.raw;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "Amazon fiyatı (.a-price-whole/.a-price-fraction) bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Amazon fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-pazarama-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("pazarama.com")) {
      sendResponse({ ok: false, error: "Geçersiz Pazarama linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1400))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const parseTrPrice = (raw) => {
                if (raw == null) return null;
                const s = String(raw).trim();
                if (!s) return null;
                const normalized = s
                  .replace(/TL/gi, "")
                  .replace(/\s+/g, "")
                  .replace(/\./g, "")
                  .replace(/,/g, ".");
                const n = Number(normalized);
                return Number.isFinite(n) ? n : null;
              };
              const extractPricesFromText = (text) => {
                if (!text) return [];
                const matches = text.match(/\d{1,3}(?:\.\d{3})*,\d{2}\s*TL|\d{1,3}(?:\.\d{3})*,\d{2}/g) || [];
                return matches
                  .map((m) => ({ raw: m.replace(/\s+/g, " ").trim(), num: parseTrPrice(m) }))
                  .filter((x) => x.num != null);
              };
              const detailRoot = document.querySelector('div[page-name="detail"]') || document;
              const isInsideOtherSellers = (el) => {
                if (!el || typeof el.closest !== "function") return false;
                return Boolean(
                  el.closest(
                    ".product__other-sellers, [class*='other-sellers'], [class*='otherSeller'], [class*='other-seller']"
                  )
                );
              };

              // 1) Prefer product-level Plus price when available.
              const plusCandidates = [];
              const collectPlusFromBlock = (block) => {
                if (!block) return;
                if (isInsideOtherSellers(block)) return;
                const strongNodes = block.querySelectorAll("span.font-bold.text-blue-500, span[class*='text-blue-500'], span[class*='font-bold']");
                for (const node of strongNodes) {
                  if (isInsideOtherSellers(node)) continue;
                  const prices = extractPricesFromText(node.textContent || "");
                  plusCandidates.push(...prices);
                }
                if (!plusCandidates.length) {
                  const allPrices = extractPricesFromText(block.textContent || "");
                  plusCandidates.push(...allPrices);
                }
              };

              const explicitPlusBlocks = document.querySelectorAll(
                "div.bg-pink-40, div[class*='bg-pink-40'], div[class*='border-pink-500']"
              );
              for (const block of explicitPlusBlocks) {
                if (isInsideOtherSellers(block)) continue;
                if (!detailRoot.contains(block)) continue;
                const txt = (block.textContent || "").toLowerCase();
                if (!txt.includes("plus") && !txt.includes("ile")) continue;
                collectPlusFromBlock(block);
              }

              const plusIconImgs = detailRoot.querySelectorAll("img[alt='plus-icon'], img[src*='pz-plus-icon']");
              for (const img of plusIconImgs) {
                if (isInsideOtherSellers(img)) continue;
                const block = img.closest("div");
                collectPlusFromBlock(block);
              }

              if (plusCandidates.length) {
                const plusMin = plusCandidates.reduce((a, b) => (a.num <= b.num ? a : b));
                return plusMin.raw;
              }

              // 2) Prefer "SEPETTE" discounted price in product area.
              const sepetteNodes = Array.from(detailRoot.querySelectorAll("div, span, p, strong, b"))
                .filter((el) => (el.textContent || "").trim().toUpperCase() === "SEPETTE" && !isInsideOtherSellers(el));
              for (const sepetteEl of sepetteNodes) {
                const nextText = sepetteEl.nextElementSibling?.textContent || "";
                const nextPrices = extractPricesFromText(nextText);
                if (nextPrices.length) {
                  return nextPrices[0].raw;
                }
                const parentText = sepetteEl.parentElement?.textContent || "";
                const parentMatch = parentText.match(/SEPETTE[\s\S]{0,80}?(\d{1,3}(?:\.\d{3})*,\d{2})\s*TL/i);
                if (parentMatch && parentMatch[1]) {
                  return parentMatch[1];
                }
              }

              // 3) Prefer main PDP final price block (exclude other sellers).
              const mainPriceNodes = detailRoot.querySelectorAll(
                ".b8e-text-scalable p.text-4xl, .b8e-text-scalable p[class*='text-4xl'], p.text-4xl, p[class*='text-4xl']"
              );
              for (const node of mainPriceNodes) {
                if (isInsideOtherSellers(node)) continue;
                const prices = extractPricesFromText(node.textContent || "");
                if (prices.length) {
                  return prices[0].raw;
                }
              }

              // 4) Fallback: normal price area (large text on PDP).
              const normalCandidates = [];
              const normalNodes = detailRoot.querySelectorAll("div.text-4xl, div[class*='text-4xl'], span.text-4xl, span[class*='text-4xl']");
              for (const node of normalNodes) {
                if (isInsideOtherSellers(node)) continue;
                const prices = extractPricesFromText(node.textContent || "");
                normalCandidates.push(...prices);
              }
              if (normalCandidates.length) {
                return normalCandidates[0].raw;
              }

              // Avoid broad page-wide fallback to prevent unrelated prices.
              return null;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "Pazarama fiyatı bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Pazarama fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-pttavm-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("pttavm.com")) {
      sendResponse({ ok: false, error: "Geçersiz PttAVM linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1400))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const getDiscountedPriceTextFromObject = (root) => {
                if (!root || typeof root !== "object") return "";
                const stack = [root];
                const visited = new Set();
                while (stack.length) {
                  const cur = stack.pop();
                  if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
                  visited.add(cur);
                  if (Object.prototype.hasOwnProperty.call(cur, "discountedPriceText")) {
                    const val = String(cur.discountedPriceText || "").trim();
                    if (val) return val;
                  }
                  if (Array.isArray(cur)) {
                    for (const item of cur) stack.push(item);
                  } else {
                    for (const val of Object.values(cur)) {
                      if (val && typeof val === "object") stack.push(val);
                    }
                  }
                }
                return "";
              };

              const scripts = document.querySelectorAll("script");
              for (const script of scripts) {
                const text = script.textContent || "";
                if (!text || !text.includes("__staticRouterHydrationData") || !text.includes("JSON.parse(")) continue;

                const parseCallMatch = text.match(/JSON\.parse\((\"[\s\S]*?\")\)/);
                if (parseCallMatch && parseCallMatch[1]) {
                  try {
                    const hydrationJsonText = JSON.parse(parseCallMatch[1]);
                    const hydrationObj = JSON.parse(hydrationJsonText);
                    const found = getDiscountedPriceTextFromObject(hydrationObj);
                    if (found) return found;
                  } catch {}
                }

                const rawMatch = text.match(/"discountedPriceText"\s*:\s*"([^"]+)"/);
                if (rawMatch && rawMatch[1]) {
                  return String(rawMatch[1]).trim();
                }
              }

              return "";
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "PttAVM fiyatı bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "PttAVM fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-idefix-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("idefix.com")) {
      sendResponse({ ok: false, error: "Geçersiz idefix linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1400))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const parseTrPrice = (raw) => {
                if (raw == null) return null;
                const s = String(raw).trim();
                if (!s) return null;
                const normalized = s
                  .replace(/TL/gi, "")
                  .replace(/[^\d.,]/g, "")
                  .replace(/\./g, "")
                  .replace(/,/g, ".");
                const n = Number(normalized);
                return Number.isFinite(n) ? n : null;
              };
              const candidates = [];
              const pushCandidate = (raw) => {
                if (raw == null) return;
                const txt = String(raw).trim();
                if (!txt) return;
                const num = parseTrPrice(txt);
                if (num == null) return;
                candidates.push({ raw: txt, num });
              };

              const ogSaleMeta = document.querySelector("meta[property='og:price:sale_price']");
              const ogSaleContent = (ogSaleMeta && ogSaleMeta.getAttribute("content")) ? String(ogSaleMeta.getAttribute("content")).trim() : "";
              if (ogSaleContent) {
                return ogSaleContent;
              }

              const scripts = document.querySelectorAll("script");
              for (const script of scripts) {
                const text = script.textContent || "";
                if (!text) continue;
                const match = text.match(/"discountedPriceText"\s*:\s*"([^"]+)"/i);
                if (match && match[1]) {
                  return String(match[1]).trim();
                }
              }

              const jsonLdScripts = document.querySelectorAll("script[type='application/ld+json']");
              for (const script of jsonLdScripts) {
                const text = script.textContent || "";
                if (!text) continue;
                try {
                  const parsed = JSON.parse(text);
                  const stack = [parsed];
                  const visited = new Set();
                  while (stack.length) {
                    const cur = stack.pop();
                    if (!cur || typeof cur !== "object" || visited.has(cur)) continue;
                    visited.add(cur);
                    if (Object.prototype.hasOwnProperty.call(cur, "price")) {
                      pushCandidate(cur.price);
                    }
                    if (Array.isArray(cur)) {
                      for (const item of cur) stack.push(item);
                    } else {
                      for (const val of Object.values(cur)) {
                        if (val && typeof val === "object") stack.push(val);
                      }
                    }
                  }
                } catch {}
              }

              const itemPropPrice = document.querySelectorAll("[itemprop='price']");
              for (const el of itemPropPrice) {
                pushCandidate(el.getAttribute("content"));
                pushCandidate(el.textContent || "");
              }

              const visiblePriceNodes = document.querySelectorAll("[class*='price'], [id*='price']");
              for (const el of visiblePriceNodes) {
                pushCandidate(el.textContent || "");
              }

              if (!candidates.length) return null;
              const min = candidates.reduce((a, b) => (a.num <= b.num ? a : b));
              return min.raw;
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "idefix fiyatı bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "idefix fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-teknosa-price") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("teknosa.com")) {
      sendResponse({ ok: false, error: "Geçersiz Teknosa linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1300))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const visiblePiInput = document.querySelector("input#visiblePi");
              const visiblePiValue = visiblePiInput ? String(visiblePiInput.value || "").trim() : "";
              if (visiblePiValue) return visiblePiValue;

              const ogSaleMeta = document.querySelector("meta[property='og:price:sale_price']");
              const ogSaleContent = ogSaleMeta ? String(ogSaleMeta.getAttribute("content") || "").trim() : "";
              if (ogSaleContent) return ogSaleContent;

              const ogAmountMeta = document.querySelector("meta[property='og:price:amount']");
              const ogAmountContent = ogAmountMeta ? String(ogAmountMeta.getAttribute("content") || "").trim() : "";
              if (ogAmountContent) return ogAmountContent;

              const itemPropPrice = document.querySelector("[itemprop='price']");
              const itemPropContent = itemPropPrice ? String(itemPropPrice.getAttribute("content") || itemPropPrice.textContent || "").trim() : "";
              if (itemPropContent) return itemPropContent;

              return "";
            }
          }))
          .then((result) => {
            cleanup();
            const price = result && result[0] && result[0].result != null
              ? String(result[0].result).trim()
              : "";
            if (!price) {
              sendResponse({ ok: false, error: "Teknosa fiyatı bulunamadı." });
              return;
            }
            sendResponse({ ok: true, price });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Teknosa fiyatı okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "product-price-tracking-get-product-meta") {
    const url = (message.url || "").trim();
    if (!url || !/^https?:\/\//i.test(url)) {
      sendResponse({ ok: false, error: "Geçersiz ürün linki." });
      return true;
    }
    chrome.tabs.create({ url, active: false }).then((tab) => {
      if (!tab || !tab.id) {
        sendResponse({ ok: false, error: "Sekme açılamadı." });
        return;
      }
      const tabId = tab.id;
      const cleanup = () => chrome.tabs.remove(tabId).catch(() => {});
      const loadListener = (updatedId, info) => {
        if (updatedId !== tabId || info.status !== "complete") return;
        chrome.tabs.onUpdated.removeListener(loadListener);
        new Promise((r) => setTimeout(r, 1000))
          .then(() => chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const absUrl = (val) => {
                if (!val) return "";
                try {
                  return new URL(String(val), window.location.origin).href;
                } catch {
                  return String(val);
                }
              };
              const title =
                (window?.model?.product?.title && String(window.model.product.title).trim())
                || (document.querySelector("meta[property='og:title']")?.getAttribute("content") || "").trim()
                || (document.querySelector("h1")?.textContent || "").trim()
                || (document.title || "").trim();
              const image =
                absUrl(document.querySelector("div.img-wrapper-onBoard img.thumbnail-img-0")?.getAttribute("src"))
                || absUrl(document.querySelector("div.img-wrapper-onBoard img.thumbnail-img-0")?.getAttribute("data-src"))
                || absUrl(document.querySelector("meta[property='og:image']")?.getAttribute("content"))
                || absUrl(document.querySelector("img")?.getAttribute("src"));
              return { title: title || "", image: image || "" };
            }
          }))
          .then((result) => {
            cleanup();
            const meta = result && result[0] && result[0].result ? result[0].result : {};
            sendResponse({ ok: true, title: String(meta.title || "").trim(), image: String(meta.image || "").trim() });
          })
          .catch((err) => {
            cleanup();
            sendResponse({ ok: false, error: err?.message || "Ürün bilgisi okunamadı." });
          });
      };
      chrome.tabs.onUpdated.addListener(loadListener);
    }).catch((err) => {
      sendResponse({ ok: false, error: err?.message || "Sekme açılamadı." });
    });
    return true;
  }
  if (message && message.type === "akakce-fetch-n11-page") {
    const url = (message.url || "").trim();
    if (!url || !url.includes("n11.com/urun/")) {
      return Promise.resolve({ ok: false, error: "Geçersiz n11 ürün linki." });
    }
    return fetch(url, { credentials: "omit" })
      .then((res) => (res.ok ? res.text() : Promise.reject(new Error("Sayfa alınamadı."))))
      .then((html) => ({ ok: true, html }))
      .catch((err) => ({ ok: false, error: err && err.message ? err.message : "İstek başarısız." }));
  }
  if (message && message.type === "open-bo-product-management") {
    const productId = String(message.productId || "").trim();
    if (!productId) {
      sendResponse({ ok: false, error: "Product ID bulunamadı." });
      return false;
    }
    const sourceUrl = sender?.tab?.url || "";
    const isQaHost = sourceUrl.includes("://qa.n11.com/");
    const targetUrl = isQaHost
      ? "https://qabo.n11.com/backoffice/product/sellerProductManagementView.xhtml"
      : "https://bo.n11.com/backoffice/product/sellerProductManagementView.xhtml";
    chrome.tabs
      .create({
        url: targetUrl,
        active: true
      })
      .then((tab) => {
        if (!tab || !tab.id) {
          sendResponse({ ok: false, error: "Yeni sekme açılamadı." });
          return;
        }
        const tabId = tab.id;
        const listener = (updatedId, info) => {
          if (updatedId !== tabId || info.status !== "complete") {
            return;
          }
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.tabs.sendMessage(
            tabId,
            { action: "bo-product-search", productId },
            (response) => {
              if (chrome.runtime.lastError || !response || !response.success) {
                sendResponse({
                  ok: false,
                  error: response?.error || "BO ürün araması başlatılamadı."
                });
                return;
              }
              sendResponse({ ok: true });
            }
          );
        };
        chrome.tabs.onUpdated.addListener(listener);
      })
      .catch((error) => {
        sendResponse({ ok: false, error: String(error) });
      });
    return true;
  }
  if (message && message.type === "resolve-campaign-id-by-slug") {
    const campaignSlug = String(message.campaignSlug || "").trim();
    if (!campaignSlug) {
      sendResponse({ ok: false, error: "Kampanya path bulunamadı." });
      return false;
    }
    let isResolved = false;
    const failSafeTimeout = setTimeout(() => {
      if (isResolved) return;
      isResolved = true;
      sendResponse({ ok: false, error: "Kampanya araması zaman aşımına uğradı." });
    }, 25000);
    chrome.tabs
      .create({
        url: "https://bo.n11.com/backoffice/campaign/campaigns.xhtml",
        active: false
      })
      .then((tab) => {
        if (!tab || !tab.id) {
          sendResponse({ ok: false, error: "Yeni sekme açılamadı." });
          return;
        }
        const tabId = tab.id;
        const cleanup = () => {
          clearTimeout(failSafeTimeout);
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.tabs.remove(tabId).catch(() => {});
        };
        const listener = (updatedId, info) => {
          if (updatedId !== tabId || info.status !== "complete") {
            return;
          }
          chrome.tabs.onUpdated.removeListener(listener);
          const payload = { action: "bo-campaign-id-by-slug", campaignSlug };
          let attempts = 0;
          const maxAttempts = 8;
          const trySend = () => {
            attempts += 1;
            chrome.tabs.sendMessage(tabId, payload, (response) => {
              if (chrome.runtime.lastError || !response || !response.success) {
                if (attempts < maxAttempts) {
                  setTimeout(trySend, 500);
                  return;
                }
                cleanup();
                if (isResolved) return;
                isResolved = true;
                sendResponse({
                  ok: false,
                  error: response?.error || "BO kampanya araması başlatılamadı."
                });
                return;
              }
              cleanup();
              if (isResolved) return;
              isResolved = true;
              sendResponse({ ok: true, campaignId: response.campaignId || "" });
            });
          };
          setTimeout(trySend, 500);
        };
        chrome.tabs.onUpdated.addListener(listener);
      })
      .catch((error) => {
        clearTimeout(failSafeTimeout);
        if (isResolved) return;
        isResolved = true;
        sendResponse({ ok: false, error: String(error) });
      });
    return true;
  }
  if (!message || message.type !== "collect-n11-links") {
    if (message && message.type === "bo-collect") {
      const matchUrls = [
        "https://bo.n11.com/backoffice/exhibition/promotionProducts.xhtml*",
        "https://stbo.n11.com/backoffice/exhibition/promotionProducts.xhtml*"
      ];
      chrome.tabs
        .query({ url: matchUrls })
        .then((tabs) => {
          const target = tabs[0];
          if (!target || !target.id) {
            sendResponse({ ok: false, error: "BO promosyon sayfası bulunamadı." });
            return;
          }
          chrome.tabs.sendMessage(target.id, { action: "collectProductIds" }, (response) => {
            if (chrome.runtime.lastError || !response || !response.success) {
              sendResponse({
                ok: false,
                error: response?.error || "Ürün ID toplanamadı."
              });
              return;
            }
            sendResponse({ ok: true, products: response.data || [] });
          });
        })
        .catch((error) => {
          sendResponse({ ok: false, error: String(error) });
        });
      return true;
    }

    if (message && (message.type === "clear-dynamic-page-cache" || message.action === "clear-dynamic-page-cache")) {
      const dynamicPageId = String(message.dynamicPageId || "").trim();
      if (!dynamicPageId) {
        sendResponse({ ok: false, error: "Dynamic Page ID bulunamadı." });
        return false;
      }
      chrome.tabs
        .create({
          url: "https://bo.n11.com/backoffice/dynamicPageManagement/dynamicPageManagement.xhtml",
          active: true
        })
        .then((tab) => {
          if (!tab || !tab.id) {
            sendResponse({ ok: false, error: "Yeni sekme açılamadı." });
            return;
          }
          const tabId = tab.id;
          const listener = (updatedId, info, updatedTab) => {
            if (updatedId !== tabId || info.status !== "complete") {
              return;
            }
            chrome.tabs.onUpdated.removeListener(listener);
            const payload = { action: "clearDynamicPageCache", dynamicPageId };
            let attempts = 0;
            const maxAttempts = 6;
            const trySend = () => {
              attempts += 1;
              chrome.tabs.sendMessage(tabId, payload, (response) => {
                if (chrome.runtime.lastError || !response || !response.success) {
                  if (attempts < maxAttempts) {
                    setTimeout(trySend, 500);
                    return;
                  }
                  sendResponse({
                    ok: false,
                    error: response?.error || "Cache temizleme başlatılamadı."
                  });
                  return;
                }
                sendResponse({ ok: true });
              });
            };
            setTimeout(trySend, 500);
          };
          chrome.tabs.onUpdated.addListener(listener);
        })
        .catch((error) => {
          sendResponse({ ok: false, error: String(error) });
        });
      return true;
    }

    return false;
  }

  collectN11Links(Boolean(message.productOnly), sender?.tab?.windowId)
    .then((links) => {
      sendResponse({ ok: true, links });
    })
    .catch((error) => {
      sendResponse({ ok: false, error: String(error) });
    });

  return true;
});
