/**
 * SEO analysis rules (step-by-step build).
 * Current scope: head opening meta order rule.
 */
(function (global) {
    "use strict";

    function runN11SeoAnalysis(doc, win) {
        const findings = [];
        const head = doc && doc.head ? doc.head : null;

        if (!head) {
            findings.push({
                severity: "error",
                category: "seo",
                code: "head-missing",
                message: "<head> bolumu bulunamadi.",
                detail: "Meta sira kontrolu yapilamadi.",
                problem: "Sayfada head bolumu algilanamadi.",
                impact: "Tarayiciya baslangic kurallari verilemez; analiz saglikli ilerlemez.",
                solution: "HTML yapisini duzeltip head bolumunu dogru sekilde ekleyin."
            });
            return {
                url: win && win.location ? String(win.location.href || "") : "",
                pageTitle: doc && doc.title ? String(doc.title) : "",
                findings: findings,
                counts: { ok: 0, info: 0, warn: 0, error: 1 },
                disclaimer: "Sadece head acilis meta sira kurali calistirildi."
            };
        }

        const expectedSelectors = [
            'meta[charset]',
            'meta[http-equiv="x-ua-compatible" i]',
            'meta[name="viewport" i]'
        ];
        const expectedLabels = [
            'meta[charset="utf-8"]',
            'meta[http-equiv="x-ua-compatible" content="ie=edge"]',
            'meta[name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"]'
        ];

        const normalized = function (s) { return String(s || "").trim().toLowerCase(); };

        const titleEl = head.querySelector("title");
        const headChildren = Array.from(head.children || []);
        const titleIndex = titleEl ? headChildren.indexOf(titleEl) : -1;

        const foundEls = expectedSelectors.map(function (selector) {
            return head.querySelector(selector);
        });
        const foundIndexes = foundEls.map(function (el) {
            return el ? headChildren.indexOf(el) : -1;
        });

        const missing = [];
        for (let i = 0; i < foundEls.length; i++) {
            if (!foundEls[i]) missing.push(expectedLabels[i]);
        }

        let valueMismatch = [];
        if (foundEls[0]) {
            const cs = normalized(foundEls[0].getAttribute("charset"));
            if (cs !== "utf-8" && cs !== "utf8") {
                valueMismatch.push('charset "' + cs + '" (beklenen utf-8)');
            }
        }
        if (foundEls[1]) {
            const xua = normalized(foundEls[1].getAttribute("content"));
            if (xua !== "ie=edge") {
                valueMismatch.push('x-ua-compatible "' + xua + '" (beklenen ie=edge)');
            }
        }
        if (foundEls[2]) {
            const vp = normalized(foundEls[2].getAttribute("content"));
            if (vp !== "width=device-width, initial-scale=1, shrink-to-fit=no") {
                valueMismatch.push('viewport "' + vp + '" (beklenen width=device-width, initial-scale=1, shrink-to-fit=no)');
            }
        }

        let orderIssue = "";
        if (!missing.length) {
            const isSequential = foundIndexes[0] < foundIndexes[1] && foundIndexes[1] < foundIndexes[2];
            const beforeTitle = titleIndex < 0 || (foundIndexes[2] < titleIndex);
            const startsFromTop = foundIndexes[0] === 0 && foundIndexes[1] === 1 && foundIndexes[2] === 2;
            if (!isSequential) orderIssue = "Meta etiket sirasi bozuk.";
            else if (!beforeTitle) orderIssue = "Meta etiketler <title> etiketinden once konumlanmamis.";
            else if (!startsFromTop) orderIssue = "Meta etiketler head icerisinde ilk 3 satirda degil.";
        }

        if (missing.length || valueMismatch.length || orderIssue) {
            const issueParts = [];
            if (missing.length) issueParts.push("Eksik etiket: " + missing.join(", "));
            if (valueMismatch.length) issueParts.push("Yanlis deger: " + valueMismatch.join(", "));
            if (orderIssue) issueParts.push(orderIssue);
            findings.push({
                severity: "warn",
                category: "seo",
                code: "head-meta-order-warn",
                message: "Sayfanin en ust teknik ayarlari eksik veya sirasi yanlis.",
                detail: "Head acilis meta kontrolunde uyumsuzluk bulundu.",
                problem: issueParts.join(" / "),
                impact: "Tarayici sayfayi gec veya yanlis yorumlayabilir; Turkce karakterler bozulabilir ve mobil cizim gecikmesi yasabilirsiniz.",
                solution: "charset, x-ua-compatible ve viewport etiketlerini head'in en basina, title'dan once ve beklenen degerlerle yerlestirin."
            });
        } else {
            findings.push({
                severity: "ok",
                category: "seo",
                code: "head-meta-order-ok",
                message: "Head baslangic ayarlari dogru yerde.",
                detail: "Head acilis meta kontrolu basarili.",
                problem: "Sorun yok.",
                impact: "Tarayici sayfayi ilk andan itibaren dogru yorumlar.",
                solution: "Mevcut konumu koruyun."
            });
        }

        const counts = { ok: 0, info: 0, warn: 0, error: 0 };
        findings.forEach(function (f) {
            if (counts[f.severity] != null) counts[f.severity]++;
        });

        return {
            url: win && win.location ? String(win.location.href || "") : "",
            pageTitle: doc && doc.title ? String(doc.title) : "",
            findings: findings,
            counts: counts,
            disclaimer: "Sadece head acilis meta sira kurali calistirildi."
        };
    }

    function escHtml(s) {
        return String(s == null ? "" : s)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    function formatN11SeoAnalysisHtml(result) {
        const findings = result && Array.isArray(result.findings) ? result.findings : [];
        const f = findings[0] || null;
        const sevClass = !f ? "seo-sev-info" : (f.severity === "ok" ? "seo-sev-ok" : f.severity === "warn" ? "seo-sev-warn" : "seo-sev-error");
        const statusLabel = !f ? "Bilgi yok" : (f.severity === "ok" ? "Uygun" : "Duzenleme gerekli");
        return (
            '<div class="seo-analysis-summary">' +
            '<div class="seo-analysis-counts">' +
            '<span class="seo-count ' + (f && f.severity === "ok" ? "seo-count-ok" : "seo-count-warn") + '">' + statusLabel + "</span>" +
            "</div>" +
            '<p class="seo-analysis-disclaimer">' + escHtml(result && result.disclaimer ? result.disclaimer : "") + "</p>" +
            "</div>" +
            '<div class="seo-analysis-section">' +
            '<div class="seo-analysis-section-title">Head Meta Sirasi</div>' +
            '<ul class="seo-analysis-list">' +
            '<li class="seo-analysis-item ' + sevClass + '">' +
            '<span class="seo-analysis-item-title"><strong>Kontrol Sonucu:</strong> ' + escHtml(f ? f.message : "Sonuc yok") + "</span>" +
            '<span class="seo-analysis-item-detail">' + escHtml(f ? f.detail : "") + "</span>" +
            '<div class="seo-analysis-columns">' +
            '<div class="seo-analysis-col">' +
            '<div class="seo-analysis-col-title">Sorun ne?</div>' +
            '<div class="seo-analysis-col-text">' + escHtml(f && f.problem ? f.problem : "-") + "</div>" +
            "</div>" +
            '<div class="seo-analysis-col">' +
            '<div class="seo-analysis-col-title">Bu neye sebep olur?</div>' +
            '<div class="seo-analysis-col-text">' + escHtml(f && f.impact ? f.impact : "-") + "</div>" +
            "</div>" +
            '<div class="seo-analysis-col">' +
            '<div class="seo-analysis-col-title">Cozum ne?</div>' +
            '<div class="seo-analysis-col-text">' + escHtml(f && f.solution ? f.solution : "-") + "</div>" +
            "</div>" +
            "</div>" +
            '<span class="seo-analysis-item-code">' + escHtml(f ? f.code : "meta-order") + "</span>" +
            "</li>" +
            "</ul>" +
            "</div>"
        );
    }

    global.runN11SeoAnalysis = runN11SeoAnalysis;
    global.formatN11SeoAnalysisHtml = formatN11SeoAnalysisHtml;
})(typeof window !== "undefined" ? window : this);
