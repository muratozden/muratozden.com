/**
 * n11.com sayfası için istemci tarafı SEO / E-E-A-T / YMYL / semantik HTML kontrolleri.
 * Google'ın dahili algoritmasını hesaplamaz; kamuya açık kalite yönergelerine dayalı heuristiklerdir.
 */
(function (global) {
    "use strict";

    const SEV = { ok: "ok", info: "info", warn: "warn", error: "error" };

    function push(out, severity, category, code, message, detail) {
        out.push({
            severity,
            category,
            code,
            message,
            detail: detail != null ? String(detail) : ""
        });
    }

    function normalizeLd(obj, typesOut) {
        if (!obj || typeof obj !== "object") return;
        if (Array.isArray(obj)) {
            obj.forEach(function (x) {
                normalizeLd(x, typesOut);
            });
            return;
        }
        if (obj["@graph"] && Array.isArray(obj["@graph"])) {
            obj["@graph"].forEach(function (x) {
                normalizeLd(x, typesOut);
            });
        }
        const t = obj["@type"];
        if (t) {
            if (Array.isArray(t)) {
                t.forEach(function (x) {
                    typesOut.add(String(x));
                });
            } else {
                typesOut.add(String(t));
            }
        }
        Object.keys(obj).forEach(function (k) {
            if (k === "@graph") return;
            const v = obj[k];
            if (v && typeof v === "object") {
                normalizeLd(v, typesOut);
            }
        });
    }

    function collectJsonLdTypes(doc) {
        const types = new Set();
        doc.querySelectorAll('script[type="application/ld+json"]').forEach(function (script) {
            const raw = (script.textContent || "").trim();
            if (!raw) return;
            try {
                const data = JSON.parse(raw);
                normalizeLd(data, types);
            } catch (e) {
                /* ignore */
            }
        });
        return types;
    }

    function hasFooterTrustLink(doc) {
        const patterns = [
            /gizlilik|privacy|kvkk|kişisel[\s-]?veri|mesafeli|iade|değişim|iletisim|iletişim|hakkimizda|hakkımızda|güvenli|guvenli|ödeme|odeme|yardim|yardım|sss|sipariş|siparis/i
        ];
        const links = doc.querySelectorAll("a[href]");
        for (let i = 0; i < links.length; i++) {
            const t = (links[i].textContent || "").trim();
            const h = links[i].getAttribute("href") || "";
            if (patterns.some(function (re) {
                return re.test(t) || re.test(h);
            })) {
                return true;
            }
        }
        return false;
    }

    function headingOutlineIssues(doc, out) {
        const headings = doc.querySelectorAll("h1, h2, h3, h4, h5, h6");
        const levels = [];
        for (let i = 0; i < headings.length; i++) {
            const tag = headings[i].tagName.toLowerCase();
            const n = parseInt(tag.slice(1), 10);
            levels.push(n);
        }
        const h1s = doc.querySelectorAll("h1");
        if (h1s.length === 0) {
            push(out, SEV.warn, "semantic", "h1-missing", "Ana konu başlığı (h1) yok.", "Arama motoru ve ekran okuyucular birincil konuyu h1 üzerinden okur. h1 yoksa hangi sorguya cevap verildiği belirsiz kalır, snippet’ta güçlü bir ana mesaj kuramazsın; sayfa konusu dağınık görünür.");
        } else if (h1s.length > 1) {
            push(out, SEV.warn, "semantic", "h1-multiple", "Bu sayfada " + h1s.length + " adet <h1> var; bu hata değil ama riskli.", "Birden fazla h1, ‘asıl konu hangisi?’ sorusunu açar: sıralama sinyali dağılır, arama motoru hangi başlığı ana tema sayacağını netleştiremez. Ekran okuyucu outline’ında aynı seviyede birden çok ‘ana başlık’ görünür; hiyerarji çöker. Kural: sayfa başına tek h1, geri kalanı h2–h6 ile yapılandır.");
        }
        let prev = 0;
        for (let i = 0; i < levels.length; i++) {
            const lv = levels[i];
            if (prev > 0 && lv - prev > 1) {
                push(out, SEV.warn, "semantic", "heading-skip", "Başlık sırası atlanıyor: h" + prev + " → h" + lv + ".", "Arada ara seviye (ör. h3) olmadan atlama, bölüm–alt bölüm ilişkisini bozar; ekran okuyucu kullanıcısı içeriğin akışını takip edemez. Arama motoru da sayfa bölümlerinin iç içe geçişini zayıf okur. Düzelt: seviyeleri sırayla kullan.");
                break;
            }
            prev = lv;
        }
    }

    function duplicateIds(doc, out) {
        const all = doc.querySelectorAll("[id]");
        const seen = Object.create(null);
        let dup = 0;
        for (let i = 0; i < all.length; i++) {
            const id = all[i].getAttribute("id");
            if (!id) continue;
            if (seen[id]) {
                dup++;
            }
            seen[id] = true;
        }
        if (dup > 0) {
            push(out, SEV.error, "semantic", "duplicate-id", "Aynı id birden fazla öğede kullanılmış; bu ciddi bir işaretleme hatası.", "id tekil olmalıdır. Tekrar edince #anchor linkleri, label[for], ARIA ve script hedefleri yanlış elemana gider; davranış öngörülemez olur. Geçerli HTML’e aykırıdır, erişilebilirlik denetiminde de düşersin.");
        }
    }

    function imagesWithoutAlt(doc, out) {
        const imgs = doc.querySelectorAll("img:not([alt])");
        if (imgs.length > 0) {
            push(out, SEV.warn, "semantic", "img-alt-missing", imgs.length + " görselde alt yok; arama ve erişilebilirlikte ham bir eksik.", "Alt olmayan görseller arama için metin bağlamı üretmez; ürün/görsel aramalarında görünürlük kaybedersin. Erişilebilirlikte görsel ‘yok’ sayılır. Dekoratif ise alt=\"\"; anlamlı içerikte mutlaka açıklayıcı alt yaz.");
        }
    }

    function emptyLinks(doc, out) {
        const as = doc.querySelectorAll("a[href]");
        let bad = 0;
        for (let i = 0; i < as.length; i++) {
            const a = as[i];
            const txt = (a.textContent || "").replace(/\s+/g, " ").trim();
            const aria = (a.getAttribute("aria-label") || "").trim();
            const title = (a.getAttribute("title") || "").trim();
            if (!txt && !aria && !title && !a.querySelector("img[alt], svg[aria-label]")) {
                bad++;
            }
        }
        if (bad > 0) {
            push(out, SEV.warn, "semantic", "link-empty", bad + " link görünür metin taşımıyor (boş veya sadece ikon, aria yok).", "Hedef URL veya bağlam anlaşılmaz; ekran okuyucuda ‘boş link’ okunur, kullanıcı tıklamaz. İç bağlantı anchor metni zayıf kalır; sayfa içi konu sinyali düşer. Her linkte anlamlı metin veya aria-label zorunlu say.");
        }
    }

    function landmarkCheck(doc, out) {
        const mains = doc.querySelectorAll("main");
        if (mains.length === 0) {
            push(out, SEV.info, "semantic", "main-missing", "<main> landmark yok; ana içerik nerede belirsiz.", "Yardımcı teknolojiler doğrudan gövdeye atlamak için main bekler; yoksa kullanıcı navigasyon ve reklam blokları arasında kaybolur. Yapısal netlik ve tutarlı okuma için tek bir ana içerik alanı işaretle.");
        } else if (mains.length > 1) {
            push(out, SEV.warn, "semantic", "main-multiple", "Birden fazla <main> (" + mains.length + "); tek olmalı.", "Birden çok main, ‘asıl içerik hangisi?’ sorusunu açar; WCAG’de de sorun çıkar. Ana makaleyi tek main içinde topla.");
        }
    }

    function interactiveNesting(doc, out) {
        if (doc.querySelector("a button, button a, a input, label a")) {
            push(out, SEV.warn, "semantic", "interactive-nesting", "Geçersiz iç içe etkileşim: link içinde buton/input veya benzeri.", "HTML spesifikasyonuna aykırı; tarayıcı olay sırası ve odak davranışı tutarsız olur. Kullanıcı ‘tıkladım olmadı’ yaşar; klavye ile erişim kırılır. Ya link ya buton; tek etkileşimli öğe kullan.");
        }
    }

    function iframesWithoutTitle(doc, out) {
        const frames = doc.querySelectorAll("iframe");
        let n = 0;
        for (let i = 0; i < frames.length; i++) {
            const t = (frames[i].getAttribute("title") || "").trim();
            if (!t) n++;
        }
        if (n > 0) {
            push(out, SEV.warn, "semantic", "iframe-title", n + " iframe’de title yok; erişilebilirlikte doğrudan başarısız sayılırsın.", "Kullanıcı ve ekran okuyucu gömülü içeriğin ne olduğunu bilmez; WCAG’de iframe’ler için erişilebilir isim şart. title veya aria-label eklemeden bırakma.");
        }
    }

    function inputsPossiblyUnlabeled(doc, out) {
        const sel = 'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="image"])';
        const inputs = doc.querySelectorAll(sel);
        let bad = 0;
        for (let i = 0; i < inputs.length; i++) {
            const el = inputs[i];
            if ((el.getAttribute("aria-label") || "").trim()) continue;
            if ((el.getAttribute("aria-labelledby") || "").trim()) continue;
            if (el.closest("label")) continue;
            const id = (el.getAttribute("id") || "").trim();
            if (id) {
                const byFor = Array.prototype.some.call(doc.querySelectorAll("label"), function (lb) {
                    return lb.htmlFor === id;
                });
                if (byFor) continue;
            }
            bad++;
        }
        if (bad > 0) {
            push(out, SEV.info, "semantic", "input-label-soft", bad + " form alanında görünür etiket ilişkisi yok gibi (otomatik tarama).", "Etiketsiz alan: kullanıcı ne gireceğini bilmez; hatalı giriş ve form terk oranı artar. label[for], saran <label> veya aria-label ile her alanı net bağla; aksi halde hem erişilebilirlik hem dönüşüm zarar görür.");
        }
    }

    function metaBasics(doc, win, out) {
        const title = (doc.title || "").trim();
        if (!title) {
            push(out, SEV.error, "meta", "title-empty", "<title> boş: arama sonucunda görünür başlık yok.", "Snippet’ta liste başlığı olarak title kullanılır; boş bırakınca arama motoru sayfadan zayıf veya rastgele bir metin seçer, tıklanma oranı düşer. Mutlaka benzersiz, niyeti tek cümlede anlatan bir title yaz.");
        } else if (title.length < 15) {
            push(out, SEV.warn, "meta", "title-short", "Title çok kısa (" + title.length + " karakter); fırsat kaçırıyorsun.", "Kısa title, ana anahtar kelime ve sayfa niyetini taşıyamaz; SERP’te rekabet eden sonuçlara göre zayıf kalır. Anlamlı uzunlukta, sorgu niyetini karşılayan başlık kullan.");
        } else if (title.length > 70) {
            push(out, SEV.info, "meta", "title-long", "Title uzun (" + title.length + " karakter); çoğu arama arayüzünde kesilir.", "Kullanıcı önemli kısmı göremez; tıklama kararını zayıflatır. Ön yükle en güçlü mesajı koy, gereksiz tekrarı kes.");
        }

        const md = doc.querySelector('meta[name="description"]');
        const desc = md ? (md.getAttribute("content") || "").trim() : "";
        if (!desc) {
            push(out, SEV.warn, "meta", "description-missing", "meta description yok; snippet kontrolünü sıfırlıyorsun.", "Açıklama olmayınca arama motoru sayfa metninden rastgele alıntı yapar; mesajın tutmaz, dönüşüm düşer. Benzersiz, tıklamayı teşvik eden 1–2 cümle yaz.");
        } else if (desc.length < 50) {
            push(out, SEV.info, "meta", "description-short", "Meta açıklama kısa (" + desc.length + " karakter); rekabetçi değil.", "Çok kısa açıklama fayda vaadini taşıyamaz; kullanıcı neden bu sayfaya tıklasın net değil. USP ve anahtar niyeti birkaç kelime daha ile güçlendir.");
        } else if (desc.length > 320) {
            push(out, SEV.info, "meta", "description-long", "Meta açıklama çok uzun; motor genelde keser, mesajın sonu çöpe gider.", "Uzun metnin sonu SERP’te görünmez; en kritik cümleleri başa al, gereksiz tekrarı sil.");
        }

        if (!doc.querySelector('meta[name="viewport"]')) {
            push(out, SEV.warn, "meta", "viewport-missing", "viewport meta yok; mobil uyumluluk iddian ciddiye alınmaz.", "Mobil öncelikli indekslemede viewport şart; yoksa düzen bozulur, kullanıcı hemen çıkar, davranış sinyalleri kötüleşir. width=device-width ekle.");
        }

        if (!doc.querySelector("meta[charset]")) {
            push(out, SEV.info, "meta", "charset-meta", "<meta charset> yok; karakter bozulması riski.", "UTF-8 bildirilmezse Türkçe karakterler ve özel semboller tarayıcıda yanlış görünebilir; güven vermez. İlk 1024 bayt içinde charset kullan.");
        }

        const canonical = doc.querySelector('link[rel="canonical"]');
        if (!canonical || !(canonical.getAttribute("href") || "").trim()) {
            push(out, SEV.info, "meta", "canonical-missing", "canonical yok veya href boş; URL çoğaltma riski.", "Aynı içerik birden fazla URL’de kalırsa otorite parçalanır, hangi URL’nin indeksleneceği belirsizleşir. Tercih edilen tek adresi canonical ile kilitle.");
        }

        if (!doc.documentElement.getAttribute("lang")) {
            push(out, SEV.warn, "meta", "html-lang-missing", "<html lang> yok; dil ve erişilebilirlik sinyali zayıf.", "Ekran okuyucu yanlış telaffuz seçer; arama motoru da sayfa dilini netleştiremez. tr veya uygun BCP 47 kodu ekle.");
        }

        const og = doc.querySelector('meta[property="og:title"], meta[property="og:description"], meta[property="og:image"]');
        if (!og) {
            push(out, SEV.info, "meta", "og-missing", "Open Graph neredeyse yok; sosyal paylaşımda görünümün çöker.", "Paylaşımlarda başlık/açıklama/görsel kontrolün olmaz; önizleme boş veya kötü çekilir, tıklanma düşer. og:title, og:description, og:image ekle.");
        }

        if (win.location.protocol !== "https:") {
            push(out, SEV.error, "trust", "not-https", "Sayfa HTTP; güven ve sıralama için kabul edilemez seviye.", "Tarayıcı ‘güvenli değil’ uyarısı verir; kullanıcı kaçar, dönüşüm düşer. Arama motorları da HTTPS’i temel beklenti sayar. TLS zorunlu.");
        } else {
            push(out, SEV.ok, "trust", "https", "HTTPS aktif; şifreleme temeli tamam.", "");
        }
    }

    function eeAtSignals(doc, types, pathname, out) {
        const hasOrg = ["Organization", "Corporation", "Store", "OnlineStore", "Brand"].some(function (t) {
            return types.has(t);
        });
        const hasProduct = types.has("Product");
        const hasBreadcrumb = types.has("BreadcrumbList");
        const hasWebSite = types.has("WebSite");
        const hasRating = types.has("AggregateRating") || types.has("Review");

        if (hasOrg) {
            push(out, SEV.ok, "eeat", "schema-org", "JSON-LD’de Organization/Brand var; kurumsal kimlik işleniyor.", "Marka şeması, arama sonuçlarında bilgi grafiği ve güven sinyali için kullanılabilir; E-E-A-T’te ‘kim’ sorusuna teknik cevap verir.");
        } else {
            push(out, SEV.info, "eeat", "schema-org-missing", "Organization/Brand şeması yok; kurumsal güven makinesine veri vermiyorsun.", "Rakip markalar şema ile kendini netleştirirken sen görünmez kalırsın. Geçerli Organization + logo + url ekle; özellikle marka sorgularında fark yaratır.");
        }

        if (hasProduct && (hasRating || doc.querySelector("[itemprop=reviewRating], .rating, [class*='rating']"))) {
            push(out, SEV.ok, "eeat", "reviews", "Ürün + değerlendirme sinyali (şema veya görünür) var.", "Kullanıcı deneyimi ve toplumsal kanıt için yorum/puan şeması güçlü sinyaldir; güven artar.");
        } else if (/\/urun\//i.test(pathname)) {
            push(out, SEV.info, "eeat", "reviews-soft", "Ürün sayfasında AggregateRating/Review şeması zayıf veya yok.", "Yıldızlı sonuç şansını düşürürsün; kullanıcı da ‘kim satıyor, güvenilir mi?’ sorusuna şemadan cevap alamaz. Geçerli ve güncel yorum verisini şemayla işle.");
        }

        if (hasBreadcrumb) {
            push(out, SEV.ok, "eeat", "breadcrumb-schema", "BreadcrumbList şeması var; kategori bağlamı net.", "Üst kategori hiyerarşisi hem kullanıcıya hem arama motoruna ‘neredesin?’ bilgisini verir; iç bağlantı otoritesi güçlenir.");
        } else {
            push(out, SEV.info, "eeat", "breadcrumb-missing", "BreadcrumbList yok; site mimarisi şemada görünmüyor.", "Ürün/kategori ilişkisini zayıf bırakırsın; zengin sonuç ve bağlam sinyali kaçırırsın. Geçerli breadcrumb JSON-LD ekle.");
        }

        if (hasWebSite) {
            push(out, SEV.info, "eeat", "website-schema", "WebSite şeması mevcut.", "Site adı ve potansiyel site içi arama kutusu ilişkisi için kullanılır; marka sorgularında destekleyici sinyal.");
        }

        const authorMeta = doc.querySelector('meta[name="author"], link[rel="author"]');
        const articleAuthor = doc.querySelector('[itemprop="author"], .author, [rel="author"]');
        if (authorMeta || articleAuthor) {
            push(out, SEV.ok, "eeat", "author-signal", "Yazar / author sinyali var.", "İçeriğin kimin uzmanlığında olduğu E-E-A-T’te kritik; yazar bilgisi şeffaflığı artırır.");
        } else if (!/\/urun\//i.test(pathname)) {
            push(out, SEV.info, "eeat", "author-missing", "Yazar bilgisi yok; uzmanlık iddiası kanıtsız kalıyor.", "Blog/rehber sayfalarında kim yazdı belli değilse ‘Experience / Expertise’ sorusu boş kalır; güven ve sıralama riski artar. Yazar, bio veya şema ile bağla.");
        }

        if (hasFooterTrustLink(doc)) {
            push(out, SEV.ok, "trust", "policy-links", "Politika / iletişim / iade tarzı bağlantılar görünür.", "YMYL ve e-ticarette yasal ve güven mesajları kullanıcıyı rahatlatır; şeffaflık eksikliği güven kaybıdır.");
        } else {
            push(out, SEV.info, "trust", "policy-links-soft", "Footer’da güven bağlantıları net çıkmadı (otomatik tarama).", "Gizlilik, KVKK, mesafeli satış, iade yoksa kullanıcı ‘güvenilir mi?’ sorusunda tereddüt eder; dönüşüm düşer. Bu linkleri görünür ve erişilebilir tut.");
        }
    }

    function ymylHints(doc, pathname, out) {
        const bodyText = (doc.body && doc.body.innerText ? doc.body.innerText : "").toLowerCase();
        const ymylHealth = /(ilaç|tedavi|doktor|tanı|kanser|diyabet|kalp|hamilelik|covid)/i.test(bodyText);
        const ymylFinance = /(kredi|faiz|yatırım|borsa|sigorta|emeklilik|kredi kartı)/i.test(bodyText);

        if (ymylHealth || ymylFinance) {
            push(out, SEV.info, "ymyl", "ymyl-topic", "Metinde sağlık veya finans içeriği seçildi; YMYL baskısı yüksek.", "Google YMYL’de hatalı bilgi ciddi zarar verebilir; kaynak, güncellik ve uzman yazar şart. İddiasız içerik veya kanıtsız tavsiye bırakma.");
            if (!doc.querySelector('meta[name="author"], [itemprop="author"]') && ymylHealth) {
                push(out, SEV.warn, "ymyl", "ymyl-author", "Sağlık temalı içerikte yazar/kaynak yok; E-E-A-T için zayıf ve riskli.", "Tıbbi iddia için hekim/uzman veya kurumsal kaynak göstermezsen güven sinyali çöker; yanlış bilgi riski kullanıcıya ve siteye yansır.");
            }
        } else if (/\/urun\//i.test(pathname)) {
            push(out, SEV.info, "ymyl", "ymyl-commerce", "Ürün sayfası: para ve güvenlik (YMYL ile kesişir).", "Ödeme, iade, satıcı, garanti bilgisi net değilse kullanıcı alışverişi bırakır; şikayet ve iade oranı kötü sinyal üretir. Politikaları görünür ve tutarlı yaz.");
        }
    }

    function runN11SeoAnalysis(doc, win) {
        const out = [];
        const pathname = win.location && win.location.pathname ? win.location.pathname : "";
        const types = collectJsonLdTypes(doc);

        metaBasics(doc, win, out);
        headingOutlineIssues(doc, out);
        duplicateIds(doc, out);
        imagesWithoutAlt(doc, out);
        emptyLinks(doc, out);
        landmarkCheck(doc, out);
        interactiveNesting(doc, out);
        iframesWithoutTitle(doc, out);
        inputsPossiblyUnlabeled(doc, out);
        eeAtSignals(doc, types, pathname, out);
        ymylHints(doc, pathname, out);

        const typeList = Array.from(types).sort();
        if (typeList.length > 0) {
            push(out, SEV.ok, "structured", "jsonld-types", "JSON-LD @type tespit edildi: " + typeList.slice(0, 12).join(", ") + (typeList.length > 12 ? "…" : ""), "Şema türleri zengin sonuç ve bilgi paneli için ham veridir; hatalı/eksik şema ise fırsat kaybıdır, doğrula.");
        } else {
            push(out, SEV.info, "structured", "jsonld-empty", "Geçerli JSON-LD yok veya parse edilemedi; yapılandırılmış veri sıfır.", "Ürün, teklif ve kurum bilgisini arama motoruna düz HTML ile taşıyamazsın; rakipler şema ile daha fazla görünürlük alır. Geçerli JSON-LD ekle.");
        }

        const counts = { ok: 0, info: 0, warn: 0, error: 0 };
        out.forEach(function (item) {
            if (counts[item.severity] != null) {
                counts[item.severity]++;
            }
        });

        return {
            url: win.location.href,
            pathname: pathname,
            pageTitle: doc.title || "",
            jsonLdTypes: typeList,
            findings: out,
            counts: counts,
            disclaimer: "Bu araç Google’ın gizli puanını hesaplamaz. Sonuçlar DOM üzerindeki otomatik kurallardır; gerçek sıralama ve kalite değerlendirmesi çok daha geniştir. Yine de aşağıdaki uyarı ve kritikler düzeltilmezse teknik ve güven sinyalinde geri kalırsın."
        };
    }

    function escHtml(s) {
        return String(s == null ? "" : s)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    function formatN11SeoAnalysisHtml(result) {
        if (!result || !result.findings) {
            return '<p class="seo-analysis-error">Analiz çalıştırılamadı. Sayfayı yenileyip tekrar dene; devam ederse eklenti yüklemesini kontrol et.</p>';
        }
        const catLabels = {
            meta: "Meta & teknik",
            semantic: "Semantik HTML & erişilebilirlik",
            trust: "Güven (Trust)",
            eeat: "E-E-A-T sinyalleri",
            ymyl: "YMYL ipuçları",
            structured: "Yapılandırılmış veri"
        };
        const sevClass = {
            ok: "seo-sev-ok",
            info: "seo-sev-info",
            warn: "seo-sev-warn",
            error: "seo-sev-error"
        };
        const byCat = {};
        result.findings.forEach(function (f) {
            if (!byCat[f.category]) {
                byCat[f.category] = [];
            }
            byCat[f.category].push(f);
        });
        const order = ["meta", "semantic", "trust", "eeat", "ymyl", "structured"];
        let html = '<div class="seo-analysis-summary">';
        html += '<div class="seo-analysis-counts">';
        html += '<span class="seo-count seo-count-ok">' + result.counts.ok + " geçerli</span>";
        html += '<span class="seo-count seo-count-info">' + result.counts.info + " bilgi / risk</span>";
        html += '<span class="seo-count seo-count-warn">' + result.counts.warn + " uyarı</span>";
        html += '<span class="seo-count seo-count-error">' + result.counts.error + " kritik</span>";
        html += "</div>";
        html += '<p class="seo-analysis-disclaimer">' + escHtml(result.disclaimer) + "</p>";
        html += "</div>";
        order.forEach(function (cat) {
            const items = byCat[cat];
            if (!items || !items.length) return;
            html += '<div class="seo-analysis-section">';
            html += '<div class="seo-analysis-section-title">' + escHtml(catLabels[cat] || cat) + "</div>";
            html += '<ul class="seo-analysis-list">';
            items.forEach(function (f) {
                html += '<li class="seo-analysis-item ' + (sevClass[f.severity] || "") + '">';
                html += '<span class="seo-analysis-item-title">' + escHtml(f.message) + "</span>";
                if (f.detail) {
                    html += '<span class="seo-analysis-item-detail">' + escHtml(f.detail) + "</span>";
                }
                html += '<span class="seo-analysis-item-code">' + escHtml(f.code) + "</span>";
                html += "</li>";
            });
            html += "</ul></div>";
        });
        return html;
    }

    global.runN11SeoAnalysis = runN11SeoAnalysis;
    global.formatN11SeoAnalysisHtml = formatN11SeoAnalysisHtml;
})(typeof window !== "undefined" ? window : this);
