(function() {
  document.addEventListener("n11ext-hepsiburada-request", async function(e) {
    var merchantName = e.detail && e.detail.merchantName;
    var page = e.detail && e.detail.page;
    if (!merchantName || !page) {
      document.dispatchEvent(new CustomEvent("n11ext-hepsiburada-response", { detail: { ok: false, error: "Parametre eksik" } }));
      return;
    }
    var filter = "VariantList.VariantListing.MerchantName:" + encodeURIComponent(merchantName);
    var url = "https://blackgate.hepsiburada.com/moriaapi/api/product?filter=" + filter + "&page=" + page + "&pageType=Merchant&size=36";
    try {
      var res = await fetch(url, { credentials: "include", headers: { Accept: "application/json" } });
      if (!res.ok) {
        document.dispatchEvent(new CustomEvent("n11ext-hepsiburada-response", { detail: { ok: false, error: "HTTP " + res.status } }));
        return;
      }
      var data = await res.json();
      document.dispatchEvent(new CustomEvent("n11ext-hepsiburada-response", { detail: { ok: true, products: data.products || [] } }));
    } catch (err) {
      document.dispatchEvent(new CustomEvent("n11ext-hepsiburada-response", { detail: { ok: false, error: (err && err.message) || "Failed" } }));
    }
  });
})();
