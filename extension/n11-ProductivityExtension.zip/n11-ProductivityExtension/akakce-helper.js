/**
 * Akakce.com sayfasında çalışır - "Daha fazla fiyat gör" butonuna tıklama veya manuel mod banner.
 * world: "MAIN" ile sayfa JavaScript bağlamında çalışır.
 */
(function () {
  const BANNER_ID = "n11-ext-akakce-manual-banner";
  function shouldShowBannerOnLoad() {
    return new URLSearchParams(window.location.search).get("n11_manuel") === "1";
  }
  function findSAPButton() {
    let btn = document.querySelector("button#SAP") || document.querySelector("[id='SAP']") || document.querySelector("button.t2b.more");
    if (!btn) {
      const all = document.querySelectorAll("button, a, [role='button'], .t2b, .more");
      for (const el of all) {
        if ((el.textContent || "").includes("Daha fazla fiyat")) return el;
      }
    }
    return btn;
  }
  function clickSAPButton() {
    const btn = findSAPButton();
    if (!btn) return false;
    btn.scrollIntoView({ block: "center" });
    btn.focus();
    btn.click();
    return true;
  }
  function tryClickWithRetry(retries, done) {
    if (clickSAPButton()) {
      if (done) done(true);
      return;
    }
    if (retries <= 0) {
      if (done) done(false);
      return;
    }
    setTimeout(() => tryClickWithRetry(retries - 1, done), 800);
  }
  function showManualBanner() {
    let el = document.getElementById(BANNER_ID);
    if (el) return;
    el = document.createElement("div");
    el.id = BANNER_ID;
    el.innerHTML = '<span>Lütfen <strong>"Daha fazla fiyat gör"</strong> butonuna tıklayın. Veriler otomatik alınacak.</span>';
    el.style.cssText = "position:fixed;top:116px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#f4e;color:#fff;padding:12px 24px;border-radius:8px;font-family:system-ui,sans-serif;font-size:14px;box-shadow:0 4px 12px rgba(0,0,0,.3);max-width:90vw;text-align:center;cursor:pointer;";
    el.addEventListener("click", () => { window.scrollTo(0, 3000); });
    document.body.appendChild(el);
  }
  function hideManualBanner() {
    const el = document.getElementById(BANNER_ID);
    if (el) el.remove();
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "akakce-click-sap") {
      tryClickWithRetry(4, (ok) => { if (sendResponse) sendResponse({ ok }); });
      return true;
    }
    if (msg && msg.type === "akakce-show-manual-banner") {
      showManualBanner();
      if (sendResponse) sendResponse({ ok: true });
      return true;
    }
    if (msg && msg.type === "akakce-manuel-update-mode") {
      showManualBanner();
      window.scrollTo(0, 0);
      if (sendResponse) sendResponse({ ok: true });
      return true;
    }
    if (msg && msg.type === "akakce-hide-manual-banner") {
      hideManualBanner();
      if (sendResponse) sendResponse({ ok: true });
      return true;
    }
    return false;
  });
  if (shouldShowBannerOnLoad()) {
    showManualBanner();
    window.scrollTo(0, 0);
  }
})();
