const CONTAINER_ID = "pageid-extension-container";
const PAGE_ID_BOX_ID = "pageid-extension-box";
const INLINE_PIMS_ID_BOX_ID = "inline-pims-id-extension-box";
const DEEPLINK_BOX_ID = "deeplink-extension-box";
const TAB_COPY_BOX_ID = "tabcopy-extension-box";
const URL_PRODUCT_BOX_ID = "url-productid-extension-box";
const PRODUCTID_URL_BOX_ID = "productid-url-extension-box";
const ID_SKU_BOX_ID = "id-sku-extension-box";
const PIMS_ID_BOX_ID = "pims-id-extension-box";
const LISTING_PRODUCT_CRAWLER_BOX_ID = "listing-product-crawler-extension-box";
const OFFER_CONTROLLER_BOX_ID = "offer-controller-extension-box";
const AKAKCE_PRODUCT_CRAWLER_BOX_ID = "akakce-product-crawler-extension-box";
const EDITORIAL_CONTROLLER_BOX_ID = "editorial-controller-extension-box";
const BO_PRODUCT_MANAGEMENT_BOX_ID = "bo-product-management-extension-box";
const AKAKCE_ID_N11_PRODUCT_BOX_ID = "akakce-id-n11-product-extension-box";
const AKAKCE_CUSTOM_DEAL_BOX_ID = "akakce-custom-deal-extension-box";
const AKAKCE_FULL_CATEGORY_BOX_ID = "akakce-full-category-extension-box";
const MODAL_ID = "pageid-extension-modal";
const BO_BOX_ID = "bo-product-extension-box";
const BO_MODAL_ID = "pageid-extension-bo-modal";
const URL_PRODUCT_MODAL_ID = "pageid-extension-url-modal";
const PRODUCTID_URL_MODAL_ID = "pageid-extension-productid-url-modal";
const ID_SKU_MODAL_ID = "id-sku-extension-modal";
const PIMS_ID_MODAL_ID = "pims-id-extension-modal";
const LISTING_PRODUCT_CRAWLER_MODAL_ID = "listing-product-crawler-extension-modal";
const OFFER_CONTROLLER_MODAL_ID = "offer-controller-extension-modal";
const AKAKCE_PRODUCT_CRAWLER_MODAL_ID = "akakce-product-crawler-extension-modal";
const EDITORIAL_CONTROLLER_MODAL_ID = "editorial-controller-extension-modal";
const PAGE_CHECKER_BOX_ID = "pagechecker-extension-box";
const PAGE_CHECKER_MODAL_ID = "pagechecker-extension-modal";
const BANNER_CHECKER_BOX_ID = "bannerchecker-extension-box";
const BANNER_CHECKER_MODAL_ID = "bannerchecker-extension-modal";
const CLEAR_CACHE_BOX_ID = "clearcache-extension-box";
const PRICE_PROTECTOR_BOX_ID = "price-protector-extension-box";
const PRODUCT_PRICE_TRACKING_BOX_ID = "product-price-tracking-extension-box";
const PRICE_PROTECTOR_MODAL_ID = "price-protector-extension-modal";
const PRODUCT_PRICE_TRACKING_MODAL_ID = "product-price-tracking-extension-modal";
const AKAKCE_ID_N11_PRODUCT_MODAL_ID = "akakce-id-n11-product-extension-modal";
const AKAKCE_CUSTOM_DEAL_MODAL_ID = "akakce-custom-deal-extension-modal";
const AKAKCE_FULL_CATEGORY_MODAL_ID = "akakce-full-category-extension-modal";
const PRODUCT_MATCH_SCORE_BOX_ID = "product-match-score-extension-box";
const PRODUCT_MATCH_SCORE_MODAL_ID = "product-match-score-extension-modal";
const PRODUCT_MATCH_SCORE_STORAGE_AUTO = "n11ProductMatchScoreAuto";
const PRODUCT_MATCH_SCORE_FLOW_ARMED = "n11ProductMatchScoreFlowArmed";
const PRODUCT_MATCH_SCORE_STORAGE_REOPEN = "n11ProductMatchScoreReopenModal";
let akakceCustomDealProgressHandler = null;
let akakceCustomDealCaptchaHandler = null;
const SELLER_PRODUCT_COUNT_BOX_ID = "seller-product-count-extension-box";
const SELLER_PRODUCT_COUNT_MODAL_ID = "seller-product-count-extension-modal";
const SELLER_PRODUCTS_CRAWLER_BOX_ID = "seller-products-crawler-extension-box";
const SELLER_PRODUCTS_CRAWLER_MODAL_ID = "seller-products-crawler-extension-modal";
const SELLER_PRODUCT_MATCH_BOX_ID = "seller-product-match-extension-box";
const SELLER_PRODUCT_MATCH_MODAL_ID = "seller-product-match-extension-modal";
const HEPSIBURADA_SELLER_PRODUCTS_CRAWLER_BOX_ID = "hepsiburada-seller-products-crawler-extension-box";
const HEPSIBURADA_SELLER_PRODUCTS_CRAWLER_MODAL_ID = "hepsiburada-seller-products-crawler-extension-modal";
const PRODUCT_DEAL_CONTROLLER_BOX_ID = "product-deal-controller-extension-box";
const PRODUCT_DEAL_CONTROLLER_MODAL_ID = "product-deal-controller-extension-modal";
const PROMOTION_THEME_PIN_BOX_ID = "promotion-theme-pin-extension-box";
const PROMOTION_THEME_PIN_MODAL_ID = "promotion-theme-pin-extension-modal";
const SO_ANNOUNCEMENT_POPUP_BOX_ID = "so-announcement-popup-extension-box";
const SO_ANNOUNCEMENT_POPUP_MODAL_ID = "so-announcement-popup-extension-modal";
const BANNER_MAILING_BOX_ID = "banner-mailing-extension-box";
const BANNER_MAILING_MODAL_ID = "banner-mailing-extension-modal";
const PRODUCT_MAILING_BOX_ID = "product-mailing-extension-box";
const PRODUCT_MAILING_MODAL_ID = "product-mailing-extension-modal";
const LOGO_RESIZER_BOX_ID = "logo-resizer-extension-box";
const LOGO_RESIZER_MODAL_ID = "logo-resizer-extension-modal";
const LOGO_LIST_BOX_ID = "logo-list-extension-box";
const LOGO_LIST_MODAL_ID = "logo-list-extension-modal";
const VERSION_BANNER_ID = "pageid-extension-version-banner";
const VERSION_BANNER_DEFAULT_MESSAGE = "Güncellendi! Yeni sürümü indirmek için tıklayın.";
const VERSION_BANNER_DOWNLOAD_URL = "https://toolkit.n11.com/assets/extension/n11-ProductivityExtension.zip";

const ID_KEYS = ["pageId", "pageid", "id", "productId", "productid"];
const DATA_ATTRS = [
  "data-page-id",
  "data-pageid",
  "data-product-id",
  "data-productid"
];
const META_ATTRS = [
  ["name", "pageId"],
  ["name", "pageid"],
  ["property", "product:id"],
  ["property", "og:product_id"]
];

const DEEPLINK_PARAM_KEY = "pageId";
const HOME_DEEPLINK = "n11mf://n11.com?pt=h&pd=-";
const DYNAMIC_DEEPLINK_PREFIX = "n11mf://n11.com?pt=dlp&pd=";
const PROMOTION_DEEPLINK_PREFIX = "n11mf://n11.com?pt=spp&pd=";

const INJECTED_SCRIPT_ID = "pageid-extension-injected";
const MESSAGE_SOURCE = "pageid-extension";
const STORAGE_KEY_UI_HIDDEN = "extensionUiHidden";
const STORAGE_KEY_GROUPS_COLLAPSED = "extensionGroupsCollapsed";
const STORAGE_KEY_PRODUCT_PRICE_TRACKING_ROWS = "productPriceTrackingRows";
const STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS = "productPriceTrackingBrands";
const N11_LOGO_URL = "https://n11scdn.akamaized.net/custom/upload/56/71/4643320758776974115.svg";
const TRENDYOL_LOGO_URL = "https://n11scdn.akamaized.net/custom/upload/52/34/8306016460707706841.svg";
const HEPSIBURADA_LOGO_URL = "https://n11scdn.akamaized.net/custom/upload/49/75/9137271869470559939.svg";
const AMAZON_LOGO_URL = "https://n11scdn.akamaized.net/custom/upload/67/31/4443647868650764054.svg";
const PAZARAMA_LOGO_URL = "https://n11scdn.akamaized.net/custom/upload/87/47/7511380717719014849.svg";
const PTTAVM_LOGO_URL = "https://n11scdn.akamaized.net/custom/upload/69/20/3989916881263112432.svg";
const IDEFIX_LOGO_URL = "https://n11scdn.akamaized.net/custom/upload/77/62/6970520296776748069.svg";
const TEKNOSA_LOGO_URL = "https://n11scdn.akamaized.net/custom/upload/65/11/4286337531925084530.svg";
const SETTINGS_ICON_URL = "https://n11scdn.akamaized.net/custom/upload/89/86/7425469397917807715.svg";

const EXTENSION_GROUP_CONFIG = [
  { id: "id-link", title: "ID & Link", boxIds: [PAGE_ID_BOX_ID, INLINE_PIMS_ID_BOX_ID, DEEPLINK_BOX_ID, TAB_COPY_BOX_ID] },
  { id: "tools", title: "Araçlar", boxIds: [URL_PRODUCT_BOX_ID, PRODUCTID_URL_BOX_ID, ID_SKU_BOX_ID, PIMS_ID_BOX_ID, LISTING_PRODUCT_CRAWLER_BOX_ID, OFFER_CONTROLLER_BOX_ID, EDITORIAL_CONTROLLER_BOX_ID, BANNER_CHECKER_BOX_ID, SELLER_PRODUCT_MATCH_BOX_ID, PRODUCT_DEAL_CONTROLLER_BOX_ID] },
  { id: "price-crawler", title: "Fiyat & Crawler", boxIds: [AKAKCE_PRODUCT_CRAWLER_BOX_ID, PRICE_PROTECTOR_BOX_ID, PRODUCT_PRICE_TRACKING_BOX_ID, AKAKCE_ID_N11_PRODUCT_BOX_ID, AKAKCE_CUSTOM_DEAL_BOX_ID, SELLER_PRODUCT_COUNT_BOX_ID] },
  {
    id: "crawl-scrapping",
    title: "Crawl & Scrapping",
    boxIds: [AKAKCE_FULL_CATEGORY_BOX_ID, PRODUCT_MATCH_SCORE_BOX_ID]
  },
  { id: "bo-page", title: "BO & Sayfa", boxIds: [BO_PRODUCT_MANAGEMENT_BOX_ID, CLEAR_CACHE_BOX_ID] },
  { id: "trendyol", title: "Trendyol", boxIds: [SELLER_PRODUCTS_CRAWLER_BOX_ID] },
  { id: "hepsiburada", title: "Hepsiburada", boxIds: [HEPSIBURADA_SELLER_PRODUCTS_CRAWLER_BOX_ID] },
  { id: "marketing-growth", title: "Marketing & Growth", boxIds: [PROMOTION_THEME_PIN_BOX_ID, SO_ANNOUNCEMENT_POPUP_BOX_ID, BANNER_MAILING_BOX_ID, PRODUCT_MAILING_BOX_ID, LOGO_RESIZER_BOX_ID, LOGO_LIST_BOX_ID] }
];
let dynamicPageIdFromPage = "";
let productIdFromPage = "";
let sellerIdFromPage = "";
let categoryIdFromPage = "";
let isCategoryPageFromPage = false;
let dataLayerPageNameFromPage = "";
let modelTotalCountFromPage;
let lastProductMatchScoreRows = [];
let isExtensionHidden = false;
let lastRightClickTarget = null;

const loadExtensionVisibilityState = () => {
  chrome.storage.local.get(STORAGE_KEY_UI_HIDDEN, (result) => {
    isExtensionHidden = Boolean(result[STORAGE_KEY_UI_HIDDEN]);
    if (document.body) {
      document.body.dataset.extensionHidden = isExtensionHidden ? "true" : "false";
    }
    applyExtensionVisibility();
  });
};

const applyExtensionVisibility = () => {
  const container = document.getElementById(CONTAINER_ID);
  if (container) {
    container.style.display = isExtensionHidden ? "none" : "";
  }
  if (!isExtensionHidden) {
    return;
  }
  const modalIds = [
    MODAL_ID,
    URL_PRODUCT_MODAL_ID,
    PRODUCTID_URL_MODAL_ID,
    ID_SKU_MODAL_ID,
    PIMS_ID_MODAL_ID,
    LISTING_PRODUCT_CRAWLER_MODAL_ID,
    OFFER_CONTROLLER_MODAL_ID,
    AKAKCE_PRODUCT_CRAWLER_MODAL_ID,
    BO_MODAL_ID,
    PAGE_CHECKER_MODAL_ID,
    BANNER_CHECKER_MODAL_ID,
    EDITORIAL_CONTROLLER_MODAL_ID,
    PRICE_PROTECTOR_MODAL_ID,
    PRODUCT_PRICE_TRACKING_MODAL_ID,
    AKAKCE_ID_N11_PRODUCT_MODAL_ID,
    AKAKCE_CUSTOM_DEAL_MODAL_ID,
    AKAKCE_FULL_CATEGORY_MODAL_ID,
    PRODUCT_MATCH_SCORE_MODAL_ID,
    SELLER_PRODUCT_COUNT_MODAL_ID,
    SELLER_PRODUCTS_CRAWLER_MODAL_ID,
    SELLER_PRODUCT_MATCH_MODAL_ID,
    HEPSIBURADA_SELLER_PRODUCTS_CRAWLER_MODAL_ID,
    PRODUCT_DEAL_CONTROLLER_MODAL_ID,
    PROMOTION_THEME_PIN_MODAL_ID,
    SO_ANNOUNCEMENT_POPUP_MODAL_ID,
    BANNER_MAILING_MODAL_ID,
    PRODUCT_MAILING_MODAL_ID,
    LOGO_RESIZER_MODAL_ID,
    LOGO_LIST_MODAL_ID
  ];
  modalIds.forEach((id) => {
    const modal = document.getElementById(id);
    if (modal && modal.style.display !== "none") {
      modal.style.display = "none";
    }
  });
};

const toggleExtensionVisibility = () => {
  isExtensionHidden = !isExtensionHidden;
  chrome.storage.local.set({ [STORAGE_KEY_UI_HIDDEN]: isExtensionHidden });
  if (document.body) {
    document.body.dataset.extensionHidden = isExtensionHidden ? "true" : "false";
  }
  applyExtensionVisibility();
};

const isProductPageUrl = () => {
  const pathname = window.location.pathname || "";
  if (!pathname.includes("/urun/")) {
    return false;
  }
  return /-?\d{4,}(?:\/|$)/.test(pathname) || /\/urun\/[^/]*\d{4,}(?:\/|$)/.test(pathname);
};

const shouldShowInlinePimsIdBox = () => {
  try {
    const url = new URL(window.location.href);
    return (
      url.hostname === "www.n11.com" &&
      url.pathname.includes("/urun/") &&
      url.searchParams.has("magaza")
    );
  } catch {
    return false;
  }
};

const getInlinePimsIdFromModel = () => {
  const direct = window?.model?.product?.defaultPimsId;
  if (direct != null && String(direct).trim() !== "") {
    return String(direct).trim();
  }
  const scripts = document.querySelectorAll("script");
  for (const scriptEl of scripts) {
    const text = scriptEl.textContent || "";
    if (!text || !/defaultPimsId/i.test(text)) continue;
    const directMatch = text.match(/model\.product\.defaultPimsId\s*[=:]\s*["']?(\d+)["']?/i);
    if (directMatch && directMatch[1]) return directMatch[1];
    const jsonMatch = text.match(/"defaultPimsId"\s*:\s*["']?(\d+)["']?/i);
    if (jsonMatch && jsonMatch[1]) return jsonMatch[1];
  }
  return findPimsIdFromPage() || "";
};

const findPageIdFromUrl = () => {
  const url = new URL(window.location.href);

  if (url.pathname.includes("/urun/")) {
    const fromProduct = findProductIdFromUrl();
    if (fromProduct) {
      return fromProduct;
    }
  }

  for (const key of ID_KEYS) {
    const value = url.searchParams.get(key);
    if (value) {
      return value;
    }
  }

  const pathMatch = url.pathname.match(/(\d{4,})/g);
  if (pathMatch && pathMatch.length > 0) {
    return pathMatch[pathMatch.length - 1];
  }

  return "";
};

const findProductIdFromProductMeta = () => {
  if (
    window.model &&
    window.model.productMeta &&
    window.model.productMeta.productId != null
  ) {
    const id = String(window.model.productMeta.productId).trim();
    if (id !== "") {
      return id;
    }
  }
  const scripts = document.querySelectorAll("script");
  for (const scriptEl of scripts) {
    const text = scriptEl.textContent || "";
    if (!text.includes("productMeta") || !text.includes("productId")) {
      continue;
    }
    const productMetaProductIdMatch = text.match(
      /"productMeta"\s*:\s*\{[\s\S]*?"productId"\s*:\s*"(\d+)"/
    );
    if (productMetaProductIdMatch && productMetaProductIdMatch[1]) {
      return productMetaProductIdMatch[1];
    }
    const productMetaProductIdNumeric = text.match(
      /"productMeta"\s*:\s*\{[\s\S]*?"productId"\s*:\s*(\d+)/
    );
    if (productMetaProductIdNumeric && productMetaProductIdNumeric[1]) {
      return productMetaProductIdNumeric[1];
    }
  }
  return "";
};

const findProductIdFromUrl = () => {
  const url = new URL(window.location.href);
  if (!url.pathname.includes("/urun/")) {
    return "";
  }
  const match = url.pathname.match(/-(\d{4,})(?:\/|$)/);
  if (match && match[1]) {
    return match[1];
  }
  const numericMatch = url.pathname.match(/\/urun\/(\d{4,})(?:\/|$)/);
  return numericMatch && numericMatch[1] ? numericMatch[1] : "";
};

const findPromotionIdFromUrl = () => {
  const url = new URL(window.location.href);
  const value = url.searchParams.get("promotions");
  return value || "";
};

const findPageIdFromDom = () => {
  for (const attr of DATA_ATTRS) {
    const node = document.querySelector(`[${attr}]`);
    if (node) {
      const value = node.getAttribute(attr);
      if (value) {
        return value;
      }
    }
  }

  for (const [metaKey, metaValue] of META_ATTRS) {
    const meta = document.querySelector(`meta[${metaKey}="${metaValue}"]`);
    if (meta) {
      const value = meta.getAttribute("content");
      if (value) {
        return value;
      }
    }
  }

  return "";
};

const getPageId = () => {
  return findPageIdFromUrl() || findPageIdFromDom() || "";
};

const findDynamicPageIdFromModel = () => {
  if (dynamicPageIdFromPage) {
    return dynamicPageIdFromPage;
  }

  if (window.model && window.model.dynamicPage && window.model.dynamicPage.id) {
    return String(window.model.dynamicPage.id);
  }

  const scripts = Array.from(document.querySelectorAll("script"));
  for (const script of scripts) {
    const text = script.textContent;
    if (!text || !text.includes("model.dynamicPage.id")) {
      continue;
    }
    const match = text.match(/model\.dynamicPage\.id\s*=\s*["']?(\d+)["']?/);
    if (match && match[1]) {
      return match[1];
    }
  }
  return "";
};

const findProductIdFromModel = () => {
  if (productIdFromPage) {
    return productIdFromPage;
  }

  const visited = new Set();
  const candidates = [];
  const pushCandidate = (value) => {
    if (value == null) {
      return;
    }
    const str = String(value).trim();
    if (!/^\d+$/.test(str)) {
      return;
    }
    candidates.push(str);
  };
  const stack = [];
  if (window.model && typeof window.model === "object") {
    stack.push(window.model);
  }
  while (stack.length > 0) {
    const current = stack.pop();
    if (!current || typeof current !== "object") {
      continue;
    }
    if (visited.has(current)) {
      continue;
    }
    visited.add(current);
    if (Array.isArray(current)) {
      current.forEach((item) => stack.push(item));
      continue;
    }
    Object.entries(current).forEach(([key, value]) => {
      if (typeof key === "string" && key.toLowerCase() === "productid") {
        pushCandidate(value);
      } else if (value && typeof value === "object") {
        stack.push(value);
      }
    });
  }

  if (candidates.length === 0) {
    return "";
  }
  candidates.sort((a, b) => b.length - a.length);
  return candidates[0];
};

const findSellerIdFromModel = () => {
  if (sellerIdFromPage) {
    return sellerIdFromPage;
  }

  if (
    window.model &&
    window.model.sellerInfo &&
    window.model.sellerInfo.sellerShopDto &&
    window.model.sellerInfo.sellerShopDto.sellerId
  ) {
    return String(window.model.sellerInfo.sellerShopDto.sellerId);
  }

  return "";
};

const openAkakceIdN11ProductModal = () => {
  let modal = document.getElementById(AKAKCE_ID_N11_PRODUCT_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = AKAKCE_ID_N11_PRODUCT_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Akakce ID &gt; n11 Product Data</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="akakce-crawler-form">
          <label for="akakce-id-n11-input">Akakce ID (her satıra bir ID, örn. 233850107)</label>
          <textarea id="akakce-id-n11-input" class="akakce-crawler-textarea" rows="4" placeholder="233850107&#10;1182771123"></textarea>
          <div class="akakce-crawler-buttons">
            <button type="button" class="akakce-run-btn" id="akakce-id-n11-run-btn">Ara ve Link Al</button>
            <button type="button" class="akakce-run-btn akakce-id-n11-resolve-btn" id="akakce-id-n11-resolve-btn" disabled>n11 Link Çözümle</button>
            <button type="button" class="download-btn" id="akakce-id-n11-download" disabled>Excel İndir</button>
          </div>
        </div>
        <div class="status" id="akakce-id-n11-status"></div>
        <div id="akakce-id-n11-result" class="akakce-crawler-result-wrap"></div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) modal.style.display = "none";
    });
    document.body.appendChild(modal);
    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => { modal.style.display = "none"; });
    const runBtn = modal.querySelector("#akakce-id-n11-run-btn");
    const resolveBtn = modal.querySelector("#akakce-id-n11-resolve-btn");
    const downloadBtn = modal.querySelector("#akakce-id-n11-download");
    const input = modal.querySelector("#akakce-id-n11-input");
    const resultWrap = modal.querySelector("#akakce-id-n11-result");
    const statusDiv = modal.querySelector("#akakce-id-n11-status");
    const showStatus = (msg, type) => {
      statusDiv.textContent = msg;
      statusDiv.className = "status " + (type || "info");
      statusDiv.style.display = "block";
    };
    const escapeHtml = (s) => {
      if (s == null) return "";
      return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    };
    let tableRows = [];
    const linkCell = (url, label) => {
      if (!url || !String(url).trim()) return escapeHtml(label || "-");
      const safe = String(url).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      return '<a href="' + safe + '" target="_blank" rel="noopener" class="akakce-link">' + (label || escapeHtml(url)) + "</a>";
    };
    const renderTable = () => {
      if (tableRows.length === 0) {
        resultWrap.innerHTML = '<p class="akakce-crawler-empty">Henüz sonuç yok. ID girip "Ara ve Link Al" tıklayın.</p>';
        if (resolveBtn) resolveBtn.disabled = true;
        if (downloadBtn) downloadBtn.disabled = true;
        return;
      }
      let html = '<table class="akakce-crawler-table akakce-id-n11-table"><thead><tr><th>Akakce ID</th><th>Akakce Link</th><th>Redirect URL</th><th>n11 Link</th><th>Product ID</th><th>Title</th><th>Pims ID</th><th>Group ID</th><th>Sku ID</th></tr></thead><tbody>';
      tableRows.forEach((r) => {
        if (r.error) {
          html += "<tr><td>" + escapeHtml(r.akakceId || "-") + "</td><td colspan=\"8\">" + escapeHtml(r.error) + "</td></tr>";
        } else {
          const pid = escapeHtml(r.productId || "-");
          const tit = escapeHtml((r.title || "-").substring(0, 40)) + ((r.title || "").length > 40 ? "…" : "");
          const pims = escapeHtml(r.pimsId || "-");
          const grp = escapeHtml(r.groupId || "-");
          const sku = escapeHtml(r.skuId || "-");
          html += "<tr><td>" + escapeHtml(r.akakceId || "-") + "</td><td>" + linkCell(r.akakceUrl, "Link") + "</td><td>" + linkCell(r.redirectUrl, "Redirect") + "</td><td>" + linkCell(r.n11Url, "n11") + "</td><td>" + pid + "</td><td title=\"" + escapeHtml(r.title || "") + "\">" + tit + "</td><td>" + pims + "</td><td>" + grp + "</td><td>" + sku + "</td></tr>";
        }
      });
      html += "</tbody></table>";
      resultWrap.innerHTML = html;
      const hasRedirect = tableRows.some((r) => !r.error && r.redirectUrl && String(r.redirectUrl).trim());
      if (resolveBtn) resolveBtn.disabled = !hasRedirect;
      if (downloadBtn) downloadBtn.disabled = false;
    };
    runBtn.addEventListener("click", async () => {
      const raw = (input.value || "").trim();
      const ids = raw.split(/\n|\s+/).map((s) => s.trim()).filter((s) => /^\d+$/.test(s));
      if (ids.length === 0) {
        showStatus("Geçerli Akakce ID girin (örn. 233850107)", "error");
        return;
      }
      runBtn.disabled = true;
      tableRows = [];
      for (let i = 0; i < ids.length; i++) {
        const id = ids[i].trim();
        showStatus(`Aranıyor: ${i + 1}/${ids.length} - ID ${id}`, "info");
        try {
          const res = await chrome.runtime.sendMessage({ type: "akakce-id-to-link", akakceId: id });
          if (res && res.ok) {
            tableRows.push({
              akakceId: id,
              akakceUrl: res.akakceUrl || "",
              redirectUrl: res.redirectUrl || "",
              error: null
            });
          } else {
            tableRows.push({ akakceId: id, akakceUrl: "", redirectUrl: "", error: (res && res.error) || "Link alınamadı" });
          }
        } catch (e) {
          tableRows.push({ akakceId: id, akakceUrl: "", redirectUrl: "", error: (e && e.message) || "Hata" });
        }
        renderTable();
      }
      showStatus(ids.length + " ID işlendi.", "success");
      runBtn.disabled = false;
    });
    resolveBtn.addEventListener("click", async () => {
      const urls = tableRows.filter((r) => !r.error && r.redirectUrl && String(r.redirectUrl).trim()).map((r) => r.redirectUrl);
      if (urls.length === 0) {
        showStatus("Önce tabloya Redirect URL ekleyin.", "error");
        return;
      }
      resolveBtn.disabled = true;
      showStatus(urls.length + " link çözümleniyor (n11'e yönlendirme bekleniyor)...", "info");
      for (let i = 0; i < urls.length; i++) {
        showStatus(`Çözümleniyor: ${i + 1}/${urls.length}`, "info");
        try {
          const res = await chrome.runtime.sendMessage({ type: "akakce-resolve-redirect-to-n11", url: urls[i] });
          const rawN11Url = (res && res.ok && res.url) ? String(res.url).trim() : "";
          const n11Url = (() => {
            if (!rawN11Url) return "";
            try {
              const u = new URL(rawN11Url);
              const search = u.search || "";
              const idx = search.indexOf("utm_source=");
              let cleanSearch = search;
              if (idx > 0) {
                cleanSearch = search.slice(0, idx - 1);
              }
              return u.origin + u.pathname + (cleanSearch || "");
            } catch (e) {
              const cut = rawN11Url.includes("&utm_source=")
                ? rawN11Url.split("&utm_source=")[0]
                : rawN11Url.split("?utm_source=")[0];
              return cut;
            }
          })();
          const row = tableRows.find((r) => !r.error && String(r.redirectUrl || "").trim() === String(urls[i] || "").trim());
          if (row && n11Url) {
            row.n11Url = n11Url;
            try {
              const fetchRes = await fetch(n11Url, { credentials: "omit" });
              if (fetchRes && fetchRes.ok) {
                const html = await fetchRes.text();
                const info = extractProductInfoFromN11Html(html);
                row.productId = info.productId || "";
                row.title = info.productName || "";
                row.pimsId = info.pimsId || "";
                row.groupId = info.groupId || "";
                row.skuId = info.skuId || "";
              }
            } catch (fetchErr) {
              console.error("n11 fetch/parse error:", fetchErr);
            }
            renderTable();
          }
        } catch (e) {
          showStatus("Hata: " + (e?.message || "Yönlendirme tamamlanamadı"), "error");
        }
        if (i < urls.length - 1) await new Promise((r) => setTimeout(r, 1200));
      }
      showStatus(urls.length + " link n11 sayfasına ulaştı.", "success");
      resolveBtn.disabled = false;
    });
    downloadBtn.addEventListener("click", () => {
      if (tableRows.length === 0) {
        showStatus("İndirilecek veri yok.", "error");
        return;
      }
      const header = "Akakce ID;Akakce Link;Redirect URL;n11 Link;Product ID;Title;Pims ID;Group ID;Sku ID\n";
      const rows = tableRows
        .filter((r) => !r.error)
        .map((r) =>
          [
            escapeCsv(r.akakceId || ""),
            escapeCsv(r.akakceUrl || ""),
            escapeCsv(r.redirectUrl || ""),
            escapeCsv(r.n11Url || ""),
            escapeCsv(r.productId || ""),
            escapeCsv(r.title || ""),
            escapeCsv(r.pimsId || ""),
            escapeCsv(r.groupId || ""),
            escapeCsv(r.skuId || "")
          ].join(";")
        )
        .join("\n");
      const content = "\uFEFF" + header + rows;
      const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `akakce_id_n11_${new Date().toISOString().split("T")[0]}.csv`;
      a.style.visibility = "hidden";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showStatus("Excel indirildi", "success");
    });
  }
  modal.style.display = "flex";
  const resultWrap = modal.querySelector("#akakce-id-n11-result");
  if (resultWrap && resultWrap.innerHTML === "") {
    resultWrap.innerHTML = '<p class="akakce-crawler-empty">Henüz sonuç yok. ID girip "Ara ve Link Al" tıklayın.</p>';
  }
};

const openAkakceCustomDealModal = () => {
  let modal = document.getElementById(AKAKCE_CUSTOM_DEAL_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = AKAKCE_CUSTOM_DEAL_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Akakce Custom Deal</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="akakce-custom-deal-form">
          <label for="akakce-custom-deal-url">Akakce kategori/urun linki</label>
          <input
            id="akakce-custom-deal-url"
            type="url"
            placeholder="https://www.akakce.com/camasir-makinesi.html"
            autocomplete="off"
          />
          <div id="akakce-custom-deal-settings-wrap" class="akakce-custom-deal-settings-wrap">
            <div class="akakce-custom-deal-settings-title">Fiyat toplanacak markalar</div>
            <div class="akakce-custom-deal-settings-grid">
              <label class="akakce-custom-deal-settings-option akakce-custom-deal-tumu-option">
                <input type="checkbox" class="akakce-custom-deal-brand-checkbox" data-acd-platform="tumu" />
                <span class="akakce-custom-deal-tumu-label">Tümü</span>
              </label>
              <label class="akakce-custom-deal-settings-option">
                <input type="checkbox" class="akakce-custom-deal-brand-checkbox" data-acd-platform="hepsiburada" checked />
                <img src="${HEPSIBURADA_LOGO_URL}" alt="Hepsiburada" class="akakce-custom-deal-settings-logo" />
              </label>
              <label class="akakce-custom-deal-settings-option">
                <input type="checkbox" class="akakce-custom-deal-brand-checkbox" data-acd-platform="trendyol" checked />
                <img src="${TRENDYOL_LOGO_URL}" alt="Trendyol" class="akakce-custom-deal-settings-logo" />
                <span class="akakce-custom-deal-plus-badge">+ Plus</span>
              </label>
              <label class="akakce-custom-deal-settings-option">
                <input type="checkbox" class="akakce-custom-deal-brand-checkbox" data-acd-platform="pttavm" checked />
                <img src="${PTTAVM_LOGO_URL}" alt="PttAVM" class="akakce-custom-deal-settings-logo" />
              </label>
              <label class="akakce-custom-deal-settings-option">
                <input type="checkbox" class="akakce-custom-deal-brand-checkbox" data-acd-platform="amazon" checked />
                <img src="${AMAZON_LOGO_URL}" alt="Amazon" class="akakce-custom-deal-settings-logo" />
              </label>
              <label class="akakce-custom-deal-settings-option">
                <input type="checkbox" class="akakce-custom-deal-brand-checkbox" data-acd-platform="idefix" checked />
                <img src="${IDEFIX_LOGO_URL}" alt="idefix" class="akakce-custom-deal-settings-logo" />
              </label>
              <label class="akakce-custom-deal-settings-option">
                <input type="checkbox" class="akakce-custom-deal-brand-checkbox" data-acd-platform="teknosa" checked />
                <img src="${TEKNOSA_LOGO_URL}" alt="Teknosa" class="akakce-custom-deal-settings-logo" />
              </label>
              <label class="akakce-custom-deal-settings-option">
                <input type="checkbox" class="akakce-custom-deal-brand-checkbox" data-acd-platform="pazarama" checked />
                <img src="${PAZARAMA_LOGO_URL}" alt="Pazarama" class="akakce-custom-deal-settings-logo" />
              </label>
            </div>
          </div>
          <div class="akakce-custom-deal-actions">
            <button type="button" id="akakce-custom-deal-run-btn">Yeni sekmede ac ve filtreyi sec</button>
            <button type="button" id="akakce-custom-deal-export-btn" class="akakce-custom-deal-export-btn" disabled>Excel Indir</button>
          </div>
        </div>
        <div class="status" id="akakce-custom-deal-status"></div>
        <div id="akakce-custom-deal-result" class="akakce-crawler-result-wrap"></div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);
    const closeBtn = modal.querySelector(".modal-close");
    const runBtn = modal.querySelector("#akakce-custom-deal-run-btn");
    const exportBtn = modal.querySelector("#akakce-custom-deal-export-btn");
    const urlInput = modal.querySelector("#akakce-custom-deal-url");
    const statusDiv = modal.querySelector("#akakce-custom-deal-status");
    const resultWrap = modal.querySelector("#akakce-custom-deal-result");
    let currentRows = [];
    let akakceCustomDealSortState = null;
    const akakceDealFieldByPlatform = {
      tumu: "tumuPrice",
      hepsiburada: "hepsiburadaPrice",
      trendyol: "trendyolPrice",
      pttavm: "pttavmPrice",
      amazon: "amazonPrice",
      idefix: "idefixPrice",
      teknosa: "teknosaPrice",
      n11: "n11Price",
      pazarama: "pazaramaPrice",
      other: "otherPrice"
    };
    const akakceDealPlatformOrder = [
      { key: "tumu", logo: "", alt: "Tümü", label: "Tümü" },
      { key: "hepsiburada", logo: HEPSIBURADA_LOGO_URL, alt: "Hepsiburada" },
      { key: "trendyol", logo: TRENDYOL_LOGO_URL, alt: "Trendyol", label: "Trendyol" },
      { key: "pttavm", logo: PTTAVM_LOGO_URL, alt: "PttAVM" },
      { key: "amazon", logo: AMAZON_LOGO_URL, alt: "Amazon" },
      { key: "idefix", logo: IDEFIX_LOGO_URL, alt: "idefix" },
      { key: "teknosa", logo: TEKNOSA_LOGO_URL, alt: "Teknosa" },
      { key: "n11", logo: N11_LOGO_URL, alt: "n11" },
      { key: "pazarama", logo: PAZARAMA_LOGO_URL, alt: "Pazarama" },
      { key: "other", logo: "", alt: "Other", label: "Other" }
    ];
    const getAkakceCustomDealCrawlPlatforms = () => {
      const fromBoxes = Array.from(modal.querySelectorAll(".akakce-custom-deal-brand-checkbox:checked"))
        .map((el) => String(el.getAttribute("data-acd-platform") || "").trim())
        .filter(Boolean);
      if (fromBoxes.includes("tumu")) return ["tumu"];
      return fromBoxes.length ? fromBoxes : ["hepsiburada"];
    };
    const getAkakceCustomDealDisplayPlatforms = () => {
      const crawl = getAkakceCustomDealCrawlPlatforms();
      if (crawl.includes("tumu")) {
        return akakceDealPlatformOrder
          .map((p) => p.key)
          .filter((k) => k !== "tumu");
      }
      const set = new Set();
      crawl.forEach((k) => {
        if (k === "trendyol_plus") set.add("trendyol");
        else set.add(k);
      });
      set.add("n11");
      return akakceDealPlatformOrder.map((p) => p.key).filter((k) => set.has(k));
    };
    const orderedDealPlatforms = (selectedKeys) => {
      const set = new Set(selectedKeys);
      return akakceDealPlatformOrder.filter((p) => set.has(p.key));
    };
    modal.querySelectorAll(".akakce-custom-deal-brand-checkbox").forEach((cb) => {
      cb.addEventListener("change", () => {
        const plat = String(cb.getAttribute("data-acd-platform") || "").trim();
        if (plat === "tumu" && cb.checked) {
          modal.querySelectorAll(".akakce-custom-deal-brand-checkbox").forEach((other) => {
            if (other !== cb) other.checked = false;
          });
        } else if (plat !== "tumu" && cb.checked) {
          const tumuCb = modal.querySelector('.akakce-custom-deal-brand-checkbox[data-acd-platform="tumu"]');
          if (tumuCb) tumuCb.checked = false;
        }
        const keys = Array.from(modal.querySelectorAll(".akakce-custom-deal-brand-checkbox:checked"))
          .map((el) => String(el.getAttribute("data-acd-platform") || "").trim())
          .filter(Boolean);
        const toStore = keys.includes("tumu")
          ? ["tumu", "n11"]
          : Array.from(new Set(keys.concat(["n11"])));
        chrome.storage.local.set({ [STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS]: toStore }, () => {});
        if (currentRows.length) {
          renderRows(currentRows);
        }
      });
    });
    const escapeHtml = (s) => {
      if (s == null) return "";
      return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    };
    const parsePriceValue = (raw) => {
      const text = String(raw || "").trim();
      if (!text || text === "-") return null;
      const normalized = text
        .replace(/TL/gi, "")
        .replace(/[^\d,.\-]/g, "")
        .replace(/\./g, "")
        .replace(",", ".");
      const value = Number.parseFloat(normalized);
      return Number.isFinite(value) ? value : null;
    };
    const computeBuyBox = (selected, row) => {
      const classes = {};
      const values = [];
      selected.forEach((key) => {
        const field = akakceDealFieldByPlatform[key];
        if (!field) return;
        const num = parsePriceValue(row[field]);
        if (num != null) values.push({ key, num });
      });
      selected.forEach((key) => {
        const field = akakceDealFieldByPlatform[key];
        if (!field) return;
        const num = parsePriceValue(row[field]);
        if (num == null || values.length <= 1) {
          classes[key] = "price-neutral";
          return;
        }
        const min = Math.min(...values.map((v) => v.num));
        classes[key] = num <= min + 0.001 ? "price-low" : "price-high";
      });
      let buyBox = "-";
      if (selected.includes("n11")) {
        const n11v = parsePriceValue(row.n11Price);
        if (n11v == null) buyBox = "-";
        else {
          const others = selected
            .filter((k) => k !== "n11")
            .map((k) => parsePriceValue(row[akakceDealFieldByPlatform[k]]))
            .filter((v) => v != null);
          if (!others.length) buyBox = "Yes";
          else {
            const minAll = Math.min(n11v, ...others);
            buyBox = n11v <= minAll + 0.001 ? "Yes" : "No";
          }
        }
      }
      return { buyBox, classes };
    };
    const renderRows = (rows) => {
      currentRows = Array.isArray(rows) ? rows.slice() : [];
      if (akakceCustomDealSortState && akakceCustomDealSortState.key) {
        const sf = akakceDealFieldByPlatform[akakceCustomDealSortState.key];
        if (sf) {
          const asc = akakceCustomDealSortState.asc !== false;
          currentRows.sort((a, b) => {
            const va = parsePriceValue(a[sf]);
            const vb = parsePriceValue(b[sf]);
            if (va == null && vb == null) return 0;
            if (va == null) return 1;
            if (vb == null) return -1;
            const d = va - vb;
            return asc ? d : -d;
          });
        }
      }
      const selected = getAkakceCustomDealDisplayPlatforms();
      const cols = orderedDealPlatforms(selected);
      if (!Array.isArray(currentRows) || currentRows.length === 0) {
        resultWrap.innerHTML = '<p class="akakce-crawler-empty">Henuz veri yok.</p>';
        exportBtn.disabled = true;
        return;
      }
      let header =
        "<table class=\"akakce-crawler-table\"><thead><tr><th>Gorsel</th><th>Title</th><th>Akakce ID</th>";
      cols.forEach((c) => {
        const active =
          akakceCustomDealSortState && akakceCustomDealSortState.key === c.key;
        const sortCls = active
          ? akakceCustomDealSortState.asc
            ? " akakce-th-sort-active akakce-th-sort-asc"
            : " akakce-th-sort-active akakce-th-sort-desc"
          : "";
        if (c.key === "tumu" || c.key === "other" || !c.logo) {
          header +=
            "<th class=\"akakce-crawler-th-sortable" +
            sortCls +
            "\" data-acd-sort-key=\"" +
            escapeHtml(c.key) +
            "\" title=\"Bu sutuna gore sirala (tekrar: ters cevir)\"><span class=\"akakce-tumu-th\">" +
            escapeHtml(c.label || c.alt || c.key) +
            "</span></th>";
        } else {
          header +=
            "<th class=\"akakce-crawler-th-sortable" +
            sortCls +
            "\" data-acd-sort-key=\"" +
            escapeHtml(c.key) +
            "\" title=\"Bu markaya gore sirala (tekrar: ters cevir)\">" +
            "<img src=\"" +
            escapeHtml(c.logo) +
            '" alt="' +
            escapeHtml(c.alt) +
            '" class="akakce-platform-logo" /></th>';
        }
      });
      header += "<th>BuyBox?</th></tr></thead><tbody>";
      let html = header;
      currentRows.forEach((row) => {
        const imageUrl = row.imageUrl ? escapeHtml(row.imageUrl) : "";
        const imageCell = imageUrl
          ? '<img src="' + imageUrl + '" alt="" style="width:56px;height:56px;object-fit:cover;border-radius:6px;border:1px solid #e5e7eb;" />'
          : "-";
        const titleText = escapeHtml(row.title || "-");
        const id = escapeHtml(row.akakceId || "-");
        const link = escapeHtml(row.url || "");
        const titleCell = link
          ? '<a href="' + link + '" target="_blank" rel="noopener" class="akakce-link">' + titleText + "</a>"
          : titleText;
        const buybox = computeBuyBox(selected, row);
        const buyBoxClass = buybox.buyBox === "Yes" ? "buybox-yes" : (buybox.buyBox === "No" ? "buybox-no" : "");
        html += "<tr><td>" + imageCell + "</td><td>" + titleCell + "</td><td>" + id + "</td>";
        cols.forEach((c) => {
          const field = akakceDealFieldByPlatform[c.key];
          const cell = escapeHtml(field ? row[field] || "-" : "-");
          const cls = buybox.classes[c.key] || "price-neutral";
          html += "<td class=\"" + cls + " akakce-price-cell\">" + cell + "</td>";
        });
        html += "<td class=\"" + buyBoxClass + "\">" + buybox.buyBox + "</td></tr>";
      });
      html += "</tbody></table>";
      resultWrap.innerHTML = html;
      exportBtn.disabled = false;
    };
    const setStatus = (message, type) => {
      statusDiv.textContent = message;
      statusDiv.className = "status " + (type || "info");
      statusDiv.style.display = "block";
    };
    akakceCustomDealProgressHandler = (rows, pageCount) => {
      renderRows(rows);
      const rowCount = Array.isArray(rows) ? rows.length : 0;
      setStatus(
        rowCount + " urun toplandi" + (pageCount > 0 ? " (" + pageCount + " sayfa)" : "") + " — devam ediyor...",
        "info"
      );
    };
    akakceCustomDealCaptchaHandler = (hint) => {
      setStatus(hint || "Akakce guvenlik sayfasi...", "info");
    };
    resultWrap.addEventListener("click", (e) => {
      const th = e.target.closest("th[data-acd-sort-key]");
      if (!th || !resultWrap.contains(th)) return;
      const key = String(th.getAttribute("data-acd-sort-key") || "").trim();
      if (!key || !akakceDealFieldByPlatform[key]) return;
      if (akakceCustomDealSortState && akakceCustomDealSortState.key === key) {
        akakceCustomDealSortState = { key, asc: !akakceCustomDealSortState.asc };
      } else {
        akakceCustomDealSortState = { key, asc: true };
      }
      renderRows(currentRows);
    });
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
    exportBtn.addEventListener("click", () => {
      if (!currentRows.length) {
        setStatus("Indirilecek veri yok.", "error");
        return;
      }
      if (typeof XLSX === "undefined") {
        setStatus("XLSX kutuphanesi yuklenemedi. Sayfayi yenileyin.", "error");
        return;
      }
      try {
        const selected = getAkakceCustomDealDisplayPlatforms();
        const cols = orderedDealPlatforms(selected);
        const labelByKey = {
          tumu: "Tümü (ilk sıra)",
          hepsiburada: "Hepsiburada Fiyat",
          trendyol: "Trendyol Fiyat (Plus dahil, en düşük)",
          pttavm: "PttAVM Fiyat",
          amazon: "Amazon Fiyat",
          idefix: "idefix Fiyat",
          teknosa: "Teknosa Fiyat",
          n11: "n11 Fiyat",
          pazarama: "Pazarama Fiyat",
          other: "Other"
        };
        const header = ["Image URL", "Title", "Akakce Link", "Akakce ID"].concat(
          cols.map((c) => labelByKey[c.key] || c.key),
          ["BuyBox"]
        );
        const rows = currentRows.map((row) => {
          const buybox = computeBuyBox(selected, row).buyBox;
          const priceCells = cols.map((c) => {
            const f = akakceDealFieldByPlatform[c.key];
            return f ? row[f] || "-" : "-";
          });
          return [
            row.imageUrl || "",
            row.title || "",
            row.url || "",
            row.akakceId || "",
            ...priceCells,
            buybox
          ];
        });
        const ws = XLSX.utils.aoa_to_sheet([header, ...rows]);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Akakce Custom Deal");
        XLSX.writeFile(wb, `akakce_custom_deal_${new Date().toISOString().split("T")[0]}.xlsx`, {
          compression: true
        });
        setStatus("Excel indirildi.", "success");
      } catch (err) {
        setStatus("Excel indirme hatasi: " + (err && err.message ? err.message : "Bilinmeyen hata"), "error");
      }
    });
    runBtn.addEventListener("click", async () => {
      const rawUrl = String(urlInput.value || "").trim();
      if (!rawUrl) {
        setStatus("Lutfen Akakce linki girin.", "error");
        return;
      }
      let normalizedUrl = rawUrl;
      if (!/^https?:\/\//i.test(normalizedUrl)) {
        normalizedUrl = "https://" + normalizedUrl;
      }
      try {
        const parsed = new URL(normalizedUrl);
        if (!/(\.|^)akakce\.com$/i.test(parsed.hostname)) {
          setStatus("Gecersiz domain. Sadece akakce.com linki kullanin.", "error");
          return;
        }
      } catch (err) {
        setStatus("Gecersiz URL formati.", "error");
        return;
      }
      runBtn.disabled = true;
      exportBtn.disabled = true;
      akakceCustomDealSortState = null;
      currentRows = [];
      resultWrap.innerHTML = "";
      setStatus("Yeni sekme aciliyor ve liste toplaniyor...", "info");
      try {
        const res = await chrome.runtime.sendMessage({
          type: "akakce-custom-deal-open-tab-and-select-hepsiburada",
          url: normalizedUrl,
          platforms: getAkakceCustomDealCrawlPlatforms()
        });
        if (res && res.ok) {
          renderRows(res.rows || []);
          const pageCount = Number(res.pageCount || 0);
          const rowCount = Array.isArray(res.rows) ? res.rows.length : 0;
          setStatus(
            rowCount + " urun toplandi" + (pageCount > 0 ? " (" + pageCount + " sayfa)" : "") + ".",
            "success"
          );
        } else {
          setStatus((res && res.error) || "Islem basarisiz.", "error");
        }
      } catch (err) {
        setStatus((err && err.message) || "Beklenmeyen hata olustu.", "error");
      } finally {
        runBtn.disabled = false;
      }
    });
  }
  chrome.storage.local.get(STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS, (result) => {
    const stored = result && Array.isArray(result[STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS])
      ? result[STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS].map((item) => String(item || "").trim()).filter(Boolean)
      : [];
    const defaults = [
      "hepsiburada",
      "trendyol",
      "pttavm",
      "amazon",
      "idefix",
      "teknosa",
      "pazarama"
    ];
    const active = stored.length ? stored : defaults;
    if (active.includes("tumu")) {
      modal.querySelectorAll(".akakce-custom-deal-brand-checkbox").forEach((cb) => {
        const k = String(cb.getAttribute("data-acd-platform") || "").trim();
        cb.checked = k === "tumu";
      });
    } else {
      modal.querySelectorAll(".akakce-custom-deal-brand-checkbox").forEach((cb) => {
        const k = String(cb.getAttribute("data-acd-platform") || "").trim();
        cb.checked =
          active.includes(k) || (k === "trendyol" && active.includes("trendyol_plus"));
      });
    }
  });
  modal.style.display = "flex";
  const resultWrap = modal.querySelector("#akakce-custom-deal-result");
  if (resultWrap && resultWrap.innerHTML === "") {
    resultWrap.innerHTML = '<p class="akakce-crawler-empty">Henuz veri yok.</p>';
  }
};

const openAkakceFullCategoryModal = () => {
  let modal = document.getElementById(AKAKCE_FULL_CATEGORY_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = AKAKCE_FULL_CATEGORY_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card akakce-full-category-modal-card">
        <div class="modal-header">
          <div class="modal-title">Akakce Cat Products</div>
          <button type="button" class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="akakce-full-category-body">
          <label for="akakce-full-category-url">Akakce kategori URL</label>
          <input
            type="url"
            id="akakce-full-category-url"
            placeholder="https://www.akakce.com/bulasik-makinesi.html"
            autocomplete="off"
          />
          <p class="status info akakce-full-category-intro">Kategori sayfasındaki tüm ürün bilgileri toplanır ve JSON formatında indirilir.</p>
          <div class="akakce-full-category-actions">
            <button type="button" id="akakce-full-category-run">Tara ve JSON indir</button>
          </div>
          <div class="status akakce-full-category-crawl-progress" id="akakce-full-category-status" hidden></div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => {
      if (e.target === modal) modal.style.display = "none";
    });
    const closeBtn = modal.querySelector(".modal-close");
    const runBtn = modal.querySelector("#akakce-full-category-run");
    const urlInput = modal.querySelector("#akakce-full-category-url");
    const statusEl = modal.querySelector("#akakce-full-category-status");
    const setStatus = (text, type) => {
      const msg = text || "";
      statusEl.textContent = msg;
      const t = type || "info";
      if (t === "progress") {
        statusEl.className = "status akakce-full-category-crawl-progress";
      } else {
        statusEl.className = "status " + t;
      }
      if (msg) statusEl.removeAttribute("hidden");
      else statusEl.setAttribute("hidden", "");
    };
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
    runBtn.addEventListener("click", async () => {
      const raw = String(urlInput.value || "").trim();
      if (!raw) {
        setStatus("Lutfen Akakce kategori linki girin.", "error");
        return;
      }
      let normalized = raw;
      if (!/^https?:\/\//i.test(normalized)) normalized = "https://" + normalized;
      try {
        const parsed = new URL(normalized);
        if (!/(\.|^)akakce\.com$/i.test(parsed.hostname)) {
          setStatus("Sadece akakce.com adresi kullanin.", "error");
          return;
        }
      } catch {
        setStatus("Gecersiz URL.", "error");
        return;
      }
      runBtn.disabled = true;
      setStatus("Yeni sekmede kategori aciliyor, sayfalar taranıyor...", "progress");
      try {
        const res = await chrome.runtime.sendMessage({
          type: "akakce-full-category-crawl",
          url: normalized
        });
        if (res && res.ok && Array.isArray(res.products)) {
          const slug =
            (() => {
              try {
                const p = new URL(res.sourceUrl || normalized).pathname.replace(/\/+/g, "/");
                const base = p.split("/").filter(Boolean).pop() || "kategori";
                return base.replace(/\.html?$/i, "").replace(/[^\w\-]+/g, "_").slice(0, 80);
              } catch {
                return "kategori";
              }
            })();
          const payload = {
            sourceUrl: res.sourceUrl || normalized,
            crawledAt: new Date().toISOString(),
            pageCount: Number(res.pageCount || 0),
            totalProducts: res.products.length,
            products: res.products
          };
          const blob = new Blob([JSON.stringify(payload, null, 2)], {
            type: "application/json;charset=utf-8"
          });
          const objUrl = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = objUrl;
          a.download =
            "akakce_category_" +
            slug +
            "_" +
            new Date().toISOString().split("T")[0] +
            ".json";
          a.rel = "noopener";
          document.body.appendChild(a);
          a.click();
          a.remove();
          URL.revokeObjectURL(objUrl);
          setStatus(
            res.products.length +
              " urun, " +
              (res.pageCount || 0) +
              " sayfa — JSON indirildi.",
            "success"
          );
        } else {
          setStatus((res && res.error) || "Islem basarisiz.", "error");
        }
      } catch (err) {
        setStatus((err && err.message) || "Beklenmeyen hata.", "error");
      } finally {
        runBtn.disabled = false;
      }
    });
    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

const getN11DataLayerFirstPageName = () => {
  if (dataLayerPageNameFromPage) {
    return dataLayerPageNameFromPage;
  }
  if (!Array.isArray(window.dataLayer)) return "";
  const first = window.dataLayer.filter((item) => item && item.pageName)[0];
  return first?.pageName != null ? String(first.pageName) : "";
};

const isProductMatchScorePage = () => {
  const p = getN11DataLayerFirstPageName();
  return p === "search-result" || p === "category-listing";
};

const getModelTotalCountForProductMatch = () => {
  if (
    typeof modelTotalCountFromPage === "number" &&
    Number.isFinite(modelTotalCountFromPage)
  ) {
    return modelTotalCountFromPage;
  }
  if (!window.model || typeof window.model !== "object") return null;
  const v = window.model.totalCount;
  if (v == null || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

const clearProductMatchScoreAutoStorage = () => {
  try {
    sessionStorage.removeItem(PRODUCT_MATCH_SCORE_STORAGE_AUTO);
  } catch {
    /* ignore */
  }
};

const clearProductMatchScoreFlowArmed = () => {
  try {
    sessionStorage.removeItem(PRODUCT_MATCH_SCORE_FLOW_ARMED);
  } catch {
    /* ignore */
  }
};

const stopProductMatchScoreAutoFlow = () => {
  clearProductMatchScoreAutoStorage();
  clearProductMatchScoreFlowArmed();
};

const scrapeProductMatchScoreRowsFromDom = () => {
  const root = document.querySelector(".searchResults");
  if (!root) return [];
  const anchors = root.querySelectorAll(":scope > a");
  const rows = [];
  anchors.forEach((a) => {
    const href = (a.getAttribute("href") || "").trim();
    const prodId = (
      a.getAttribute("data-prod-id") ||
      (a.dataset && a.dataset.prodId) ||
      ""
    ).trim();
    const titleEl = a.querySelector("div.product-item-title");
    const title =
      titleEl && titleEl.textContent ? titleEl.textContent.trim() : "";
    rows.push({ href, prodId, title });
  });
  return rows;
};

const fetchProductMatchScoreRowsViaVueSearch = async (onProgress) => {
  const base = "https://www.n11.com";
  const u = new URL(window.location.href);
  u.searchParams.delete("pg");
  u.searchParams.delete("page");
  let pg = 1;
  const allRows = [];
  const seen = new Set();
  let totalPagesFromApi = null;
  const MAX_PG = 500;

  while (pg <= MAX_PG) {
    const fetchUrl = new URL(u.toString());
    fetchUrl.searchParams.set("vueSearch", "1");
    fetchUrl.searchParams.set("pg", String(pg));
    if (typeof onProgress === "function") {
      onProgress(pg, allRows.length);
    }
    const response = await fetch(fetchUrl.toString(), { credentials: "omit" });
    if (!response.ok) {
      break;
    }
    let json;
    try {
      json = await response.json();
    } catch {
      break;
    }
    if (totalPagesFromApi == null) {
      const candidates = [
        json?.data?.pagination?.totalPage,
        json?.data?.pagination?.totalPages,
        json?.data?.paging?.totalPage,
        json?.data?.paging?.totalPages,
        json?.data?.totalPage,
        json?.data?.totalPages,
        json?.data?.pageCount,
        json?.data?.searchResult?.pagination?.totalPage,
        json?.data?.searchResult?.pagination?.totalPages
      ];
      for (const cand of candidates) {
        const n = Number(cand);
        if (Number.isFinite(n) && n >= 1) {
          totalPagesFromApi = n;
          break;
        }
      }
    }
    if (json?.data?.suggestedKeywordsResult != null) {
      break;
    }
    let items = json?.data?.productListingItems;
    if (!Array.isArray(items) && isMagazaPage()) {
      items =
        json?.data?.storeProductListingItems ??
        json?.data?.products ??
        json?.data?.sellerProducts ??
        null;
    }
    if (!Array.isArray(items) || items.length === 0) {
      break;
    }
    let added = 0;
    for (const item of items) {
      if (!item || typeof item !== "object") continue;
      const productId = item.id != null ? String(item.id) : "";
      const pathRaw = item.urlWithoutSellerShop || item.url || "";
      const path = String(pathRaw).trim();
      const title =
        (item.title != null ? String(item.title) : "") ||
        (item.subtitle != null ? String(item.subtitle) : "") ||
        "";
      let href = "";
      if (path.startsWith("http")) {
        href = path;
      } else if (path) {
        href = path.startsWith("/") ? `${base}${path}` : `${base}/${path}`;
      }
      const key = productId || href;
      if (!key || seen.has(key)) continue;
      seen.add(key);
      allRows.push({ href, prodId: productId, title });
      added += 1;
    }
    if (added === 0 && items.length > 0) {
      break;
    }
    if (totalPagesFromApi != null && pg >= totalPagesFromApi) {
      break;
    }
    if (items.length < 20) {
      break;
    }
    pg += 1;
    await new Promise((r) => setTimeout(r, 300));
  }
  return allRows;
};

const PRODUCT_MATCH_SCORE_SIM_THRESHOLD = 0.8;

const productMatchScoreWordDiceSimilarity = (a, b) => {
  const sa = String(a || "")
    .toLowerCase()
    .trim()
    .replace(/[^\p{L}\p{N}\s]+/gu, " ");
  const sb = String(b || "")
    .toLowerCase()
    .trim()
    .replace(/[^\p{L}\p{N}\s]+/gu, " ");
  const wa = sa.split(/\s+/).filter(Boolean);
  const wb = sb.split(/\s+/).filter(Boolean);
  if (wa.length === 0 && wb.length === 0) return 1;
  if (wa.length === 0 || wb.length === 0) return 0;
  const mapA = new Map();
  for (const w of wa) mapA.set(w, (mapA.get(w) || 0) + 1);
  const mapB = new Map();
  for (const w of wb) mapB.set(w, (mapB.get(w) || 0) + 1);
  let inter = 0;
  for (const [w, c] of mapA) {
    if (mapB.has(w)) inter += Math.min(c, mapB.get(w));
  }
  return (2 * inter) / (wa.length + wb.length);
};

const computeProductMatchScoreBestMatches = (titles) => {
  const n = titles.length;
  const out = [];
  if (n < 2) {
    for (let i = 0; i < n; i += 1) {
      out.push({ score: null, bestIndex: null });
    }
    return out;
  }
  for (let i = 0; i < n; i += 1) {
    let max = -1;
    let bestJ = -1;
    const ti = titles[i];
    for (let j = 0; j < n; j += 1) {
      if (i === j) continue;
      const s = productMatchScoreWordDiceSimilarity(ti, titles[j]);
      if (s > max) {
        max = s;
        bestJ = j;
      }
    }
    out.push({
      score: bestJ >= 0 ? max : null,
      bestIndex: bestJ >= 0 ? bestJ : null
    });
  }
  return out;
};

const productMatchScoreRowDomId = (oneBasedIndex) =>
  `product-match-score-r-${oneBasedIndex}`;

const resetProductMatchScoreTableHeader = (modal) => {
  const theadRow = modal.querySelector(".product-match-score-table thead tr");
  if (!theadRow) return;
  theadRow.innerHTML = `
    <th class="product-match-score-idx-col" scope="col">#</th>
    <th>data-prod-id</th>
    <th width="34%">product-item-title</th>
  `;
};

const bindProductMatchScoreTableJumpLinks = (modal) => {
  const tb = modal.querySelector("#product-match-score-tbody");
  if (!tb || tb.dataset.pmsJumpBound === "1") return;
  tb.dataset.pmsJumpBound = "1";
  tb.addEventListener("click", (e) => {
    const a = e.target.closest("a.product-match-score-row-jump");
    if (!a || !tb.contains(a)) return;
    const href = a.getAttribute("href");
    if (!href || href.charAt(0) !== "#") return;
    const id = href.slice(1);
    if (!id) return;
    e.preventDefault();
    e.stopPropagation();
    const row = document.getElementById(id);
    if (!row || !modal.contains(row)) return;

    tb.querySelectorAll("tr.product-match-score-jump-active").forEach((tr) => {
      tr.classList.remove("product-match-score-jump-active");
    });
    tb.querySelectorAll("a.product-match-score-row-jump--active").forEach((x) => {
      x.classList.remove("product-match-score-row-jump--active");
    });

    row.classList.add("product-match-score-jump-active");
    a.classList.add("product-match-score-row-jump--active");

    let restoreDisplay = false;
    if (row.classList.contains("product-match-score-low-sim")) {
      row.style.display = "table-row";
      restoreDisplay = true;
    }
    row.scrollIntoView({ block: "center", behavior: "smooth", inline: "nearest" });
    if (restoreDisplay) {
      window.setTimeout(() => {
        row.style.removeProperty("display");
      }, 2200);
    }
  });
};

const runProductMatchScoreSkorla = (modal, opts) => {
  const onComplete =
    opts && typeof opts.onComplete === "function" ? opts.onComplete : null;
  const invokeComplete = () => {
    if (onComplete) onComplete();
  };

  const statusEl = modal.querySelector("#product-match-score-count-status");
  const tb = modal.querySelector("#product-match-score-tbody");
  const rows = lastProductMatchScoreRows;
  if (!tb || !rows.length) {
    if (statusEl) {
      statusEl.hidden = false;
      statusEl.className =
        "product-match-score-status product-match-score-status-bad";
      statusEl.textContent =
        "Önce listeyi «Tümünü Çek» veya «JSON Upload» ile doldurun.";
    }
    invokeComplete();
    return;
  }

  const trs = tb.querySelectorAll("tr");
  if (trs.length !== rows.length) {
    if (statusEl) {
      statusEl.hidden = false;
      statusEl.className =
        "product-match-score-status product-match-score-status-bad";
      statusEl.textContent = "Tablo ile veri uyumsuz; yeniden çekin.";
    }
    invokeComplete();
    return;
  }

  const theadRow = modal.querySelector(".product-match-score-table thead tr");
  if (theadRow && !theadRow.querySelector("th.product-match-score-skor-col")) {
    const thS = document.createElement("th");
    thS.className = "product-match-score-skor-col";
    thS.textContent = "Skor";
    const thM = document.createElement("th");
    thM.className = "product-match-score-match-col";
    thM.textContent = "Eşleşen";
    theadRow.append(thS, thM);
  }

  trs.forEach((tr) => {
    tr.classList.remove("product-match-score-low-sim");
    let td = tr.querySelector("td.product-match-score-skor-cell");
    if (!td) {
      td = document.createElement("td");
      td.className = "product-match-score-skor-cell";
      tr.appendChild(td);
    }
    td.textContent = "…";
    let tdM = tr.querySelector("td.product-match-score-match-cell");
    if (!tdM) {
      tdM = document.createElement("td");
      tdM.className = "product-match-score-match-cell";
      tr.appendChild(tdM);
    }
    tdM.textContent = "…";
    tdM.removeAttribute("title");
  });

  const titles = rows.map((r) => String(r.title || ""));
  window.requestAnimationFrame(() => {
    const bests = computeProductMatchScoreBestMatches(titles);
    trs.forEach((tr, i) => {
      const td = tr.querySelector("td.product-match-score-skor-cell");
      const tdM = tr.querySelector("td.product-match-score-match-cell");
      if (!td) return;
      const { score: sc, bestIndex } = bests[i] || {};
      if (sc == null || bestIndex == null) {
        td.textContent = "—";
        if (tdM) {
          tdM.textContent = "—";
          tdM.removeAttribute("title");
        }
        tr.classList.remove("product-match-score-low-sim");
        return;
      }
      td.textContent = `%${Math.round(sc * 100)}`;
      const other = rows[bestIndex];
      const fullTitle = String(other?.title || "").trim();
      const idPart = String(other?.prodId || "").trim();
      if (tdM) {
        const line = fullTitle
          ? fullTitle.length > 80
            ? `${fullTitle.slice(0, 80)}…`
            : fullTitle
          : "(başlık yok)";
        tdM.textContent = "";
        const jump = document.createElement("a");
        jump.className = "product-match-score-row-jump";
        jump.href = `#${productMatchScoreRowDomId(bestIndex + 1)}`;
        jump.textContent = `#${bestIndex + 1}`;
        tdM.appendChild(jump);
        tdM.appendChild(document.createTextNode(` · ${line}`));
        tdM.title = [
          `Liste sırası: ${bestIndex + 1} (tıkla: satıra git)`,
          idPart ? `Ürün ID: ${idPart}` : null,
          fullTitle ? `Başlık: ${fullTitle}` : null
        ]
          .filter(Boolean)
          .join("\n");
      }
      if (sc < PRODUCT_MATCH_SCORE_SIM_THRESHOLD) {
        tr.classList.add("product-match-score-low-sim");
      } else {
        tr.classList.remove("product-match-score-low-sim");
      }
    });
    if (statusEl) {
      const hidden = [...trs].filter((tr) =>
        tr.classList.contains("product-match-score-low-sim")
      ).length;
      statusEl.hidden = false;
      statusEl.className =
        "product-match-score-status product-match-score-status-info";
      statusEl.textContent = `Skor, listedeki başka bir ürünle en yüksek başlık benzerliğidir; «Eşleşen» sütununda eşleşen satır ve özet görünür (üzerine gelince tam metin ve ID). %${Math.round(PRODUCT_MATCH_SCORE_SIM_THRESHOLD * 100)} ve üzeri gösterilir; altı ${hidden} satır listede yok.`;
    }
    invokeComplete();
  });
};

const downloadProductMatchScoreJson = (rows, meta) => {
  const list = Array.isArray(rows) ? rows : [];
  const minp = meta && meta.minp != null ? Number(meta.minp) : NaN;
  const maxp = meta && meta.maxp != null ? Number(meta.maxp) : NaN;
  const minPart = Number.isFinite(minp) ? String(minp) : "na";
  const maxPart = Number.isFinite(maxp) ? String(maxp) : "na";
  const payload = {
    downloadedAt: new Date().toISOString(),
    sourceUrl: (meta && meta.sourceUrl) || "",
    modelTotalCount:
      meta && meta.totalCount != null && Number.isFinite(Number(meta.totalCount))
        ? Number(meta.totalCount)
        : null,
    minp: Number.isFinite(minp) ? minp : null,
    maxp: Number.isFinite(maxp) ? maxp : null,
    productCount: list.length,
    hint: (meta && meta.chainHint) || "",
    products: list.map((r) => ({
      id: r.prodId,
      url: r.href,
      title: r.title
    }))
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json;charset=utf-8"
  });
  const objUrl = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = objUrl;
  const d = new Date().toISOString().split("T")[0];
  a.download = `n11_product_match_${minPart}_${maxPart}_${d}.json`;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(objUrl);
};

const downloadProductMatchScoreExcel = (modal) => {
  if (typeof XLSX === "undefined") {
    return {
      error: "Excel (XLSX) kütüphanesi yüklenemedi. Sayfayı yenileyin."
    };
  }
  const list = lastProductMatchScoreRows;
  if (!Array.isArray(list) || !list.length) {
    return { error: "Önce tabloyu doldurun." };
  }
  const tb = modal && modal.querySelector("#product-match-score-tbody");
  const header = ["#", "Ürün ID", "Başlık", "URL", "Skor", "Eşleşen"];
  const body = list.map((r, i) => {
    let skorTxt = "";
    let esTxt = "";
    if (tb) {
      const tr = tb.querySelectorAll("tr")[i];
      if (tr) {
        const skEl = tr.querySelector("td.product-match-score-skor-cell");
        const mEl = tr.querySelector("td.product-match-score-match-cell");
        if (skEl) skorTxt = skEl.textContent.replace(/\s+/g, " ").trim();
        if (mEl) esTxt = mEl.textContent.replace(/\s+/g, " ").trim();
      }
    }
    return [i + 1, r.prodId, r.title, r.href, skorTxt, esTxt];
  });
  let minp = NaN;
  let maxp = NaN;
  try {
    const loc = new URL(window.location.href);
    minp = Number(loc.searchParams.get("minp"));
    maxp = Number(loc.searchParams.get("maxp"));
  } catch {
    /* ignore */
  }
  const minPart = Number.isFinite(minp) ? String(minp) : "na";
  const maxPart = Number.isFinite(maxp) ? String(maxp) : "na";
  const d = new Date().toISOString().split("T")[0];
  try {
    const ws = XLSX.utils.aoa_to_sheet([header, ...body]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Product Match");
    XLSX.writeFile(
      wb,
      `n11_product_match_${minPart}_${maxPart}_${d}.xlsx`,
      { bookType: "xlsx", compression: true }
    );
    return { ok: true, count: list.length };
  } catch (err) {
    return { error: (err && err.message) || "Excel oluşturulamadı." };
  }
};

const parseUploadedProductMatchScoreJson = (text) => {
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    return { error: "JSON okunamadı veya geçersiz." };
  }
  let products = null;
  if (Array.isArray(data)) {
    products = data;
  } else if (data && typeof data === "object") {
    if (Array.isArray(data.products)) products = data.products;
    else if (Array.isArray(data.items)) products = data.items;
  }
  if (!products || products.length === 0) {
    return {
      error:
        "Dosyada ürün listesi yok. İndirilen formatta `products` dizisi veya doğrudan ürün dizisi beklenir."
    };
  }
  const rows = [];
  for (const p of products) {
    if (!p || typeof p !== "object") continue;
    const href = String(p.url ?? p.href ?? "").trim();
    const prodId = String(p.id ?? p.prodId ?? "").trim();
    const title = String(p.title ?? p.productItemTitle ?? p.name ?? "").trim();
    if (!href && !prodId && !title) continue;
    rows.push({ href, prodId, title });
  }
  if (!rows.length) {
    return {
      error: "Hiç geçerli ürün satırı çıkarılamadı (url, id, title alanları)."
    };
  }
  return { rows };
};

const setProductMatchScoreJsonUploadLoading = (modal, on, message) => {
  const uploadJsonBtn = modal.querySelector("#product-match-score-upload-json");
  const statusEl = modal.querySelector("#product-match-score-count-status");
  if (uploadJsonBtn) uploadJsonBtn.disabled = Boolean(on);
  if (statusEl && on) {
    statusEl.hidden = false;
    statusEl.className =
      "product-match-score-status product-match-score-status-loading";
    statusEl.textContent = message || "Yükleniyor…";
  }
};

const handleProductMatchScoreJsonUpload = (modal, file) => {
  const statusEl = modal.querySelector("#product-match-score-count-status");
  modal.dataset.pmsJsonUploading = "1";
  const finishUploadUi = () => {
    delete modal.dataset.pmsJsonUploading;
    const uploadJsonBtn = modal.querySelector("#product-match-score-upload-json");
    if (uploadJsonBtn) uploadJsonBtn.disabled = false;
  };

  setProductMatchScoreJsonUploadLoading(modal, true, "JSON okunuyor…");

  const reader = new FileReader();
  reader.onload = () => {
    const parsed = parseUploadedProductMatchScoreJson(
      String(reader.result || "")
    );
    if (parsed.error) {
      if (statusEl) {
        statusEl.hidden = false;
        statusEl.className =
          "product-match-score-status product-match-score-status-bad";
        statusEl.textContent = parsed.error;
      }
      finishUploadUi();
      return;
    }
    setProductMatchScoreJsonUploadLoading(
      modal,
      true,
      "Tablo dolduruluyor, skor hesaplanıyor…"
    );
    fillProductMatchScoreTable(modal, parsed.rows);
    syncProductMatchScoreModal(modal);
    setProductMatchScoreJsonUploadLoading(modal, true, "Skor hesaplanıyor…");
    runProductMatchScoreSkorla(modal, { onComplete: finishUploadUi });
  };
  reader.onerror = () => {
    if (statusEl) {
      statusEl.hidden = false;
      statusEl.className =
        "product-match-score-status product-match-score-status-bad";
      statusEl.textContent = "Dosya okunamadı.";
    }
    finishUploadUi();
  };
  reader.readAsText(file, "UTF-8");
};

const buildProductMatchScoreProductLinkUrl = (r) => {
  const raw = String(r.href || "").trim();
  const idText = String(r.prodId || "").trim();
  if (raw) {
    try {
      if (/^https?:\/\//i.test(raw)) {
        return new URL(raw).href;
      }
      return new URL(raw.startsWith("/") ? raw : `/${raw}`, "https://www.n11.com")
        .href;
    } catch {
      /* fall through */
    }
  }
  if (idText && /^\d+$/.test(idText)) {
    return `https://www.n11.com/urun/urun-${idText}`;
  }
  return "";
};

const fillProductMatchScoreTable = (modal, rows) => {
  const safeRows = Array.isArray(rows) ? rows : [];
  lastProductMatchScoreRows = safeRows.slice();
  const tb = modal.querySelector("#product-match-score-tbody");
  if (!tb) return;
  resetProductMatchScoreTableHeader(modal);
  tb.innerHTML = "";
  safeRows.forEach((r, i) => {
    const tr = document.createElement("tr");
    const displayN = i + 1;
    tr.id = productMatchScoreRowDomId(displayN);
    const tdIdx = document.createElement("td");
    tdIdx.className = "product-match-score-idx-cell";
    tdIdx.textContent = String(displayN);
    const tdId = document.createElement("td");
    const tdTitle = document.createElement("td");

    const idText = String(r.prodId || "").trim();
    const productUrl = buildProductMatchScoreProductLinkUrl(r);
    if (productUrl && idText) {
      const a = document.createElement("a");
      a.className = "product-match-score-prod-link";
      a.href = productUrl;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = idText;
      tdId.appendChild(a);
    } else {
      tdId.textContent = idText || "—";
    }

    tdTitle.textContent = r.title;
    tr.append(tdIdx, tdId, tdTitle);
    tb.appendChild(tr);
  });
};

const navigateProductMatchScoreWithMinpMaxp = (minp, maxp, opts) => {
  const nextMin = String(Math.round(minp));
  const nextMax = String(Math.round(maxp));
  const url = new URL(window.location.href);
  const curMin = url.searchParams.get("minp");
  const curMax = url.searchParams.get("maxp");
  url.searchParams.set("minp", nextMin);
  url.searchParams.set("maxp", nextMax);
  const nextUrl = url.toString();
  if (curMin === nextMin && curMax === nextMax && window.location.href.split("#")[0] === nextUrl.split("#")[0]) {
    return false;
  }
  const reopenModal = !opts || opts.reopenModal !== false;
  if (reopenModal) {
    try {
      sessionStorage.setItem(PRODUCT_MATCH_SCORE_STORAGE_REOPEN, "1");
    } catch {
      /* ignore */
    }
  }
  window.location.assign(nextUrl);
  return true;
};

const scheduleProductMatchScoreModalReopenIfPending = () => {
  window.setTimeout(() => {
    let pending = false;
    try {
      pending = sessionStorage.getItem(PRODUCT_MATCH_SCORE_STORAGE_REOPEN) === "1";
      if (pending) {
        sessionStorage.removeItem(PRODUCT_MATCH_SCORE_STORAGE_REOPEN);
      }
    } catch {
      return;
    }
    if (!pending || isExtensionHidden) {
      return;
    }
    openProductMatchScoreModal();
  }, 500);
};

const PRODUCT_MATCH_SCORE_PRICE_STEP_MIN = 8;
const PRODUCT_MATCH_SCORE_PRICE_STEP_MAX = 140;

const randomProductMatchScorePriceDelta = () => {
  const lo = PRODUCT_MATCH_SCORE_PRICE_STEP_MIN;
  const hi = PRODUCT_MATCH_SCORE_PRICE_STEP_MAX;
  return lo + Math.floor(Math.random() * (hi - lo + 1));
};

const stepProductMatchScoreMinMaxRandomShift = (minp, maxp) => {
  const delta = randomProductMatchScorePriceDelta();
  return {
    minp: Math.round(minp + delta),
    maxp: Math.round(maxp + delta)
  };
};

const PRODUCT_MATCH_SCORE_DEFAULT_MINP = 1;
const PRODUCT_MATCH_SCORE_DEFAULT_MAXP = 500;

const buildProductMatchScoreAutoState = () => ({
  v: 1,
  maxSteps: 80,
  stepCount: 0,
  waitTries: 0,
  chainVueDownload: true
});

const ensureProductMatchScoreAutoFlow = () => {
  if (!isPublicN11Host() || !canApplyProductMatchScorePriceParams()) {
    return;
  }
  try {
    const url = new URL(window.location.href);
    const minpRaw = url.searchParams.get("minp");
    const maxpRaw = url.searchParams.get("maxp");
    const minp = Number(minpRaw);
    const maxp = Number(maxpRaw);
    const hasPair =
      minpRaw != null &&
      maxpRaw != null &&
      Number.isFinite(minp) &&
      Number.isFinite(maxp) &&
      minp >= 0 &&
      maxp >= 0;

    if (!hasPair) {
      sessionStorage.setItem(
        PRODUCT_MATCH_SCORE_STORAGE_AUTO,
        JSON.stringify(buildProductMatchScoreAutoState())
      );
      navigateProductMatchScoreWithMinpMaxp(
        PRODUCT_MATCH_SCORE_DEFAULT_MINP,
        PRODUCT_MATCH_SCORE_DEFAULT_MAXP,
        { reopenModal: true }
      );
      return;
    }

    let raw = null;
    try {
      raw = sessionStorage.getItem(PRODUCT_MATCH_SCORE_STORAGE_AUTO);
    } catch {
      raw = null;
    }
    if (!raw) {
      const tc = getModelTotalCountForProductMatch();
      if (tc == null || tc < 700 || tc > 1000) {
        sessionStorage.setItem(
          PRODUCT_MATCH_SCORE_STORAGE_AUTO,
          JSON.stringify(buildProductMatchScoreAutoState())
        );
        window.setTimeout(tryResumeProductMatchScoreAuto, 250);
      }
    }
  } catch {
    /* ignore */
  }
};

const finishProductMatchScoreAutoSuccess = (totalCount) => {
  clearProductMatchScoreAutoStorage();
  openProductMatchScoreModal();
  (async () => {
    const m = document.getElementById(PRODUCT_MATCH_SCORE_MODAL_ID);
    const st = m?.querySelector("#product-match-score-count-status");
    if (st) {
      st.hidden = false;
      st.className =
        "product-match-score-status product-match-score-status-info";
      st.textContent =
        "Otomatik zincir: vueSearch ile tüm sayfalar alınıyor...";
    }
    let rows = [];
    try {
      rows = await fetchProductMatchScoreRowsViaVueSearch((page, n) => {
        if (st) {
          st.textContent = `vueSearch sayfa ${page}… (${n} ürün toplandı)`;
        }
      });
    } catch (err) {
      stopProductMatchScoreAutoFlow();
      if (st) {
        st.className =
          "product-match-score-status product-match-score-status-bad";
        st.textContent = (err && err.message) || "Liste alınamadı.";
      }
      return;
    }

    let minp = NaN;
    let maxp = NaN;
    let sourceUrl = "";
    try {
      const loc = new URL(window.location.href);
      sourceUrl = loc.toString();
      minp = Number(loc.searchParams.get("minp"));
      maxp = Number(loc.searchParams.get("maxp"));
    } catch {
      /* ignore */
    }

    downloadProductMatchScoreJson(rows, {
      totalCount,
      minp,
      maxp,
      sourceUrl,
      chainHint: "auto-chain"
    });

    if (Number.isFinite(minp) && Number.isFinite(maxp)) {
      try {
        sessionStorage.setItem(
          PRODUCT_MATCH_SCORE_STORAGE_AUTO,
          JSON.stringify(buildProductMatchScoreAutoState())
        );
      } catch {
        /* ignore */
      }
      const nextRange = stepProductMatchScoreMinMaxRandomShift(minp, maxp);
      if (st) {
        st.textContent = `JSON indirildi (${rows.length} ürün). Sonraki aralığa rastgele kaydırma (+${nextRange.minp - minp} TL) ile geçiliyor...`;
      }
      navigateProductMatchScoreWithMinpMaxp(nextRange.minp, nextRange.maxp, {
        reopenModal: false
      });
      return;
    }

    if (!m) return;
    fillProductMatchScoreTable(m, rows);
    syncProductMatchScoreModal(m);
    stopProductMatchScoreAutoFlow();
    if (st) {
      st.hidden = false;
      st.className =
        "product-match-score-status product-match-score-status-ok";
      st.textContent = `Tamam: ${totalCount} sonuç (700–1000). ${rows.length} satır; JSON indirildi (minp/maxp eksik, zincir durdu).`;
    }
  })();
};

const tryResumeProductMatchScoreAuto = () => {
  if (!isPublicN11Host()) return;
  let armed = null;
  try {
    armed = sessionStorage.getItem(PRODUCT_MATCH_SCORE_FLOW_ARMED);
  } catch {
    return;
  }
  if (armed !== "1") {
    try {
      if (sessionStorage.getItem(PRODUCT_MATCH_SCORE_STORAGE_AUTO)) {
        sessionStorage.removeItem(PRODUCT_MATCH_SCORE_STORAGE_AUTO);
      }
    } catch {
      /* ignore */
    }
    return;
  }
  let raw = null;
  try {
    raw = sessionStorage.getItem(PRODUCT_MATCH_SCORE_STORAGE_AUTO);
  } catch {
    return;
  }
  if (!raw) return;
  let state = null;
  try {
    state = JSON.parse(raw);
  } catch {
    stopProductMatchScoreAutoFlow();
    return;
  }
  if (!state || state.v !== 1) {
    stopProductMatchScoreAutoFlow();
    return;
  }
  if (!canApplyProductMatchScorePriceParams()) {
    stopProductMatchScoreAutoFlow();
    return;
  }

  let minp;
  let maxp;
  try {
    const url = new URL(window.location.href);
    minp = Number(url.searchParams.get("minp"));
    maxp = Number(url.searchParams.get("maxp"));
  } catch {
    minp = NaN;
    maxp = NaN;
  }
  if (!Number.isFinite(minp) || !Number.isFinite(maxp)) {
    stopProductMatchScoreAutoFlow();
    return;
  }

  const tc = getModelTotalCountForProductMatch();
  if (tc === null) {
    const waitTries = Number(state.waitTries) || 0;
    if (waitTries >= 50) {
      stopProductMatchScoreAutoFlow();
      return;
    }
    state.waitTries = waitTries + 1;
    try {
      sessionStorage.setItem(
        PRODUCT_MATCH_SCORE_STORAGE_AUTO,
        JSON.stringify(state)
      );
    } catch {
      /* ignore */
    }
    window.setTimeout(tryResumeProductMatchScoreAuto, 400);
    return;
  }

  state.waitTries = 0;
  try {
    sessionStorage.setItem(
      PRODUCT_MATCH_SCORE_STORAGE_AUTO,
      JSON.stringify(state)
    );
  } catch {
    /* ignore */
  }

  if (tc >= 700 && tc <= 1000) {
    finishProductMatchScoreAutoSuccess(tc);
    return;
  }

  const maxSteps = Number(state.maxSteps) || 80;
  const stepCount = Number(state.stepCount) || 0;
  if (stepCount >= maxSteps) {
    stopProductMatchScoreAutoFlow();
    openProductMatchScoreModal();
    window.requestAnimationFrame(() => {
      const m = document.getElementById(PRODUCT_MATCH_SCORE_MODAL_ID);
      if (!m) return;
      syncProductMatchScoreModal(m);
      const st = m.querySelector("#product-match-score-count-status");
      if (st) {
        st.hidden = false;
        st.className =
          "product-match-score-status product-match-score-status-bad";
        st.textContent = `Otomatik durdu: ${maxSteps} adım sonunda aralık bulunamadı (son totalCount: ${tc}).`;
      }
    });
    return;
  }

  const next = stepProductMatchScoreMinMaxRandomShift(minp, maxp);
  const nextState = {
    v: 1,
    maxSteps,
    stepCount: stepCount + 1,
    waitTries: 0,
    chainVueDownload: true
  };
  try {
    sessionStorage.setItem(
      PRODUCT_MATCH_SCORE_STORAGE_AUTO,
      JSON.stringify(nextState)
    );
  } catch {
    /* ignore */
  }
  navigateProductMatchScoreWithMinpMaxp(next.minp, next.maxp);
};

const syncProductMatchScoreModal = (modal) => {
  const warnEl = modal.querySelector("#product-match-score-page-warning");
  const fetchVueBtn = modal.querySelector("#product-match-score-fetch-vue");
  const downloadJsonBtn = modal.querySelector("#product-match-score-download-json");
  const downloadXlsxBtn = modal.querySelector("#product-match-score-download-xlsx");
  const startFlowBtn = modal.querySelector("#product-match-score-start");
  const uploadJsonBtn = modal.querySelector("#product-match-score-upload-json");
  const skorlaBtn = modal.querySelector("#product-match-score-skorla");
  const statusEl = modal.querySelector("#product-match-score-count-status");
  if (!warnEl || !statusEl) return;

  const jsonUploadBusy = modal.dataset.pmsJsonUploading === "1";

  let urlMin = "";
  let urlMax = "";
  try {
    const url = new URL(window.location.href);
    urlMin = url.searchParams.get("minp") || "";
    urlMax = url.searchParams.get("maxp") || "";
  } catch {
    /* ignore */
  }
  const rangeHint =
    urlMin !== "" && urlMax !== ""
      ? `URL: minp=${urlMin} maxp=${urlMax}. `
      : "URL’de henüz minp/maxp yok; «Başlat» ile 1–500 uygulanır. ";

  const pageName = getN11DataLayerFirstPageName();
  const strictOk = isProductMatchScorePage();
  const canOk = canApplyProductMatchScorePriceParams();

  if (!canOk) {
    warnEl.hidden = false;
    warnEl.className = "product-match-score-warning";
    warnEl.textContent = `Bu araç arama veya kategori listeleme sayfalarında kullanılır. dataLayer pageName: "${pageName || "(yok)"}". «JSON Upload» ile indirdiğiniz dosyayı bu sayfada da yükleyebilirsiniz.`;
    if (fetchVueBtn) fetchVueBtn.disabled = true;
    if (downloadJsonBtn) downloadJsonBtn.disabled = true;
    if (downloadXlsxBtn) downloadXlsxBtn.disabled = true;
    if (startFlowBtn) startFlowBtn.disabled = true;
    if (uploadJsonBtn) uploadJsonBtn.disabled = jsonUploadBusy;
    if (skorlaBtn) skorlaBtn.disabled = !lastProductMatchScoreRows.length;
    if (!jsonUploadBusy) {
      statusEl.hidden = false;
      statusEl.className =
        "product-match-score-status product-match-score-status-info";
      statusEl.textContent = lastProductMatchScoreRows.length
        ? `Tabloda ${lastProductMatchScoreRows.length} ürün (JSON). «Skorla» ile yeniden skorlayabilirsiniz.`
        : "Liste çekmek için uygun sayfada olun veya «JSON Upload» kullanın.";
    }
    return;
  }

  if (!strictOk) {
    warnEl.hidden = false;
    warnEl.className = "product-match-score-hint";
    warnEl.textContent =
      "Kategori/arama algılandı. Otomatik tarama için «Başlat»a basın (700–1000 hedef; minp/maxp rastgele kayar).";
  } else {
    warnEl.hidden = true;
    warnEl.className = "product-match-score-warning";
  }
  if (fetchVueBtn) fetchVueBtn.disabled = false;
  if (downloadJsonBtn) downloadJsonBtn.disabled = false;
  if (downloadXlsxBtn) downloadXlsxBtn.disabled = false;
  if (startFlowBtn) startFlowBtn.disabled = false;
  if (uploadJsonBtn) uploadJsonBtn.disabled = jsonUploadBusy;
  if (skorlaBtn) {
    skorlaBtn.disabled = !lastProductMatchScoreRows.length;
  }

  const tc = getModelTotalCountForProductMatch();
  if (jsonUploadBusy) {
    return;
  }
  statusEl.hidden = false;
  if (tc === null) {
    statusEl.className =
      "product-match-score-status product-match-score-status-info";
    statusEl.textContent =
      rangeHint +
      "model.totalCount bekleniyor. Otomatik tarama yalnızca «Başlat» sonrası çalışır. «Tekrar kontrol» kullanılabilir.";
  } else if (tc >= 700 && tc <= 1000) {
    statusEl.className =
      "product-match-score-status product-match-score-status-ok";
    statusEl.textContent =
      rangeHint +
        `Ürün sayısı uygun: ${tc} (700–1000). «Tümünü Çek» veya «JSON Upload» ile listeyi alın.`;
  } else {
    statusEl.className =
      "product-match-score-status product-match-score-status-bad";
    statusEl.textContent =
      rangeHint +
      `Ürün sayısı: ${tc}. Hedef 700–1000; «Başlat» ile tarama açıksa minp/maxp rastgele kaydırılarak devam eder.`;
  }
};

const openProductMatchScoreModal = () => {
  let modal = document.getElementById(PRODUCT_MATCH_SCORE_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PRODUCT_MATCH_SCORE_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card product-match-score-modal-card">
        <div class="modal-header">
          <div class="modal-title">Product Match Score</div>
          <button type="button" class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <p id="product-match-score-page-warning" class="product-match-score-warning" hidden></p>
        <div class="product-match-score-body">
          <div class="product-match-score-actions">
            <button type="button" id="product-match-score-start">Başlat</button>
            <button type="button" id="product-match-score-fetch-vue" class="product-match-score-secondary">Tümünü Çek</button>
            <button type="button" id="product-match-score-download-json" class="product-match-score-secondary">JSON indir</button>
            <button type="button" id="product-match-score-download-xlsx" class="product-match-score-secondary">Excel indir</button>
            <button type="button" id="product-match-score-upload-json" class="product-match-score-secondary">JSON Upload</button>
            <input type="file" id="product-match-score-json-file" accept=".json,application/json" hidden aria-hidden="true" />
            <button type="button" id="product-match-score-skorla" class="product-match-score-skorla-btn">Skorla</button>
            <button type="button" id="product-match-score-recheck" class="product-match-score-secondary">Tekrar kontrol</button>
          </div>
        </div>
        <div id="product-match-score-count-status" class="product-match-score-status" hidden></div>
        <div class="product-match-score-table-wrap">
          <table class="product-match-score-table">
            <thead>
              <tr>
                <th class="product-match-score-idx-col" scope="col">#</th>
                <th>data-prod-id</th>
                <th>product-item-title</th>
              </tr>
            </thead>
            <tbody id="product-match-score-tbody"></tbody>
          </table>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => {
      if (e.target === modal) modal.style.display = "none";
    });
    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
    const startFlowBtn = modal.querySelector("#product-match-score-start");
    startFlowBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const statusEl = modal.querySelector("#product-match-score-count-status");
      if (!canApplyProductMatchScorePriceParams()) {
        if (statusEl) {
          statusEl.hidden = false;
          statusEl.className =
            "product-match-score-status product-match-score-status-bad";
          statusEl.textContent =
            "Bu sayfa tipinde otomatik fiyat taraması başlatılamaz.";
        }
        return;
      }
      try {
        sessionStorage.setItem(PRODUCT_MATCH_SCORE_FLOW_ARMED, "1");
      } catch {
        /* ignore */
      }
      ensureProductMatchScoreAutoFlow();
      if (statusEl) {
        statusEl.hidden = false;
        statusEl.className =
          "product-match-score-status product-match-score-status-info";
        statusEl.textContent =
          "Otomatik fiyat taraması başlatıldı (700–1000 hedef; minp/maxp rastgele kaydırılır).";
      }
    });
    const jsonFileInput = modal.querySelector("#product-match-score-json-file");
    const uploadJsonBtn = modal.querySelector("#product-match-score-upload-json");
    uploadJsonBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      jsonFileInput.click();
    });
    jsonFileInput.addEventListener("change", () => {
      const f = jsonFileInput.files && jsonFileInput.files[0];
      jsonFileInput.value = "";
      if (!f) return;
      handleProductMatchScoreJsonUpload(modal, f);
    });
    const fetchVueBtn = modal.querySelector("#product-match-score-fetch-vue");
    fetchVueBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const statusEl = modal.querySelector("#product-match-score-count-status");
      if (!canApplyProductMatchScorePriceParams()) {
        if (statusEl) {
          statusEl.hidden = false;
          statusEl.className =
            "product-match-score-status product-match-score-status-bad";
          statusEl.textContent =
            "Bu sayfa tipinde vueSearch ile liste alınamaz.";
        }
        return;
      }
      fetchVueBtn.disabled = true;
      try {
        if (statusEl) {
          statusEl.hidden = false;
          statusEl.className =
            "product-match-score-status product-match-score-status-info";
          statusEl.textContent = "vueSearch=1 ile sayfalar isteniyor...";
        }
        const rows = await fetchProductMatchScoreRowsViaVueSearch(
          (page, n) => {
            if (statusEl) {
              statusEl.textContent = `vueSearch sayfa ${page}… (${n} ürün toplandı)`;
            }
          }
        );
        fillProductMatchScoreTable(modal, rows);
        if (statusEl) {
          statusEl.hidden = false;
          statusEl.className =
            "product-match-score-status product-match-score-status-ok";
          statusEl.textContent = `vueSearch ile ${rows.length} ürün toplandı.`;
        }
      } catch (err) {
        if (statusEl) {
          statusEl.hidden = false;
          statusEl.className =
            "product-match-score-status product-match-score-status-bad";
          statusEl.textContent =
            (err && err.message) || "vueSearch isteği başarısız.";
        }
      } finally {
        fetchVueBtn.disabled = false;
        syncProductMatchScoreModal(modal);
      }
    });
    const downloadJsonBtn = modal.querySelector("#product-match-score-download-json");
    downloadJsonBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const statusEl = modal.querySelector("#product-match-score-count-status");
      if (!lastProductMatchScoreRows.length) {
        if (statusEl) {
          statusEl.hidden = false;
          statusEl.className =
            "product-match-score-status product-match-score-status-bad";
          statusEl.textContent =
            "Önce tabloyu doldurun («Tümünü Çek» veya «JSON Upload»).";
        }
        return;
      }
      let minp = NaN;
      let maxp = NaN;
      let sourceUrl = "";
      try {
        const loc = new URL(window.location.href);
        sourceUrl = loc.toString();
        minp = Number(loc.searchParams.get("minp"));
        maxp = Number(loc.searchParams.get("maxp"));
      } catch {
        /* ignore */
      }
      downloadProductMatchScoreJson(lastProductMatchScoreRows, {
        totalCount: getModelTotalCountForProductMatch(),
        minp,
        maxp,
        sourceUrl,
        chainHint: "manual-download"
      });
      if (statusEl) {
        statusEl.hidden = false;
        statusEl.className =
          "product-match-score-status product-match-score-status-ok";
        statusEl.textContent = `JSON indirildi (${lastProductMatchScoreRows.length} ürün).`;
      }
    });
    const downloadXlsxBtn = modal.querySelector("#product-match-score-download-xlsx");
    downloadXlsxBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const statusEl = modal.querySelector("#product-match-score-count-status");
      const result = downloadProductMatchScoreExcel(modal);
      if (result.error) {
        if (statusEl) {
          statusEl.hidden = false;
          statusEl.className =
            "product-match-score-status product-match-score-status-bad";
          statusEl.textContent = result.error;
        }
        return;
      }
      if (statusEl) {
        statusEl.hidden = false;
        statusEl.className =
          "product-match-score-status product-match-score-status-ok";
        statusEl.textContent = `Excel indirildi (${result.count} satır).`;
      }
    });
    const skorlaBtn = modal.querySelector("#product-match-score-skorla");
    if (skorlaBtn) {
      skorlaBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        runProductMatchScoreSkorla(modal);
      });
    }
    const recheckBtn = modal.querySelector("#product-match-score-recheck");
    recheckBtn.addEventListener("click", () => {
      syncProductMatchScoreModal(modal);
    });
    bindProductMatchScoreTableJumpLinks(modal);
    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
  syncProductMatchScoreModal(modal);
  window.setTimeout(() => {
    const el = document.getElementById(PRODUCT_MATCH_SCORE_MODAL_ID);
    if (el && el.style.display === "flex") {
      syncProductMatchScoreModal(el);
    }
  }, 450);
};

const findPimsIdFromPage = () => {
  if (window.model && typeof window.model === "object") {
    const visited = new Set();
    const stack = [window.model];
    while (stack.length > 0) {
      const current = stack.pop();
      if (!current || typeof current !== "object" || visited.has(current)) {
        continue;
      }
      visited.add(current);
      if (Object.prototype.hasOwnProperty.call(current, "pimsId")) {
        const v = current.pimsId;
        if (v != null && String(v).trim() !== "") {
          return String(v).trim();
        }
      }
      if (Array.isArray(current)) {
        current.forEach((item) => stack.push(item));
      } else {
        Object.values(current).forEach((val) => {
          if (val && typeof val === "object") {
            stack.push(val);
          }
        });
      }
    }
  }
  return "";
};

const extractProductInfoFromN11Html = (html) => {
  let productName = "";
  let pimsId = null;
  let gtin = null;
  let productId = null;
  let sku = null;
  let groupId = null;
  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const h1El = doc.querySelector(".pdpMainInfo h1");
    if (h1El && h1El.textContent) {
      productName = h1El.textContent.trim();
    }
    const parseScripts = (scripts) => {
      for (const script of scripts) {
        if (!script || !script.includes("model") || !script.includes("adData")) continue;
        if (!pimsId && script.includes("product") && script.includes("defaultPimsId")) {
          const m = script.match(/model\.product\.defaultPimsId\s*[=:]\s*(\d+)/);
          if (m && m[1]) pimsId = m[1];
          else {
            const j = script.match(/"defaultPimsId"\s*:\s*(\d+)/);
            if (j && j[1]) pimsId = j[1];
          }
        }
        if (!gtin && script.includes("product") && script.includes("defaultGtin")) {
          const m = script.match(/model\.product\.defaultGtin\s*[=:]\s*["']?(\d+)["']?/i);
          if (m && m[1]) gtin = m[1];
          else {
            const j = script.match(/"defaultGtin"\s*:\s*["']?(\d+)["']?/i);
            if (j && j[1]) gtin = j[1];
          }
        }
        if (!productId && script.includes("productId")) {
          const m = script.match(/model\.adData\.productId\s*[=:]\s*["']?(\d+)["']?/);
          if (m && m[1]) productId = m[1];
          else {
            const j = script.match(/"adData"\s*:\s*\{[\s\S]*?"productId"\s*:\s*["']?(\d+)["']?/);
            if (j && j[1]) productId = j[1];
          }
        }
        if (!sku && script.includes("skuId")) {
          const m = script.match(/model\.adData\.skuId\s*[=:]\s*["']?(\d+)["']?/);
          if (m && m[1]) sku = m[1];
          else {
            const j = script.match(/"adData"\s*:\s*\{[\s\S]*?"skuId"\s*:\s*["']?(\d+)["']?/);
            if (j && j[1]) sku = j[1];
          }
        }
        if (!groupId && script.includes("groupId")) {
          const m = script.match(/model\.adData\.groupId\s*[=:]\s*(\d+)/);
          if (m && m[1]) groupId = m[1];
          else {
            const j = script.match(/"adData"\s*:\s*\{[\s\S]*?"groupId"\s*:\s*(\d+)/);
            if (j && j[1]) groupId = j[1];
          }
        }
      }
    };
    const scriptMatches = html.match(/<script[^>]*>[\s\S]*?<\/script>/gi) || [];
    parseScripts(scriptMatches);
    if (!pimsId || !gtin || !productId || !sku || !groupId) {
      const doc2 = new DOMParser().parseFromString(html, "text/html");
      const allScripts = doc2.querySelectorAll("script");
      for (const scriptEl of allScripts) {
        const text = scriptEl.textContent || "";
        parseScripts([text]);
      }
    }
  } catch (e) {}
  return {
    productName: productName || "",
    pimsId: pimsId != null ? String(pimsId) : "",
    gtin: gtin != null ? String(gtin) : "",
    productId: productId != null ? String(productId) : "",
    skuId: sku != null ? String(sku) : "",
    groupId: groupId != null ? String(groupId) : ""
  };
};

const findCategoryIdFromModel = () => {
  if (categoryIdFromPage) {
    return categoryIdFromPage;
  }

  if (window.model && window.model.data && window.model.data.categoryIdForSeo) {
    return String(window.model.data.categoryIdForSeo);
  }

  if (window.model && window.model.biddingAdImpression) {
    if (window.model.biddingAdImpression.pageTypeValue) {
      return String(window.model.biddingAdImpression.pageTypeValue);
    }
  }

  return "";
};

const isCategoryListingPage = () => {
  if (window.location.pathname.includes("category-listing")) {
    return true;
  }
  if (isCategoryPageFromPage) {
    return true;
  }
  if (window.model && window.model._isCategoryPage === true) {
    return true;
  }
  return false;
};

const getSearchQuery = () => {
  const url = new URL(window.location.href);
  return url.searchParams.get("q") || "";
};

const isCartPage = () => {
  return window.location.pathname === "/sepetim";
};

const getAccountDeeplink = () => {
  const path = window.location.pathname;
  if (path === "/hesabim/siparislerim") {
    return "n11mf://n11.com?pt=o&pd=-";
  }
  if (path === "/hesabim/kuponlarim") {
    return "n11mf://n11.com?pt=a&pd=";
  }
  return "";
};

const buildDeeplinkParam = (pageId) => {
  if (!pageId) {
    return "";
  }
  return `${DEEPLINK_PARAM_KEY}=${encodeURIComponent(pageId)}`;
};

const animateCopy = (box) => {
  if (!box) {
    return;
  }
  box.classList.add("copied");
  window.setTimeout(() => {
    box.classList.remove("copied");
  }, 700);
};

const buildCopyText = (pageId, deeplinkParam) => {
  const idLine = `pageId=${pageId || "bulunamadı"}`;
  const deeplinkLine = `deeplink=${deeplinkParam || "bulunamadı"}`;
  return `${idLine}\n${deeplinkLine}`;
};

const isHomePage = () => {
  const url = new URL(window.location.href);
  return url.pathname === "/" && url.search === "";
};

const isBoPromotionPage = () => {
  const url = new URL(window.location.href);
  const isBoHost =
    url.hostname === "bo.n11.com" || url.hostname === "stbo.n11.com";
  if (!isBoHost) {
    return false;
  }
  return (
    url.pathname === "/backoffice/exhibition/promotionProducts.xhtml" &&
    url.searchParams.has("promotionId")
  );
};

const isBoInventoryPage = () => {
  const url = new URL(window.location.href);
  const isBoHost =
    url.hostname === "bo.n11.com" || url.hostname === "stbo.n11.com";
  if (!isBoHost) {
    return false;
  }
  return url.pathname === "/backoffice/inventory/inventoryManagement.xhtml";
};

const isBoCampaignPage = () => {
  const url = new URL(window.location.href);
  const isBoHost =
    url.hostname === "bo.n11.com" || url.hostname === "stbo.n11.com";
  if (!isBoHost) {
    return false;
  }
  return url.pathname.startsWith("/backoffice/campaign/campaign.xhtml");
};

const isBoHost = () => {
  const host = window.location.hostname;
  return (
    host === "bo.n11.com" ||
    host === "stbo.n11.com" ||
    host === "qabo.n11.com"
  );
};

const isPublicN11Host = () => {
  const host = window.location.hostname;
  return host === "www.n11.com" || host === "n11.com";
};

const isTrendyolHost = () => {
  return window.location.hostname === "www.trendyol.com";
};

const isHepsiburadaHost = () => {
  const host = window.location.hostname;
  return host === "www.hepsiburada.com" || host === "hepsiburada.com";
};

const getTrendyolMagazaMidFromPath = () => {
  const path = (window.location.pathname || "").replace(/\/+$/, "");
  const match = path.match(/\/magaza\/[^/]+-m-(\d+)$/i);
  return match ? match[1] : null;
};

const isMagazaPage = () => {
  return isPublicN11Host() && window.location.pathname.startsWith("/magaza/");
};

const isHepsiburadaMagazaPage = () => {
  const path = window.location.pathname || "";
  return isHepsiburadaHost() && path.startsWith("/magaza/");
};

const isOfferControllerPage = () => {
  if (!isPublicN11Host()) return false;
  try {
    const url = new URL(window.location.href);
    return (
      url.pathname === "/arama" &&
      Boolean(url.searchParams.get("promotions"))
    );
  } catch {
    return false;
  }
};

const isCategoryListingByDataLayer = () => {
  if (Array.isArray(window.dataLayer)) {
    const firstWithPageName = window.dataLayer.filter((item) => item.pageName)[0];
    if (firstWithPageName?.pageName === "category-listing") {
      return true;
    }
    if (window.dataLayer.some((item) => item.pageName === "category-listing")) {
      return true;
    }
  }
  const scripts = document.querySelectorAll("script:not([src])");
  for (const script of scripts) {
    const text = script.textContent || "";
    if (text.includes("dataLayer") && text.includes("pageName") && text.includes("category-listing")) {
      if (/["']pageName["']\s*:\s*["']category-listing["']/.test(text)) {
        return true;
      }
    }
  }
  return false;
};

const isSearchListingPage = () => {
  try {
    const url = new URL(window.location.href);
    return url.pathname === "/arama" && Boolean(url.searchParams.get("q"));
  } catch {
    return false;
  }
};

const isN11SeoListingPath = () => {
  if (!isPublicN11Host()) return false;
  try {
    const raw = window.location.pathname || "/";
    const p = raw.replace(/\/+$/, "") || "/";
    if (p === "/" || p === "") return false;
    if (p.startsWith("/urun/")) return false;
    if (
      p.startsWith("/hesabim") ||
      p.startsWith("/sepetim") ||
      p.startsWith("/giris")
    ) {
      return false;
    }
    if (p === "/arama") return true;
    return /^\/[\w-]+(\/[\w-]+)*$/.test(p);
  } catch {
    return false;
  }
};

const canApplyProductMatchScorePriceParams = () =>
  isProductMatchScorePage() ||
  isSearchListingPage() ||
  isCategoryListingByDataLayer() ||
  isN11SeoListingPath();

const shouldShowListingProductCrawler = () =>
  isCategoryListingByDataLayer() || isSearchListingPage() || isMagazaPage();

const updateListingProductCrawlerBoxVisibility = () => {
  const container = document.getElementById(CONTAINER_ID);
  const pimsIdBoxEl = document.getElementById(PIMS_ID_BOX_ID);
  const existingCrawler = document.getElementById(LISTING_PRODUCT_CRAWLER_BOX_ID);
  if (shouldShowListingProductCrawler()) {
    if (!container || !pimsIdBoxEl) {
      return;
    }
    let box = existingCrawler;
    if (!box) {
      box = document.createElement("div");
      box.id = LISTING_PRODUCT_CRAWLER_BOX_ID;
      box.className = "pageid-extension-box";
      box.setAttribute("role", "button");
      box.setAttribute("aria-label", "Listing Product Crawler");
      setBoxContent(box, "Crawler", "", "Listing Product Crawler");
      box.onclick = () => {
        openListingProductCrawlerModal();
      };
    }
    if (!container.contains(box)) {
      const next = pimsIdBoxEl.nextSibling;
      if (next) {
        container.insertBefore(box, next);
      } else {
        container.appendChild(box);
      }
    }
  } else if (existingCrawler && existingCrawler.parentNode) {
    existingCrawler.parentNode.removeChild(existingCrawler);
  }
};

const scheduleListingCrawlerCheck = () => {
  updateListingProductCrawlerBoxVisibility();
  [400, 1000, 2500, 5000].forEach((delay) => {
    window.setTimeout(updateListingProductCrawlerBoxVisibility, delay);
  });
};

const parseVersion = (s) => {
  if (typeof s !== "string") return [0, 0, 0];
  const parts = s.trim().split(".").map((p) => parseInt(p, 10) || 0);
  return [parts[0] || 0, parts[1] || 0, parts[2] || 0];
};

const isVersionLess = (current, latest) => {
  const a = parseVersion(current);
  const b = parseVersion(latest);
  if (a[0] !== b[0]) return a[0] < b[0];
  if (a[1] !== b[1]) return a[1] < b[1];
  return a[2] < b[2];
};

const VERSION_CHECK_DELAY_MS = 2500;

const checkAndShowVersionBanner = () => {
  if (document.getElementById(VERSION_BANNER_ID)) return;
  const versionEl = document.querySelector("[data-extension]");
  const pageVersion = (versionEl?.getAttribute("data-extension") || "").trim();
  if (!pageVersion) return;
  const latest = pageVersion.includes(".") ? pageVersion : pageVersion + ".0.0";
  const current = typeof chrome !== "undefined" && chrome?.runtime?.getManifest?.()?.version || "";
  if (!current || !isVersionLess(current, latest)) return;
  const banner = document.createElement("div");
  banner.id = VERSION_BANNER_ID;
  banner.className = "pageid-extension-version-banner";
  const downloadUrl = escapeHtml(VERSION_BANNER_DOWNLOAD_URL);
  const linkText = escapeHtml(VERSION_BANNER_DEFAULT_MESSAGE);
  banner.innerHTML = `
    <a href="${downloadUrl}" target="_blank" rel="noopener" class="pageid-extension-version-banner-link">${linkText}</a>
  `;
  requestAnimationFrame(() => {
    if (document.getElementById(VERSION_BANNER_ID)) return;
    const container = document.getElementById(CONTAINER_ID);
    if (!container || !document.body.contains(container)) return;
    if (container.firstChild) {
      container.insertBefore(banner, container.firstChild);
    } else {
      container.appendChild(banner);
    }
  });
};

const scheduleVersionCheckAfterLoad = () => {
  const runCheck = () => {
    window.setTimeout(() => checkAndShowVersionBanner(), VERSION_CHECK_DELAY_MS);
  };
  if (document.readyState === "complete") {
    runCheck();
  } else {
    window.addEventListener("load", runCheck);
  }
};

const ensureContainer = () => {
  let container = document.getElementById(CONTAINER_ID);
  if (!container) {
    container = document.createElement("div");
    container.id = CONTAINER_ID;
    document.body.appendChild(container);
  } else if (!document.body.contains(container)) {
    document.body.appendChild(container);
  }
  applyExtensionVisibility();
  return container;
};

const setBoxContent = (box, label, value, hint) => {
  box.innerHTML = `
    <div class="hint">${hint}</div>
  `;
};

const ensureBox = (boxId, ariaLabel) => {
  let box = document.getElementById(boxId);
  if (!box) {
    const container = ensureContainer();
    box = document.createElement("div");
    box.id = boxId;
    box.className = "pageid-extension-box";
    box.setAttribute("role", "button");
    box.setAttribute("aria-label", ariaLabel);
    container.appendChild(box);
  }
  return box;
};

const boxIdToGroupId = () => {
  const map = {};
  EXTENSION_GROUP_CONFIG.forEach((g) => {
    g.boxIds.forEach((bid) => { map[bid] = g.id; });
  });
  return map;
};

const appendGroupedBoxes = (container, ordered) => {
  if (!ordered || ordered.length === 0) return;
  Array.from(container.children).forEach((child) => {
    if (child.id !== VERSION_BANNER_ID) child.remove();
  });
  const gidMap = boxIdToGroupId();
  const byGroup = {};
  ordered.forEach((el) => {
    const gid = (el.id && gidMap[el.id]) ? gidMap[el.id] : "other";
    if (!byGroup[gid]) byGroup[gid] = [];
    byGroup[gid].push(el);
  });
  const groupOrder = ["id-link", "tools", "price-crawler", "bo-page", "trendyol", "hepsiburada", "marketing-growth", "crawl-scrapping", "other"];
  const titles = {};
  EXTENSION_GROUP_CONFIG.forEach((c) => { titles[c.id] = c.title; });
  titles.other = "Diğer";
  groupOrder.forEach((gid) => {
    const boxes = byGroup[gid];
    if (!boxes || boxes.length === 0) return;
    const groupDiv = document.createElement("div");
    groupDiv.className = "pageid-extension-group";
    groupDiv.dataset.groupId = gid;
    const header = document.createElement("div");
    header.className = "pageid-extension-group-header";
    header.setAttribute("role", "button");
    header.setAttribute("aria-expanded", "true");
    header.innerHTML = `${titles[gid] || gid} <span class="pageid-extension-group-chevron" aria-hidden="true">▼</span>`;
    const body = document.createElement("div");
    body.className = "pageid-extension-group-body";
    boxes.forEach((b) => body.appendChild(b));
    groupDiv.appendChild(header);
    groupDiv.appendChild(body);
    container.appendChild(groupDiv);
    header.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isCollapsed = groupDiv.classList.toggle("collapsed");
      header.setAttribute("aria-expanded", String(!isCollapsed));
      chrome.storage.local.get(STORAGE_KEY_GROUPS_COLLAPSED, (res) => {
        const next = { ...(res[STORAGE_KEY_GROUPS_COLLAPSED] || {}), [gid]: isCollapsed };
        chrome.storage.local.set({ [STORAGE_KEY_GROUPS_COLLAPSED]: next });
      });
    });
  });
  chrome.storage.local.get(STORAGE_KEY_GROUPS_COLLAPSED, (res) => {
    const collapsed = res[STORAGE_KEY_GROUPS_COLLAPSED] || {};
    groupOrder.forEach((gid) => {
      const groupEl = container.querySelector(`.pageid-extension-group[data-group-id="${gid}"]`);
      if (groupEl && collapsed[gid]) {
        groupEl.classList.add("collapsed");
        const h = groupEl.querySelector(".pageid-extension-group-header");
        if (h) h.setAttribute("aria-expanded", "false");
      }
    });
  });
};

const openModal = () => {
  let modal = document.getElementById(MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">n11 Sekme Linkleri</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="modal-controls">
          <label>
            <input type="checkbox" id="tabcopy-product-only" checked />
            Sadece Ürün Linkleri
          </label>
          <div>
            <button class="collect-btn" id="tabcopy-collect">Topla</button>
            <button class="copy-btn" id="tabcopy-copy" disabled>Kopyala</button>
          </div>
        </div>
        <textarea id="tabcopy-results" placeholder="Linkler burada görünecek..." readonly></textarea>
        <div class="status" id="tabcopy-status"></div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const collectBtn = modal.querySelector("#tabcopy-collect");
    const copyBtn = modal.querySelector("#tabcopy-copy");
    const resultsArea = modal.querySelector("#tabcopy-results");
    const productOnly = modal.querySelector("#tabcopy-product-only");
    const status = modal.querySelector("#tabcopy-status");

    const showStatus = (message, type) => {
      status.textContent = message;
      status.className = `status ${type}`;
      status.style.display = "block";
    };

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    collectBtn.addEventListener("click", async () => {
      collectBtn.disabled = true;
      collectBtn.textContent = "Toplanıyor...";
      status.style.display = "none";
      try {
        const response = await chrome.runtime.sendMessage({
          type: "collect-n11-links",
          productOnly: productOnly.checked
        });
        if (response && response.ok && response.links.length > 0) {
          resultsArea.value = response.links.join("\n");
          copyBtn.disabled = false;
          showStatus(`✅ ${response.links.length} adet link bulundu`, "success");
        } else if (response && response.ok) {
          resultsArea.value = "";
          copyBtn.disabled = true;
          showStatus("❌ Hiç n11.com linki bulunamadı", "error");
        } else {
          showStatus("❌ Linkler toplanamadı", "error");
        }
      } catch (error) {
        showStatus("❌ Linkler toplanamadı", "error");
      } finally {
        collectBtn.disabled = false;
        collectBtn.textContent = "Topla";
      }
    });

    copyBtn.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(resultsArea.value || "");
        showStatus("✅ Linkler panoya kopyalandı!", "success");
      } catch (error) {
        showStatus("❌ Kopyalama başarısız", "error");
      }
    });

    productOnly.addEventListener("change", () => {
      copyBtn.disabled = true;
      resultsArea.value = "";
      status.style.display = "none";
    });
  }

  modal.style.display = "flex";
};

const escapeCsv = (value) => {
  const str = value == null ? "" : String(value);
  if (/[",\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
};

const downloadCsv = (products) => {
  const header = "Product ID;Product Name\n";
  const rows = products.map((p) => `${escapeCsv(p.id)};${escapeCsv(p.name)}`).join("\n");
  const content = `\uFEFF${header}${rows}`;
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `n11_promosyon_urunleri_${new Date().toISOString().split("T")[0]}.csv`;
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

const downloadIdCsv = (rows, filenamePrefix) => {
  const header = "Product ID\n";
  const body = rows.map((row) => escapeCsv(row)).join("\n");
  const content = `\uFEFF${header}${body}`;
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${filenamePrefix}_${new Date().toISOString().split("T")[0]}.csv`;
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

const openBoModal = () => {
  let modal = document.getElementById(BO_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = BO_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">BO Promosyon Ürün ID Toplayıcı</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="modal-controls">
          <div>
            <button class="collect-btn" id="bo-collect">Topla</button>
            <button class="copy-btn" id="bo-copy" disabled>Kopyala</button>
            <button class="download-btn" id="bo-download" disabled>CSV İndir</button>
          </div>
        </div>
        <textarea id="bo-results" placeholder="Ürün ID'leri burada görünecek..." readonly></textarea>
        <div class="status" id="bo-status"></div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const collectBtn = modal.querySelector("#bo-collect");
    const copyBtn = modal.querySelector("#bo-copy");
    const downloadBtn = modal.querySelector("#bo-download");
    const resultsArea = modal.querySelector("#bo-results");
    const status = modal.querySelector("#bo-status");
    let products = [];

    const showStatus = (message, type) => {
      status.textContent = message;
      status.className = `status ${type}`;
      status.style.display = "block";
    };

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    collectBtn.addEventListener("click", async () => {
      collectBtn.disabled = true;
      collectBtn.textContent = "Toplanıyor...";
      status.style.display = "none";
      resultsArea.value = "";
      copyBtn.disabled = true;
      downloadBtn.disabled = true;
      try {
        const response = await chrome.runtime.sendMessage({ type: "bo-collect" });
        if (response && response.ok && Array.isArray(response.products)) {
          products = response.products;
          resultsArea.value = products.map((p) => p.id).join("\n");
          if (products.length > 0) {
            copyBtn.disabled = false;
            downloadBtn.disabled = false;
            showStatus(`✅ ${products.length} ürün bulundu`, "success");
          } else {
            showStatus("❌ Ürün bulunamadı", "error");
          }
        } else {
          showStatus(response?.error || "❌ Ürünler toplanamadı", "error");
        }
      } catch (error) {
        showStatus("❌ Ürünler toplanamadı", "error");
      } finally {
        collectBtn.disabled = false;
        collectBtn.textContent = "Topla";
      }
    });

    copyBtn.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(resultsArea.value || "");
        showStatus("✅ ID'ler panoya kopyalandı!", "success");
      } catch (error) {
        showStatus("❌ Kopyalama başarısız", "error");
      }
    });

    downloadBtn.addEventListener("click", () => {
      if (products.length === 0) {
        showStatus("❌ Ürün bulunamadı", "error");
        return;
      }
      downloadCsv(products);
      showStatus("✅ CSV indirildi", "success");
    });
  }

  modal.style.display = "flex";
};

const extractProductIdFromHtml = (htmlContent) => {
  const scripts = htmlContent.match(/<script[^>]*>[\s\S]*?<\/script>/gi) || [];

  for (const script of scripts) {
    if (script.includes("window.model")) {
      const adDataPatterns = [
        /"adData"\s*:\s*\{[^}]*?"id"\s*:\s*(\d{9,})/,
        /"adData"\s*:\s*\{[^}]*?"id"\s*:\s*"(\d{9,})"/
      ];
      for (const pattern of adDataPatterns) {
        const match = script.match(pattern);
        if (match && match[1]) {
          return match[1];
        }
      }
    }
  }

  const productIdPatterns = [
    /productId["\s:]+(\d{9,})/i,
    /"productId"\s*:\s*"(\d{9,})"/i,
    /"productId"\s*:\s*(\d{9,})/i,
    /productId\s*:\s*(\d{9,})/i
  ];

  for (const script of scripts) {
    for (const pattern of productIdPatterns) {
      const match = script.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }
  }

  return null;
};

const fetchProductIdFromUrl = async (url) => {
  try {
    const response = await fetch(url, {
      mode: "cors",
      credentials: "omit"
    });
    if (!response.ok) {
      return null;
    }
    const htmlContent = await response.text();
    return extractProductIdFromHtml(htmlContent);
  } catch (error) {
    console.error("Error fetching product ID:", error);
    return null;
  }
};

const extractProductUrlFromSearchHtml = (htmlContent) => {
  const doc = new DOMParser().parseFromString(htmlContent, "text/html");
  const selectors = [
    ".searchResults a.product-item",
    ".searchResults a[href*='/urun/']",
    ".searchResults a:first-child",
    ".searchResults > a",
    ".searchResults a",
    ".productList a[href*='/urun/']",
    "a[href*='/urun/'][href*='-']"
  ];
  for (const sel of selectors) {
    const anchor = doc.querySelector(sel);
    if (anchor) {
      const href = anchor.getAttribute("href") || "";
      if (href && href.includes("/urun/") && href.match(/-\d+/)) {
        try {
          return new URL(href, "https://www.n11.com").toString();
        } catch (e) {}
      }
    }
  }
  return null;
};

const extractSkuIdFromProductHtml = (htmlContent) => {
  const scripts = htmlContent.match(/<script[^>]*>[\s\S]*?<\/script>/gi) || [];
  for (const script of scripts) {
    if (script.includes("adData") && script.includes("skuId")) {
      const skuIdPatterns = [
        /"skuId"\s*:\s*"([^"]*)"/,
        /"skuId"\s*:\s*(\d+)/,
        /skuId\s*:\s*"([^"]*)"/,
        /skuId\s*:\s*(\d+)/
      ];
      for (const pattern of skuIdPatterns) {
        const match = script.match(pattern);
        if (match && match[1]) {
          return String(match[1]).trim();
        }
      }
    }
  }
  return null;
};

const fetchSkuFromProductUrl = async (productUrl) => {
  try {
    const response = await fetch(productUrl, {
      mode: "cors",
      credentials: "omit"
    });
    if (!response.ok) {
      return null;
    }
    const htmlContent = await response.text();
    return extractSkuIdFromProductHtml(htmlContent);
  } catch (error) {
    console.error("Error fetching SKU:", error);
    return null;
  }
};

const PRODUCT_NOT_FOUND = "Ürün Bulunamadı";

const fetchProductUrlFromId = async (productId) => {
  const searchUrl = `https://www.n11.com/arama?q=${encodeURIComponent(productId)}`;
  try {
    const response = await fetch(searchUrl, {
      mode: "cors",
      credentials: "omit"
    });
    if (!response.ok) {
      return null;
    }
    const htmlContent = await response.text();
    const doc = new DOMParser().parseFromString(htmlContent, "text/html");
    if (doc.querySelector(".empty-search-result")) {
      return PRODUCT_NOT_FOUND;
    }
    return extractProductUrlFromSearchHtml(htmlContent);
  } catch (error) {
    console.error("Error fetching product URL:", error);
    return null;
  }
};

const parseProductIdLine = (line) => {
  const trimmed = line.trim();
  if (!trimmed) {
    return "";
  }
  const match = trimmed.match(/\d{4,}/);
  return match ? match[0] : "";
};

const openUrlProductModal = () => {
  let modal = document.getElementById(URL_PRODUCT_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = URL_PRODUCT_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Product URL > Product ID</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="textarea-group">
          <label for="url-product-links">1. n11 Ürün Linkleri (Her satıra bir link)</label>
          <textarea id="url-product-links" placeholder="https://www.n11.com/urun/...&#10;https://www.n11.com/urun/..."></textarea>
        </div>
        <div class="modal-controls">
          <div>
            <button class="collect-btn" id="url-product-extract">ID'leri Çıkar</button>
            <button class="download-btn" id="url-product-download" disabled>Excel İndir</button>
            <button class="clear-btn" id="url-product-clear">Temizle</button>
          </div>
        </div>
        <div class="status" id="url-product-status"></div>
        <div class="textarea-group">
          <label for="url-product-ids">2. Ürün ID'leri</label>
          <textarea id="url-product-ids" placeholder="ID'ler buraya eklenecek..." readonly></textarea>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const extractBtn = modal.querySelector("#url-product-extract");
    const clearBtn = modal.querySelector("#url-product-clear");
    const linksTextarea = modal.querySelector("#url-product-links");
    const idsTextarea = modal.querySelector("#url-product-ids");
    const statusDiv = modal.querySelector("#url-product-status");
    const downloadBtn = modal.querySelector("#url-product-download");
    let currentIds = [];

    const showStatus = (message, type = "info") => {
      statusDiv.textContent = message;
      statusDiv.className = `status ${type}`;
      statusDiv.style.display = "block";
      window.setTimeout(() => {
        statusDiv.className = "status";
      }, 5000);
    };

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    extractBtn.addEventListener("click", async () => {
      const links = (linksTextarea.value || "")
        .split("\n")
        .map((line) => line.trim())
        .filter((line) => line.length > 0 && line.includes("n11.com/urun"));

      if (links.length === 0) {
        showStatus("Lütfen geçerli n11 ürün linkleri girin!", "error");
        return;
      }

      extractBtn.disabled = true;
      extractBtn.textContent = "İşleniyor...";
      idsTextarea.value = "";
      downloadBtn.disabled = true;
      showStatus(`${links.length} link işleniyor, lütfen bekleyin...`, "info");

      const productIds = [];

      for (let i = 0; i < links.length; i += 1) {
        const link = links[i];
        showStatus(
          `İşleniyor: ${i + 1}/${links.length} - ${link.substring(0, 50)}...`,
          "info"
        );
        const productId = await fetchProductIdFromUrl(link);
        if (productId) {
          productIds.push(productId);
        } else {
          productIds.push("ID BULUNAMADI");
        }
        idsTextarea.value = productIds.join("\n");
        await new Promise((resolve) => setTimeout(resolve, 500));
      }

      extractBtn.disabled = false;
      extractBtn.textContent = "ID'leri Çıkar";
      currentIds = productIds.filter((id) => id !== "ID BULUNAMADI");
      if (currentIds.length > 0) {
        downloadBtn.disabled = false;
      }
      const successCount = currentIds.length;
      showStatus(`${successCount}/${links.length} ürün ID'si başarıyla çıkarıldı!`, "success");
    });

    downloadBtn.addEventListener("click", () => {
      if (currentIds.length === 0) {
        showStatus("❌ İndirilecek ürün ID bulunamadı", "error");
        return;
      }
      downloadIdCsv(currentIds, "n11_urun_idleri");
      showStatus("✅ Excel indirildi", "success");
    });

    clearBtn.addEventListener("click", () => {
      linksTextarea.value = "";
      idsTextarea.value = "";
      currentIds = [];
      downloadBtn.disabled = true;
      statusDiv.className = "status";
      statusDiv.style.display = "none";
    });
  }

  modal.style.display = "flex";
};

const openProductIdUrlModal = () => {
  let modal = document.getElementById(PRODUCTID_URL_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PRODUCTID_URL_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Product ID > Product URL</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="textarea-group">
          <label for="productid-url-ids">1. Product ID'ler (Her satıra bir ID)</label>
          <textarea id="productid-url-ids" placeholder="651645215&#10;651645216"></textarea>
        </div>
        <div class="modal-controls">
          <div>
            <button class="collect-btn" id="productid-url-extract">URL'leri Bul</button>
            <button class="download-btn" id="productid-url-download" disabled>Excel İndir</button>
            <button class="clear-btn" id="productid-url-clear">Temizle</button>
          </div>
        </div>
        <div class="status" id="productid-url-status"></div>
        <div class="textarea-group">
          <label for="productid-url-results">2. Ürün URL'leri</label>
          <textarea id="productid-url-results" placeholder="URL'ler buraya eklenecek..." readonly></textarea>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const extractBtn = modal.querySelector("#productid-url-extract");
    const clearBtn = modal.querySelector("#productid-url-clear");
    const idsTextarea = modal.querySelector("#productid-url-ids");
    const urlsTextarea = modal.querySelector("#productid-url-results");
    const statusDiv = modal.querySelector("#productid-url-status");
    const downloadBtn = modal.querySelector("#productid-url-download");
    let currentRows = [];

    const showStatus = (message, type = "info") => {
      statusDiv.textContent = message;
      statusDiv.className = `status ${type}`;
      statusDiv.style.display = "block";
      window.setTimeout(() => {
        statusDiv.className = "status";
      }, 5000);
    };

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    extractBtn.addEventListener("click", async () => {
      const rawIds = (idsTextarea.value || "").split("\n");
      const ids = rawIds
        .map((line) => parseProductIdLine(line))
        .filter((line) => line.length > 0);

      if (ids.length === 0) {
        showStatus("Lütfen geçerli Product ID'ler girin!", "error");
        return;
      }

      extractBtn.disabled = true;
      extractBtn.textContent = "İşleniyor...";
      urlsTextarea.value = "";
      downloadBtn.disabled = true;
      showStatus(`${ids.length} ID işleniyor, lütfen bekleyin...`, "info");

      const results = [];

      for (let i = 0; i < ids.length; i += 1) {
        const id = ids[i];
        const searchUrl = `https://www.n11.com/arama?q=${encodeURIComponent(id)}`;
        showStatus(
          `İşleniyor: ${i + 1}/${ids.length} - ${id}`,
          "info"
        );
        const productUrl = await fetchProductUrlFromId(id);
        if (productUrl === PRODUCT_NOT_FOUND) {
          results.push({ id, url: PRODUCT_NOT_FOUND, searchUrl });
        } else if (productUrl) {
          results.push({ id, url: productUrl });
        } else {
          results.push({ id, url: "URL BULUNAMADI", searchUrl });
        }
        urlsTextarea.value = results.map((row) => row.url).join("\n");
        await new Promise((resolve) => setTimeout(resolve, 500));
      }

      extractBtn.disabled = false;
      extractBtn.textContent = "URL'leri Bul";
      currentRows = results.filter((row) => row.url !== "URL BULUNAMADI" && row.url !== PRODUCT_NOT_FOUND);
      if (currentRows.length > 0) {
        downloadBtn.disabled = false;
      }
      showStatus(
        `${currentRows.length}/${ids.length} ürün URL'si başarıyla bulundu!`,
        "success"
      );
    });

    downloadBtn.addEventListener("click", () => {
      if (currentRows.length === 0) {
        showStatus("❌ İndirilecek ürün URL bulunamadı", "error");
        return;
      }
      const header = "Product ID;Product URL\n";
      const rows = currentRows
        .map((row) => `${escapeCsv(row.id)};${escapeCsv(row.url)}`)
        .join("\n");
      const content = `\uFEFF${header}${rows}`;
      const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `n11_urun_url_${new Date().toISOString().split("T")[0]}.csv`;
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showStatus("✅ Excel indirildi", "success");
    });

    clearBtn.addEventListener("click", () => {
      idsTextarea.value = "";
      urlsTextarea.value = "";
      currentRows = [];
      downloadBtn.disabled = true;
      statusDiv.className = "status";
      statusDiv.style.display = "none";
    });
  }

  modal.style.display = "flex";
};

const getProductTitleFromProductHtml = (html) => {
  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const h1 = doc.querySelector(".product-summary h1");
    return h1 ? (h1.textContent || "").trim() : null;
  } catch {
    return null;
  }
};

const getProductSellerFromProductHtml = (html) => {
  if (!html || typeof html !== "string") return null;
  try {
    const patterns = [
      /model\.product\.seller\.nickName\s*=\s*["']([^"']+)["']/,
      /model\.product\.seller\s*=\s*\{[^}]*nickName\s*:\s*["']([^"']+)["']/,
      /["']seller["']\s*:\s*\{[^}]*["']nickName["']\s*:\s*["']([^"']+)["']/,
      /["']sellerNickName["']\s*:\s*["']([^"']+)["']/,
      /["']nickName["']\s*:\s*["']([^"']+)["']\s*[,}].*seller/
    ];
    for (const re of patterns) {
      const m = html.match(re);
      if (m && m[1]) return String(m[1]).trim();
    }
    return null;
  } catch {
    return null;
  }
};

/** Türkçe/US fiyat string'ini sayıya çevirir. 5.800 → 5800 (binlik nokta), 5,80 → 5.80 (ondalık virgül). */
const parsePriceStringToNumber = (str) => {
  if (str == null || String(str).trim() === "") return null;
  const s = String(str).replace(/[^\d,.]/g, "").replace(/\s/g, "");
  if (!s) return null;
  const lastComma = s.lastIndexOf(",");
  const lastDot = s.lastIndexOf(".");
  if (lastComma >= 0 && lastDot >= 0) {
    if (lastComma > lastDot) {
      return parseFloat(s.replace(/\./g, "").replace(",", "."));
    }
    return parseFloat(s.replace(/,/g, ""));
  }
  if (lastDot >= 0 && lastComma < 0) {
    const afterDot = s.slice(lastDot + 1);
    if (afterDot.length === 3) {
      return parseFloat(s.replace(/\./g, ""));
    }
    return parseFloat(s);
  }
  if (lastComma >= 0 && lastDot < 0) {
    const afterComma = s.slice(lastComma + 1);
    if (afterComma.length === 3) {
      return parseFloat(s.replace(/,/g, ""));
    }
    return parseFloat(s.replace(",", "."));
  }
  return parseFloat(s) || null;
};

const getProductPriceFromProductHtml = (html) => {
  if (!html || typeof html !== "string") return null;
  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const priceSelectors = [
      ".product-summary .price",
      ".product-summary [class*='price']",
      ".product-summary ins",
      ".product-summary .newPrice",
      ".unf-p-summary-price",
      "[data-price]"
    ];
    for (const sel of priceSelectors) {
      const el = doc.querySelector(sel);
      if (el) {
        const text = (el.textContent || el.getAttribute("data-price") || "").trim();
        const match = text.match(/(\d[\d.,]*)\s*TL/i) || text.match(/(\d[\d.,]+)/);
        if (match && match[1]) return match[1].trim() + " TL";
      }
    }
    const priceMatch = html.match(/"price"\s*:\s*["']?([\d.,]+)["']?/i)
      || html.match(/"salePrice"\s*:\s*["']?([\d.,]+)["']?/i)
      || html.match(/"amount"\s*:\s*["']?([\d.,]+)["']?/i);
    if (priceMatch && priceMatch[1]) {
      const num = parsePriceStringToNumber(priceMatch[1]);
      if (num != null && !isNaN(num)) {
        return num.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
      }
    }
    return null;
  } catch {
    return null;
  }
};

const openPriceProtectorModal = () => {
  let modal = document.getElementById(PRICE_PROTECTOR_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PRICE_PROTECTOR_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Price Protector</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="akakce-crawler-form">
          <label for="price-protector-ids">n11 ürün linkleri (her satıra bir link)</label>
          <textarea id="price-protector-ids" class="akakce-crawler-textarea" rows="6" placeholder="https://www.n11.com/urun/urun-adi-651645215"></textarea>
          <p class="akakce-cloudflare-note">Not: Linklerden ürün alınır, ardından Akakce araması yapılır.</p>
          <p class="akakce-deep-analysis-note">Not: Deep Analysis bazen doğru ürünü bulamayabilir. Ürün kapanmış, URL değiştirilmiş olabilir. Gemini search grounding en güncel index'e göre sonuç döner.</p>
          <div class="akakce-crawler-buttons">
            <button type="button" class="akakce-run-btn" id="price-protector-run-btn">Akakce'de Ara</button>
            <button type="button" class="download-btn" id="price-protector-download-btn" disabled>Excel İndir</button>
          </div>
        </div>
        <div class="status" id="price-protector-status"></div>
        <div id="price-protector-result" class="akakce-crawler-result-wrap"></div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const runBtn = modal.querySelector("#price-protector-run-btn");
    const downloadBtn = modal.querySelector("#price-protector-download-btn");
    const idsTextarea = modal.querySelector("#price-protector-ids");
    const resultWrap = modal.querySelector("#price-protector-result");
    const statusDiv = modal.querySelector("#price-protector-status");
    let priceProtectorTableRows = [];
    let lastN11ProductUrl = null;

    const showStatus = (message, type = "info") => {
      statusDiv.textContent = message;
      statusDiv.className = `status ${type}`;
      statusDiv.style.display = "block";
    };

    const priceCell = (val) => {
      if (val == null || val === "" || String(val) === "-") return "-";
      return String(val).replace(/</g, "&lt;").replace(/>/g, "&gt;").trim() || "-";
    };

    const parsePriceToNumber = (str) => {
      if (str == null || String(str).trim() === "" || String(str) === "-") return null;
      return parsePriceStringToNumber(str);
    };

    const computePriceAverage = (allPrices) => {
      if (!Array.isArray(allPrices) || allPrices.length === 0) return null;
      const nums = allPrices.map((p) => parsePriceToNumber(p)).filter((n) => n != null && !isNaN(n));
      if (nums.length === 0) return null;
      const avg = nums.reduce((a, b) => a + b, 0) / nums.length;
      return avg.toFixed(2).replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    };

    const computeBuybox = (n11Price, trendyolPrice, hbPrice, amazonPrice) => {
      const n11Num = parsePriceToNumber(n11Price);
      const prices = [
        { brand: "n11", num: n11Num },
        { brand: "trendyol", num: parsePriceToNumber(trendyolPrice) },
        { brand: "hb", num: parsePriceToNumber(hbPrice) },
        { brand: "amazon", num: parsePriceToNumber(amazonPrice) }
      ].filter((p) => p.num != null && !isNaN(p.num));
      if (prices.length === 0 || n11Num == null || isNaN(n11Num)) return "";
      const lowest = Math.min(...prices.map((p) => p.num));
      return lowest === n11Num ? "Yes" : "No";
    };

    const getBuyboxBrand = (r) => {
      const prices = [
        { key: "n11", num: parsePriceToNumber(r.n11Price) },
        { key: "trendyol", num: parsePriceToNumber(r.trendyolPrice) },
        { key: "hb", num: parsePriceToNumber(r.hbPrice) },
        { key: "amazon", num: parsePriceToNumber(r.amazonPrice) }
      ].filter((p) => p.num != null && !isNaN(p.num));
      if (prices.length === 0) return null;
      const lowest = Math.min(...prices.map((p) => p.num));
      const winner = prices.find((p) => p.num === lowest);
      return winner ? winner.key : null;
    };

    const computeStatus = (r) => {
      const empty = (v) => v == null || String(v).trim() === "" || String(v) === "-";
      const hasPriceAverage = !empty(r.priceAverage);
      const hasN11Price = !empty(r.n11Price);
      const hasDeepAnalysisNote = !empty(r.deepAnalysisNote);
      if (hasPriceAverage && hasN11Price) {
        const avgNum = parsePriceToNumber(r.priceAverage);
        const n11Num = parsePriceToNumber(r.n11Price);
        if (avgNum != null && !isNaN(avgNum) && n11Num != null && !isNaN(n11Num) && n11Num > 0) {
          const ratio = avgNum / n11Num;
          const isRisky = ratio >= 1.30 || ratio <= 0.70;
          const txt = isRisky ? "RİSKLİ" : "Sorun yok";
          return { text: txt, isRisky, fullText: txt };
        }
      }
      if (!hasPriceAverage && hasDeepAnalysisNote) {
        const note = r.deepAnalysisNote;
        const n11Num = parsePriceToNumber(r.n11Price);
        const compPrices = [
          parsePriceToNumber(r.trendyolPrice),
          parsePriceToNumber(r.hbPrice),
          parsePriceToNumber(r.amazonPrice)
        ].filter((n) => n != null && !isNaN(n));
        let isRisky = null;
        if (n11Num != null && !isNaN(n11Num) && n11Num > 0 && compPrices.length > 0) {
          const compNum = compPrices[0];
          const ratio = compNum / n11Num;
          isRisky = ratio >= 1.30 || ratio <= 0.70;
        }
        const prefix = isRisky === true ? "RİSKLİ" : isRisky === false ? "SORUN YOK" : null;
        const fullText = prefix ? prefix + " - " + note : note;
        return { text: fullText, isRisky: isRisky === true, fullText };
      }
      if (!hasPriceAverage) {
        return { text: "Ürün bulunamadı, Deep Analysis ile tarama yapınız.", isRisky: false, isError: true, fullText: "Ürün bulunamadı, derin analiz ile tarama yapınız." };
      }
      return { text: "-", isRisky: false, fullText: "-" };
    };

    const priceCellWithBuybox = (val, brandKey, buyboxBrand) => {
      const html = priceCell(val);
      const empty = (v) => v == null || String(v).trim() === "" || String(v) === "-";
      if (empty(val)) return html;
      if (brandKey === buyboxBrand) return '<span class="akakce-price-buybox">' + html + "</span>";
      if (brandKey === "n11" && buyboxBrand) return '<span class="akakce-price-n11-losing">' + html + "</span>";
      return html;
    };

    const hasNoAkakceData = (r) => {
      const empty = (v) => v == null || String(v).trim() === "" || String(v) === "-";
      const noCompetitorData = empty(r.trendyolPrice) && empty(r.hbPrice) && empty(r.amazonPrice);
      const hasProductInfo = r.productUrl || r.productId;
      return noCompetitorData && hasProductInfo;
    };

    const renderPriceProtectorTable = () => {
      const rows = priceProtectorTableRows;
      let html =
        '<table class="akakce-crawler-table">' +
        '<thead><tr><th>ID</th><th>ÜRÜN ADI</th><th>SATICI</th><th><img src="https://n11scdn.akamaized.net/custom/upload/52/78/8763995404733138810.svg" alt="akakce"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/56/71/4643320758776974115.svg" alt="n11"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/52/34/8306016460707706841.svg" alt="trendyol"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/49/75/9137271869470559939.svg" alt="hepsiburada"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/67/31/4443647868650764054.svg" alt="amazon"></th><th>Fiyat ortalaması</th><th>Status</th><th>Deep Analysis</th></tr></thead><tbody>';
      if (rows.length === 0) {
        html += '<tr><td colspan="11" class="akakce-crawler-empty">Henüz veri yok. n11 linki ekleyip Akakce\'de Ara butonuna tıklayın.</td></tr>';
      } else {
        rows.forEach((r, idx) => {
          const linkCell = r.akakceUrl
            ? '<a href="' + (r.akakceUrl || "").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;") + '" target="_blank" rel="noopener" class="akakce-link"><b>Link &#128279;</b></a>'
            : "-";
          const needsDeepAnalysis = hasNoAkakceData(r);
          const deepAnalysisCell = needsDeepAnalysis
            ? '<button type="button" class="akakce-manuel-btn price-protector-manuel-btn" data-row-idx="' + idx + '"><b>Deep Analysis</b></button>'
            : "-";
          const buyboxBrand = getBuyboxBrand(r);
          const idCell = (r.productId && String(r.productId).trim())
            ? (r.productUrl
              ? '<a href="' + (r.productUrl || "").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;") + '" target="_blank" rel="noopener" style="color:#f4e"><b>' + escapeHtml(r.productId) + "</b></a>"
              : escapeHtml(r.productId))
            : "-";
          const sellerCell = (r.sellerNickName && String(r.sellerNickName).trim() !== "")
            ? '<a href="https://www.n11.com/magaza/' + encodeURIComponent(String(r.sellerNickName).trim().toLowerCase()) + '" target="_blank" rel="noopener" style="color:#f4e"><b>' + escapeHtml(String(r.sellerNickName).trim().toLowerCase()) + "</b></a>"
            : "-";
          html +=
            "<tr><td>" + idCell + "</td><td>" + escapeHtml(r.productName) +
            "</td><td>" + sellerCell +
            "</td><td>" + linkCell +
            "</td><td>" + priceCellWithBuybox(r.n11Price, "n11", buyboxBrand) +
            "</td><td>" + priceCellWithBuybox(r.trendyolPrice, "trendyol", buyboxBrand) +
            "</td><td>" + priceCellWithBuybox(r.hbPrice, "hb", buyboxBrand) +
            "</td><td>" + priceCellWithBuybox(r.amazonPrice, "amazon", buyboxBrand) +
            "</td><td>" + priceCell(r.priceAverage) +
            "</td><td class='status-cell'>" + (() => {
              const st = computeStatus(r);
              const text = typeof st === "object" ? st.fullText : String(st);
              const isRisky = typeof st === "object" ? st.isRisky : false;
              const isError = typeof st === "object" ? st.isError : false;
              const isOk = typeof st === "object" && !isRisky && !isError && text !== "-";
              const dashIdx = text.indexOf(" - ");
              if (isError) {
                return '<span class="status-error-box">' + escapeHtml(text) + "</span>";
              }
              if ((isRisky || isOk) && dashIdx > 0) {
                const label = text.slice(0, dashIdx);
                const detail = text.slice(dashIdx + 3);
                const labelCls = isRisky ? " status-label status-risky" : " status-label status-ok";
                return '<span class="' + labelCls + '">' + escapeHtml(label) + "</span> <span class='status-detail'>" + escapeHtml(detail) + "</span>";
              }
              if (isRisky || isOk) {
                const cls = isRisky ? " status-risky" : " status-ok";
                return '<span class="' + cls + '"><b>' + escapeHtml(text) + "</b></span>";
              }
              return escapeHtml(text);
            })() +
            "</td><td>" + deepAnalysisCell + "</td></tr>";
        });
      }
      html += "</tbody></table>";
      resultWrap.innerHTML = html;
      resultWrap.querySelectorAll(".price-protector-manuel-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          const idx = parseInt(btn.getAttribute("data-row-idx"), 10);
          const row = priceProtectorTableRows[idx];
          if (!row) return;
          const productUrl = row.productUrl || (row.productId ? `https://www.n11.com/urun/urun-${row.productId}` : "");
          if (!productUrl) {
            showStatus("Ürün linki bulunamadı.", "error");
            return;
          }
          btn.disabled = true;
          btn.textContent = "Analiz ediliyor...";
          showStatus("Gemini ile fiyat analizi yapılıyor...", "info");
          chrome.runtime.sendMessage({
            type: "price-protector-deep-analysis",
            productUrl,
            n11Price: row.n11Price || "",
            sellerNickName: row.sellerNickName || "",
            productName: row.productName || "",
            rowIndex: idx
          });
        });
      });
    };

    const runOne = (productId, productUrl, productName, n11Price, sellerNickName, index, total) => {
      const googleUrl = "https://www.google.com/search?q=akakce+" + encodeURIComponent(productName);
      showStatus(`${index + 1}/${total}: Google'da aranıyor, akakce sayfası açılıyor...`, "info");
      return new Promise((resolve) => {
        const port = chrome.runtime.connect({ name: "price-protector-flow" });
        port.onMessage.addListener((msg) => {
          if (msg.error) {
            showStatus("Hata: " + msg.error, "error");
          } else if (index + 1 >= total) {
            showStatus("İşlem tamamlandı.", "success");
          }
          port.disconnect();
          resolve();
        });
        port.onDisconnect.addListener(() => resolve());
        port.postMessage({ googleUrl, productId, productName, productUrl, n11Price, sellerNickName });
      });
    };

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    const N11_PRODUCT_URL_RE = /^https?:\/\/(www\.)?n11\.com\/urun\/[^/]+-\d+(?:\/|\?|$)/i;
    const parseInputs = () => {
      return (idsTextarea.value || "")
        .split(/\n/)
        .map((s) => s.trim())
        .filter((s) => s && (N11_PRODUCT_URL_RE.test(s) || /^\d{4,}$/.test(s)));
    };
    const parseInputToUrlAndId = (input) => {
      if (N11_PRODUCT_URL_RE.test(input)) {
        const normalized = input.split("?")[0].trim();
        const idMatch = normalized.match(/-(\d+)(?:\/|$)/);
        return { url: normalized, id: idMatch ? idMatch[1] : "" };
      }
      const id = parseProductIdLine(input);
      return { url: null, id };
    };

    runBtn.addEventListener("click", async () => {
      const inputs = parseInputs();
      if (inputs.length === 0) {
        showStatus("Geçerli n11 linki veya Product ID bulunamadı. Her satıra bir link veya ID girin.", "error");
        return;
      }

      priceProtectorTableRows = [];
      renderPriceProtectorTable();
      runBtn.disabled = true;
      runBtn.textContent = "İşleniyor...";
      downloadBtn.disabled = true;

      for (let i = 0; i < inputs.length; i++) {
        const { url: inputUrl, id: inputId } = parseInputToUrlAndId(inputs[i]);
        let productUrl = inputUrl;
        let productId = inputId;

        if (!productUrl) {
          showStatus(`${i + 1}/${inputs.length}: Product ID ${inputId} → URL çevriliyor...`, "info");
          productUrl = await fetchProductUrlFromId(inputId);
          productId = inputId;
          if (!productUrl || productUrl === PRODUCT_NOT_FOUND) {
            productUrl = `https://www.n11.com/urun/urun-${productId}`;
            showStatus(`${i + 1}/${inputs.length}: URL bulunamadı, fallback kullanılıyor.`, "info");
          }
        }

        let productName = null;
        let n11Price = null;
        let sellerNickName = null;
        try {
          const res = await fetch(productUrl, { credentials: "omit" });
          if (res.ok) {
            const html = await res.text();
            productName = getProductTitleFromProductHtml(html);
            n11Price = getProductPriceFromProductHtml(html);
            sellerNickName = getProductSellerFromProductHtml(html);
            if (!productId) {
              const idMatch = html.match(/model\.product\.id\s*[=:]\s*["']?(\d+)["']?/) || html.match(/"productId"\s*:\s*["']?(\d+)["']?/);
              productId = idMatch ? idMatch[1] : "";
            }
          }
        } catch (err) {
          console.error("Product fetch error:", err);
        }
        if (!productName) {
          productName = "Ürün " + (productId || "?");
        }
        if (!productId) {
          productId = productUrl.match(/-(\d+)(?:\/|\?|$)/)?.[1] || "";
        }
        lastN11ProductUrl = productUrl;
        await runOne(productId, productUrl, productName, n11Price, sellerNickName, i, inputs.length);
        await new Promise((r) => setTimeout(r, 500));
      }

      runBtn.disabled = false;
      runBtn.textContent = "Akakce'de Ara";
      downloadBtn.disabled = priceProtectorTableRows.length === 0;
    });

    downloadBtn.addEventListener("click", () => {
      if (priceProtectorTableRows.length === 0) return;
      const header = "ID;Ürün Adı;Satıcı;Akakce Link;N11 Fiyat;Trendyol Fiyat;Hepsiburada Fiyat;Amazon Fiyat;Fiyat Ortalaması;Status\n";
      const rows = priceProtectorTableRows
        .map((r) =>
          [escapeCsv(r.productId), escapeCsv(r.productName), escapeCsv((r.sellerNickName || "").toLowerCase()), escapeCsv(r.akakceUrl || ""), escapeCsv(r.n11Price || ""), escapeCsv(r.trendyolPrice || ""), escapeCsv(r.hbPrice || ""), escapeCsv(r.amazonPrice || ""), escapeCsv(r.priceAverage || ""), escapeCsv((() => { const st = computeStatus(r); return typeof st === "object" ? st.fullText : String(st || ""); })())]
            .join(";")
        )
        .join("\n");
      const content = "\uFEFF" + header + rows;
      const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "price_protector_" + new Date().toISOString().split("T")[0] + ".csv";
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);
    });

    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "price-protector-page-data") {
        const data = Array.isArray(msg.data) ? msg.data : [];
        const productId = msg.productId != null ? String(msg.productId) : "";
        const productName = msg.productName != null ? String(msg.productName) : "";
        const n11 = data.find((x) => x.brand === "n11");
        const trendyol = data.find((x) => x.brand === "Trendyol");
        const hepsiburada = data.find((x) => x.brand === "Hepsiburada");
        const amazon = data.find((x) => x.brand === "Amazon Türkiye");
        const n11PriceVal = (msg.n11Price != null && String(msg.n11Price).trim() !== "") ? String(msg.n11Price).trim() : (n11 ? (n11.price || "").trim() : "");
        const trendyolPriceVal = trendyol ? (trendyol.price || "").trim() : "-";
        const hbPriceVal = hepsiburada ? (hepsiburada.price || "").trim() : "-";
        const amazonPriceVal = amazon ? (amazon.price || "").trim() : "-";
        const priceAverage = computePriceAverage(msg.allPrices);
        const sellerNickName = (msg.sellerNickName != null && String(msg.sellerNickName).trim() !== "") ? String(msg.sellerNickName).trim() : "";
        const row = {
          productId,
          productName,
          productUrl: (msg.productUrl || "").trim() || lastN11ProductUrl || "",
          akakceUrl: msg.akakceUrl || "",
          sellerNickName,
          n11Price: n11PriceVal,
          trendyolPrice: trendyolPriceVal,
          hbPrice: hbPriceVal,
          amazonPrice: amazonPriceVal,
          priceAverage: priceAverage != null ? priceAverage : ""
        };
        priceProtectorTableRows.push(row);
        renderPriceProtectorTable();
        downloadBtn.disabled = false;
      }
      if (msg && msg.type === "price-protector-manuel-update-result") {
        const idx = typeof msg.rowIndex === "number" ? msg.rowIndex : -1;
        const row = idx >= 0 && idx < priceProtectorTableRows.length ? priceProtectorTableRows[idx] : priceProtectorTableRows.find((r) => r.productId === msg.productId);
        if (!row) return;
        const brandToKey = { "Trendyol": "trendyolPrice", "Hepsiburada": "hbPrice", "Amazon Türkiye": "amazonPrice" };
        (msg.data || []).forEach((item) => {
          const key = brandToKey[item.brand];
          if (key && (!row[key] || row[key].trim() === "" || row[key] === "-") && item.price) row[key] = String(item.price).trim();
        });
        const avg = computePriceAverage(msg.allPrices);
        row.priceAverage = avg != null ? avg : (row.priceAverage || "");
        renderPriceProtectorTable();
        resultWrap.querySelectorAll(".price-protector-manuel-btn").forEach((btn) => {
          btn.disabled = false;
          btn.textContent = "Deep Analysis";
        });
      }
      if (msg && msg.type === "price-protector-deep-analysis-result") {
        const idx = typeof msg.rowIndex === "number" ? msg.rowIndex : -1;
        const row = idx >= 0 && idx < priceProtectorTableRows.length ? priceProtectorTableRows[idx] : null;
        resultWrap.querySelectorAll(".price-protector-manuel-btn").forEach((btn) => {
          btn.disabled = false;
          btn.textContent = "Deep Analysis";
        });
        if (msg.error) {
          showStatus("Deep Analysis hatası: " + msg.error, "error");
          return;
        }
        const result = msg.result;
        if (!row) return;
        if (result && result.found && result.platform && result.competitor_price != null) {
          const platformToKey = { "Hepsiburada": "hbPrice", "Trendyol": "trendyolPrice", "Amazon": "amazonPrice", "Amazon Türkiye": "amazonPrice" };
          const key = platformToKey[result.platform];
          if (key) {
            let priceStr;
            if (typeof result.competitor_price === "number") {
              priceStr = result.competitor_price.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
            } else {
              const s = String(result.competitor_price || "").trim();
              priceStr = s ? (s.includes("TL") ? s : s + " TL") : "-";
            }
            row[key] = priceStr;
          }
          row.deepAnalysisNote = result.analysis_note || "";
          row.deepAnalysisUrl = (result.platform === "Hepsiburada" && (row.productName || "").trim())
            ? "https://www.hepsiburada.com/ara?q=" + encodeURIComponent(String(row.productName).trim())
            : (result.source_url || "");
          showStatus(`Bulundu: ${result.platform} - ${result.competitor_price} TL (${result.confidence_score || "-"}%)`, "success");
        } else if (result && result.analysis_note) {
          row.deepAnalysisNote = result.analysis_note;
          showStatus(result.analysis_note, "info");
        } else {
          showStatus("Rakip fiyat bulunamadı.", "info");
        }
        renderPriceProtectorTable();
      }
    });
  }

  modal.style.display = "flex";
};

const openProductPriceTrackingModal = () => {
  let modal = document.getElementById(PRODUCT_PRICE_TRACKING_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PRODUCT_PRICE_TRACKING_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card product-price-tracking-modal-card">
        <div class="modal-header">
          <div class="modal-title">Product Price Tracking</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="product-price-tracking-body">
          <div class="product-price-tracking-actions">
            <button type="button" id="product-price-tracking-add-btn" class="product-price-tracking-add-btn">Ürün Ekle</button>
            <button type="button" id="product-price-tracking-refresh-btn" class="product-price-tracking-refresh-btn">Güncelle</button>
            <button type="button" id="product-price-tracking-export-btn" class="product-price-tracking-export-btn">Excel İndir</button>
            <button type="button" id="product-price-tracking-import-excel-btn" class="product-price-tracking-import-btn">Excel Yükle</button>
            <input type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" id="product-price-tracking-import-excel-input" class="product-price-tracking-import-input" />
            <button type="button" id="product-price-tracking-settings-btn" class="product-price-tracking-settings-btn" aria-label="Ayarlar" title="Ayarlar">
              <img src="${SETTINGS_ICON_URL}" alt="Ayarlar" class="product-price-tracking-settings-icon" />
            </button>
          </div>
          <div id="product-price-tracking-excel-drop-zone" class="product-price-tracking-excel-drop-zone">
            <b>Excel dosyasını sürükleyip bırakın</b> veya "<b>Excel Yükle</b>" ile seçin.
          </div>
          <div id="product-price-tracking-settings-wrap" class="product-price-tracking-settings-wrap" style="display:none;">
            <div class="product-price-tracking-settings-title">Crawl Edilecek Markalar</div>
            <div class="product-price-tracking-settings-grid">
              <label class="product-price-tracking-settings-option">
                <input type="checkbox" class="product-price-tracking-brand-checkbox" data-pt-platform="n11" checked />
                <img src="${N11_LOGO_URL}" alt="n11" class="product-price-tracking-settings-logo" />
              </label>
              <label class="product-price-tracking-settings-option">
                <input type="checkbox" class="product-price-tracking-brand-checkbox" data-pt-platform="trendyol" checked />
                <img src="${TRENDYOL_LOGO_URL}" alt="Trendyol" class="product-price-tracking-settings-logo" />
              </label>
              <label class="product-price-tracking-settings-option">
                <input type="checkbox" class="product-price-tracking-brand-checkbox" data-pt-platform="hepsiburada" checked />
                <img src="${HEPSIBURADA_LOGO_URL}" alt="Hepsiburada" class="product-price-tracking-settings-logo" />
              </label>
              <label class="product-price-tracking-settings-option">
                <input type="checkbox" class="product-price-tracking-brand-checkbox" data-pt-platform="amazon" checked />
                <img src="${AMAZON_LOGO_URL}" alt="Amazon" class="product-price-tracking-settings-logo" />
              </label>
              <label class="product-price-tracking-settings-option">
                <input type="checkbox" class="product-price-tracking-brand-checkbox" data-pt-platform="pazarama" checked />
                <img src="${PAZARAMA_LOGO_URL}" alt="Pazarama" class="product-price-tracking-settings-logo" />
              </label>
              <label class="product-price-tracking-settings-option">
                <input type="checkbox" class="product-price-tracking-brand-checkbox" data-pt-platform="pttavm" checked />
                <img src="${PTTAVM_LOGO_URL}" alt="PttAVM" class="product-price-tracking-settings-logo" />
              </label>
              <label class="product-price-tracking-settings-option">
                <input type="checkbox" class="product-price-tracking-brand-checkbox" data-pt-platform="idefix" checked />
                <img src="${IDEFIX_LOGO_URL}" alt="idefix" class="product-price-tracking-settings-logo" />
              </label>
              <label class="product-price-tracking-settings-option">
                <input type="checkbox" class="product-price-tracking-brand-checkbox" data-pt-platform="teknosa" checked />
                <img src="${TEKNOSA_LOGO_URL}" alt="Teknosa" class="product-price-tracking-settings-logo" />
              </label>
            </div>
          </div>
          <div id="product-price-tracking-form-wrap" class="product-price-tracking-form-wrap" style="display:none;">
            <div class="product-price-tracking-form-grid">
              <div class="product-price-tracking-input-group" data-pt-platform="n11">
                <label for="product-price-tracking-n11" class="product-price-tracking-input-label">
                  <img src="${N11_LOGO_URL}" alt="n11" class="product-price-tracking-input-logo" />
                </label>
                <input type="url" id="product-price-tracking-n11" class="product-price-tracking-input" placeholder="https://www.n11.com/urun/..." aria-label="n11 ürün linki" />
              </div>
              <div class="product-price-tracking-input-group" data-pt-platform="trendyol">
                <label for="product-price-tracking-trendyol" class="product-price-tracking-input-label">
                  <img src="${TRENDYOL_LOGO_URL}" alt="Trendyol" class="product-price-tracking-input-logo" />
                </label>
                <input type="url" id="product-price-tracking-trendyol" class="product-price-tracking-input" placeholder="https://www.trendyol.com/..." aria-label="Trendyol ürün linki" />
              </div>
              <div class="product-price-tracking-input-group" data-pt-platform="hepsiburada">
                <label for="product-price-tracking-hepsiburada" class="product-price-tracking-input-label">
                  <img src="${HEPSIBURADA_LOGO_URL}" alt="Hepsiburada" class="product-price-tracking-input-logo" />
                </label>
                <input type="url" id="product-price-tracking-hepsiburada" class="product-price-tracking-input" placeholder="https://www.hepsiburada.com/..." aria-label="Hepsiburada ürün linki" />
              </div>
              <div class="product-price-tracking-input-group" data-pt-platform="amazon">
                <label for="product-price-tracking-amazon" class="product-price-tracking-input-label">
                  <img src="${AMAZON_LOGO_URL}" alt="Amazon" class="product-price-tracking-input-logo" />
                </label>
                <input type="url" id="product-price-tracking-amazon" class="product-price-tracking-input" placeholder="https://www.amazon.com.tr/..." aria-label="Amazon ürün linki" />
              </div>
              <div class="product-price-tracking-input-group" data-pt-platform="pazarama">
                <label for="product-price-tracking-pazarama" class="product-price-tracking-input-label">
                  <img src="${PAZARAMA_LOGO_URL}" alt="Pazarama" class="product-price-tracking-input-logo" />
                </label>
                <input type="url" id="product-price-tracking-pazarama" class="product-price-tracking-input" placeholder="https://www.pazarama.com/..." aria-label="Pazarama ürün linki" />
              </div>
              <div class="product-price-tracking-input-group" data-pt-platform="pttavm">
                <label for="product-price-tracking-pttavm" class="product-price-tracking-input-label">
                  <img src="${PTTAVM_LOGO_URL}" alt="PttAVM" class="product-price-tracking-input-logo" />
                </label>
                <input type="url" id="product-price-tracking-pttavm" class="product-price-tracking-input" placeholder="https://www.pttavm.com/..." aria-label="PttAVM ürün linki" />
              </div>
              <div class="product-price-tracking-input-group" data-pt-platform="idefix">
                <label for="product-price-tracking-idefix" class="product-price-tracking-input-label">
                  <img src="${IDEFIX_LOGO_URL}" alt="idefix" class="product-price-tracking-input-logo" />
                </label>
                <input type="url" id="product-price-tracking-idefix" class="product-price-tracking-input" placeholder="https://www.idefix.com/..." aria-label="idefix ürün linki" />
              </div>
              <div class="product-price-tracking-input-group" data-pt-platform="teknosa">
                <label for="product-price-tracking-teknosa" class="product-price-tracking-input-label">
                  <img src="${TEKNOSA_LOGO_URL}" alt="Teknosa" class="product-price-tracking-input-logo" />
                </label>
                <input type="url" id="product-price-tracking-teknosa" class="product-price-tracking-input" placeholder="https://www.teknosa.com/..." aria-label="Teknosa ürün linki" />
              </div>
            </div>
            <div class="product-price-tracking-form-actions">
              <button type="button" id="product-price-tracking-save-btn" class="product-price-tracking-save-btn">Kaydet</button>
              <button type="button" id="product-price-tracking-cancel-btn" class="product-price-tracking-cancel-btn">Vazgeç</button>
            </div>
          </div>
          <div class="product-price-tracking-table-wrap">
            <table class="product-price-tracking-table">
              <thead>
                <tr>
                  <th>Ürün</th>
                  <th>Link</th>
                  <th>Product ID</th>
                  <th>Pims ID</th>
                  <th>Sku ID</th>
                  <th>Group ID</th>
                  <th>Buybox?</th>
                  <th data-pt-col="n11"><img src="${N11_LOGO_URL}" alt="n11" class="product-price-tracking-header-logo" /></th>
                  <th data-pt-col="trendyol"><img src="${TRENDYOL_LOGO_URL}" alt="Trendyol" class="product-price-tracking-header-logo" /></th>
                  <th data-pt-col="hepsiburada"><img src="${HEPSIBURADA_LOGO_URL}" alt="Hepsiburada" class="product-price-tracking-header-logo" /></th>
                  <th data-pt-col="amazon"><img src="${AMAZON_LOGO_URL}" alt="Amazon" class="product-price-tracking-header-logo" /></th>
                  <th data-pt-col="pazarama"><img src="${PAZARAMA_LOGO_URL}" alt="Pazarama" class="product-price-tracking-header-logo" /></th>
                  <th data-pt-col="pttavm"><img src="${PTTAVM_LOGO_URL}" alt="PttAVM" class="product-price-tracking-header-logo" /></th>
                  <th data-pt-col="idefix"><img src="${IDEFIX_LOGO_URL}" alt="idefix" class="product-price-tracking-header-logo" /></th>
                  <th data-pt-col="teknosa"><img src="${TEKNOSA_LOGO_URL}" alt="Teknosa" class="product-price-tracking-header-logo" /></th>
                  <th class="text-center">İşlem</th>
                </tr>
              </thead>
              <tbody id="product-price-tracking-tbody"></tbody>
            </table>
          </div>
          <div class="product-price-tracking-backup-actions">
            <button type="button" id="product-price-tracking-export-json-btn" class="product-price-tracking-export-json-btn">Veriyi İndir</button>
            <input type="file" accept=".json,application/json" id="product-price-tracking-import-input" class="product-price-tracking-import-input" />
            <button type="button" id="product-price-tracking-import-btn" class="product-price-tracking-import-btn">Veriyi Yükle</button>
          </div>
          <div class="status info" id="product-price-tracking-status"></div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const addBtn = modal.querySelector("#product-price-tracking-add-btn");
    const refreshBtn = modal.querySelector("#product-price-tracking-refresh-btn");
    const importExcelBtn = modal.querySelector("#product-price-tracking-import-excel-btn");
    const importExcelInput = modal.querySelector("#product-price-tracking-import-excel-input");
    const excelDropZone = modal.querySelector("#product-price-tracking-excel-drop-zone");
    const exportJsonBtn = modal.querySelector("#product-price-tracking-export-json-btn");
    const importBtn = modal.querySelector("#product-price-tracking-import-btn");
    const importInput = modal.querySelector("#product-price-tracking-import-input");
    const exportBtn = modal.querySelector("#product-price-tracking-export-btn");
    const settingsBtn = modal.querySelector("#product-price-tracking-settings-btn");
    const settingsWrap = modal.querySelector("#product-price-tracking-settings-wrap");
    const saveBtn = modal.querySelector("#product-price-tracking-save-btn");
    const cancelBtn = modal.querySelector("#product-price-tracking-cancel-btn");
    const formWrap = modal.querySelector("#product-price-tracking-form-wrap");
    const n11Input = modal.querySelector("#product-price-tracking-n11");
    const trendyolInput = modal.querySelector("#product-price-tracking-trendyol");
    const hepsiburadaInput = modal.querySelector("#product-price-tracking-hepsiburada");
    const amazonInput = modal.querySelector("#product-price-tracking-amazon");
    const pazaramaInput = modal.querySelector("#product-price-tracking-pazarama");
    const pttavmInput = modal.querySelector("#product-price-tracking-pttavm");
    const idefixInput = modal.querySelector("#product-price-tracking-idefix");
    const teknosaInput = modal.querySelector("#product-price-tracking-teknosa");
    const tbody = modal.querySelector("#product-price-tracking-tbody");
    const brandCheckboxes = Array.from(modal.querySelectorAll(".product-price-tracking-brand-checkbox"));
    const statusEl = modal.querySelector("#product-price-tracking-status");
    const platformColumns = Array.from(modal.querySelectorAll("th[data-pt-col]"));
    const formGroups = Array.from(modal.querySelectorAll(".product-price-tracking-input-group[data-pt-platform]"));
    let rows = [];
    let editingRowId = null;
    const platformConfig = [
      { key: "n11", priceKey: "n11Price", urlKey: "n11Url" },
      { key: "trendyol", priceKey: "trendyolPrice", urlKey: "trendyolUrl" },
      { key: "hepsiburada", priceKey: "hepsiburadaPrice", urlKey: "hepsiburadaUrl" },
      { key: "amazon", priceKey: "amazonPrice", urlKey: "amazonUrl" },
      { key: "pazarama", priceKey: "pazaramaPrice", urlKey: "pazaramaUrl" },
      { key: "pttavm", priceKey: "pttavmPrice", urlKey: "pttavmUrl" },
      { key: "idefix", priceKey: "idefixPrice", urlKey: "idefixUrl" },
      { key: "teknosa", priceKey: "teknosaPrice", urlKey: "teknosaUrl" }
    ];

    const setStatus = (message, type = "info") => {
      statusEl.textContent = message || "";
      statusEl.className = `status ${type}`;
      statusEl.style.display = message ? "block" : "none";
    };

    const loadRowsFromStorage = () => new Promise((resolve) => {
      chrome.storage.local.get(STORAGE_KEY_PRODUCT_PRICE_TRACKING_ROWS, (result) => {
        const list = result && Array.isArray(result[STORAGE_KEY_PRODUCT_PRICE_TRACKING_ROWS])
          ? result[STORAGE_KEY_PRODUCT_PRICE_TRACKING_ROWS]
          : [];
        resolve(list);
      });
    });

    const saveRowsToStorage = (nextRows, options = {}) => new Promise((resolve) => {
      const shouldSync = options && options.sync !== false;
      chrome.storage.local.set({ [STORAGE_KEY_PRODUCT_PRICE_TRACKING_ROWS]: nextRows }, () => {
        if (
          shouldSync &&
          window.n11PricePool &&
          typeof window.n11PricePool.syncRowsFromTracking === "function"
        ) {
          window.n11PricePool.syncRowsFromTracking(nextRows, { interactive: false }).catch((err) => {
            console.error("Price Pool sync error:", err);
          });
        }
        resolve();
      });
    });

    const loadSelectedBrandsFromStorage = () => new Promise((resolve) => {
      chrome.storage.local.get(STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS, (result) => {
        const selected = result && Array.isArray(result[STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS])
          ? result[STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS].map((item) => String(item || "").trim()).filter(Boolean)
          : [];
        resolve(selected);
      });
    });

    const saveSelectedBrandsToStorage = (brands) => new Promise((resolve) => {
      chrome.storage.local.set({ [STORAGE_KEY_PRODUCT_PRICE_TRACKING_BRANDS]: brands }, () => resolve());
    });

    const getSelectedPlatformKeys = () => {
      const selected = brandCheckboxes
        .filter((checkbox) => checkbox.checked)
        .map((checkbox) => checkbox.getAttribute("data-pt-platform") || "")
        .map((key) => key.trim())
        .filter(Boolean);
      return selected.length ? selected : platformConfig.map((item) => item.key);
    };

    const applyBrandVisibility = () => {
      const selected = getSelectedPlatformKeys();
      formGroups.forEach((group) => {
        const key = (group.getAttribute("data-pt-platform") || "").trim();
        group.style.display = selected.includes(key) ? "flex" : "none";
      });
      platformColumns.forEach((col) => {
        const key = (col.getAttribute("data-pt-col") || "").trim();
        col.style.display = selected.includes(key) ? "" : "none";
      });
      renderTable();
    };

    const normalizeRow = (row) => {
      const source = row && typeof row === "object" ? row : {};
      return {
        id: source.id ? String(source.id) : (Date.now().toString(36) + Math.random().toString(36).slice(2)),
        productTitle: source.productTitle ? String(source.productTitle) : "",
        productImage: source.productImage ? String(source.productImage) : "",
        link: source.link ? String(source.link) : "",
        productId: source.productId ? String(source.productId) : "",
        pimsId: source.pimsId ? String(source.pimsId) : "",
        skuId: source.skuId ? String(source.skuId) : "",
        groupId: source.groupId ? String(source.groupId) : "",
        n11Url: source.n11Url ? String(source.n11Url) : "",
        n11Price: source.n11Price ? String(source.n11Price) : "-",
        trendyolPrice: source.trendyolPrice ? String(source.trendyolPrice) : "-",
        trendyolUrl: source.trendyolUrl ? String(source.trendyolUrl) : "",
        hepsiburadaPrice: source.hepsiburadaPrice ? String(source.hepsiburadaPrice) : "-",
        hepsiburadaUrl: source.hepsiburadaUrl ? String(source.hepsiburadaUrl) : "",
        amazonPrice: source.amazonPrice ? String(source.amazonPrice) : "-",
        amazonUrl: source.amazonUrl ? String(source.amazonUrl) : "",
        pazaramaPrice: source.pazaramaPrice ? String(source.pazaramaPrice) : "-",
        pazaramaUrl: source.pazaramaUrl ? String(source.pazaramaUrl) : "",
        pttavmPrice: source.pttavmPrice ? String(source.pttavmPrice) : "-",
        pttavmUrl: source.pttavmUrl ? String(source.pttavmUrl) : "",
        idefixPrice: source.idefixPrice ? String(source.idefixPrice) : "-",
        idefixUrl: source.idefixUrl ? String(source.idefixUrl) : "",
        teknosaPrice: source.teknosaPrice ? String(source.teknosaPrice) : "-",
        teknosaUrl: source.teknosaUrl ? String(source.teknosaUrl) : ""
      };
    };

    const escapeHtmlLocal = (value) => {
      if (value == null) return "";
      return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    };

    const formatPriceTL = (raw) => {
      const parsed = parsePriceStringToNumber(raw);
      if (parsed == null || Number.isNaN(parsed)) return "-";
      return parsed.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
    };

    const extractN11PriceFromHtml = (html) => {
      if (!html || typeof html !== "string") return null;
      const patterns = [
        /model\.adData\.price\s*[=:]\s*["']?([\d.,]+)["']?/i,
        /model\[['"]adData['"]\]\[['"]price['"]\]\s*[=:]\s*["']?([\d.,]+)["']?/i,
        /"adData"\s*:\s*\{[\s\S]*?"price"\s*:\s*["']?([\d.,]+)["']?/i
      ];
      for (const pattern of patterns) {
        const match = html.match(pattern);
        if (match && match[1]) {
          return formatPriceTL(match[1]);
        }
      }
      return null;
    };

    const extractN11IdsFromHtml = (html, n11Url = "") => {
      if (!html || typeof html !== "string") {
        return { productId: "", pimsId: "", skuId: "", groupId: "" };
      }
      try {
        const strong = extractProductInfoFromN11Html(html);
        if (strong && typeof strong === "object") {
          const parsed = {
            productId: String(strong.productId || "").trim(),
            pimsId: String(strong.pimsId || "").trim(),
            skuId: String(strong.skuId || "").trim(),
            groupId: String(strong.groupId || "").trim()
          };
          if (parsed.productId || parsed.pimsId || parsed.skuId || parsed.groupId) {
            if (!parsed.productId) {
              const m = String(n11Url || "").trim().match(/-(\d+)(?:\/|\?|$)/);
              if (m && m[1]) parsed.productId = m[1];
            }
            return parsed;
          }
        }
      } catch {}
      const matchFirst = (patterns) => {
        for (const pattern of patterns) {
          const m = html.match(pattern);
          if (m && m[1]) return String(m[1]).trim();
        }
        return "";
      };
      const productIdFromHtml = matchFirst([
        /model\.adData\.productId\s*[=:]\s*["']?(\d+)["']?/i,
        /model\.productMeta\.productId\s*[=:]\s*["']?(\d+)["']?/i,
        /"productMeta"\s*:\s*\{[\s\S]*?"productId"\s*:\s*["']?(\d+)["']?/i,
        /"adData"\s*:\s*\{[\s\S]*?"productId"\s*:\s*["']?(\d+)["']?/i,
        /"productId"\s*:\s*["']?(\d{6,})["']?/i
      ]);
      const pimsIdFromHtml = matchFirst([
        /model\.product\.defaultPimsId\s*[=:]\s*["']?(\d+)["']?/i,
        /"defaultPimsId"\s*:\s*["']?(\d+)["']?/i,
        /"pimsId"\s*:\s*["']?(\d+)["']?/i
      ]);
      const skuIdFromHtml = matchFirst([
        /model\.adData\.skuId\s*[=:]\s*["']?(\d+)["']?/i,
        /"adData"\s*:\s*\{[\s\S]*?"skuId"\s*:\s*["']?(\d+)["']?/i,
        /"skuId"\s*:\s*["']?(\d+)["']?/i
      ]);
      const groupIdFromHtml = matchFirst([
        /model\.adData\.groupId\s*[=:]\s*["']?(\d+)["']?/i,
        /"adData"\s*:\s*\{[\s\S]*?"groupId"\s*:\s*["']?(\d+)["']?/i,
        /"groupId"\s*:\s*["']?(\d+)["']?/i
      ]);
      const productIdFromUrl = (() => {
        const val = String(n11Url || "").trim();
        if (!val) return "";
        const m = val.match(/-(\d+)(?:\/|\?|$)/);
        return m && m[1] ? m[1] : "";
      })();
      return {
        productId: productIdFromHtml || productIdFromUrl || "",
        pimsId: pimsIdFromHtml || "",
        skuId: skuIdFromHtml || "",
        groupId: groupIdFromHtml || ""
      };
    };

    const fetchN11IdsFromUrl = async (n11Url) => {
      const url = String(n11Url || "").trim();
      if (!url || !/https?:\/\/(?:www\.)?n11\.com\//i.test(url)) {
        return { productId: "", pimsId: "", skuId: "", groupId: "" };
      }
      try {
        const response = await fetch(url, { credentials: "omit" });
        if (!response.ok) {
          return { productId: "", pimsId: "", skuId: "", groupId: "" };
        }
        const html = await response.text();
        const info = extractProductInfoFromN11Html(html);
        const productIdFallbackMatch = url.match(/-(\d+)(?:\/|\?|$)/);
        return {
          productId: String(info.productId || "").trim() || (productIdFallbackMatch && productIdFallbackMatch[1] ? productIdFallbackMatch[1] : ""),
          pimsId: String(info.pimsId || "").trim(),
          skuId: String(info.skuId || "").trim(),
          groupId: String(info.groupId || "").trim()
        };
      } catch {
        return { productId: "", pimsId: "", skuId: "", groupId: "" };
      }
    };

    const linkCell = (url, label) => {
      const val = (url || "").trim();
      if (!val) return "-";
      const safeUrl = escapeHtmlLocal(val);
      const safeLabel = escapeHtmlLocal(label || val);
      return `<a href="${safeUrl}" target="_blank" rel="noopener">${safeLabel}</a>`;
    };

    const renderTable = () => {
      const selectedPlatforms = getSelectedPlatformKeys();
      const selectedConfig = platformConfig.filter((item) => selectedPlatforms.includes(item.key));
      if (!rows.length) {
        tbody.innerHTML = `<tr><td colspan="${selectedConfig.length + 8}" class="akakce-crawler-empty">Henüz ürün eklenmedi.</td></tr>`;
        exportBtn.disabled = true;
        exportJsonBtn.disabled = true;
        return;
      }
      exportBtn.disabled = false;
      exportJsonBtn.disabled = false;
      tbody.innerHTML = rows
        .map((item) => {
          const pricedPlatforms = selectedConfig
            .map((platform) => ({
              key: platform.key,
              num: parsePriceStringToNumber(item[platform.priceKey] || "")
            }))
            .filter((entry) => typeof entry.num === "number" && !Number.isNaN(entry.num));
          const allPricedPlatforms = platformConfig
            .map((platform) => ({
              key: platform.key,
              num: parsePriceStringToNumber(item[platform.priceKey] || "")
            }))
            .filter((entry) => typeof entry.num === "number" && !Number.isNaN(entry.num));
          const buybox = pricedPlatforms.length
            ? pricedPlatforms.reduce((lowest, current) => (lowest.num <= current.num ? lowest : current))
            : null;
          const buyboxAll = allPricedPlatforms.length
            ? allPricedPlatforms.reduce((lowest, current) => (lowest.num <= current.num ? lowest : current))
            : null;
          const buyboxText = buyboxAll && buyboxAll.key === "n11" ? "yes" : "no";
          const isN11Losing = Boolean(
            buybox &&
            buybox.key !== "n11" &&
            pricedPlatforms.some((entry) => entry.key === "n11")
          );

          return `
            <tr>
              <td>${productCell(item)}</td>
              <td class="link"><b>${linkCell(item.link, "Ürün Linki")}</b></td>
              <td class="text-center">${escapeHtmlLocal(item.productId || "-")}</td>
              <td class="text-center">${escapeHtmlLocal(item.pimsId || "-")}</td>
              <td class="text-center">${escapeHtmlLocal(item.skuId || "-")}</td>
              <td class="text-center">${escapeHtmlLocal(item.groupId || "-")}</td>
              <td class="text-center"><b>${buyboxText}</b></td>
              ${selectedConfig.map((platform) => {
                const isBuybox = Boolean(buybox && buybox.key === platform.key);
                const className = platform.key === "n11" && isN11Losing
                  ? "product-price-tracking-price-n11-losing"
                  : (isBuybox ? "product-price-tracking-price-buybox" : "");
                if (platform.key === "n11") {
                  const safePrice = escapeHtmlLocal(item.n11Price || "-");
                  return `<td class="text-center"><b class="${className}">${safePrice}</b></td>`;
                }
                return `<td class="text-center">${platformPriceCell(item[platform.urlKey], item[platform.priceKey], className)}</td>`;
              }).join("")}
              <td class="product-price-tracking-actions-cell text-right">
                <button type="button" class="product-price-tracking-row-refresh" data-pt-action="refresh" data-pt-id="${escapeHtmlLocal(item.id)}">Güncelle</button>
                <button type="button" class="product-price-tracking-row-edit" data-pt-action="edit" data-pt-id="${escapeHtmlLocal(item.id)}">Düzenle</button>
                <button type="button" class="product-price-tracking-row-delete" data-pt-action="delete" data-pt-id="${escapeHtmlLocal(item.id)}">Sil</button>
              </td>
            </tr>
          `;
        })
        .join("");
    };

    const platformLinkCell = (url, logoUrl, altText) => {
      const val = (url || "").trim();
      if (!val) return "-";
      const safeUrl = escapeHtmlLocal(val);
      const safeLogo = escapeHtmlLocal(logoUrl);
      const safeAlt = escapeHtmlLocal(altText);
      return `<a href="${safeUrl}" target="_blank" rel="noopener" class="product-price-tracking-platform-link"><img src="${safeLogo}" alt="${safeAlt}" class="product-price-tracking-cell-logo" /></a>`;
    };

    const platformPriceCell = (url, price, className = "") => {
      const priceText = (price || "").trim();
      if (!url && !priceText) return "-";
      const safeClass = escapeHtmlLocal(className || "");
      if (!url) {
        const safeTextOnly = escapeHtmlLocal(priceText || "-");
        return safeClass ? `<span class="${safeClass}">${safeTextOnly}</span>` : safeTextOnly;
      }
      const safeUrl = escapeHtmlLocal(url);
      const safeText = escapeHtmlLocal(priceText || "-");
      const classes = ["product-price-tracking-price-link"];
      if (safeClass) classes.push(safeClass);
      return `<a href="${safeUrl}" target="_blank" rel="noopener" class="${classes.join(" ")}">${safeText}</a>`;
    };

    const productCell = (item) => {
      const title = escapeHtmlLocal(item.productTitle || "-");
      const img = (item.productImage || "").trim();
      const safeImg = escapeHtmlLocal(img);
      const imageHtml = img
        ? `<img src="${safeImg}" alt="${title}" class="product-price-tracking-product-thumb" />`
        : '<span class="product-price-tracking-product-thumb-empty">-</span>';
      if (item.link) {
        const safeLink = escapeHtmlLocal(item.link);
        return `<a href="${safeLink}" target="_blank" rel="noopener" class="product-price-tracking-product-cell">${imageHtml}<span class="product-price-tracking-product-title">${title}</span></a>`;
      }
      return `<div class="product-price-tracking-product-cell">${imageHtml}<span class="product-price-tracking-product-title">${title}</span></div>`;
    };

    const resetForm = () => {
      n11Input.value = "";
      trendyolInput.value = "";
      hepsiburadaInput.value = "";
      amazonInput.value = "";
      pazaramaInput.value = "";
      pttavmInput.value = "";
      idefixInput.value = "";
      teknosaInput.value = "";
    };

    const openForm = () => {
      formWrap.style.display = "block";
      n11Input.focus();
    };

    const closeForm = () => {
      formWrap.style.display = "none";
      resetForm();
      editingRowId = null;
      saveBtn.textContent = "Kaydet";
    };

    const xmlEscape = (value) => {
      if (value == null) return "";
      return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
    };

    const downloadExcelXml = () => {
      if (!rows.length) {
        setStatus("İndirilecek kayıt yok.", "error");
        return;
      }
      const headerCells = ["Ürün Başlık", "Ürün Görsel", "Link", "Product ID", "Pims ID", "Sku ID", "Group ID", "Buybox?", "n11 Fiyat", "Trendyol Fiyat", "Trendyol Link", "Hepsiburada Fiyat", "Hepsiburada Link", "Amazon Fiyat", "Amazon Link", "Pazarama Fiyat", "Pazarama Link", "PttAVM Fiyat", "PttAVM Link", "idefix Fiyat", "idefix Link", "Teknosa Fiyat", "Teknosa Link"]
        .map((h) => `<Cell><Data ss:Type="String">${xmlEscape(h)}</Data></Cell>`)
        .join("");
      const bodyRows = rows.map((r) => {
        const allPricedPlatforms = platformConfig
          .map((platform) => ({
            key: platform.key,
            num: parsePriceStringToNumber(r[platform.priceKey] || "")
          }))
          .filter((entry) => typeof entry.num === "number" && !Number.isNaN(entry.num));
        const buyboxAll = allPricedPlatforms.length
          ? allPricedPlatforms.reduce((lowest, current) => (lowest.num <= current.num ? lowest : current))
          : null;
        const buyboxText = buyboxAll && buyboxAll.key === "n11" ? "yes" : "no";
        const cells = [
          r.productTitle || "",
          r.productImage || "",
          r.link || "",
          r.productId || "",
          r.pimsId || "",
          r.skuId || "",
          r.groupId || "",
          buyboxText,
          r.n11Price || "-",
          r.trendyolPrice || "-",
          r.trendyolUrl || "",
          r.hepsiburadaPrice || "-",
          r.hepsiburadaUrl || "",
          r.amazonPrice || "-",
          r.amazonUrl || "",
          r.pazaramaPrice || "-",
          r.pazaramaUrl || "",
          r.pttavmPrice || "-",
          r.pttavmUrl || "",
          r.idefixPrice || "-",
          r.idefixUrl || "",
          r.teknosaPrice || "-",
          r.teknosaUrl || ""
        ].map((v) => `<Cell><Data ss:Type="String">${xmlEscape(v)}</Data></Cell>`).join("");
        return `<Row>${cells}</Row>`;
      }).join("");
      const xml =
        '<?xml version="1.0"?>' +
        '<?mso-application progid="Excel.Sheet"?>' +
        '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' +
        '<Worksheet ss:Name="Product Price Tracking"><Table>' +
        `<Row>${headerCells}</Row>${bodyRows}` +
        '</Table></Worksheet></Workbook>';
      const blob = new Blob([xml], { type: "application/vnd.ms-excel;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "product-price-tracking-" + new Date().toISOString().slice(0, 10) + ".xls";
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(a.href);
      setStatus("Excel dosyası indirildi.", "success");
    };

    const downloadJsonBackup = () => {
      if (!rows.length) {
        setStatus("İndirilecek kayıt yok.", "error");
        return;
      }
      const payload = {
        type: "product-price-tracking-backup",
        version: 1,
        exportedAt: new Date().toISOString(),
        rows: rows.map((item) => normalizeRow(item))
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "product-price-tracking-backup-" + new Date().toISOString().slice(0, 10) + ".json";
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(a.href);
      setStatus("JSON yedek indirildi. Yeni sürümde 'JSON Yedek Yükle' ile geri alabilirsiniz.", "success");
    };

    const parseImportedRows = (data) => {
      const sourceRows = Array.isArray(data)
        ? data
        : (data && Array.isArray(data.rows) ? data.rows : []);
      if (!sourceRows.length) {
        throw new Error("Dosyada geri yüklenecek kayıt bulunamadı.");
      }
      const importedRows = sourceRows
        .map((item) => normalizeRow(item))
        .filter((item) => {
          return Boolean(
            (item.link || "").trim() ||
            (item.n11Url || "").trim() ||
            (item.trendyolUrl || "").trim() ||
            (item.hepsiburadaUrl || "").trim() ||
            (item.amazonUrl || "").trim() ||
            (item.pazaramaUrl || "").trim() ||
            (item.pttavmUrl || "").trim() ||
            (item.idefixUrl || "").trim() ||
            (item.teknosaUrl || "").trim()
          );
        });
      if (!importedRows.length) {
        throw new Error("Dosyadaki kayıtlar geçerli URL içermiyor.");
      }
      return importedRows;
    };

    const readExcelFileAsArrayBuffer = (file) =>
      new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error("Excel dosyası okunamadı."));
        reader.readAsArrayBuffer(file);
      });

    const normalizeDetectedUrl = (rawUrl) => {
      const value = String(rawUrl || "").trim();
      if (!value) return "";
      const cleaned = value.replace(/[)\],.;]+$/g, "");
      try {
        return new URL(cleaned).toString();
      } catch {
        return "";
      }
    };

    const detectPlatformFromUrl = (urlValue) => {
      const value = String(urlValue || "").trim();
      if (!value) return "";
      try {
        const host = (new URL(value)).hostname.toLowerCase();
        if (/(^|\.)n11\.com$/.test(host)) return "n11";
        if (/(^|\.)trendyol\.com$/.test(host)) return "trendyol";
        if (/(^|\.)hepsiburada\.com$/.test(host)) return "hepsiburada";
        if (/(^|\.)amazon\./.test(host)) return "amazon";
        if (/(^|\.)pazarama\.com$/.test(host)) return "pazarama";
        if (/(^|\.)pttavm\.com$/.test(host)) return "pttavm";
        if (/(^|\.)idefix\.com$/.test(host)) return "idefix";
        if (/(^|\.)teknosa\.com$/.test(host)) return "teknosa";
      } catch {}
      return "";
    };

    const extractPlatformUrlsFromCell = (rawCell) => {
      const text = String(rawCell || "");
      const matches = text.match(/https?:\/\/[^\s"'<>]+/gi) || [];
      const out = {};
      matches.forEach((rawMatch) => {
        const normalized = normalizeDetectedUrl(rawMatch);
        if (!normalized) return;
        const key = detectPlatformFromUrl(normalized);
        if (!key || out[key]) return;
        out[key] = normalized;
      });
      return out;
    };

    const extractRowsFromExcelWorkbook = (workbook) => {
      const extracted = [];
      const seen = new Set();
      const mainOrder = ["n11", "trendyol", "hepsiburada", "amazon", "pazarama", "pttavm", "idefix", "teknosa"];
      const toUrlKey = {
        n11: "n11Url",
        trendyol: "trendyolUrl",
        hepsiburada: "hepsiburadaUrl",
        amazon: "amazonUrl",
        pazarama: "pazaramaUrl",
        pttavm: "pttavmUrl",
        idefix: "idefixUrl",
        teknosa: "teknosaUrl"
      };
      workbook.SheetNames.forEach((sheetName) => {
        const ws = workbook.Sheets[sheetName];
        if (!ws) return;
        const sheetRows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "", raw: false });
        sheetRows.forEach((row) => {
          if (!Array.isArray(row) || row.length === 0) return;
          const platformUrls = {};
          row.forEach((cell) => {
            const detected = extractPlatformUrlsFromCell(cell);
            Object.entries(detected).forEach(([key, val]) => {
              if (!platformUrls[key]) platformUrls[key] = val;
            });
          });
          const signature = mainOrder.map((k) => platformUrls[k] || "").join("|");
          if (!signature.replace(/\|/g, "")) return;
          if (seen.has(signature)) return;
          seen.add(signature);
          const mainLink = mainOrder.map((k) => platformUrls[k] || "").find((u) => u) || "";
          const rowData = { link: mainLink };
          mainOrder.forEach((key) => {
            const urlKey = toUrlKey[key];
            rowData[urlKey] = platformUrls[key] || "";
          });
          extracted.push(normalizeRow(rowData));
        });
      });
      return extracted;
    };

    const resolvePlatformUrls = (row) => {
      const main = (row && row.link ? String(row.link) : "").trim();
      const infer = (regex) => (regex.test(main) ? main : "");
      return {
        n11Url: ((row && row.n11Url) || infer(/https?:\/\/(?:www\.)?n11\.com\//i) || "").trim(),
        trendyolUrl: ((row && row.trendyolUrl) || infer(/https?:\/\/(?:www\.)?trendyol\.com\//i) || "").trim(),
        hepsiburadaUrl: ((row && row.hepsiburadaUrl) || infer(/https?:\/\/(?:www\.)?hepsiburada\.com\//i) || "").trim(),
        amazonUrl: ((row && row.amazonUrl) || infer(/https?:\/\/(?:www\.)?amazon\./i) || "").trim(),
        pazaramaUrl: ((row && row.pazaramaUrl) || infer(/https?:\/\/(?:www\.)?pazarama\.com\//i) || "").trim(),
        pttavmUrl: ((row && row.pttavmUrl) || infer(/https?:\/\/(?:www\.)?pttavm\.com\//i) || "").trim(),
        idefixUrl: ((row && row.idefixUrl) || infer(/https?:\/\/(?:www\.)?idefix\.com\//i) || "").trim(),
        teknosaUrl: ((row && row.teknosaUrl) || infer(/https?:\/\/(?:www\.)?teknosa\.com\//i) || "").trim()
      };
    };

    const fetchPlatformPrices = async (urls, currentPrices = {}, selectedPlatforms = []) => {
      const shouldCrawl = (platformKey) => selectedPlatforms.includes(platformKey);
      let n11Price = currentPrices.n11Price || "-";
      let trendyolPrice = currentPrices.trendyolPrice || "-";
      let hepsiburadaPrice = currentPrices.hepsiburadaPrice || "-";
      let amazonPrice = currentPrices.amazonPrice || "-";
      let pazaramaPrice = currentPrices.pazaramaPrice || "-";
      let pttavmPrice = currentPrices.pttavmPrice || "-";
      let idefixPrice = currentPrices.idefixPrice || "-";
      let teknosaPrice = currentPrices.teknosaPrice || "-";
      const errors = [];

      if (urls.n11Url && shouldCrawl("n11")) {
        if (!/https?:\/\/(?:www\.)?n11\.com\//i.test(urls.n11Url)) {
          errors.push("n11 ürün linki geçersiz.");
        } else {
          try {
            const fromTab = await chrome.runtime.sendMessage({
              type: "product-price-tracking-get-n11-price",
              url: urls.n11Url
            });
            if (fromTab && fromTab.ok && fromTab.price != null && String(fromTab.price).trim() !== "") {
              n11Price = formatPriceTL(fromTab.price);
            } else {
              const response = await chrome.runtime.sendMessage({ type: "akakce-fetch-n11-page", url: urls.n11Url });
              if (response && response.ok && response.html) {
                const extracted = extractN11PriceFromHtml(response.html);
                if (extracted) {
                  n11Price = extracted;
                } else {
                  errors.push("n11 fiyatı bulunamadı (model.adData.price).");
                }
              } else {
                errors.push((response && response.error) || "n11 sayfası alınamadı.");
              }
            }
          } catch (err) {
            errors.push("n11 fiyatı alınırken hata oluştu: " + ((err && err.message) || "Bilinmeyen hata"));
          }
        }
      }

      if (urls.trendyolUrl && shouldCrawl("trendyol")) {
        if (!/https?:\/\/(?:www\.)?trendyol\.com\//i.test(urls.trendyolUrl)) {
          errors.push("Trendyol ürün linki geçersiz.");
        } else {
          try {
            const trendyolRes = await chrome.runtime.sendMessage({
              type: "product-price-tracking-get-trendyol-price",
              url: urls.trendyolUrl
            });
            if (trendyolRes && trendyolRes.ok && trendyolRes.price != null && String(trendyolRes.price).trim() !== "") {
              trendyolPrice = formatPriceTL(trendyolRes.price);
            } else {
              errors.push((trendyolRes && trendyolRes.error) || "Trendyol fiyatı alınamadı.");
            }
          } catch (err) {
            errors.push("Trendyol fiyatı alınırken hata oluştu: " + ((err && err.message) || "Bilinmeyen hata"));
          }
        }
      }

      if (urls.hepsiburadaUrl && shouldCrawl("hepsiburada")) {
        if (!/https?:\/\/(?:www\.)?hepsiburada\.com\//i.test(urls.hepsiburadaUrl)) {
          errors.push("Hepsiburada ürün linki geçersiz.");
        } else {
          try {
            const hepsiburadaRes = await chrome.runtime.sendMessage({
              type: "product-price-tracking-get-hepsiburada-price",
              url: urls.hepsiburadaUrl
            });
            if (hepsiburadaRes && hepsiburadaRes.ok && hepsiburadaRes.price != null && String(hepsiburadaRes.price).trim() !== "") {
              hepsiburadaPrice = formatPriceTL(hepsiburadaRes.price);
            } else {
              errors.push((hepsiburadaRes && hepsiburadaRes.error) || "Hepsiburada fiyatı alınamadı.");
            }
          } catch (err) {
            errors.push("Hepsiburada fiyatı alınırken hata oluştu: " + ((err && err.message) || "Bilinmeyen hata"));
          }
        }
      }

      if (urls.amazonUrl && shouldCrawl("amazon")) {
        if (!/https?:\/\/(?:www\.)?amazon\./i.test(urls.amazonUrl)) {
          amazonPrice = "stok & fiyat yok";
          errors.push("Amazon ürün linki geçersiz.");
        } else {
          try {
            const amazonRes = await chrome.runtime.sendMessage({
              type: "product-price-tracking-get-amazon-price",
              url: urls.amazonUrl
            });
            if (amazonRes && amazonRes.ok && amazonRes.price != null && String(amazonRes.price).trim() !== "") {
              amazonPrice = formatPriceTL(amazonRes.price);
            } else {
              amazonPrice = "stok & fiyat yok";
              errors.push((amazonRes && amazonRes.error) || "Amazon fiyatı alınamadı.");
            }
          } catch (err) {
            amazonPrice = "stok & fiyat yok";
            errors.push("Amazon fiyatı alınırken hata oluştu: " + ((err && err.message) || "Bilinmeyen hata"));
          }
        }
      }

      if (urls.pazaramaUrl && shouldCrawl("pazarama")) {
        if (!/https?:\/\/(?:www\.)?pazarama\.com\//i.test(urls.pazaramaUrl)) {
          errors.push("Pazarama ürün linki geçersiz.");
        } else {
          try {
            const pazaramaRes = await chrome.runtime.sendMessage({
              type: "product-price-tracking-get-pazarama-price",
              url: urls.pazaramaUrl
            });
            if (pazaramaRes && pazaramaRes.ok && pazaramaRes.price != null && String(pazaramaRes.price).trim() !== "") {
              pazaramaPrice = formatPriceTL(pazaramaRes.price);
            } else {
              errors.push((pazaramaRes && pazaramaRes.error) || "Pazarama fiyatı alınamadı.");
            }
          } catch (err) {
            errors.push("Pazarama fiyatı alınırken hata oluştu: " + ((err && err.message) || "Bilinmeyen hata"));
          }
        }
      }

      if (urls.pttavmUrl && shouldCrawl("pttavm")) {
        if (!/https?:\/\/(?:www\.)?pttavm\.com\//i.test(urls.pttavmUrl)) {
          errors.push("PttAVM ürün linki geçersiz.");
        } else {
          try {
            const pttavmRes = await chrome.runtime.sendMessage({
              type: "product-price-tracking-get-pttavm-price",
              url: urls.pttavmUrl
            });
            if (pttavmRes && pttavmRes.ok && pttavmRes.price != null && String(pttavmRes.price).trim() !== "") {
              pttavmPrice = formatPriceTL(pttavmRes.price);
            } else {
              errors.push((pttavmRes && pttavmRes.error) || "PttAVM fiyatı alınamadı.");
            }
          } catch (err) {
            errors.push("PttAVM fiyatı alınırken hata oluştu: " + ((err && err.message) || "Bilinmeyen hata"));
          }
        }
      }

      if (urls.idefixUrl && shouldCrawl("idefix")) {
        if (!/https?:\/\/(?:www\.)?idefix\.com\//i.test(urls.idefixUrl)) {
          errors.push("idefix ürün linki geçersiz.");
        } else {
          try {
            const idefixRes = await chrome.runtime.sendMessage({
              type: "product-price-tracking-get-idefix-price",
              url: urls.idefixUrl
            });
            if (idefixRes && idefixRes.ok && idefixRes.price != null && String(idefixRes.price).trim() !== "") {
              idefixPrice = formatPriceTL(idefixRes.price);
            } else {
              errors.push((idefixRes && idefixRes.error) || "idefix fiyatı alınamadı.");
            }
          } catch (err) {
            errors.push("idefix fiyatı alınırken hata oluştu: " + ((err && err.message) || "Bilinmeyen hata"));
          }
        }
      }

      if (urls.teknosaUrl && shouldCrawl("teknosa")) {
        if (!/https?:\/\/(?:www\.)?teknosa\.com\//i.test(urls.teknosaUrl)) {
          errors.push("Teknosa ürün linki geçersiz.");
        } else {
          try {
            const teknosaRes = await chrome.runtime.sendMessage({
              type: "product-price-tracking-get-teknosa-price",
              url: urls.teknosaUrl
            });
            if (teknosaRes && teknosaRes.ok && teknosaRes.price != null && String(teknosaRes.price).trim() !== "") {
              teknosaPrice = formatPriceTL(teknosaRes.price);
            } else {
              errors.push((teknosaRes && teknosaRes.error) || "Teknosa fiyatı alınamadı.");
            }
          } catch (err) {
            errors.push("Teknosa fiyatı alınırken hata oluştu: " + ((err && err.message) || "Bilinmeyen hata"));
          }
        }
      }

      return { n11Price, trendyolPrice, hepsiburadaPrice, amazonPrice, pazaramaPrice, pttavmPrice, idefixPrice, teknosaPrice, errors };
    };

    const fetchProductMeta = async (url) => {
      if (!url || !/^https?:\/\//i.test(url)) {
        return { title: "", image: "" };
      }
      try {
        const res = await chrome.runtime.sendMessage({
          type: "product-price-tracking-get-product-meta",
          url
        });
        if (res && res.ok) {
          return {
            title: String(res.title || "").trim(),
            image: String(res.image || "").trim()
          };
        }
      } catch {}
      return { title: "", image: "" };
    };

    const updateSingleTrackingRow = async (row, selectedPlatforms) => {
      const urls = resolvePlatformUrls(row);
      const prices = await fetchPlatformPrices(urls, row, selectedPlatforms);
      let n11Ids = { productId: "", pimsId: "", skuId: "", groupId: "" };
      if (urls.n11Url && /https?:\/\/(?:www\.)?n11\.com\//i.test(urls.n11Url)) {
        n11Ids = await fetchN11IdsFromUrl(urls.n11Url);
      }
      const meta = await fetchProductMeta(
        row.link ||
        urls.n11Url ||
        urls.trendyolUrl ||
        urls.hepsiburadaUrl ||
        urls.amazonUrl ||
        urls.pazaramaUrl ||
        urls.pttavmUrl ||
        urls.idefixUrl ||
        urls.teknosaUrl
      );
      const updatedRow = normalizeRow({
        ...row,
        ...urls,
        productId: n11Ids.productId || row.productId || "",
        pimsId: n11Ids.pimsId || row.pimsId || "",
        skuId: n11Ids.skuId || row.skuId || "",
        groupId: n11Ids.groupId || row.groupId || "",
        productTitle: meta.title || row.productTitle || "",
        productImage: meta.image || row.productImage || "",
        n11Price: prices.n11Price,
        trendyolPrice: prices.trendyolPrice,
        hepsiburadaPrice: prices.hepsiburadaPrice,
        amazonPrice: prices.amazonPrice,
        pazaramaPrice: prices.pazaramaPrice,
        pttavmPrice: prices.pttavmPrice,
        idefixPrice: prices.idefixPrice,
        teknosaPrice: prices.teknosaPrice
      });
      return { updatedRow, errors: prices.errors || [] };
    };

    addBtn.addEventListener("click", () => {
      openForm();
      setStatus("", "info");
    });

    settingsBtn.addEventListener("click", () => {
      settingsWrap.style.display = settingsWrap.style.display === "none" ? "block" : "none";
    });

    brandCheckboxes.forEach((checkbox) => {
      checkbox.addEventListener("change", async () => {
        if (!brandCheckboxes.some((item) => item.checked)) {
          checkbox.checked = true;
          setStatus("En az bir marka seçili olmalıdır.", "error");
          return;
        }
        const selected = getSelectedPlatformKeys();
        await saveSelectedBrandsToStorage(selected);
        applyBrandVisibility();
      });
    });

    cancelBtn.addEventListener("click", () => {
      closeForm();
      setStatus("", "info");
    });

    exportBtn.addEventListener("click", () => {
      downloadExcelXml();
    });

    exportJsonBtn.addEventListener("click", () => {
      downloadJsonBackup();
    });

    importBtn.addEventListener("click", () => {
      importInput.click();
    });

    importInput.addEventListener("change", () => {
      const file = importInput.files && importInput.files[0];
      if (!file) return;
      setStatus("JSON yedek dosyası okunuyor...", "info");
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const parsed = JSON.parse(String(reader.result || ""));
          const importedRows = parseImportedRows(parsed);
          const shouldReplace = confirm("Mevcut kayıtlar içe aktarılan JSON ile değiştirilecek. Devam edilsin mi?");
          if (!shouldReplace) {
            setStatus("JSON yükleme iptal edildi.", "info");
            importInput.value = "";
            return;
          }
          rows = importedRows;
          await saveRowsToStorage(rows);
          renderTable();
          closeForm();
          setStatus(rows.length + " kayıt JSON yedekten geri yüklendi.", "success");
        } catch (err) {
          const message = err && err.message ? err.message : "Bilinmeyen hata";
          setStatus("JSON içeriği geçersiz: " + message, "error");
        } finally {
          importInput.value = "";
        }
      };
      reader.onerror = () => {
        setStatus("JSON dosyası okunamadı.", "error");
        importInput.value = "";
      };
      reader.readAsText(file, "UTF-8");
    });

    const importFromExcelFile = async (file) => {
      if (!file) return;
      if (typeof XLSX === "undefined") {
        setStatus("Excel kütüphanesi yüklenemedi. Sayfayı yenileyin.", "error");
        return;
      }
      const fileName = String(file.name || "").toLowerCase();
      if (!/\.(xlsx|xls)$/i.test(fileName)) {
        setStatus("Lütfen .xlsx veya .xls dosyası yükleyin.", "error");
        return;
      }
      importExcelBtn.disabled = true;
      addBtn.disabled = true;
      refreshBtn.disabled = true;
      importBtn.disabled = true;
      exportBtn.disabled = true;
      exportJsonBtn.disabled = true;
      setStatus("Excel dosyası okunuyor...", "info");
      try {
        const buf = await readExcelFileAsArrayBuffer(file);
        const workbook = XLSX.read(new Uint8Array(buf), { type: "array" });
        const importedRows = extractRowsFromExcelWorkbook(workbook);
        if (!importedRows.length) {
          setStatus("Excel içinde desteklenen platform linki bulunamadı.", "error");
          return;
        }
        const existing = new Set(
          rows.map((r) => [r.n11Url || "", r.trendyolUrl || "", r.hepsiburadaUrl || "", r.amazonUrl || "", r.pazaramaUrl || "", r.pttavmUrl || "", r.idefixUrl || "", r.teknosaUrl || ""].join("|"))
        );
        const uniqueNewRows = importedRows.filter((r) => {
          const sig = [r.n11Url || "", r.trendyolUrl || "", r.hepsiburadaUrl || "", r.amazonUrl || "", r.pazaramaUrl || "", r.pttavmUrl || "", r.idefixUrl || "", r.teknosaUrl || ""].join("|");
          if (existing.has(sig)) return false;
          existing.add(sig);
          return true;
        });
        if (!uniqueNewRows.length) {
          setStatus("Excel verileri zaten tabloda mevcut.", "info");
          return;
        }
        const selectedPlatforms = getSelectedPlatformKeys();
        const builtRows = [];
        const allErrors = [];
        for (let i = 0; i < uniqueNewRows.length; i++) {
          setStatus(`Excel satırları işleniyor... (${i + 1}/${uniqueNewRows.length})`, "info");
          const { updatedRow, errors } = await updateSingleTrackingRow(uniqueNewRows[i], selectedPlatforms);
          builtRows.push(updatedRow);
          if (errors.length) allErrors.push(`Kayıt ${i + 1}: ${errors.join(" ")}`);
        }
        rows = rows.concat(builtRows);
        await saveRowsToStorage(rows);
        renderTable();
        if (allErrors.length) {
          setStatus(`${builtRows.length} kayıt eklendi. Bazı hatalar: ${allErrors.join(" | ")}`, "error");
        } else {
          setStatus(`${builtRows.length} kayıt Excel'den eklendi.`, "success");
        }
      } catch (err) {
        setStatus("Excel işlenemedi: " + ((err && err.message) || "Bilinmeyen hata"), "error");
      } finally {
        importExcelBtn.disabled = false;
        addBtn.disabled = false;
        refreshBtn.disabled = false;
        importBtn.disabled = false;
        exportBtn.disabled = false;
        exportJsonBtn.disabled = false;
      }
    };

    importExcelBtn.addEventListener("click", () => {
      importExcelInput.click();
    });

    importExcelInput.addEventListener("change", () => {
      const file = importExcelInput.files && importExcelInput.files[0];
      if (!file) return;
      importFromExcelFile(file).finally(() => {
        importExcelInput.value = "";
      });
    });

    excelDropZone.addEventListener("dragover", (e) => {
      e.preventDefault();
      excelDropZone.classList.add("product-price-tracking-excel-drop-zone-active");
    });
    excelDropZone.addEventListener("dragleave", (e) => {
      e.preventDefault();
      excelDropZone.classList.remove("product-price-tracking-excel-drop-zone-active");
    });
    excelDropZone.addEventListener("drop", (e) => {
      e.preventDefault();
      excelDropZone.classList.remove("product-price-tracking-excel-drop-zone-active");
      const file = e.dataTransfer?.files && e.dataTransfer.files[0] ? e.dataTransfer.files[0] : null;
      if (!file) return;
      importFromExcelFile(file);
    });

    refreshBtn.addEventListener("click", async () => {
      if (!rows.length) {
        setStatus("Güncellenecek kayıt yok.", "error");
        return;
      }
      refreshBtn.disabled = true;
      addBtn.disabled = true;
      importExcelBtn.disabled = true;
      importBtn.disabled = true;
      exportJsonBtn.disabled = true;
      exportBtn.disabled = true;
      try {
        const selectedPlatforms = getSelectedPlatformKeys();
        const updatedRows = [];
        const allErrors = [];
        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          setStatus(`Fiyatlar güncelleniyor... (${i + 1}/${rows.length})`, "info");
          const { updatedRow, errors } = await updateSingleTrackingRow(row, selectedPlatforms);
          updatedRows.push(updatedRow);
          if (errors.length) {
            allErrors.push(`Kayıt ${i + 1}: ${errors.join(" ")}`);
          }
        }
        rows = updatedRows;
        await saveRowsToStorage(updatedRows);
        renderTable();
        if (allErrors.length) {
          setStatus("Güncelleme tamamlandı. " + allErrors.join(" | "), "error");
        } else {
          setStatus("Tüm fiyatlar güncellendi.", "success");
        }
      } finally {
        refreshBtn.disabled = false;
        addBtn.disabled = false;
        importExcelBtn.disabled = false;
        importBtn.disabled = false;
        renderTable();
      }
    });

    tbody.addEventListener("click", async (event) => {
      const button = event.target.closest("button[data-pt-action]");
      if (!button) return;
      const action = button.getAttribute("data-pt-action");
      const id = button.getAttribute("data-pt-id");
      if (!id) return;
      const row = rows.find((item) => item.id === id);
      if (!row) return;

      if (action === "edit") {
        editingRowId = id;
        n11Input.value = row.link && /n11\.com/i.test(row.link) ? row.link : "";
        if (row.n11Url && String(row.n11Url).trim()) {
          n11Input.value = String(row.n11Url).trim();
        }
        trendyolInput.value = row.trendyolUrl || "";
        hepsiburadaInput.value = row.hepsiburadaUrl || "";
        amazonInput.value = row.amazonUrl || "";
        pazaramaInput.value = row.pazaramaUrl || "";
        pttavmInput.value = row.pttavmUrl || "";
        idefixInput.value = row.idefixUrl || "";
        teknosaInput.value = row.teknosaUrl || "";
        formWrap.style.display = "block";
        saveBtn.textContent = "Güncelle";
        setStatus("Kayıt düzenleme modunda.", "info");
        return;
      }

      if (action === "refresh") {
        const rowIndex = rows.findIndex((item) => item.id === id);
        if (rowIndex < 0) return;
        const selectedPlatforms = getSelectedPlatformKeys();
        const originalText = button.textContent;
        button.disabled = true;
        button.textContent = "Güncelleniyor...";
        try {
          setStatus("Seçili satır güncelleniyor...", "info");
          const { updatedRow, errors } = await updateSingleTrackingRow(rows[rowIndex], selectedPlatforms);
          rows[rowIndex] = updatedRow;
          await saveRowsToStorage(rows, { sync: false });
          if (window.n11PricePool && typeof window.n11PricePool.syncSingleTrackingRow === "function") {
            window.n11PricePool.syncSingleTrackingRow(updatedRow, { interactive: false }).catch((err) => {
              console.error("Price Pool single row sync error:", err);
            });
          }
          renderTable();
          if (errors.length) {
            setStatus("Satır güncellendi, ancak bazı hatalar var: " + errors.join(" "), "error");
          } else {
            setStatus("Satır fiyatları güncellendi.", "success");
          }
        } catch (err) {
          setStatus("Satır güncellenemedi: " + ((err && err.message) || "Bilinmeyen hata"), "error");
        } finally {
          button.disabled = false;
          button.textContent = originalText;
        }
        return;
      }

      if (action === "delete") {
        const nextRows = rows.filter((item) => item.id !== id);
        rows = nextRows;
        await saveRowsToStorage(nextRows);
        renderTable();
        setStatus("Kayıt silindi.", "success");
      }
    });

    saveBtn.addEventListener("click", async () => {
      const selectedPlatforms = getSelectedPlatformKeys();
      const n11Url = (n11Input.value || "").trim();
      const trendyolUrl = (trendyolInput.value || "").trim();
      const hepsiburadaUrl = (hepsiburadaInput.value || "").trim();
      const amazonUrl = (amazonInput.value || "").trim();
      const pazaramaUrl = (pazaramaInput.value || "").trim();
      const pttavmUrl = (pttavmInput.value || "").trim();
      const idefixUrl = (idefixInput.value || "").trim();
      const teknosaUrl = (teknosaInput.value || "").trim();
      const urlByKey = { n11: n11Url, trendyol: trendyolUrl, hepsiburada: hepsiburadaUrl, amazon: amazonUrl, pazarama: pazaramaUrl, pttavm: pttavmUrl, idefix: idefixUrl, teknosa: teknosaUrl };
      const selectedMainLink = selectedPlatforms.map((key) => urlByKey[key] || "").find((url) => url.trim());
      const mainLink = selectedMainLink || n11Url || trendyolUrl || hepsiburadaUrl || amazonUrl || pazaramaUrl || pttavmUrl || idefixUrl || teknosaUrl;

      if (!selectedMainLink) {
        setStatus("Seçili markalardan en az biri için ürün linki giriniz.", "error");
        return;
      }

      let n11Price = "-";
      let trendyolPrice = "-";
      let hepsiburadaPrice = "-";
      let amazonPrice = "-";
      let priceFetchError = "";
      setStatus("Fiyatlar çekiliyor...", "info");
      const fetched = await fetchPlatformPrices({ n11Url, trendyolUrl, hepsiburadaUrl, amazonUrl, pazaramaUrl, pttavmUrl, idefixUrl, teknosaUrl }, {}, selectedPlatforms);
      const meta = await fetchProductMeta(mainLink);
      let n11Ids = { productId: "", pimsId: "", skuId: "", groupId: "" };
      if (n11Url && /https?:\/\/(?:www\.)?n11\.com\//i.test(n11Url)) {
        n11Ids = await fetchN11IdsFromUrl(n11Url);
      }
      n11Price = fetched.n11Price;
      trendyolPrice = fetched.trendyolPrice;
      hepsiburadaPrice = fetched.hepsiburadaPrice;
      amazonPrice = fetched.amazonPrice;
      let pazaramaPrice = fetched.pazaramaPrice;
      let pttavmPrice = fetched.pttavmPrice;
      let idefixPrice = fetched.idefixPrice;
      let teknosaPrice = fetched.teknosaPrice;
      priceFetchError = fetched.errors.join(" ");

      let nextRows;
      if (editingRowId) {
        nextRows = rows.map((item) => {
          if (item.id !== editingRowId) return item;
          return normalizeRow({
            ...item,
            id: item.id,
            productTitle: meta.title || item.productTitle || "",
            productImage: meta.image || item.productImage || "",
            link: mainLink,
            productId: n11Ids.productId || item.productId || "",
            pimsId: n11Ids.pimsId || item.pimsId || "",
            skuId: n11Ids.skuId || item.skuId || "",
            groupId: n11Ids.groupId || item.groupId || "",
            n11Url,
            n11Price,
            trendyolPrice,
            trendyolUrl,
            hepsiburadaPrice,
            hepsiburadaUrl,
            amazonPrice,
            amazonUrl,
            pazaramaPrice,
            pazaramaUrl,
            pttavmPrice,
            pttavmUrl,
            idefixPrice,
            idefixUrl,
            teknosaPrice,
            teknosaUrl
          });
        });
      } else {
        nextRows = rows.concat([normalizeRow({
          productTitle: meta.title || "",
          productImage: meta.image || "",
          link: mainLink,
          productId: n11Ids.productId || "",
          pimsId: n11Ids.pimsId || "",
          skuId: n11Ids.skuId || "",
          groupId: n11Ids.groupId || "",
          n11Url,
          n11Price,
          trendyolPrice,
          trendyolUrl,
          hepsiburadaPrice,
          hepsiburadaUrl,
          amazonPrice,
          amazonUrl,
          pazaramaPrice,
          pazaramaUrl,
          pttavmPrice,
          pttavmUrl,
          idefixPrice,
          idefixUrl,
          teknosaPrice,
          teknosaUrl
        })]);
      }
      rows = nextRows;
      await saveRowsToStorage(nextRows);
      renderTable();
      closeForm();
      if (priceFetchError) {
        setStatus("Ürün eklendi, ancak " + priceFetchError, "error");
      } else {
        setStatus("Ürün tabloya eklendi.", "success");
      }
    });

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
    Promise.all([loadRowsFromStorage(), loadSelectedBrandsFromStorage()]).then(([storedRows, storedBrands]) => {
      rows = storedRows.map((item) => normalizeRow(item));
      const validBrandKeys = platformConfig.map((item) => item.key);
      const selected = storedBrands.filter((brandKey) => validBrandKeys.includes(brandKey));
      const nextSelected = selected.length ? selected : validBrandKeys;
      brandCheckboxes.forEach((checkbox) => {
        const key = (checkbox.getAttribute("data-pt-platform") || "").trim();
        checkbox.checked = nextSelected.includes(key);
      });
      applyBrandVisibility();
    }).catch(() => {
      rows = [];
      applyBrandVisibility();
    });
  }

  modal.style.display = "flex";
};

const openIdSkuModal = () => {
  let modal = document.getElementById(ID_SKU_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = ID_SKU_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">ID > SKU</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="textarea-group">
          <label for="id-sku-ids">Product ID'ler (Her satıra bir ID, örn. 677257816)</label>
          <textarea id="id-sku-ids" placeholder="677257816&#10;677257817"></textarea>
        </div>
        <div class="modal-controls">
          <button class="collect-btn" id="id-sku-extract">SKU'ları Bul</button>
          <button class="download-btn" id="id-sku-download" disabled>Excel İndir</button>
          <button class="clear-btn" id="id-sku-clear">Temizle</button>
        </div>
        <div class="status" id="id-sku-status"></div>
        <div class="id-sku-table-wrap">
          <table class="id-sku-table">
            <thead>
              <tr>
                <th>URL</th>
                <th>Product ID</th>
                <th>skuID</th>
              </tr>
            </thead>
            <tbody id="id-sku-tbody"></tbody>
          </table>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const extractBtn = modal.querySelector("#id-sku-extract");
    const clearBtn = modal.querySelector("#id-sku-clear");
    const downloadBtn = modal.querySelector("#id-sku-download");
    const idsTextarea = modal.querySelector("#id-sku-ids");
    const tbody = modal.querySelector("#id-sku-tbody");
    const statusDiv = modal.querySelector("#id-sku-status");
    let currentRows = [];

    const showStatus = (message, type = "info") => {
      statusDiv.textContent = message;
      statusDiv.className = `status ${type}`;
      statusDiv.style.display = "block";
    };

    const renderTable = (rows) => {
      tbody.innerHTML = "";
      for (const row of rows) {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td class="id-sku-url">${escapeHtml(row.url)}</td>
          <td>${escapeHtml(row.productId)}</td>
          <td>${escapeHtml(row.skuId)}</td>
        `;
        tbody.appendChild(tr);
      }
    };

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    extractBtn.addEventListener("click", async () => {
      const rawIds = (idsTextarea.value || "").split("\n");
      const ids = rawIds
        .map((line) => parseProductIdLine(line))
        .filter((id) => id.length > 0);

      if (ids.length === 0) {
        showStatus("Lütfen geçerli Product ID'ler girin (örn. 677257816).", "error");
        return;
      }

      extractBtn.disabled = true;
      extractBtn.textContent = "İşleniyor...";
      downloadBtn.disabled = true;
      currentRows = [];
      renderTable(currentRows);
      showStatus(`${ids.length} ID işleniyor: arama → ürün URL → skuID...`, "info");

      for (let i = 0; i < ids.length; i += 1) {
        const productId = ids[i];
        showStatus(`İşleniyor: ${i + 1}/${ids.length} - ${productId}`, "info");

        const searchUrl = `https://www.n11.com/arama?q=${encodeURIComponent(productId)}`;
        let productUrl = null;
        try {
          const searchRes = await fetch(searchUrl, { mode: "cors", credentials: "omit" });
          if (searchRes.ok) {
            const searchHtml = await searchRes.text();
            productUrl = extractProductUrlFromSearchHtml(searchHtml);
          }
        } catch (err) {
          console.error("Search fetch error:", err);
        }

        if (!productUrl) {
          currentRows.push({ url: "URL BULUNAMADI", productId, skuId: "-" });
          renderTable(currentRows);
          await new Promise((r) => setTimeout(r, 400));
          continue;
        }

        const skuId = await fetchSkuFromProductUrl(productUrl);
        currentRows.push({
          url: productUrl,
          productId,
          skuId: skuId != null && skuId !== "" ? skuId : "-"
        });
        renderTable(currentRows);
        await new Promise((r) => setTimeout(r, 500));
      }

      extractBtn.disabled = false;
      extractBtn.textContent = "SKU'ları Bul";
      if (currentRows.length > 0) {
        downloadBtn.disabled = false;
      }
      const successCount = currentRows.filter((r) => r.skuId !== "-").length;
      showStatus(`${successCount}/${ids.length} ürün için skuID bulundu.`, "success");
    });

    downloadBtn.addEventListener("click", () => {
      if (currentRows.length === 0) {
        showStatus("İndirilecek veri yok.", "error");
        return;
      }
      const header = "URL;Product ID;skuID\n";
      const rows = currentRows
        .map((r) => `${escapeCsv(r.url)};${escapeCsv(r.productId)};${escapeCsv(r.skuId)}`)
        .join("\n");
      const content = `\uFEFF${header}${rows}`;
      const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `n11_id_sku_${new Date().toISOString().split("T")[0]}.csv`;
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showStatus("✅ Excel indirildi", "success");
    });

    clearBtn.addEventListener("click", () => {
      idsTextarea.value = "";
      currentRows = [];
      renderTable(currentRows);
      downloadBtn.disabled = true;
      statusDiv.className = "status";
      statusDiv.style.display = "none";
    });
  }

  modal.style.display = "flex";
};

const openPimsIdModal = () => {
  let modal = document.getElementById(PIMS_ID_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PIMS_ID_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Product ID Scanner</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="textarea-group">
          <label for="pims-id-links">Ürün detay linkleri (Her satıra bir link)</label>
          <textarea id="pims-id-links" placeholder="https://www.n11.com/urun/arzum-ar4075-pronto-lux-2si-1-arada-dik-elektrikli-supurge-1043703?magaza=mebteknoloji&#10;https://www.n11.com/urun/..."></textarea>
        </div>
        <div class="modal-controls">
          <button class="collect-btn" id="pims-id-extract">ID'leri Bul</button>
          <button class="download-btn" id="pims-id-download" disabled>Excel İndir</button>
          <button class="clear-btn" id="pims-id-clear">Temizle</button>
        </div>
        <div class="status" id="pims-id-status"></div>
        <div class="pims-id-table-wrap">
          <table class="pims-id-table">
            <thead>
              <tr>
                <th>URL</th>
                <th>Ürün İsmi</th>
                <th>Pims ID</th>
                <th>Product ID</th>
                <th>GTIN</th>
                <th>Sku ID</th>
                <th>Group ID</th>
              </tr>
            </thead>
            <tbody id="pims-id-tbody"></tbody>
          </table>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const extractBtn = modal.querySelector("#pims-id-extract");
    const clearBtn = modal.querySelector("#pims-id-clear");
    const downloadBtn = modal.querySelector("#pims-id-download");
    const linksTextarea = modal.querySelector("#pims-id-links");
    const tbody = modal.querySelector("#pims-id-tbody");
    const statusDiv = modal.querySelector("#pims-id-status");
    let currentRows = [];

    const showStatus = (message, type = "info") => {
      statusDiv.textContent = message;
      statusDiv.className = `status ${type}`;
      statusDiv.style.display = "block";
    };

    const renderTable = (rows) => {
      tbody.innerHTML = "";
      for (const row of rows) {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td class="pims-id-url">${escapeHtml(row.url)}</td>
          <td class="pims-id-product-name">${escapeHtml(row.productName || "")}</td>
          <td>${escapeHtml(row.pimsId)}</td>
          <td>${escapeHtml(row.productId)}</td>
          <td>${escapeHtml(row.gtin)}</td>
          <td>${escapeHtml(row.sku)}</td>
          <td>${escapeHtml(row.groupId)}</td>
        `;
        tbody.appendChild(tr);
      }
    };

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    extractBtn.addEventListener("click", async () => {
      const rawLinks = (linksTextarea.value || "").split("\n");
      const links = rawLinks
        .map((line) => line.trim())
        .filter((line) => line.length > 0 && line.includes("n11.com/urun"));

      if (links.length === 0) {
        showStatus("Lütfen geçerli n11 ürün linkleri girin!", "error");
        return;
      }

      extractBtn.disabled = true;
      extractBtn.textContent = "İşleniyor...";
      downloadBtn.disabled = true;
      currentRows = [];
      renderTable(currentRows);
      showStatus(`${links.length} link işleniyor...`, "info");

      for (let i = 0; i < links.length; i += 1) {
        const link = links[i];
        showStatus(`İşleniyor: ${i + 1}/${links.length} - ${link.substring(0, 50)}...`, "info");
        try {
          const response = await fetch(link, { credentials: "omit" });
          if (!response.ok) {
            currentRows.push({
              url: link,
              productName: "-",
              pimsId: `Hata: ${response.status}`,
              productId: "-",
              gtin: "-",
              sku: "-",
              groupId: "-"
            });
            renderTable(currentRows);
            await new Promise((r) => setTimeout(r, 400));
            continue;
          }
          const html = await response.text();
          const info = extractProductInfoFromN11Html(html);
          currentRows.push({
            url: link,
            productName: info.productName || "-",
            pimsId: info.pimsId || "Bulunamadı",
            productId: info.productId || "Bulunamadı",
            gtin: info.gtin || "Bulunamadı",
            sku: info.skuId || "Bulunamadı",
            groupId: info.groupId || "Bulunamadı"
          });
          renderTable(currentRows);
        } catch (err) {
          console.error("Product ID fetch error:", err);
          currentRows.push({
            url: link,
            productName: "-",
            pimsId: "Hata: " + (err.message || String(err)),
            productId: "-",
            gtin: "-",
            sku: "-",
            groupId: "-"
          });
          renderTable(currentRows);
        }
        await new Promise((r) => setTimeout(r, 500));
      }

      extractBtn.disabled = false;
      extractBtn.textContent = "Product ID'leri Bul";
      if (currentRows.length > 0) {
        downloadBtn.disabled = false;
      }
      const successCount = currentRows.filter((r) => r.pimsId !== "Bulunamadı" && !r.pimsId.startsWith("Hata")).length;
      showStatus(`${successCount}/${links.length} ürün için veriler toplandı.`, "success");
    });

    downloadBtn.addEventListener("click", () => {
      if (currentRows.length === 0) {
        showStatus("İndirilecek veri yok.", "error");
        return;
      }
      if (typeof XLSX === "undefined") {
        showStatus("XLSX kütüphanesi yüklenemedi. Sayfayı yenileyin.", "error");
        return;
      }
      try {
        const header = [
          "URL",
          "Ürün İsmi",
          "Pims ID",
          "Product ID",
          "GTIN",
          "Sku",
          "Group ID"
        ];
        const body = currentRows.map((r) => [
          r.url || "",
          r.productName || "",
          r.pimsId || "",
          r.productId || "",
          r.gtin || "",
          r.sku || "",
          r.groupId || ""
        ]);
        const ws = XLSX.utils.aoa_to_sheet([header, ...body]);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Pims ID Scanner");
        XLSX.writeFile(
          wb,
          `n11_pims_id_${new Date().toISOString().split("T")[0]}.xlsx`,
          { bookType: "xlsx", compression: true }
        );
        showStatus("✅ XLSX indirildi", "success");
      } catch (err) {
        showStatus(`XLSX indirilemedi: ${err?.message || "Bilinmeyen hata"}`, "error");
      }
    });

    clearBtn.addEventListener("click", () => {
      linksTextarea.value = "";
      currentRows = [];
      renderTable(currentRows);
      downloadBtn.disabled = true;
      statusDiv.className = "status";
      statusDiv.style.display = "none";
    });
  }

  modal.style.display = "flex";
};

/**
 * Ürün objesinde "Sepette kampanyası" (sepette indirim / kampanya rozeti) var mı?
 * promotion.json örnekleri:
 * 1. mobilePriceBadge dolu ("SEPETTE") → kampanya var
 * 2. mobilePriceBadge null ama badge / topLeftBadges dolu (N11_CAMPAIGN_2 vb.) → kampanya var
 * 3. mobilePriceBadge null, badge/topLeftBadges null → kampanya yok
 */
const hasSepetteCampaign = (item) => {
  if (!item || typeof item !== "object") return false;
  const dto = item.finalPriceAreaDTO;
  if (dto != null) {
    if (dto.mobilePriceBadge != null && String(dto.mobilePriceBadge).trim() !== "") return true;
    if (dto.mobileWebPriceBadge != null && String(dto.mobileWebPriceBadge).trim() !== "") return true;
    if (dto.mallDiscountPriceBadge != null && String(dto.mallDiscountPriceBadge).trim() !== "") return true;
  }
  if (item.hasInstantDiscount === true) return true;
  if (item.badge != null && typeof item.badge === "object") {
    if (item.badge.productBadgeType != null || (item.badge.description != null && String(item.badge.description).trim() !== "")) return true;
  }
  if (Array.isArray(item.topLeftBadges) && item.topLeftBadges.length > 0) return true;
  return false;
};

const openAkakceProductCrawlerModal = () => {
  const doOpen = () => {
    let modal = document.getElementById(AKAKCE_PRODUCT_CRAWLER_MODAL_ID);
    if (!modal) {
      modal = document.createElement("div");
      modal.id = AKAKCE_PRODUCT_CRAWLER_MODAL_ID;
      modal.innerHTML = `
        <div class="modal-card">
          <div class="modal-header">
            <div class="modal-title">Akakce & LLM Product Crawler</div>
            <button class="modal-close" aria-label="Kapat">✕</button>
          </div>
          <div class="akakce-crawler-form">
            <label for="akakce-crawler-urls"><b>n11 ürün linkleri</b> veya <b>Akakçe ID</b> (her satıra bir link veya ID)</label>
            <textarea id="akakce-crawler-urls" class="akakce-crawler-textarea" rows="6" placeholder="https://www.n11.com/urun/... veya 1194731361"></textarea>
            <p class="akakce-cloudflare-note"><b>Not:</b> Akakce Cloudflare kullanıyor. <b>Performing security verification</b> görürseniz doğrulamayı tamamlayın, sayfa otomatik devam edecek.</p>
            <p class="akakce-deep-analysis-note"><b>Not:</b> Deep Analysis bazen doğru ürün linkini <u>bulamayabilir</u>. Ürün kapanmış, URL değiştirilmiş olabilir. <b>Gemini search grounding</b> indexlediği son veriye göre sonuç döner.</p>
            <div class="akakce-crawler-buttons">
              <button type="button" class="akakce-run-btn" id="akakce-crawler-run-btn">Akakce'de Ara</button>
              <button type="button" class="download-btn" id="akakce-crawler-download-btn" disabled>Excel İndir</button>
            </div>
          </div>
          <div class="status" id="akakce-crawler-status"></div>
          <div id="akakce-crawler-result" class="akakce-crawler-result-wrap"></div>
        </div>
      `;
      modal.addEventListener("click", (event) => {
        if (event.target === modal) {
          modal.style.display = "none";
        }
      });
      document.body.appendChild(modal);
      modal.querySelector(".modal-close").addEventListener("click", () => {
        modal.style.display = "none";
      });
      if (typeof window.registerAkakceCrawlerButton === "function") {
        window.registerAkakceCrawlerButton(modal);
      }
    }
    modal.style.display = "flex";
    if (typeof window.fillAkakceCurrentProduct === "function") {
      window.fillAkakceCurrentProduct();
    }
  };
  setTimeout(doOpen, 0);
};

const openOfferControllerModal = () => {
  let modal = document.getElementById(OFFER_CONTROLLER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = OFFER_CONTROLLER_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Offer Controller</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="offer-controller-form">
          <label for="offer-controller-type">Kontrol tipi</label>
          <select id="offer-controller-type">
            <option value="sepette-indirim">Sepette İndirim</option>
          </select>
          <button type="button" class="collect-btn" id="offer-controller-check">Kontrol Et</button>
          <button type="button" class="download-btn" id="offer-controller-download" disabled>Excel İndir</button>
        </div>
        <div class="status" id="offer-controller-status"></div>
        <div class="offer-controller-result-wrap" id="offer-controller-result"></div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);
    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    const statusEl = document.getElementById("offer-controller-status");
    const resultWrap = document.getElementById("offer-controller-result");
    const checkBtn = document.getElementById("offer-controller-check");
    const downloadBtn = document.getElementById("offer-controller-download");
    let offerControllerLastResult = [];
    const offerControllerHighlightClass = "offer-controller-highlight";
    const clearOfferControllerHighlights = () => {
      document.querySelectorAll(`.searchResults a.product-item.${offerControllerHighlightClass}`).forEach((el) => {
        el.classList.remove(offerControllerHighlightClass);
      });
    };
    const showStatus = (msg, type) => {
      statusEl.textContent = msg;
      statusEl.className = "status " + (type === "error" ? "error" : type === "success" ? "success" : "info");
    };

    checkBtn.addEventListener("click", async () => {
      const type = document.getElementById("offer-controller-type").value;
      if (type !== "sepette-indirim") return;
      const url = new URL(window.location.href);
      if (url.pathname !== "/arama" || !url.searchParams.get("promotions")) {
        showStatus("Bu sayfa promotion sayfası değil. Önce bir kampanya sayfasına gidin (örn. ?promotions=2062422).", "error");
        return;
      }
      const base = "https://www.n11.com";
      const includeInList = (item) => !hasSepetteCampaign(item);
      checkBtn.disabled = true;
      downloadBtn.disabled = true;
      offerControllerLastResult = [];
      clearOfferControllerHighlights();
      resultWrap.innerHTML = "";
      showStatus("Sayfalar taranıyor...", "info");
      try {
        let pg = 1;
        let listComplete = false;
        const allItems = [];
        while (!listComplete) {
          const fetchUrl = new URL(window.location.href);
          fetchUrl.searchParams.set("pg", pg);
          fetchUrl.searchParams.set("vueSearch", "1");
          const finalUrl = fetchUrl.toString();
          showStatus(`Sayfa ${pg} isteniyor...`, "info");
          const response = await fetch(finalUrl, { credentials: "omit" });
          if (!response.ok) {
            showStatus(`Hata: ${response.status} ${response.statusText}`, "error");
            break;
          }
          const json = await response.json();
          const items = json?.data?.productListingItems;
          if (Array.isArray(items) && items.length > 0) {
            allItems.push(...items);
          }
          if (json?.data?.suggestedKeywordsResult != null || !Array.isArray(items) || items.length === 0) {
            listComplete = true;
          } else if (items.length < 20) {
            listComplete = true;
          } else {
            pg += 1;
            await new Promise((r) => setTimeout(r, 300));
          }
        }
        const withoutCampaign = allItems.filter((item) => item != null && includeInList(item));
        const labelNone = "Sepette kampanyası olmayan";
        const labelOk = "Tüm ürünlerde sepette kampanyası var.";
        if (withoutCampaign.length === 0) {
          showStatus(`Toplam ${allItems.length} ürün tarandı. Hata yok.`, "success");
          resultWrap.innerHTML = `<p class="offer-controller-ok">${labelOk}</p>`;
        } else {
          offerControllerLastResult = withoutCampaign.map((item) => {
            const path = item.urlWithoutSellerShop || item.url || "";
            const href = path.startsWith("http") ? path : `${base}${path}`;
            return {
              id: item.id != null ? String(item.id) : "",
              title: item.title || item.subtitle || "",
              url: href
            };
          });
          downloadBtn.disabled = false;
          showStatus(
            `Toplam ${allItems.length} ürün. ${labelNone}: ${withoutCampaign.length} ürün.`,
            "error"
          );
          const table = document.createElement("table");
          table.className = "listing-crawler-table";
          table.innerHTML = `
            <thead>
              <tr>
                <th>Ürün ID</th>
                <th>Başlık</th>
                <th>URL</th>
              </tr>
            </thead>
            <tbody></tbody>
          `;
          const tbody = table.querySelector("tbody");
          for (const item of withoutCampaign) {
            const path = item.urlWithoutSellerShop || item.url || "";
            const href = path.startsWith("http") ? path : `${base}${path}`;
            const tr = document.createElement("tr");
            tr.innerHTML = `
              <td>${escapeHtml(item.id != null ? String(item.id) : "-")}</td>
              <td>${escapeHtml(item.title || item.subtitle || "-")}</td>
              <td><a href="${escapeHtml(href)}" target="_blank" rel="noopener">${escapeHtml(href)}</a></td>
            `;
            tbody.appendChild(tr);
          }
          resultWrap.innerHTML = "";
          resultWrap.appendChild(table);
          for (const item of withoutCampaign) {
            const id = item.id != null ? String(item.id) : "";
            if (!id) continue;
            const el = document.querySelector(`.searchResults a.product-item[data-prod-id="${id}"]`);
            if (el) {
              el.classList.add(offerControllerHighlightClass);
            }
          }
        }
      } catch (err) {
        console.error("Offer controller check error:", err);
        showStatus("Veri alınamadı: " + (err.message || String(err)), "error");
      }
      checkBtn.disabled = false;
    });

    downloadBtn.addEventListener("click", () => {
      if (offerControllerLastResult.length === 0) return;
      const header = "Ürün ID;Başlık;URL\n";
      const rows = offerControllerLastResult
        .map((r) => `${escapeCsv(r.id)};${escapeCsv(r.title)};${escapeCsv(r.url)}`)
        .join("\n");
      const content = `\uFEFF${header}${rows}`;
      const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `n11_offer_controller_kampanya_yok_${new Date().toISOString().split("T")[0]}.csv`;
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showStatus("Excel indirildi.", "success");
    });
  }
  modal.style.display = "flex";
};

const LISTING_CRAWLER_RCAT_KEYS = ["rCat1", "rCat2", "rCat3", "rCat4", "rCat5", "rCatMain"];

const getReportingCategoryFromItem = (item) => {
  if (!item || typeof item !== "object") return null;
  const rc = item.reportingCategory || item.reportingCategoryDto || item.categoryReporting || {};
  const obj = {};
  for (const key of LISTING_CRAWLER_RCAT_KEYS) {
    const val = (rc[key] != null ? rc[key] : item[key]);
    obj[key] = val != null ? String(val).trim() : "";
  }
  return obj;
};

const getReportingCategoryFromHtml = (html) => {
  if (!html || typeof html !== "string") return null;
  try {
    const obj = {};
    for (const key of LISTING_CRAWLER_RCAT_KEYS) {
      const re = new RegExp('"' + key + '"\\s*:\\s*"([^"]*)"', "i");
      const m = html.match(re);
      obj[key] = m && m[1] != null ? String(m[1]).trim() : "";
    }
    return obj;
  } catch (e) {
    return null;
  }
};

const openListingProductCrawlerModal = () => {
  let modal = document.getElementById(LISTING_PRODUCT_CRAWLER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = LISTING_PRODUCT_CRAWLER_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card listing-crawler-modal-card">
        <div class="modal-header">
          <div class="modal-title">Listing Product Crawler</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="listing-crawler-max-pages-box">
          <div class="textarea-group">
            <label for="listing-crawler-max-pages">Maksimum sayfa sayısı (ör: 10 = pg=1 ile 10 arası; boş = tümü)</label>
            <input type="number" id="listing-crawler-max-pages" class="listing-crawler-max-pages-input" min="1" placeholder="Boş bırakırsanız tüm sayfalar toplanır">
          </div>
        </div>
        <div class="listing-crawler-include-category-box">
          <label class="listing-crawler-include-category-label">
            <input type="checkbox" id="listing-crawler-include-category" class="listing-crawler-include-category-checkbox">
            Ürünler için kategori bilgisi eklensin mi?
          </label>
        </div>
        <div class="listing-crawler-include-category-box">
          <label class="listing-crawler-include-category-label">
            <input type="checkbox" id="listing-crawler-include-pims" class="listing-crawler-include-category-checkbox">
            Pims ID toplansın
          </label>
        </div>
        <div class="modal-controls">
          <button class="collect-btn" id="listing-crawler-collect">Ürün listesini topla</button>
          <button class="download-btn" id="listing-crawler-download" disabled>Excel İndir</button>
        </div>
        <div class="status" id="listing-crawler-status"></div>
        <div class="listing-crawler-table-wrap">
          <table class="listing-crawler-table">
            <thead>
              <tr>
                <th>URL</th>
                <th>Ürün ID</th>
                <th>Sku ID</th>
                <th>Fiyat</th>
              </tr>
            </thead>
            <tbody id="listing-crawler-tbody"></tbody>
          </table>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    const collectBtn = modal.querySelector("#listing-crawler-collect");
    const downloadBtn = modal.querySelector("#listing-crawler-download");
    const maxPagesInput = modal.querySelector("#listing-crawler-max-pages");
    const categoryCheckbox = modal.querySelector("#listing-crawler-include-category");
    const pimsCheckbox = modal.querySelector("#listing-crawler-include-pims");
    const statusDiv = modal.querySelector("#listing-crawler-status");
    const theadTr = modal.querySelector(".listing-crawler-table thead tr");
    const tbody = modal.querySelector("#listing-crawler-tbody");
    let currentRows = [];
    let currentIncludeCategories = false;
    let currentIncludePims = false;

    const buildListingCrawlerTheadHtml = (includePims, includeCat) => {
      let h = "<th>URL</th><th>Ürün ID</th>";
      if (includePims) h += "<th>Pims ID</th>";
      h += "<th>Sku ID</th><th>Fiyat</th>";
      if (includeCat) {
        h +=
          "<th>rCat1</th><th>rCat2</th><th>rCat3</th><th>rCat4</th><th>rCat5</th><th>rCatMain</th>";
      }
      return h;
    };

    const showStatus = (message, type = "info") => {
      statusDiv.textContent = message;
      statusDiv.className = `status ${type}`;
      statusDiv.style.display = "block";
    };

    const renderTable = (rows, includeCategories, includePims) => {
      const showCat = includeCategories !== false;
      const showPims = includePims === true;
      tbody.innerHTML = "";
      for (const row of rows) {
        const tr = document.createElement("tr");
        const pimsCell =
          row.pimsId != null && String(row.pimsId).trim() !== ""
            ? escapeHtml(String(row.pimsId).trim())
            : "-";
        let cells = `
          <td class="listing-crawler-url"><a href="${escapeHtml(row.url)}" target="_blank" rel="noopener">${escapeHtml(row.url)}</a></td>
          <td>${escapeHtml(row.productId)}</td>
        `;
        if (showPims) {
          cells += `<td>${pimsCell}</td>`;
        }
        cells += `
          <td>${escapeHtml(row.skuId)}</td>
          <td>${escapeHtml(row.fiyat)}</td>
        `;
        if (showCat) {
          const rCat1 = row.rCat1 != null ? String(row.rCat1) : "";
          const rCat2 = row.rCat2 != null ? String(row.rCat2) : "";
          const rCat3 = row.rCat3 != null ? String(row.rCat3) : "";
          const rCat4 = row.rCat4 != null ? String(row.rCat4) : "";
          const rCat5 = row.rCat5 != null ? String(row.rCat5) : "";
          const rCatMain = row.rCatMain != null ? String(row.rCatMain) : "";
          cells += `
          <td>${escapeHtml(rCat1)}</td>
          <td>${escapeHtml(rCat2)}</td>
          <td>${escapeHtml(rCat3)}</td>
          <td>${escapeHtml(rCat4)}</td>
          <td>${escapeHtml(rCat5)}</td>
          <td>${escapeHtml(rCatMain)}</td>
        `;
        }
        tr.innerHTML = cells;
        tbody.appendChild(tr);
      }
    };

    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });

    collectBtn.addEventListener("click", async () => {
      currentIncludeCategories = categoryCheckbox.checked;
      currentIncludePims = !!(pimsCheckbox && pimsCheckbox.checked);
      theadTr.innerHTML = buildListingCrawlerTheadHtml(currentIncludePims, currentIncludeCategories);
      const rawVal = (maxPagesInput?.value || "").trim();
      const maxPages = rawVal === "" ? null : parseInt(rawVal, 10);
      const hasPageLimit = maxPages != null && !isNaN(maxPages) && maxPages >= 1;
      const rawUrl = window.location.href;
      const u = new URL(rawUrl);
      u.searchParams.delete("pg");
      u.searchParams.delete("page");
      const baseUrl = u.toString();
      const separator = baseUrl.includes("?") ? "&" : "?";
      const base = "https://www.n11.com";
      collectBtn.disabled = true;
      collectBtn.textContent = "Toplanıyor...";
      downloadBtn.disabled = true;
      currentRows = [];
      renderTable(currentRows, currentIncludeCategories, currentIncludePims);
      showStatus("Sayfa 1 isteniyor...", "info");
      try {
        let allRows = [];
        let pg = 1;
        let listComplete = false;
        let totalPagesFromApi = null;
        let repeatedNoNewPageCount = 0;
        const seenKeys = new Set();
        while (!listComplete) {
          const fetchUrl = `${baseUrl}${separator}pg=${pg}&vueSearch=1`;
          showStatus(`Sayfa ${pg} isteniyor...`, "info");
          const response = await fetch(fetchUrl, { credentials: "omit" });
          if (!response.ok) {
            showStatus(`Hata: ${response.status} ${response.statusText}`, "error");
            break;
          }
          const json = await response.json();
          if (totalPagesFromApi == null) {
            const candidatePages = [
              json?.data?.pagination?.totalPage,
              json?.data?.pagination?.totalPages,
              json?.data?.paging?.totalPage,
              json?.data?.paging?.totalPages,
              json?.data?.totalPage,
              json?.data?.totalPages,
              json?.data?.pageCount,
              json?.data?.searchResult?.pagination?.totalPage,
              json?.data?.searchResult?.pagination?.totalPages
            ];
            for (const cand of candidatePages) {
              const n = Number(cand);
              if (Number.isFinite(n) && n >= 1) {
                totalPagesFromApi = n;
                break;
              }
            }
          }
          let items = json?.data?.productListingItems;
          if (!Array.isArray(items) && isMagazaPage()) {
            items = json?.data?.storeProductListingItems ?? json?.data?.products ?? json?.data?.sellerProducts ?? null;
          }
          if (Array.isArray(items) && items.length > 0) {
            const pageRows = [];
            for (const item of items) {
              const path = item.urlWithoutSellerShop || item.url || "";
              const url = path.startsWith("http") ? path : `${base}${path}`;
              const productId = item.id != null ? String(item.id) : "";
              let pimsId = "";
              if (currentIncludePims) {
                const pimsRaw =
                  item.defaultPimsId ??
                  item.pimsId ??
                  item.pimsID ??
                  item.pims_id ??
                  (item.product && (item.product.defaultPimsId ?? item.product.pimsId));
                pimsId =
                  pimsRaw != null && String(pimsRaw).trim() !== "" ? String(pimsRaw).trim() : "";
              }
              const skuId = item.skuId != null ? String(item.skuId) : "-";
              const fiyat = item.priceStr != null ? String(item.priceStr) : "";
              const uniqueKey = productId || `${url}__${skuId}`;
              if (seenKeys.has(uniqueKey)) {
                continue;
              }
              seenKeys.add(uniqueKey);
              const row = { url, productId, pimsId, skuId, fiyat };
              if (currentIncludeCategories) {
                const rCat = getReportingCategoryFromItem(item) || {};
                row.rCat1 = rCat.rCat1 || "";
                row.rCat2 = rCat.rCat2 || "";
                row.rCat3 = rCat.rCat3 || "";
                row.rCat4 = rCat.rCat4 || "";
                row.rCat5 = rCat.rCat5 || "";
                row.rCatMain = rCat.rCatMain || "";
              }
              pageRows.push(row);
            }
            if (pageRows.length > 0) {
              repeatedNoNewPageCount = 0;
              allRows = allRows.concat(pageRows);
              currentRows = allRows;
              renderTable(currentRows, currentIncludeCategories, currentIncludePims);
            } else {
              repeatedNoNewPageCount += 1;
            }
          }
          if (json?.data?.suggestedKeywordsResult != null) {
            listComplete = true;
            break;
          }
          if (!Array.isArray(items) || items.length === 0) {
            break;
          }
          if (totalPagesFromApi != null && pg >= totalPagesFromApi) {
            listComplete = true;
            break;
          }
          if (repeatedNoNewPageCount >= 1) {
            listComplete = true;
            break;
          }
          if (hasPageLimit && pg >= maxPages) {
            listComplete = true;
            break;
          }
          pg += 1;
          await new Promise((r) => setTimeout(r, 300));
        }
        currentRows = allRows;
        renderTable(currentRows, currentIncludeCategories, currentIncludePims);
        if (currentRows.length > 0) {
          const rowNeedsProductPageFetch = (row) => {
            const needPims =
              currentIncludePims && (!row.pimsId || String(row.pimsId).trim() === "");
            const needCat =
              currentIncludeCategories && !row.rCatMain && !row.rCat1;
            return needPims || needCat;
          };
          const needsFetch = currentRows.filter(rowNeedsProductPageFetch);
          if (needsFetch.length > 0) {
            const detailParts = [];
            if (currentIncludePims) detailParts.push("Pims ID");
            if (currentIncludeCategories) detailParts.push("kategori");
            const detailLabel = detailParts.length ? detailParts.join(" / ") : "detay";
            showStatus(
              `${needsFetch.length} ürün için ürün sayfasından ${detailLabel} alınıyor...`,
              "info"
            );
            let fetched = 0;
            for (let i = 0; i < currentRows.length; i += 1) {
              const row = currentRows[i];
              if (!rowNeedsProductPageFetch(row)) continue;
              fetched += 1;
              if (fetched % 5 === 0) {
                showStatus(`Ürün detayı alınıyor (${fetched}/${needsFetch.length})...`, "info");
                renderTable(currentRows, currentIncludeCategories, currentIncludePims);
              }
              try {
                const res = await fetch(row.url, { credentials: "omit" });
                if (res.ok) {
                  const html = await res.text();
                  if (
                    currentIncludePims &&
                    (!row.pimsId || String(row.pimsId).trim() === "")
                  ) {
                    const info = extractProductInfoFromN11Html(html);
                    if (info.pimsId) row.pimsId = String(info.pimsId).trim();
                  }
                  if (currentIncludeCategories && !row.rCatMain && !row.rCat1) {
                    const rCat = getReportingCategoryFromHtml(html);
                    if (rCat) {
                      row.rCat1 = rCat.rCat1 || "";
                      row.rCat2 = rCat.rCat2 || "";
                      row.rCat3 = rCat.rCat3 || "";
                      row.rCat4 = rCat.rCat4 || "";
                      row.rCat5 = rCat.rCat5 || "";
                      row.rCatMain = rCat.rCatMain || "";
                    }
                  }
                }
              } catch (_) {}
              await new Promise((r) => setTimeout(r, 180));
            }
          }
          renderTable(currentRows, currentIncludeCategories, currentIncludePims);
          if (currentIncludeCategories && currentIncludePims) {
            showStatus(
              needsFetch.length === 0
                ? `${currentRows.length} ürün toplandı (${pg} sayfa). Pims ID ve kategori liste yanıtından alındı.`
                : `${currentRows.length} ürün toplandı (${pg} sayfa); eksik Pims ID ve/veya kategori ürün sayfasından tamamlandı.`,
              "success"
            );
          } else if (currentIncludeCategories) {
            showStatus(
              needsFetch.length === 0
                ? `${currentRows.length} ürün toplandı (${pg} sayfa). Kategori bilgileri liste yanıtından alındı.`
                : `${currentRows.length} ürün toplandı (${pg} sayfa); eksik kategori ürün sayfasından tamamlandı.`,
              "success"
            );
          } else if (currentIncludePims) {
            showStatus(
              needsFetch.length === 0
                ? `${currentRows.length} ürün toplandı (${pg} sayfa). Pims ID liste yanıtından alındı.`
                : `${currentRows.length} ürün toplandı (${pg} sayfa); eksik Pims ID ürün sayfasından tamamlandı.`,
              "success"
            );
          } else {
            showStatus(`${currentRows.length} ürün toplandı (${pg} sayfa).`, "success");
          }
          downloadBtn.disabled = false;
        } else if (!listComplete) {
          showStatus("Ürün bulunamadı.", "error");
        }
      } catch (err) {
        console.error("Listing crawler error:", err);
        showStatus("Veri alınamadı: " + (err.message || String(err)), "error");
      }
      collectBtn.disabled = false;
      collectBtn.textContent = "Ürün listesini topla";
    });

    downloadBtn.addEventListener("click", () => {
      if (currentRows.length === 0) {
        showStatus("İndirilecek veri yok.", "error");
        return;
      }
      if (typeof XLSX === "undefined") {
        showStatus("XLSX kütüphanesi yüklenemedi. Sayfayı yenileyin.", "error");
        return;
      }
      try {
        const header = ["URL", "Ürün ID"];
        if (currentIncludePims) header.push("Pims ID");
        header.push("Sku ID", "Fiyat");
        if (currentIncludeCategories) {
          header.push("rCat1", "rCat2", "rCat3", "rCat4", "rCat5", "rCatMain");
        }
        const body = currentRows.map((r) => {
          const base = [r.url != null ? String(r.url) : "", r.productId != null ? String(r.productId) : ""];
          if (currentIncludePims) base.push(r.pimsId != null ? String(r.pimsId) : "");
          base.push(r.skuId != null ? String(r.skuId) : "", r.fiyat != null ? String(r.fiyat) : "");
          if (currentIncludeCategories) {
            base.push(
              r.rCat1 != null ? String(r.rCat1) : "",
              r.rCat2 != null ? String(r.rCat2) : "",
              r.rCat3 != null ? String(r.rCat3) : "",
              r.rCat4 != null ? String(r.rCat4) : "",
              r.rCat5 != null ? String(r.rCat5) : "",
              r.rCatMain != null ? String(r.rCatMain) : ""
            );
          }
          return base;
        });
        const ws = XLSX.utils.aoa_to_sheet([header, ...body]);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Listing Crawler");
        XLSX.writeFile(
          wb,
          `n11_listing_urunler_${new Date().toISOString().split("T")[0]}.xlsx`,
          { bookType: "xlsx", compression: true }
        );
        showStatus("✅ XLSX indirildi", "success");
      } catch (err) {
        showStatus(`XLSX indirilemedi: ${err?.message || "Bilinmeyen hata"}`, "error");
      }
    });
  }
  modal.style.display = "flex";
};

const escapeHtml = (str) => {
  if (str == null) return "";
  const s = String(str);
  const div = document.createElement("div");
  div.textContent = s;
  return div.innerHTML;
};

const hasSepetteDiscount = (text) => {
  if (!text) {
    return false;
  }
  const normalized = text.replace(/\s+/g, " ").trim();
  const sepetteIndex = normalized.toLowerCase().indexOf("sepette");
  if (sepetteIndex === -1) {
    return false;
  }
  const afterSepette = normalized.slice(sepetteIndex + "sepette".length);
  return /%\s*\d+/.test(afterSepette);
};

const hasMissingSpaceBeforeTl = (text) => {
  if (!text) {
    return false;
  }
  const normalized = text.replace(/\s+/g, " ").trim();
  return /\d(?:[.,]\d{3})*TL\b/.test(normalized);
};

const isTextTooLong = (text, hasDescriptionText) => {
  if (!text) {
    return false;
  }
  const normalized = text.replace(/\s+/g, " ").trim();
  const limit = hasDescriptionText ? 40 : 50;
  return normalized.length > limit;
};

const hasUnformattedPrice = (text) => {
  if (!text) {
    return false;
  }
  const normalized = text.replace(/\s+/g, " ").trim();
  return /\b\d{4,}\s*TL\b/i.test(normalized);
};

const hasForbiddenKeywords = (text) => {
  if (!text) {
    return false;
  }
  const normalized = text.replace(/\s+/g, " ").trim().toLowerCase();
  if (normalized.includes(" net ")) {
    return true;
  }
  if (normalized.includes("keşfedin") || normalized.includes("kesfedin")) {
    return true;
  }
  return false;
};

const normalizePriceFormatting = (text) => {
  if (!text) {
    return text;
  }
  const formatThousands = (digits) =>
    digits.replace(/\B(?=(\d{3})+(?!\d))/g, ".");

  let result = text;
  result = result.replace(
    /(\d{1,3}(?:\.\d{3})+)(\s*)t[lL]\b/g,
    (_, digits) => `${digits} TL`
  );
  result = result.replace(
    /(\d{4,})(\s*)t[lL]\b/g,
    (_, digits) => `${formatThousands(digits)} TL`
  );
  return result;
};

const normalizeSepetteFormatting = (text) => {
  if (!text) {
    return text;
  }
  return text.replace(/sepette\s*(%+\s*\d+)/gi, (_, pct) => {
    const cleaned = pct.replace(/\s+/g, "");
    return `${cleaned} Sepette`;
  });
};

const normalizeEditorialText = (text) => {
  const withPrice = normalizePriceFormatting(text);
  return normalizeSepetteFormatting(withPrice);
};

const getEditorialErrors = (text, hasDescriptionText) => {
  if (!text || !text.trim()) {
    return [];
  }
  const errors = [];
  if (hasSepetteDiscount(text)) {
    errors.push("“%xx Sepette İndirim” formatı kullanılmalı.");
  }
  if (hasMissingSpaceBeforeTl(text)) {
    errors.push("TL öncesinde boşluk olmalı (örn. 750 TL).");
  }
  if (isTextTooLong(text, hasDescriptionText)) {
    errors.push(
      `Metin ${hasDescriptionText ? 40 : 50} karakteri geçmemeli.`
    );
  }
  if (hasUnformattedPrice(text)) {
    errors.push("Fiyat 1.000 formatında olmalı.");
  }
  if (hasForbiddenKeywords(text)) {
    errors.push("“Net” veya “Keşfedin” kullanılmamalı.");
  }
  return errors;
};

const initBoEditorialController = () => {
  if (document.body?.dataset?.boEditorialControllerInit === "true") {
    return;
  }

  let tries = 0;
  const maxTries = 40;
  const interval = window.setInterval(() => {
    const titleInput = document.querySelector("input#contentBannerTitle");
    const descriptionInput = document.querySelector(
      "input#contentBannerDescription"
    );

    if (!titleInput && !descriptionInput) {
      tries += 1;
      if (tries >= maxTries) {
        window.clearInterval(interval);
      }
      return;
    }

    if (document.body) {
      document.body.dataset.boEditorialControllerInit = "true";
    }
    window.clearInterval(interval);

    const getHasDescriptionText = () =>
      Boolean(descriptionInput && descriptionInput.value.trim());

    const ensureErrorEl = (input) => {
      if (!input || !input.parentElement) {
        return null;
      }
      let errorEl = input.parentElement.querySelector(
        ".editorial-error-message"
      );
      if (!errorEl) {
        errorEl = document.createElement("div");
        errorEl.className = "editorial-error-message";
        errorEl.style.color = "#FF3939";
        errorEl.style.fontSize = "12px";
        errorEl.style.marginTop = "6px";
        input.insertAdjacentElement("afterend", errorEl);
      }
      return errorEl;
    };

    const bindValidation = (input, isDescription) => {
      if (!input) {
        return;
      }
      const errorEl = ensureErrorEl(input);
    const run = (shouldFormat = false) => {
      if (shouldFormat) {
        const formatted = normalizeEditorialText(input.value || "");
        if (formatted !== input.value) {
          input.value = formatted;
        }
      }
        const hasDescriptionText = isDescription
          ? true
          : getHasDescriptionText();
        const errors = getEditorialErrors(input.value || "", hasDescriptionText);
        if (!errorEl) {
          return;
        }
        if (errors.length === 0) {
          errorEl.textContent = "";
          errorEl.style.display = "none";
          return;
        }
        errorEl.textContent = errors.join(" ");
        errorEl.style.display = "block";
      };
    input.addEventListener("input", () => run(false));
    input.addEventListener("keyup", () => run(false));
    input.addEventListener("change", () => run(true));
    input.addEventListener("blur", () => run(true));
      run();
      input.dataset.editorialBound = "true";
    };

    bindValidation(titleInput, false);
    bindValidation(descriptionInput, true);

    const delegatedRun = (target, shouldFormat = false) => {
      if (!target || !(target instanceof HTMLInputElement)) {
        return;
      }
      if (
        target.id !== "contentBannerTitle" &&
        target.id !== "contentBannerDescription"
      ) {
        return;
      }
      const errorEl = ensureErrorEl(target);
      if (!errorEl) {
        return;
      }
      if (shouldFormat) {
        const formatted = normalizeEditorialText(target.value || "");
        if (formatted !== target.value) {
          target.value = formatted;
        }
      }
      const hasDescriptionText =
        target.id === "contentBannerDescription"
          ? true
          : getHasDescriptionText();
      const errors = getEditorialErrors(
        target.value || "",
        hasDescriptionText
      );
      if (errors.length === 0) {
        errorEl.textContent = "";
        errorEl.style.display = "none";
        return;
      }
      errorEl.textContent = errors.join(" ");
      errorEl.style.display = "block";
    };

    document.addEventListener(
      "input",
      (event) => delegatedRun(event.target, false),
      true
    );
    document.addEventListener(
      "keyup",
      (event) => delegatedRun(event.target, false),
      true
    );
    document.addEventListener(
      "change",
      (event) => delegatedRun(event.target, true),
      true
    );
    document.addEventListener(
      "blur",
      (event) => delegatedRun(event.target, true),
      true
    );
  }, 500);
};

const openEditorialControllerModal = () => {
  let modal = document.getElementById(EDITORIAL_CONTROLLER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = EDITORIAL_CONTROLLER_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Editorial Controller</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="status" id="editorial-controller-status">Analiz başlıyor..</div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }

  modal.style.display = "flex";
  const status = modal.querySelector("#editorial-controller-status");
  if (status) {
    status.textContent = "Sayfa analiz ediliyor..";
    status.className = "status info";
    status.style.display = "block";
  }

  let matchCount = 0;

  const scanAndHighlight = () => {
    const nodes = document.querySelectorAll(
      ".home-page-three-banner .bottom-information > span, .home-page-three-banner .bottom-information .banner-title"
    );
    nodes.forEach((node) => {
      const text = node.textContent || "";
      const bannerRoot = node.closest(".home-page-three-banner");
      const hasDescriptionText = Boolean(
        bannerRoot &&
          bannerRoot.querySelector(".banner-description") &&
          bannerRoot.querySelector(".banner-description").textContent.trim()
      );
      const errors = getEditorialErrors(text, hasDescriptionText);
      if (errors.length === 0) {
        return;
      }
      const container = node.closest(".bottom-information");
      if (!container || container.dataset.editorialHighlight === "true") {
        return;
      }
      container.dataset.editorialHighlight = "true";
      container.style.backgroundColor = "#FF3939";
      matchCount += 1;
    });
  };

  const scrollStep = () => {
    scanAndHighlight();
    if (status) {
      status.textContent = `Sayfa analiz ediliyor.. (${matchCount} eşleşme)`;
      status.className = "status info";
    }
    const banners = document.querySelectorAll(".THREE_ROW_SQUARE_BANNER_WEB");
    const lastBanner = banners.length > 0 ? banners[banners.length - 1] : null;
    const reachedEnd = lastBanner
      ? lastBanner.getBoundingClientRect().bottom <= window.innerHeight + 2
      : document.documentElement.scrollTop + window.innerHeight >=
        document.documentElement.scrollHeight - 2;
    if (reachedEnd) {
      scanAndHighlight();
      if (status) {
        if (matchCount === 0) {
          status.textContent =
            "Harika! Hatalı Offer metni bulunmadı. Teşekkürler.";
          status.className = "status success";
        } else {
          status.textContent =
            "Hatalı Offer metinleri var, Kırmızı ile işaretledim. kontrol ediniz.";
          status.className = "status error";
        }
        status.style.transition = "opacity 0.8s ease";
        status.style.opacity = "1";
        window.setTimeout(() => {
          status.style.opacity = "0";
        }, 2000);
      }
      window.setTimeout(() => {
        modal.style.display = "none";
        const firstHighlight = document.querySelector(
          ".home-page-three-banner .bottom-information[data-editorial-highlight=\"true\"]"
        );
        if (firstHighlight) {
          const top =
            firstHighlight.getBoundingClientRect().top +
            window.pageYOffset -
            100;
          window.scrollTo({ top: Math.max(top, 0), behavior: "smooth" });
        }
      }, 3000);
      return;
    }
    window.scrollBy({ top: window.innerHeight, left: 0, behavior: "smooth" });
    window.setTimeout(scrollStep, 1500);
  };

  window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  window.setTimeout(scrollStep, 800);
};

const openPageCheckerModal = () => {
  let modal = document.getElementById(PAGE_CHECKER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PAGE_CHECKER_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Page Checker</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="status" id="pagechecker-status">Analiz başlıyor..</div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }

  modal.style.display = "flex";
  const status = modal.querySelector("#pagechecker-status");
  if (status) {
    status.textContent = "Analiz başlıyor..";
    status.className = "status info";
    status.style.display = "block";
  }

  const scrollStep = () => {
    const doc = document.documentElement;
    const bottom = doc.scrollTop + window.innerHeight >= doc.scrollHeight - 2;
    if (bottom) {
      if (status) {
        status.textContent = "Analiz tamamlandı.";
        status.className = "status success";
      }
      return;
    }
    window.scrollBy({ top: window.innerHeight, left: 0, behavior: "smooth" });
    window.setTimeout(scrollStep, 2500);
  };

  window.setTimeout(scrollStep, 2500);
};

const openBoProductManagement = (productId) => {
  if (!productId) {
    alert("Product ID bulunamadı.");
    return;
  }
  chrome.runtime.sendMessage({
    type: "open-bo-product-management",
    productId
  });
};

const openSellerProductsCrawlerModal = () => {
  let modal = document.getElementById(SELLER_PRODUCTS_CRAWLER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = SELLER_PRODUCTS_CRAWLER_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.innerHTML = `
      <div class="modal-card" id="seller-products-crawler-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Seller Products Crawler</div>
        </div>
        <div class="seller-products-crawler-body">
          <div class="seller-products-crawler-actions">
            <button type="button" class="seller-products-crawler-run-btn" id="seller-products-crawler-run-btn">Product Crawler</button>
            <button type="button" class="seller-products-crawler-download-btn" id="seller-products-crawler-download-btn" disabled>Download</button>
            <button type="button" class="seller-products-crawler-excel-btn" id="seller-products-crawler-excel-btn" disabled>Excel</button>
          </div>
          <div class="status info" id="seller-products-crawler-status">URL'de mid parametresi bulunan bir satıcı sayfasında (sr?mid=…) Product Crawler ile listeyi çekin.</div>
          <div class="seller-products-crawler-table-wrap">
            <table class="seller-products-crawler-table">
              <thead>
                <tr>
                  <th>Görsel</th>
                  <th>Ürün adı</th>
                  <th>URL</th>
                  <th>Fiyat</th>
                </tr>
              </thead>
              <tbody id="seller-products-crawler-tbody"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
    const runBtn = modal.querySelector("#seller-products-crawler-run-btn");
    runBtn.addEventListener("click", runSellerProductsCrawler);
    const downloadBtn = modal.querySelector("#seller-products-crawler-download-btn");
    downloadBtn.addEventListener("click", downloadSellerProductsCrawlerJson);
    const excelBtn = modal.querySelector("#seller-products-crawler-excel-btn");
    excelBtn.addEventListener("click", downloadSellerProductsCrawlerExcel);
    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

let sellerProductsCrawlerDownloadData = [];
let sellerProductsCrawlerSellerName = "";

const sanitizeFilename = (str) => {
  if (!str || typeof str !== "string") return "seller-products";
  return str
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\w\u00C0-\u024F\-]/gi, "")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "") || "seller-products";
};

const downloadSellerProductsCrawlerJson = () => {
  if (!sellerProductsCrawlerDownloadData.length) return;
  const json = JSON.stringify(sellerProductsCrawlerDownloadData, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  const namePart = sanitizeFilename(sellerProductsCrawlerSellerName);
  a.download = `trendyol-${namePart}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

const escapeHtmlForExcel = (str) => {
  if (str == null) return "";
  const s = String(str);
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
};

const downloadSellerProductsCrawlerExcel = () => {
  if (!sellerProductsCrawlerDownloadData.length) return;
  const namePart = sanitizeFilename(sellerProductsCrawlerSellerName);
  const rows = sellerProductsCrawlerDownloadData.map((p) => [
    escapeHtmlForExcel(p.name),
    escapeHtmlForExcel(p.image),
    escapeHtmlForExcel(p.url),
    escapeHtmlForExcel(p.discountedPriceText)
  ]);
  const headerRow = "<tr><th>Ürün adı</th><th>Görsel</th><th>URL</th><th>Fiyat</th></tr>";
  const dataRows = rows
    .map(
      (r) =>
        `<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td></tr>`
    )
    .join("");
  const html = `<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
<head>
<meta charset="UTF-8">
<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Ürünler</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
</head>
<body>
<table border="1">
<thead>${headerRow}</thead>
<tbody>${dataRows}</tbody>
</table>
</body>
</html>`;
  const blob = new Blob(
    ["\uFEFF" + html],
    { type: "application/vnd.ms-excel;charset=utf-8" }
  );
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `trendyol-${namePart}.xls`;
  a.click();
  URL.revokeObjectURL(url);
};

const runSellerProductsCrawler = async () => {
  const modal = document.getElementById(SELLER_PRODUCTS_CRAWLER_MODAL_ID);
  if (!modal) return;
  const status = modal.querySelector("#seller-products-crawler-status");
  const tbody = modal.querySelector("#seller-products-crawler-tbody");
  const runBtn = modal.querySelector("#seller-products-crawler-run-btn");
  try {
    const params = new URLSearchParams(window.location.search);
    const mid = params.get("mid");
    if (!mid) {
      status.textContent = "Bu sayfada mid parametresi yok. Örnek: https://www.trendyol.com/sr?mid=63";
      status.className = "status error";
      return;
    }
    runBtn.disabled = true;
    const downloadBtn = modal.querySelector("#seller-products-crawler-download-btn");
    if (downloadBtn) downloadBtn.disabled = true;
    const excelBtn = modal.querySelector("#seller-products-crawler-excel-btn");
    if (excelBtn) excelBtn.disabled = true;
    sellerProductsCrawlerDownloadData = [];
    const h1 = document.querySelector("h1");
    sellerProductsCrawlerSellerName = (h1 && h1.textContent) ? h1.textContent.trim() : "";
    tbody.innerHTML = "";
    status.textContent = "Sayfa 1 çekiliyor...";
    status.className = "status info";
    const tableWrap = modal.querySelector(".seller-products-crawler-table-wrap");
    if (tableWrap) tableWrap.style.display = "block";
    let pi = 1;
    let totalAppended = 0;
    const baseUrl = "https://www.trendyol.com";
    const collected = [];
    while (true) {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: "trendyol-seller-products", mid, pi },
          (r) => resolve(r || { ok: false, error: "Yanıt yok" })
        );
      });
      if (!response.ok) {
        status.textContent = `Hata (sayfa ${pi}): ${response.error || "Bilinmeyen"}`;
        status.className = "status error";
        break;
      }
      const products = response.products || [];
      if (products.length === 0) {
        status.textContent = totalAppended === 0
          ? "Ürün bulunamadı."
          : `Tamamlandı. Toplam ${totalAppended} ürün listelendi.`;
        status.className = "status info";
        if (totalAppended > 0) {
          sellerProductsCrawlerDownloadData = collected;
          const dlBtn = modal.querySelector("#seller-products-crawler-download-btn");
          if (dlBtn) dlBtn.disabled = false;
          const excelBtn = modal.querySelector("#seller-products-crawler-excel-btn");
          if (excelBtn) excelBtn.disabled = false;
        }
        break;
      }
      for (const p of products) {
        const name = p.name || "";
        const img = p.image || (p.images && p.images[0]) || "";
        const urlPath = p.url || "";
        const url = urlPath.startsWith("http") ? urlPath : `${baseUrl}${urlPath}`;
        const priceText = (p.price && p.price.discountedPriceText) || "";
        const codesFromName = extractProductCodes(name);
        const productCodes = codesFromName.length > 0 ? codesFromName : extractProductCodes(urlPath);
        collected.push({
          name,
          image: img,
          url,
          discountedPriceText: priceText,
          productCodes,
          id: p.id ?? p.contentId ?? "",
          brand: p.brand ?? ""
        });
        const tr = document.createElement("tr");
        const imgTd = document.createElement("td");
        if (img) {
          const imgEl = document.createElement("img");
          imgEl.src = img;
          imgEl.alt = name;
          imgEl.style.maxWidth = "60px";
          imgEl.style.maxHeight = "60px";
          imgEl.style.objectFit = "contain";
          imgTd.appendChild(imgEl);
        } else {
          imgTd.textContent = "—";
        }
        const nameTd = document.createElement("td");
        nameTd.textContent = name;
        nameTd.style.maxWidth = "240px";
        nameTd.style.wordBreak = "break-word";
        const urlTd = document.createElement("td");
        const link = document.createElement("a");
        link.href = url;
        link.target = "_blank";
        link.rel = "noopener";
        link.textContent = url.length > 50 ? url.slice(0, 47) + "…" : url;
        link.title = url;
        urlTd.appendChild(link);
        const priceTd = document.createElement("td");
        priceTd.textContent = priceText;
        tr.append(imgTd, nameTd, urlTd, priceTd);
        tbody.appendChild(tr);
        totalAppended += 1;
      }
      status.textContent = `Sayfa ${pi} işlendi (${products.length} ürün). Toplam: ${totalAppended}. Sonraki sayfa çekiliyor...`;
      pi += 1;
    }
  } catch (err) {
    status.textContent = `Hata: ${err?.message || String(err)}`;
    status.className = "status error";
  } finally {
    runBtn.disabled = false;
  }
};

const getHepsiburadaMerchantNameFromPage = () => {
  const el = document.querySelector("h1#page_title");
  if (!el) return "";
  return (el.textContent || "").trim();
};

const openHepsiburadaSellerProductsCrawlerModal = () => {
  let modal = document.getElementById(HEPSIBURADA_SELLER_PRODUCTS_CRAWLER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = HEPSIBURADA_SELLER_PRODUCTS_CRAWLER_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.innerHTML = `
      <div class="modal-card" id="hepsiburada-seller-products-crawler-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Seller Products Crawler (Hepsiburada)</div>
        </div>
        <div class="seller-products-crawler-body">
          <div class="seller-products-crawler-actions">
            <button type="button" class="seller-products-crawler-run-btn" id="hepsiburada-seller-products-crawler-run-btn">Product Crawler</button>
            <button type="button" class="seller-products-crawler-download-btn" id="hepsiburada-seller-products-crawler-download-btn" disabled>Download</button>
            <button type="button" class="seller-products-crawler-excel-btn" id="hepsiburada-seller-products-crawler-excel-btn" disabled>Excel</button>
          </div>
          <div class="status info" id="hepsiburada-seller-products-crawler-status">Mağaza sayfasında (magaza/...) Product Crawler ile listeyi çekin. Satıcı adı sayfadaki h1#page_title metninden alınır.</div>
          <div class="seller-products-crawler-table-wrap">
            <table class="seller-products-crawler-table">
              <thead>
                <tr>
                  <th>Görsel</th>
                  <th>Ürün adı</th>
                  <th>URL</th>
                  <th>Fiyat</th>
                </tr>
              </thead>
              <tbody id="hepsiburada-seller-products-crawler-tbody"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    modal.querySelector(".modal-close").addEventListener("click", () => { modal.style.display = "none"; });
    modal.querySelector("#hepsiburada-seller-products-crawler-run-btn").addEventListener("click", runHepsiburadaSellerProductsCrawler);
    modal.querySelector("#hepsiburada-seller-products-crawler-download-btn").addEventListener("click", downloadHepsiburadaSellerProductsCrawlerJson);
    modal.querySelector("#hepsiburada-seller-products-crawler-excel-btn").addEventListener("click", downloadHepsiburadaSellerProductsCrawlerExcel);
    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

let hepsiburadaSellerProductsCrawlerDownloadData = [];
let hepsiburadaSellerProductsCrawlerSellerName = "";

const downloadHepsiburadaSellerProductsCrawlerJson = () => {
  if (!hepsiburadaSellerProductsCrawlerDownloadData.length) return;
  const json = JSON.stringify(hepsiburadaSellerProductsCrawlerDownloadData, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `hepsiburada-${sanitizeFilename(hepsiburadaSellerProductsCrawlerSellerName)}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

const downloadHepsiburadaSellerProductsCrawlerExcel = () => {
  if (!hepsiburadaSellerProductsCrawlerDownloadData.length) return;
  const namePart = sanitizeFilename(hepsiburadaSellerProductsCrawlerSellerName);
  const rows = hepsiburadaSellerProductsCrawlerDownloadData.map((p) => [
    escapeHtmlForExcel(p.name),
    escapeHtmlForExcel(p.image),
    escapeHtmlForExcel(p.url),
    escapeHtmlForExcel(p.discountedPriceText)
  ]);
  const headerRow = "<tr><th>Ürün adı</th><th>Görsel</th><th>URL</th><th>Fiyat</th></tr>";
  const dataRows = rows.map((r) => `<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td></tr>`).join("");
  const html = `<!DOCTYPE html><html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table border="1"><thead>${headerRow}</thead><tbody>${dataRows}</tbody></table></body></html>`;
  const blob = new Blob(["\uFEFF" + html], { type: "application/vnd.ms-excel;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `hepsiburada-${namePart}.xls`;
  a.click();
  URL.revokeObjectURL(a.href);
};

const HEPSIBURADA_BRIDGE_INJECTED = "data-n11ext-hepsiburada-bridge";

const ensureHepsiburadaBridgeInjected = () => {
  if (document.documentElement.getAttribute(HEPSIBURADA_BRIDGE_INJECTED) === "1") return Promise.resolve();
  return new Promise((resolve) => {
    try {
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL("hepsiburada-bridge.js");
      script.onload = () => { script.remove(); resolve(); };
      script.onerror = () => resolve();
      (document.head || document.documentElement).appendChild(script);
      document.documentElement.setAttribute(HEPSIBURADA_BRIDGE_INJECTED, "1");
    } catch (_) {
      resolve();
    }
  });
};

const fetchHepsiburadaApiViaPage = (merchantName, pageNum) => {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      document.removeEventListener("n11ext-hepsiburada-response", handler);
      resolve({ ok: false, error: "Zaman aşımı (sayfa bağlamı)" });
    }, 25000);
    const handler = (e) => {
      clearTimeout(timeout);
      document.removeEventListener("n11ext-hepsiburada-response", handler);
      resolve(e.detail || { ok: false, error: "Yanıt yok" });
    };
    document.addEventListener("n11ext-hepsiburada-response", handler);
    document.dispatchEvent(new CustomEvent("n11ext-hepsiburada-request", { detail: { merchantName, page: pageNum } }));
  });
};

const runHepsiburadaSellerProductsCrawler = async () => {
  const modal = document.getElementById(HEPSIBURADA_SELLER_PRODUCTS_CRAWLER_MODAL_ID);
  if (!modal) return;
  const status = modal.querySelector("#hepsiburada-seller-products-crawler-status");
  const tbody = modal.querySelector("#hepsiburada-seller-products-crawler-tbody");
  const runBtn = modal.querySelector("#hepsiburada-seller-products-crawler-run-btn");
  const downloadBtn = modal.querySelector("#hepsiburada-seller-products-crawler-download-btn");
  const excelBtn = modal.querySelector("#hepsiburada-seller-products-crawler-excel-btn");
  const merchantName = getHepsiburadaMerchantNameFromPage();
  if (!merchantName) {
    status.textContent = "Satıcı adı bulunamadı. Sayfada h1#page_title elementi olan bir mağaza sayfasında olun (örn. hepsiburada.com/magaza/...).";
    status.className = "status error";
    return;
  }
  hepsiburadaSellerProductsCrawlerSellerName = merchantName;
  runBtn.disabled = true;
  if (downloadBtn) downloadBtn.disabled = true;
  if (excelBtn) excelBtn.disabled = true;
  hepsiburadaSellerProductsCrawlerDownloadData = [];
  tbody.innerHTML = "";
  status.textContent = "Sayfa 1 çekiliyor (sayfa bağlamında)...";
  status.className = "status info";
  modal.querySelector(".seller-products-crawler-table-wrap").style.display = "block";
  await ensureHepsiburadaBridgeInjected();
  await new Promise((r) => setTimeout(r, 400));
  const baseUrl = "https://www.hepsiburada.com";
  const collected = [];
  let page = 1;
  const isRetriableError = (err) => {
    const s = (err || "").toLowerCase();
    return s.includes("zaman aşımı") || s.includes("failed to fetch") || s.includes("failed") || s.includes("network") || s.includes("load");
  };
  const fetchPageWithRetry = async (p) => {
    let response = await fetchHepsiburadaApiViaPage(merchantName, p);
    if (!response.ok && isRetriableError(response.error)) {
      const delayRetry = 12000 + Math.floor(Math.random() * 6000);
      status.textContent = `Sayfa ${p} hata (${response.error}). ${(delayRetry / 1000).toFixed(0)} saniye sonra yeniden denenecek...`;
      await new Promise((r) => setTimeout(r, delayRetry));
      response = await fetchHepsiburadaApiViaPage(merchantName, p);
    }
    if (!response.ok && isRetriableError(response.error)) {
      status.textContent = `Sayfa ${p} tekrar denendi, background ile deneniyor...`;
      await new Promise((r) => setTimeout(r, 3000));
      response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: "hepsiburada-seller-products", merchantName, page: p },
          (r) => resolve(r || { ok: false, error: "Yanıt yok" })
        );
      });
    }
    return response;
  };
  try {
    while (true) {
      let response = await fetchPageWithRetry(page);
      if (!response.ok) {
        if (collected.length > 0) {
          hepsiburadaSellerProductsCrawlerDownloadData = collected;
          if (downloadBtn) downloadBtn.disabled = false;
          if (excelBtn) excelBtn.disabled = false;
          status.textContent = `Hata (sayfa ${page}): ${response.error || "Bilinmeyen"}. O ana kadar toplanan ${collected.length} ürün JSON veya Excel ile indirilebilir.`;
        } else {
          status.textContent = `Hata (sayfa ${page}): ${response.error || "Bilinmeyen"}`;
        }
        status.className = "status error";
        break;
      }
      const products = response.products || [];
      if (products.length === 0) {
        status.textContent = collected.length === 0 ? "Ürün bulunamadı." : `Tamamlandı. Toplam ${collected.length} ürün listelendi.`;
        status.className = "status info";
        if (collected.length > 0) {
          hepsiburadaSellerProductsCrawlerDownloadData = collected;
          if (downloadBtn) downloadBtn.disabled = false;
          if (excelBtn) excelBtn.disabled = false;
        }
        break;
      }
      for (const p of products) {
        const v = p.variantList && p.variantList[0];
        const name = v ? (v.name || "") : "";
        const urlPath = v ? (v.url || "") : "";
        const url = urlPath.startsWith("http") ? urlPath : `${baseUrl}${urlPath}`;
        const priceInfo = v && v.listing && v.listing.priceInfo ? v.listing.priceInfo : null;
        const priceNum = priceInfo && priceInfo.price != null ? Number(priceInfo.price) : null;
        const priceText = priceNum != null ? `${String(priceNum).replace(".", ",")} TL` : "";
        const imgLink = v && v.images && v.images[0] && v.images[0].link ? v.images[0].link : "";
        const image = imgLink ? imgLink.replace(/\{size\}/g, "400") : "";
        collected.push({ name, image, url, discountedPriceText: priceText });
        const tr = document.createElement("tr");
        const imgTd = document.createElement("td");
        if (image) {
          const imgEl = document.createElement("img");
          imgEl.src = image;
          imgEl.alt = name;
          imgEl.style.maxWidth = "60px";
          imgEl.style.maxHeight = "60px";
          imgEl.style.objectFit = "contain";
          imgTd.appendChild(imgEl);
        } else {
          imgTd.textContent = "—";
        }
        const nameTd = document.createElement("td");
        nameTd.textContent = name;
        nameTd.style.maxWidth = "240px";
        nameTd.style.wordBreak = "break-word";
        const urlTd = document.createElement("td");
        const link = document.createElement("a");
        link.href = url;
        link.target = "_blank";
        link.rel = "noopener";
        link.textContent = url.length > 50 ? url.slice(0, 47) + "…" : url;
        link.title = url;
        urlTd.appendChild(link);
        const priceTd = document.createElement("td");
        priceTd.textContent = priceText;
        tr.append(imgTd, nameTd, urlTd, priceTd);
        tbody.appendChild(tr);
      }
      status.textContent = `Sayfa ${page} işlendi (${products.length} ürün). Toplam: ${collected.length}. Sonraki sayfa...`;
      page += 1;
      if (products.length > 0) {
        const delayMs = 5000 + Math.floor(Math.random() * 5000);
        status.textContent = `Sayfa ${page - 1} işlendi. ${(delayMs / 1000).toFixed(1)} saniye bekleniyor (bot koruması için)...`;
        await new Promise((r) => setTimeout(r, delayMs));
      }
    }
  } catch (err) {
    status.textContent = `Hata: ${err?.message || String(err)}`;
    status.className = "status error";
  } finally {
    runBtn.disabled = false;
  }
};

let sellerProductMatchUploadedData = [];
let sellerProductMatchLastResults = [];

const openSellerProductMatchModal = () => {
  let modal = document.getElementById(SELLER_PRODUCT_MATCH_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = SELLER_PRODUCT_MATCH_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.innerHTML = `
      <div class="modal-card seller-product-match-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Seller Product Match</div>
        </div>
        <div class="seller-product-match-body">
          <div class="seller-product-match-drop-wrap">
            <input type="file" accept=".json,application/json" multiple id="seller-product-match-file-input" class="seller-product-match-file-input" />
            <div class="seller-product-match-drop-zone" id="seller-product-match-drop-zone">
              <p class="seller-product-match-drop-text">Trendyol veya Hepsiburada JSON dosyalarını buraya sürükleyin (birden fazla seçebilirsiniz) veya <strong>Gözat</strong> ile seçin</p>
            </div>
            <button type="button" class="seller-product-match-browse-btn" id="seller-product-match-browse-btn">Gözat</button>
          </div>
          <div class="status info" id="seller-product-match-status">Trendyol veya Hepsiburada eklentisi ile indirdiğiniz .json dosyalarını yükleyin (birden fazla seçebilirsiniz).</div>
          <div class="seller-product-match-actions">
            <button type="button" class="seller-product-match-analyze-btn" id="seller-product-match-analyze-btn" disabled>Analiz Et & Karşılaştır</button>
            <button type="button" class="seller-product-match-download-btn" id="seller-product-match-download-btn" disabled>Excel İndir</button>
          </div>
          <div class="seller-product-match-table-wrap">
            <table class="seller-product-match-table">
              <thead>
                <tr>
                  <th>Kaynak</th>
                  <th>Ürün adı</th>
                  <th>Platform Fiyat</th>
                  <th>n11 Fiyat</th>
                  <th>Eşleşme %</th>
                  <th>Trendyol Link</th>
                  <th>Hepsiburada Link</th>
                  <th>n11 Link</th>
                </tr>
              </thead>
              <tbody id="seller-product-match-tbody"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
    const fileInput = modal.querySelector("#seller-product-match-file-input");
    const dropZone = modal.querySelector("#seller-product-match-drop-zone");
    const browseBtn = modal.querySelector("#seller-product-match-browse-btn");
    const analyzeBtn = modal.querySelector("#seller-product-match-analyze-btn");
    const downloadBtn = modal.querySelector("#seller-product-match-download-btn");
    browseBtn.addEventListener("click", () => fileInput.click());
    dropZone.addEventListener("click", () => fileInput.click());
    dropZone.addEventListener("dragover", (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.add("seller-product-match-drop-zone-active");
    });
    dropZone.addEventListener("dragleave", (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove("seller-product-match-drop-zone-active");
    });
    dropZone.addEventListener("drop", (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove("seller-product-match-drop-zone-active");
      const files = e.dataTransfer?.files;
      if (files && files.length > 0) {
        handleSellerProductMatchFiles(Array.from(files), modal);
      }
    });
    fileInput.addEventListener("change", () => {
      const files = fileInput.files;
      if (files && files.length > 0) {
        handleSellerProductMatchFiles(Array.from(files), modal);
      }
      fileInput.value = "";
    });
    analyzeBtn.addEventListener("click", () => {
      const m = document.getElementById(SELLER_PRODUCT_MATCH_MODAL_ID);
      if (m) runSellerProductMatchAnalyze(m);
    });
    if (downloadBtn) {
      downloadBtn.addEventListener("click", () => {
        const m = document.getElementById(SELLER_PRODUCT_MATCH_MODAL_ID);
        if (m) downloadSellerProductMatchExcel(m);
      });
    }
    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

const readFileAsText = (file) =>
  new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error("Dosya okunamadı"));
    r.readAsText(file, "UTF-8");
  });

const parseJsonAndNormalizeProducts = (content) => {
  const result = { items: [], source: null };
  try {
    const json = typeof content === "string" ? JSON.parse(content) : content;
    const arr = Array.isArray(json) ? json : (json && Array.isArray(json.products) ? json.products : null);
    if (!arr || arr.length === 0) return result;
    const first = arr[0];
    const isHepsiburada = first && first.variantList && Array.isArray(first.variantList) && first.variantList[0];
    const hepsiBase = "https://www.hepsiburada.com";
    if (isHepsiburada) {
      result.source = "hepsiburada";
      result.items = arr.map((p) => {
        const v = p.variantList && p.variantList[0];
        const name = v && v.name != null ? String(v.name) : "";
        let url = v && v.url != null ? String(v.url).trim() : "";
        if (url && !url.startsWith("http")) url = url.startsWith("/") ? hepsiBase + url : hepsiBase + "/" + url;
        const priceInfo = v && v.listing && v.listing.priceInfo;
        const priceNum = priceInfo && priceInfo.price != null ? Number(priceInfo.price) : null;
        const discountedPriceText = priceNum != null ? `${String(priceNum).replace(".", ",")} TL` : "";
        const productCodes = extractProductCodes(name);
        return { name, discountedPriceText, productCodes, url, source: "hepsiburada" };
      });
    } else {
      result.source = "trendyol";
      result.items = arr.map((p) => {
        const name = p.name != null ? String(p.name) : "";
        const productCodes = Array.isArray(p.productCodes) && p.productCodes.length > 0
          ? p.productCodes.filter((c) => typeof c === "string")
          : extractProductCodes(name);
        let url = p.url != null ? String(p.url).trim() : "";
        if (url && !url.startsWith("http")) {
          url = url.startsWith("/") ? "https://www.trendyol.com" + url : "https://www.trendyol.com/" + url;
        }
        return {
          name,
          discountedPriceText: (p.discountedPriceText != null ? String(p.discountedPriceText) : (p.price && p.price.discountedPriceText) ? String(p.price.discountedPriceText) : ""),
          productCodes,
          url,
          source: "trendyol"
        };
      });
    }
  } catch (_) {}
  return result;
};

const handleSellerProductMatchFiles = async (files, modal) => {
  const status = modal.querySelector("#seller-product-match-status");
  const analyzeBtn = modal.querySelector("#seller-product-match-analyze-btn");
  const downloadBtn = modal.querySelector("#seller-product-match-download-btn");
  if (!files || files.length === 0) return;
  status.textContent = "Dosya(lar) okunuyor...";
  status.className = "status info";
  const allItems = [];
  for (const file of files) {
    try {
      const text = await readFileAsText(file);
      const { items } = parseJsonAndNormalizeProducts(text);
      if (items.length > 0) allItems.push(...items);
    } catch (err) {
      status.textContent = `"${file.name}" okunamadı: ${err?.message || "Geçersiz JSON"}`;
      status.className = "status error";
      if (analyzeBtn) analyzeBtn.disabled = true;
      return;
    }
  }
  if (allItems.length === 0) {
    status.textContent = "Geçerli ürün listesi bulunamadı. Trendyol veya Hepsiburada JSON dosyası yükleyin.";
    status.className = "status error";
    sellerProductMatchUploadedData = [];
    if (analyzeBtn) analyzeBtn.disabled = true;
    if (downloadBtn) downloadBtn.disabled = true;
    return;
  }
  sellerProductMatchUploadedData = allItems;
  const trendCount = allItems.filter((i) => i.source === "trendyol").length;
  const hepsiCount = allItems.filter((i) => i.source === "hepsiburada").length;
  const parts = [];
  if (trendCount) parts.push(`${trendCount} Trendyol`);
  if (hepsiCount) parts.push(`${hepsiCount} Hepsiburada`);
  status.textContent = `Toplam ${allItems.length} ürün yüklendi (${parts.join(", ")}). "Analiz Et & Karşılaştır" ile devam edin.`;
  status.className = "status info";
  if (analyzeBtn) analyzeBtn.disabled = false;
  if (downloadBtn) downloadBtn.disabled = true;
};

const downloadSellerProductMatchExcel = (modal) => {
  if (!Array.isArray(sellerProductMatchLastResults) || sellerProductMatchLastResults.length === 0) {
    const status = modal.querySelector("#seller-product-match-status");
    if (status) {
      status.textContent = "Önce analiz çalıştırın. Excel sadece analiz edilmiş liste için oluşturulur.";
      status.className = "status error";
    }
    return;
  }
  if (typeof XLSX === "undefined") {
    const status = modal.querySelector("#seller-product-match-status");
    if (status) {
      status.textContent = "Excel kütüphanesi (XLSX) yüklenemedi.";
      status.className = "status error";
    }
    return;
  }
  const header = [
    "Kaynak",
    "Ürün adı",
    "Platform Fiyat",
    "n11 Fiyat",
    "Eşleşme %",
    "Trendyol Link",
    "Hepsiburada Link",
    "n11 Link"
  ];
  const rows = sellerProductMatchLastResults.map((m) => {
    const scorePercent = m.score != null ? Math.round(m.score * 100) : "";
    return [
      m.source || "",
      m.name || "",
      m.platformPrice || "",
      m.n11Price || "",
      scorePercent,
      m.trendyolUrl || "",
      m.hepsiburadaUrl || "",
      m.n11Url || ""
    ];
  });
  const wsData = [header, ...rows];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Seller Product Match");
  const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([wbout], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "seller_product_match.xlsx";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

const normalizeProductName = (s) => {
  if (s == null || typeof s !== "string") return "";
  return s
    .toLowerCase()
    .trim()
    .replace(/\s+/g, " ")
    .replace(/[^\w\u00C0-\u024F\s]/g, "");
};

const tokenizeForMatch = (s) => {
  const n = normalizeProductName(s);
  if (!n) return [];
  return n.split(/\s+/).filter((w) => w.length > 0);
};

/**
 * Ürün kodu / barkod numaralarını title veya metinden çıkarır.
 * Ürün adı içinde "168752-620" gibi barkod varsa (örn. "Mavi ... Tişört ... 168752-620"),
 * eşleştirmede bu kod kullanılır: platform ürün adı ve n11 subtitle'da aynı barkod varsa eşleşir.
 * Tire etrafında boşluk da kabul edilir ("168752 - 620" → "168752-620" normalize).
 */
const extractProductCodes = (str) => {
  if (str == null || typeof str !== "string") return [];
  const re = /\b(\d{2,})\s*-\s*(\d{2,})\b/g;
  const codes = [];
  let m;
  while ((m = re.exec(str)) !== null) {
    codes.push(m[1] + "-" + m[2]);
  }
  return [...new Set(codes)];
};

/**
 * Text similarity score 0–1: word-based Dice coefficient.
 * 2 * |A ∩ B| / (|A| + |B|) for word sets.
 */
const textSimilarityScore = (str1, str2) => {
  const words1 = new Set(tokenizeForMatch(str1));
  const words2 = new Set(tokenizeForMatch(str2));
  if (words1.size === 0 && words2.size === 0) return 1;
  if (words1.size === 0 || words2.size === 0) return 0;
  let intersection = 0;
  for (const w of words1) {
    if (words2.has(w)) intersection += 1;
  }
  return (2 * intersection) / (words1.size + words2.size);
};

/**
 * Eşleştirme skoru: ürün kodu/barkod eşleşmesi (platform adı vs n11) önceliklidir.
 * Barkod title'da veya n11 URL'sinde (örn. ...-1010299-91180-...) olabilir; her iki kaynaktan çıkarılır.
 * trendyolProductCodes: JSON'dan gelen önceden çıkarılmış kodlar; yoksa title'dan extractProductCodes ile alınır.
 * n11Url: n11 ürün linki; API subtitle'da barkod olmasa bile URL'deki barkod ile eşleşme yapılır.
 */
const combinedMatchScore = (trendyolName, n11Subtitle, trendyolProductCodes = null, n11Url = "") => {
  const textScore = textSimilarityScore(trendyolName, n11Subtitle);
  const codesT = Array.isArray(trendyolProductCodes) && trendyolProductCodes.length > 0
    ? trendyolProductCodes
    : extractProductCodes(trendyolName);
  const codesFromSubtitle = extractProductCodes(n11Subtitle);
  const codesFromUrl = n11Url ? extractProductCodes(n11Url) : [];
  const codesN = [...new Set([...codesFromSubtitle, ...codesFromUrl])];
  const hasCodeMatch = codesT.length > 0 && codesN.length > 0 && codesT.some((c) => codesN.includes(c));
  if (hasCodeMatch) {
    return Math.min(1, 0.82 + 0.18 * textScore);
  }
  return textScore;
};

const runSellerProductMatchAnalyze = async (modal) => {
  const status = modal.querySelector("#seller-product-match-status");
  const tbody = modal.querySelector("#seller-product-match-tbody");
  const analyzeBtn = modal.querySelector("#seller-product-match-analyze-btn");
  if (!sellerProductMatchUploadedData.length) {
    status.textContent = "Önce Trendyol veya Hepsiburada JSON dosyası yükleyin.";
    status.className = "status error";
    return;
  }
  const sellerId = findSellerIdFromModel();
  if (!sellerId) {
    status.textContent = "Mağaza (seller) ID bulunamadı. model.sellerInfo.sellerShopDto.sellerId sayfa yüklenene kadar bekleyin.";
    status.className = "status error";
    return;
  }
  analyzeBtn.disabled = true;
  status.textContent = "n11 ürün listesi alınıyor...";
  status.className = "status info";
  tbody.innerHTML = "";
  const base = "https://www.n11.com";
  const n11Items = [];
  const seenN11Ids = new Set();
  let pg = 1;
  let n11TotalCountFromApi = null;
  const N11_MAX_PAGES = 250;
  try {
    while (pg <= N11_MAX_PAGES) {
      const url = `https://www.n11.com/arama?pg=${pg}&srt=NUMARA11&iw=&_getAttributes=1&_withProduct=1&sellerId=${encodeURIComponent(sellerId)}&vueSearch=1`;
      status.textContent = `n11 sayfa ${pg} alınıyor...`;
      const response = await fetch(url, { credentials: "omit" });
      if (!response.ok) {
        status.textContent = `n11 isteği hata (sayfa ${pg}): ${response.status}`;
        status.className = "status error";
        break;
      }
      let data;
      try {
        data = await response.json();
      } catch (_) {
        break;
      }
      if (pg === 1 && data?.data?.pagination?.totalCount != null) {
        n11TotalCountFromApi = Number(data.data.pagination.totalCount);
      }
      const items = data?.data?.productListingItems;
      if (!Array.isArray(items) || items.length === 0) {
        break;
      }
      const allAlreadySeen = items.every((item) => {
        const id = item.id != null ? String(item.id) : null;
        return id != null && seenN11Ids.has(id);
      });
      if (allAlreadySeen) {
        break;
      }
      for (const item of items) {
        const id = item.id != null ? String(item.id) : "";
        if (id && seenN11Ids.has(id)) continue;
        if (id) seenN11Ids.add(id);
        const subtitle = item.subtitle != null ? String(item.subtitle) : (item.title != null ? String(item.title) : "");
        const priceStr = item.priceStr != null ? String(item.priceStr) : "";
        const path = item.urlWithoutSellerShop || item.url || "";
        const href = path.startsWith("http") ? path : `${base}${path}`;
        n11Items.push({
          subtitle,
          priceStr,
          url: href
        });
      }
      status.textContent = `n11 sayfa ${pg} alındı (${items.length} ürün). Toplam: ${n11Items.length} ürün. Sonraki sayfa...`;
      pg += 1;
      await new Promise((r) => setTimeout(r, 350));
    }
    if (n11TotalCountFromApi != null && n11Items.length < n11TotalCountFromApi) {
      status.textContent = `n11'den ${n11Items.length} ürün toplandı (mağazada toplam ${n11TotalCountFromApi} ürün; API sayfa limiti nedeniyle tümü alınamıyor olabilir). Eşleştirme yapılıyor...`;
    } else {
      status.textContent = `n11'den ${n11Items.length} ürün toplandı. Eşleştirme yapılıyor...`;
    }
    await new Promise((r) => setTimeout(r, 100));
    const minScoreThreshold = 0.2;
    const candidatePairs = [];
    for (let tIdx = 0; tIdx < sellerProductMatchUploadedData.length; tIdx += 1) {
      const p = sellerProductMatchUploadedData[tIdx];
      const trendyolCodes = p.productCodes;
      for (let nIdx = 0; nIdx < n11Items.length; nIdx += 1) {
        const n11 = n11Items[nIdx];
        const score = combinedMatchScore(p.name, n11.subtitle, trendyolCodes, n11.url || "");
        if (score >= minScoreThreshold) {
          candidatePairs.push({ tIdx, nIdx, score });
        }
      }
    }
    candidatePairs.sort((a, b) => b.score - a.score);
    const assignedTrendyol = new Set();
    const assignedN11 = new Set();
    const matchByTrendyol = new Map();
    for (const { tIdx, nIdx, score } of candidatePairs) {
      if (assignedTrendyol.has(tIdx) || assignedN11.has(nIdx)) continue;
      assignedTrendyol.add(tIdx);
      assignedN11.add(nIdx);
      matchByTrendyol.set(tIdx, { n11Index: nIdx, score });
    }
    const matches = [];
    for (let tIdx = 0; tIdx < sellerProductMatchUploadedData.length; tIdx += 1) {
      const p = sellerProductMatchUploadedData[tIdx];
      const pair = matchByTrendyol.get(tIdx);
      const source = p.source === "hepsiburada" ? "Hepsiburada" : "Trendyol";
      if (pair) {
        const n11 = n11Items[pair.n11Index];
        matches.push({
          name: p.name,
          source,
          platformPrice: p.discountedPriceText,
          n11Price: n11.priceStr,
          n11Url: n11.url,
          trendyolUrl: source === "Trendyol" ? (p.url || "") : "",
          hepsiburadaUrl: source === "Hepsiburada" ? (p.url || "") : "",
          score: pair.score
        });
      } else {
        matches.push({
          name: p.name,
          source,
          platformPrice: p.discountedPriceText,
          n11Price: "",
          n11Url: "",
          trendyolUrl: source === "Trendyol" ? (p.url || "") : "",
          hepsiburadaUrl: source === "Hepsiburada" ? (p.url || "") : "",
          score: null
        });
      }
    }
    sellerProductMatchLastResults = matches;
    tbody.innerHTML = matches
      .map(
        (m) => {
          const scoreCell = m.score != null ? `<td class="seller-product-match-score">%${Math.round(m.score * 100)}</td>` : "<td>—</td>";
          const trendyolLinkCell = m.trendyolUrl ? `<a href="${escapeHtml(m.trendyolUrl)}" target="_blank" rel="noopener">Trendyol</a>` : "—";
          const hepsiburadaLinkCell = m.hepsiburadaUrl ? `<a href="${escapeHtml(m.hepsiburadaUrl)}" target="_blank" rel="noopener">Hepsiburada</a>` : "—";
          const n11LinkCell = m.n11Url ? `<a href="${escapeHtml(m.n11Url)}" target="_blank" rel="noopener">n11</a>` : "—";
          return `<tr>
            <td>${escapeHtml(m.source)}</td>
            <td class="seller-product-match-name">${escapeHtml(m.name)}</td>
            <td>${escapeHtml(m.platformPrice)}</td>
            <td>${escapeHtml(m.n11Price)}</td>
            ${scoreCell}
            <td>${trendyolLinkCell}</td>
            <td>${hepsiburadaLinkCell}</td>
            <td>${n11LinkCell}</td>
          </tr>`;
        }
      )
      .join("");
    const matchedCount = matches.filter((m) => m.n11Price).length;
    const trendInMatch = matches.filter((m) => m.source === "Trendyol").length;
    const hepsiInMatch = matches.filter((m) => m.source === "Hepsiburada").length;
    let statusMsg = `Toplam ${matches.length} ürün (${trendInMatch} Trendyol, ${hepsiInMatch} Hepsiburada), ${matchedCount} eşleşme. n11'den ${n11Items.length} ürün alındı`;
    if (n11TotalCountFromApi != null && n11Items.length < n11TotalCountFromApi) {
      statusMsg += ` (mağazada ${n11TotalCountFromApi} ürün; API ~50 sayfa limiti nedeniyle ${n11Items.length} kadarı çekilebiliyor).`;
    } else {
      statusMsg += ".";
    }
    status.textContent = statusMsg;
    status.className = "status info";
    const downloadBtn = modal.querySelector("#seller-product-match-download-btn");
    if (downloadBtn) {
      downloadBtn.disabled = matches.length === 0;
    }
  } catch (err) {
    status.textContent = "Hata: " + (err?.message || String(err));
    status.className = "status error";
  } finally {
    analyzeBtn.disabled = false;
  }
};

const sellerProductCountSiteLabel = (site) => {
  if (site === "n11") return "n11";
  if (site === "hepsiburada") return "Hepsiburada";
  if (site === "trendyol") return "Trendyol";
  return site || "";
};

const openSellerProductCountModal = () => {
  let modal = document.getElementById(SELLER_PRODUCT_COUNT_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = SELLER_PRODUCT_COUNT_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.innerHTML = `
      <div class="modal-card seller-product-count-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Seller Product Count</div>
        </div>
        <div class="seller-product-count-body">
          <div class="seller-product-count-form-row">
            <input type="text" id="seller-product-count-brand" class="seller-product-count-input seller-product-count-input-brand" placeholder="Marka adı (örn. Mavi)" />
            <div class="seller-product-count-input-group">
              <img src="https://n11scdn.akamaized.net/custom/upload/56/71/4643320758776974115.svg" alt="n11" class="seller-product-count-logo" />
              <input type="text" id="seller-product-count-n11" class="seller-product-count-input" placeholder="n11 mağaza URL" />
            </div>
            <div class="seller-product-count-input-group">
              <img src="https://n11scdn.akamaized.net/custom/upload/52/34/8306016460707706841.svg" alt="Trendyol" class="seller-product-count-logo" />
              <input type="text" id="seller-product-count-trendyol" class="seller-product-count-input" placeholder="Trendyol mağaza URL" />
            </div>
            <div class="seller-product-count-input-group">
              <img src="https://n11scdn.akamaized.net/custom/upload/49/75/9137271869470559939.svg" alt="Hepsiburada" class="seller-product-count-logo" />
              <input type="text" id="seller-product-count-hepsiburada" class="seller-product-count-input" placeholder="Hepsiburada mağaza URL" />
            </div>
            <button type="button" id="seller-product-count-add" class="seller-product-count-add-btn">Satıcı Ekle</button>
          </div>
          <div class="seller-product-count-actions">
            <button type="button" id="seller-product-count-run">Çalıştır</button>
            <button type="button" id="seller-product-count-update">Update</button>
            <button type="button" id="seller-product-count-excel">Excel İndir</button>
            <button type="button" id="seller-product-count-clear" class="seller-product-count-clear-btn">Veri Temizle</button>
            <button type="button" id="seller-product-count-export">Veriyi İndir</button>
            <input type="file" accept=".json,application/json" id="seller-product-count-import-input" class="seller-product-count-import-input" />
            <button type="button" id="seller-product-count-import">Veriyi Yükle</button>
          </div>
          <div class="status info" id="seller-product-count-status"></div>
          <div class="seller-product-count-table-wrap">
            <table class="seller-product-count-table">
              <thead>
                <tr>
                  <th>Marka</th>
                  <th>Link</th>
                  <th>n11</th>
                  <th>Trendyol</th>
                  <th>Hepsiburada</th>
                  <th>İşlem</th>
                </tr>
              </thead>
              <tbody id="seller-product-count-tbody"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    modal.querySelector(".modal-close").addEventListener("click", () => { modal.style.display = "none"; });
    const brandEl = modal.querySelector("#seller-product-count-brand");
    const n11El = modal.querySelector("#seller-product-count-n11");
    const trendyolEl = modal.querySelector("#seller-product-count-trendyol");
    const hepsiburadaEl = modal.querySelector("#seller-product-count-hepsiburada");
    const statusEl = modal.querySelector("#seller-product-count-status");
    const tbody = modal.querySelector("#seller-product-count-tbody");
    let sellers = [];
    let results = [];
    let editingSellerId = null;
    const setStatus = (text, type) => {
      statusEl.textContent = text || "";
      statusEl.className = "status " + (type || "info");
    };
    const asNumberOrNull = (val) => {
      if (val == null) return null;
      const n = Number(val);
      return Number.isFinite(n) ? n : null;
    };
    const renderTable = () => {
      tbody.innerHTML = "";
      sellers.forEach((s) => {
        const res = results.find((r) => r && r.sellerId === s.id) || {};
        const n11Count = asNumberOrNull(res.n11 && res.n11.count);
        const trendyolCount = asNumberOrNull(res.trendyol && res.trendyol.count);
        const hepsiCount = asNumberOrNull(res.hepsiburada && res.hepsiburada.count);
        const total = [n11Count, trendyolCount, hepsiCount].filter((n) => n != null).reduce((a, b) => a + b, 0);
        const mainUrl = s.n11Url || s.trendyolUrl || s.hepsiburadaUrl || "";
        const tr = document.createElement("tr");
        const brandSafe = escapeHtml(s.brand || "");
        const urlSafe = escapeHtml(mainUrl);
        const totalText = total && Number.isFinite(total) ? String(total) : "-";
        const n11Text = n11Count != null ? String(n11Count) : "-";
        const trendyolText = trendyolCount != null ? String(trendyolCount) : "-";
        const hepsiText = hepsiCount != null ? String(hepsiCount) : "-";
        tr.innerHTML = `
          <td>
            <div><b>${brandSafe || "-"}</b></div>
          </td>
          <td class="seller-product-count-url-cell">
            ${mainUrl ? `<a href="${urlSafe}" target="_blank" rel="noopener">${urlSafe}</a>` : "-"}
          </td>
          <td class="seller-product-count-count">${escapeHtml(n11Text)}</td>
          <td class="seller-product-count-count">${escapeHtml(trendyolText)}</td>
          <td class="seller-product-count-count">${escapeHtml(hepsiText)}</td>
          <td class="seller-product-count-actions-cell">
            <button type="button" data-spc-action="edit" data-spc-id="${escapeHtml(s.id)}">Düzenle</button>
            <button type="button" data-spc-action="delete" data-spc-id="${escapeHtml(s.id)}">Sil</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    };
    tbody.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-spc-action]");
      if (!btn) return;
      const action = btn.getAttribute("data-spc-action");
      const id = btn.getAttribute("data-spc-id");
      if (!id) return;
      if (action === "edit") {
        const s = sellers.find((x) => x.id === id);
        if (!s) return;
        editingSellerId = id;
        brandEl.value = s.brand || "";
        n11El.value = s.n11Url || "";
        trendyolEl.value = s.trendyolUrl || "";
        hepsiburadaEl.value = s.hepsiburadaUrl || "";
        setStatus("Düzenleme modunda. Değişiklikten sonra Satıcı Ekle'ye basın.", "info");
      } else if (action === "delete") {
        const next = sellers.filter((x) => x.id !== id);
        setStatus("Siliniyor...", "info");
        chrome.runtime.sendMessage({ type: "seller-product-count-saveUrls", sellers: next }, (resp) => {
          if (chrome.runtime.lastError) {
            setStatus("Hata: " + chrome.runtime.lastError.message, "error");
            return;
          }
          if (!resp || !resp.ok) {
            setStatus(resp.error || "Silinemedi", "error");
            return;
          }
          sellers = Array.isArray(resp.sellers) ? resp.sellers : [];
          if (editingSellerId === id) {
            editingSellerId = null;
            brandEl.value = "";
            n11El.value = "";
            trendyolEl.value = "";
            hepsiburadaEl.value = "";
          }
          setStatus("Satıcı silindi.", "success");
          renderTable();
        });
      }
    });
    const downloadExcel = (allSellers, allResults) => {
      if (!allSellers || allSellers.length === 0) { setStatus("İndirilecek veri yok", "error"); return; }
      const headers = ["Marka", "Link", "n11", "Trendyol", "Hepsiburada", "Toplam"];
      const rows = [("\uFEFF" + headers.join(";"))];
      allSellers.forEach((s) => {
        const res = allResults.find((r) => r && r.sellerId === s.id) || {};
        const n11Count = asNumberOrNull(res.n11 && res.n11.count);
        const trendyolCount = asNumberOrNull(res.trendyol && res.trendyol.count);
        const hepsiCount = asNumberOrNull(res.hepsiburada && res.hepsiburada.count);
        const total = [n11Count, trendyolCount, hepsiCount].filter((n) => n != null).reduce((a, b) => a + b, 0);
        const mainUrl = s.n11Url || s.trendyolUrl || s.hepsiburadaUrl || "";
        const cells = [
          `"${(s.brand || "").replace(/"/g, '""')}"`,
          `"${(mainUrl || "").replace(/"/g, '""')}"`,
          `"${n11Count != null ? n11Count : "-"}"`,
          `"${trendyolCount != null ? trendyolCount : "-"}"`,
          `"${hepsiCount != null ? hepsiCount : "-"}"`,
          `"${total && Number.isFinite(total) ? total : "-"}"`
        ];
        rows.push(cells.join(";"));
      });
      const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "seller-product-count-" + new Date().toISOString().split("T")[0] + ".csv";
      a.style.visibility = "hidden";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(a.href);
      setStatus("Excel indirildi", "success");
    };
    modal.querySelector("#seller-product-count-add").addEventListener("click", () => {
      const brand = (brandEl.value || "").trim();
      const n11Url = (n11El.value || "").trim();
      const trendyolUrl = (trendyolEl.value || "").trim();
      const hepsiburadaUrl = (hepsiburadaEl.value || "").trim();
      if (!brand && !n11Url && !trendyolUrl && !hepsiburadaUrl) {
        setStatus("En az bir alan doldurun.", "error");
        return;
      }
      if (!n11Url && !trendyolUrl && !hepsiburadaUrl) {
        setStatus("En az bir mağaza URL'i girin.", "error");
        return;
      }
      let next;
      if (editingSellerId) {
        next = sellers.map((s) =>
          s.id === editingSellerId ? { id: s.id, brand, n11Url, trendyolUrl, hepsiburadaUrl } : s
        );
      } else {
        const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
        next = sellers.concat([{ id, brand, n11Url, trendyolUrl, hepsiburadaUrl }]);
      }
      setStatus("Kaydediliyor...", "info");
      chrome.runtime.sendMessage({ type: "seller-product-count-saveUrls", sellers: next }, (resp) => {
        if (chrome.runtime.lastError) { setStatus("Hata: " + chrome.runtime.lastError.message, "error"); return; }
        if (!resp || !resp.ok) { setStatus(resp.error || "Kaydedilemedi", "error"); return; }
        sellers = Array.isArray(resp.sellers) ? resp.sellers : [];
        brandEl.value = "";
        n11El.value = "";
        trendyolEl.value = "";
        hepsiburadaEl.value = "";
        editingSellerId = null;
        setStatus("Satıcı kaydedildi.", "success");
        renderTable();
      });
    });
    modal.querySelector("#seller-product-count-run").addEventListener("click", () => {
      if (!sellers || sellers.length === 0) { setStatus("Önce satıcı ekleyin.", "error"); return; }
      setStatus("Toplanıyor...");
      chrome.runtime.sendMessage({ type: "seller-product-count-scrape", sellers }, (resp) => {
        if (chrome.runtime.lastError) { setStatus("Hata: " + chrome.runtime.lastError.message, "error"); return; }
        if (!resp || !resp.ok) { setStatus(resp.error || "Toplama hatası", "error"); return; }
        results = Array.isArray(resp.results) ? resp.results : [];
        renderTable();
        setStatus("Bitti", "success");
      });
    });
    modal.querySelector("#seller-product-count-update").addEventListener("click", () => {
      setStatus("Kayıtlı satıcılar için güncelleniyor...", "info");
      chrome.runtime.sendMessage({ type: "seller-product-count-getData" }, (resp) => {
        if (chrome.runtime.lastError) { setStatus("Hata: " + chrome.runtime.lastError.message, "error"); return; }
        if (!resp || !resp.ok) { setStatus(resp.error || "Veriler alınamadı", "error"); return; }
        const storedSellers = Array.isArray(resp.sellers) ? resp.sellers : [];
        if (!storedSellers.length) {
          setStatus("Kayıtlı satıcı bulunamadı.", "error");
          return;
        }
        sellers = storedSellers;
        chrome.runtime.sendMessage({ type: "seller-product-count-scrape", sellers }, (resp2) => {
          if (chrome.runtime.lastError) { setStatus("Hata: " + chrome.runtime.lastError.message, "error"); return; }
          if (!resp2 || !resp2.ok) { setStatus(resp2.error || "Toplama hatası", "error"); return; }
          results = Array.isArray(resp2.results) ? resp2.results : [];
          renderTable();
          setStatus("Kayıtlı satıcılar güncellendi.", "success");
        });
      });
    });
    modal.querySelector("#seller-product-count-excel").addEventListener("click", () => {
      if (!sellers || sellers.length === 0) {
        setStatus("Önce satıcı ekleyin.", "error");
        return;
      }
      downloadExcel(sellers, results);
    });
    modal.querySelector("#seller-product-count-clear").addEventListener("click", () => {
      if (!confirm("Tüm kaydedilmiş URL'ler ve sonuçlar silinecek. Emin misiniz?")) return;
      setStatus("Temizleniyor...");
      chrome.runtime.sendMessage({ type: "seller-product-count-clearData" }, (resp) => {
        if (chrome.runtime.lastError) { setStatus("Hata: " + chrome.runtime.lastError.message, "error"); return; }
        if (!resp || !resp.ok) { setStatus(resp.error || "Temizlenemedi", "error"); return; }
        sellers = [];
        results = [];
        tbody.innerHTML = "";
        setStatus("Tüm veriler temizlendi", "success");
      });
    });
    modal.querySelector("#seller-product-count-export").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "seller-product-count-getData" }, (resp) => {
        if (chrome.runtime.lastError) { setStatus("Hata: " + chrome.runtime.lastError.message, "error"); return; }
        if (!resp || !resp.ok) { setStatus(resp.error || "Veri alınamadı", "error"); return; }
        const payload = {
          sellers: Array.isArray(resp.sellers) ? resp.sellers : [],
          results: Array.isArray(resp.results) ? resp.results : [],
          exportedAt: new Date().toISOString()
        };
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "seller-product-count-backup-" + new Date().toISOString().slice(0, 10) + ".json";
        a.style.visibility = "hidden";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(a.href);
        setStatus("Veri indirildi. Eklenti güncellendiğinde 'Veriyi Yükle' ile geri yükleyebilirsiniz.", "success");
      });
    });
    const importInput = modal.querySelector("#seller-product-count-import-input");
    modal.querySelector("#seller-product-count-import").addEventListener("click", () => importInput.click());
    importInput.addEventListener("change", () => {
      const file = importInput.files && importInput.files[0];
      if (!file) return;
      setStatus("Yükleniyor...", "info");
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = JSON.parse(reader.result);
          const sellersList = Array.isArray(data.sellers) ? data.sellers : [];
          const resultsList = Array.isArray(data.results) ? data.results : [];
          if (sellersList.length === 0 && resultsList.length === 0) {
            setStatus("Dosyada geçerli satıcı veya sonuç bulunamadı.", "error");
            importInput.value = "";
            return;
          }
          chrome.runtime.sendMessage({ type: "seller-product-count-restore", sellers: sellersList, results: resultsList }, (resp) => {
            if (chrome.runtime.lastError) { setStatus("Hata: " + chrome.runtime.lastError.message, "error"); importInput.value = ""; return; }
            if (!resp || !resp.ok) { setStatus(resp.error || "Geri yükleme başarısız", "error"); importInput.value = ""; return; }
            sellers = Array.isArray(resp.sellers) ? resp.sellers : [];
            results = Array.isArray(resp.results) ? resp.results : [];
            renderTable();
            setStatus("Veri geri yüklendi. " + sellers.length + " satıcı.", "success");
            importInput.value = "";
          });
        } catch (e) {
          setStatus("Geçersiz JSON: " + (e && e.message ? e.message : "Bilinmeyen hata"), "error");
          importInput.value = "";
        }
      };
      reader.readAsText(file, "UTF-8");
    });
    document.body.appendChild(modal);
    chrome.runtime.sendMessage({ type: "seller-product-count-getData" }, (resp) => {
      if (resp && resp.ok) {
        sellers = Array.isArray(resp.sellers) ? resp.sellers : [];
        results = Array.isArray(resp.results) ? resp.results : [];
        renderTable();
      }
    });
  }
  modal.style.display = "flex";
};

const openProductDealControllerModal = () => {
  let modal = document.getElementById(PRODUCT_DEAL_CONTROLLER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PRODUCT_DEAL_CONTROLLER_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.innerHTML = `
      <div class="modal-card product-deal-controller-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Product Deal Controller</div>
        </div>
        <div class="product-deal-controller-body">
          <label class="product-deal-controller-multi-wrap">
            <input type="checkbox" id="product-deal-controller-multi-checkbox" class="product-deal-controller-multi-checkbox" />
            <span>Çoklu dosya birleştir</span>
          </label>
          <div class="product-deal-controller-drop-wrap">
            <input type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" multiple id="product-deal-controller-file-input" class="product-deal-controller-file-input" />
            <div class="product-deal-controller-drop-zone" id="product-deal-controller-drop-zone">
              <p class="product-deal-controller-drop-text">Product Deal Excel dosyasını (.xlsx) buraya sürükleyin veya <strong>Gözat</strong> ile seçin. Çoklu birleştir seçiliyse birden fazla dosya seçebilirsiniz.</p>
            </div>
            <button type="button" class="product-deal-controller-browse-btn" id="product-deal-controller-browse-btn">Gözat</button>
          </div>
          <div class="status info" id="product-deal-controller-status">Excel yükleyin. Tüm hatalar L kolonunda virgülle yazılacak (Duplicate Pims ID, A=K eşit, D-J boş/0/geçersiz, sıralama hataları).</div>
          <div class="product-deal-controller-actions">
            <button type="button" class="product-deal-controller-analyze-btn" id="product-deal-controller-analyze-btn" disabled>Analiz Et</button>
            <button type="button" class="product-deal-controller-download-btn" id="product-deal-controller-download-btn" disabled>Düzeltilmiş Dosyayı İndir (XLSX)</button>
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    modal.querySelector(".modal-close").addEventListener("click", () => { modal.style.display = "none"; });
    const fileInput = modal.querySelector("#product-deal-controller-file-input");
    const dropZone = modal.querySelector("#product-deal-controller-drop-zone");
    const browseBtn = modal.querySelector("#product-deal-controller-browse-btn");
    const analyzeBtn = modal.querySelector("#product-deal-controller-analyze-btn");
    const downloadBtn = modal.querySelector("#product-deal-controller-download-btn");
    browseBtn.addEventListener("click", () => fileInput.click());
    dropZone.addEventListener("click", () => fileInput.click());
    dropZone.addEventListener("dragover", (e) => { e.preventDefault(); e.stopPropagation(); dropZone.classList.add("product-deal-controller-drop-zone-active"); });
    dropZone.addEventListener("dragleave", (e) => { e.preventDefault(); e.stopPropagation(); dropZone.classList.remove("product-deal-controller-drop-zone-active"); });
    dropZone.addEventListener("drop", (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove("product-deal-controller-drop-zone-active");
      const files = e.dataTransfer?.files;
      if (files && files.length > 0) handleProductDealControllerFiles(Array.from(files), modal);
    });
    fileInput.addEventListener("change", () => {
      const files = fileInput.files;
      if (files && files.length > 0) handleProductDealControllerFiles(Array.from(files), modal);
      fileInput.value = "";
    });
    analyzeBtn.addEventListener("click", () => runProductDealControllerAnalyze(modal));
    downloadBtn.addEventListener("click", () => downloadProductDealControllerExcel(modal));
    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

const openPromotionThemePinModal = () => {
  let modal = document.getElementById(PROMOTION_THEME_PIN_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PROMOTION_THEME_PIN_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.innerHTML = `
      <div class="modal-card promotion-theme-pin-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Promotion Theme Pin</div>
        </div>
        <div class="promotion-theme-pin-body">
          <div id="promotion-theme-pin-upload-area" class="promotion-theme-pin-upload-area">
            <h3>Görsel Yükle</h3>
            <p>Dosya seçmek için tıklayın veya bir gorseli buraya sürükleyin.</p>
            <input type="file" id="promotion-theme-pin-file-input" accept="image/*" style="display:none;" />
            <div class="promotion-theme-pin-divider">veya</div>
            <div class="promotion-theme-pin-url-row">
              <input type="text" id="promotion-theme-pin-image-url" placeholder="Gorsel URL girin" class="promotion-theme-pin-input" />
              <button type="button" id="promotion-theme-pin-load-url-btn" class="promotion-theme-pin-url-btn">URL'den Yükle</button>
            </div>
          </div>
          <div id="promotion-theme-pin-image-wrap" class="promotion-theme-pin-image-wrap">
            <img id="promotion-theme-pin-image" alt="Yüklenen görsel" />
            <div id="promotion-theme-pin-mouse-pos" class="promotion-theme-pin-mouse-pos">X: 0px, Y: 0px</div>
            <div id="promotion-theme-pin-image-info" class="promotion-theme-pin-image-info"></div>
          </div>
          <div id="promotion-theme-pin-coords-card" class="promotion-theme-pin-coords-card hidden">
            <h3>Koordinatlar</h3>
            <div id="promotion-theme-pin-coords-list" class="promotion-theme-pin-coords-list">
              <p id="promotion-theme-pin-empty">Henüz pin eklenmedi. Görsele tıklayarak pin ekleyin.</p>
            </div>
            <div class="promotion-theme-pin-controls">
              <button type="button" id="promotion-theme-pin-clear-btn" class="promotion-theme-pin-clear-btn">Tum Pinleri Temizle</button>
            </div>
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    modal.querySelector(".modal-close").addEventListener("click", () => { modal.style.display = "none"; });

    const uploadArea = modal.querySelector("#promotion-theme-pin-upload-area");
    const fileInput = modal.querySelector("#promotion-theme-pin-file-input");
    const urlInput = modal.querySelector("#promotion-theme-pin-image-url");
    const loadUrlBtn = modal.querySelector("#promotion-theme-pin-load-url-btn");
    const imageWrap = modal.querySelector("#promotion-theme-pin-image-wrap");
    const imageEl = modal.querySelector("#promotion-theme-pin-image");
    const mousePos = modal.querySelector("#promotion-theme-pin-mouse-pos");
    const imageInfo = modal.querySelector("#promotion-theme-pin-image-info");
    const coordsCard = modal.querySelector("#promotion-theme-pin-coords-card");
    const coordsList = modal.querySelector("#promotion-theme-pin-coords-list");
    const clearBtn = modal.querySelector("#promotion-theme-pin-clear-btn");

    let pins = [];
    let pinSeq = 1;
    let draggingPinId = null;
    let dragOffsetX = 0;
    let dragOffsetY = 0;

    const getRelativePoint = (clientX, clientY) => {
      const rect = imageEl.getBoundingClientRect();
      if (!rect.width || !rect.height) return null;
      let displayX = clientX - rect.left;
      let displayY = clientY - rect.top;
      displayX = Math.max(0, Math.min(rect.width, displayX));
      displayY = Math.max(0, Math.min(rect.height, displayY));
      const xPercent = (displayX / rect.width) * 100;
      const yPercent = (displayY / rect.height) * 100;
      const xPx = Math.round((xPercent / 100) * imageEl.naturalWidth);
      const yPx = Math.round((yPercent / 100) * imageEl.naturalHeight);
      return { displayX, displayY, xPercent, yPercent, xPx, yPx, displayWidth: rect.width, displayHeight: rect.height };
    };

    const updatePinElementPosition = (pinObj) => {
      if (!pinObj || !pinObj.el) return;
      const rect = imageEl.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const left = (pinObj.xPercent / 100) * rect.width;
      const top = (pinObj.yPercent / 100) * rect.height;
      pinObj.el.style.left = `${left}px`;
      pinObj.el.style.top = `${top}px`;
    };

    const removeAllPinElements = () => {
      const existing = imageWrap.querySelectorAll(".promotion-theme-pin-pin");
      existing.forEach((el) => el.remove());
    };

    const renderPins = () => {
      removeAllPinElements();
      pins.forEach((pinObj) => {
        const pinEl = document.createElement("div");
        pinEl.className = "promotion-theme-pin-pin";
        pinEl.dataset.pinId = String(pinObj.id);
        pinEl.innerHTML = `<span>${pinObj.id}</span>`;
        pinObj.el = pinEl;
        updatePinElementPosition(pinObj);
        pinEl.addEventListener("mousedown", (event) => {
          event.preventDefault();
          event.stopPropagation();
          draggingPinId = pinObj.id;
          const pinRect = pinEl.getBoundingClientRect();
          dragOffsetX = event.clientX - (pinRect.left + pinRect.width / 2);
          dragOffsetY = event.clientY - (pinRect.top + pinRect.height / 2);
          pinEl.classList.add("dragging");
        });
        imageWrap.appendChild(pinEl);
      });
    };

    const renderCoords = () => {
      if (!pins.length) {
        coordsList.innerHTML = '<p id="promotion-theme-pin-empty">Henuz pin eklenmedi. Gorsele tiklayarak pin ekleyin.</p>';
        return;
      }
      const html = pins
        .map((p) => (
          `<div class="promotion-theme-pin-coord-item" data-pin-id="${p.id}">
            <div class="pin-indicator">${p.id}</div>
            <input class="coordinate-input" type="text" readonly value="X: ${p.xPx}px, Y: ${p.yPx}px" />
            <button type="button" class="delete-pin">Sil</button>
          </div>`
        ))
        .join("");
      coordsList.innerHTML = html;
      coordsList.querySelectorAll(".delete-pin").forEach((btn) => {
        btn.addEventListener("click", () => {
          const row = btn.closest(".promotion-theme-pin-coord-item");
          const pinId = row ? Number(row.dataset.pinId) : NaN;
          pins = pins.filter((p) => p.id !== pinId);
          renderPins();
          renderCoords();
        });
      });
    };

    const addPin = (point) => {
      pins.push({
        id: pinSeq,
        xPercent: point.xPercent,
        yPercent: point.yPercent,
        xPx: point.xPx,
        yPx: point.yPx,
        el: null
      });
      pinSeq += 1;
      renderPins();
      renderCoords();
    };

    const resetPins = () => {
      pins = [];
      pinSeq = 1;
      draggingPinId = null;
      renderPins();
      renderCoords();
    };

    const applyImage = (src) => {
      if (!src) return;
      imageEl.src = src;
    };

    imageEl.addEventListener("load", () => {
      imageWrap.style.display = "block";
      coordsCard.classList.remove("hidden");
      const rect = imageEl.getBoundingClientRect();
      imageInfo.textContent = `Orijinal: ${imageEl.naturalWidth} x ${imageEl.naturalHeight}px | Gorunen: ${Math.round(rect.width)} x ${Math.round(rect.height)}px`;
      resetPins();
    });

    imageEl.addEventListener("error", () => {
      alert("Gorsel yuklenemedi.");
    });

    uploadArea.addEventListener("click", () => fileInput.click());
    uploadArea.addEventListener("dragover", (e) => {
      e.preventDefault();
      uploadArea.classList.add("promotion-theme-pin-upload-active");
    });
    uploadArea.addEventListener("dragleave", (e) => {
      e.preventDefault();
      uploadArea.classList.remove("promotion-theme-pin-upload-active");
    });
    uploadArea.addEventListener("drop", (e) => {
      e.preventDefault();
      uploadArea.classList.remove("promotion-theme-pin-upload-active");
      const files = e.dataTransfer && e.dataTransfer.files ? e.dataTransfer.files : null;
      if (!files || !files.length) return;
      const file = files[0];
      if (!file.type || !file.type.startsWith("image/")) return;
      const reader = new FileReader();
      reader.onload = () => applyImage(String(reader.result || ""));
      reader.readAsDataURL(file);
    });

    fileInput.addEventListener("change", () => {
      const file = fileInput.files && fileInput.files[0];
      if (!file) return;
      if (!file.type || !file.type.startsWith("image/")) {
        fileInput.value = "";
        return;
      }
      const reader = new FileReader();
      reader.onload = () => applyImage(String(reader.result || ""));
      reader.readAsDataURL(file);
      fileInput.value = "";
    });

    loadUrlBtn.addEventListener("click", () => {
      const url = String(urlInput.value || "").trim();
      if (!url) return;
      applyImage(url);
    });
    urlInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        loadUrlBtn.click();
      }
    });

    imageWrap.addEventListener("mousemove", (e) => {
      if (!imageEl.src) return;
      const pos = getRelativePoint(e.clientX, e.clientY);
      if (!pos) return;
      mousePos.style.display = "block";
      mousePos.textContent = `X: ${pos.xPx}px, Y: ${pos.yPx}px`;
    });
    imageWrap.addEventListener("mouseleave", () => {
      mousePos.style.display = "none";
    });

    imageWrap.addEventListener("click", (e) => {
      if (draggingPinId != null) return;
      if (e.target && e.target.classList && e.target.classList.contains("promotion-theme-pin-pin")) return;
      if (e.target !== imageEl) return;
      const pos = getRelativePoint(e.clientX, e.clientY);
      if (!pos) return;
      addPin(pos);
    });

    document.addEventListener("mousemove", (e) => {
      if (draggingPinId == null) return;
      const pinObj = pins.find((p) => p.id === draggingPinId);
      if (!pinObj) return;
      const rect = imageEl.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const pos = getRelativePoint(e.clientX - dragOffsetX, e.clientY - dragOffsetY);
      if (!pos) return;
      pinObj.xPercent = pos.xPercent;
      pinObj.yPercent = pos.yPercent;
      pinObj.xPx = pos.xPx;
      pinObj.yPx = pos.yPx;
      updatePinElementPosition(pinObj);
      renderCoords();
    });

    document.addEventListener("mouseup", () => {
      if (draggingPinId == null) return;
      const pinObj = pins.find((p) => p.id === draggingPinId);
      if (pinObj && pinObj.el) pinObj.el.classList.remove("dragging");
      draggingPinId = null;
    });

    window.addEventListener("resize", () => {
      const rect = imageEl.getBoundingClientRect();
      if (imageEl.naturalWidth && imageEl.naturalHeight && rect.width && rect.height) {
        imageInfo.textContent = `Orijinal: ${imageEl.naturalWidth} x ${imageEl.naturalHeight}px | Gorunen: ${Math.round(rect.width)} x ${Math.round(rect.height)}px`;
      }
      renderPins();
    });

    clearBtn.addEventListener("click", () => {
      resetPins();
    });

    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

const openSoAnnouncementPopupModal = () => {
  let modal = document.getElementById(SO_ANNOUNCEMENT_POPUP_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = SO_ANNOUNCEMENT_POPUP_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.style.position = "fixed";
    modal.style.inset = "0";
    modal.style.zIndex = "2147483647";
    modal.style.display = "none";
    modal.style.alignItems = "center";
    modal.style.justifyContent = "center";
    modal.style.background = "rgba(0, 0, 0, 0.64)";
    modal.innerHTML = `
      <div class="modal-card so-announcement-popup-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">SO Duyuru & Popup</div>
        </div>
        <div class="so-announcement-popup-body">
          <div id="so-announcement-popup-drop-zone" class="so-announcement-popup-drop-zone" role="button" tabindex="0">
            <div class="so-announcement-popup-drop-title">mailing html dosyasını buraya bırakın</div>
            <div class="so-announcement-popup-drop-subtitle">veya dosya seçmek için tıklayın</div>
            <input type="file" id="so-announcement-popup-file-input" class="so-announcement-popup-file-input" accept=".html,text/html" />
          </div>
          <div class="so-announcement-popup-actions">
            <button type="button" id="so-announcement-popup-download-btn" class="download-btn" disabled>SO Popup & Duyuru</button>
            <button type="button" id="so-announcement-popup-ssc-btn" class="download-btn" disabled>SSC</button>
          </div>
          <div id="so-announcement-popup-status" class="status info"></div>
          <div id="so-announcement-popup-output-wrap" style="display:none;">
            <label for="so-announcement-popup-output"><b>Oluşturulan HTML</b></label>
            <textarea id="so-announcement-popup-output" class="akakce-crawler-textarea" rows="10" readonly></textarea>
          </div>
        </div>
      </div>
    `;

    const closeBtn = modal.querySelector(".modal-close");
    const dropZone = modal.querySelector("#so-announcement-popup-drop-zone");
    const fileInput = modal.querySelector("#so-announcement-popup-file-input");
    const downloadBtn = modal.querySelector("#so-announcement-popup-download-btn");
    const sscBtn = modal.querySelector("#so-announcement-popup-ssc-btn");
    const statusEl = modal.querySelector("#so-announcement-popup-status");
    const outputWrap = modal.querySelector("#so-announcement-popup-output-wrap");
    const outputEl = modal.querySelector("#so-announcement-popup-output");

    let generatedHtml = "";
    let generatedSscHtml = "";
    let extractedMailingInnerHtml = "";

    const popupTemplate = `<!doctypehtml>
<html lang=tr><title>n11</title>
<meta charset=UTF-8>
<meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover" name=viewport>
<div style="font-family:Arial;font-size:13px;line-height:1.5" class="modal-contentHtml">
    <style>.lightBox .content{padding:10px}.popup-text{font-size:14px;line-height:1.32em;text-align:left}.modal-contentHtml a{color:#5d3ebc;display:inline}.modal-contentHtml ul{list-style:disc;margin:10px 0 16px 18px;padding:0}.modal-contentHtml b{font-weight:600}.popup-text table{border-collapse:collapse;border-spacing:0;width:100%}.popup-text td{padding:10px;border-top:1px solid #dedede}.popup-text table tr>td:first-child{font-weight:700}.popup-text th{background-color:#5d3ebc;padding:10px;color:#fff}</style>
    <div style="padding:8px;line-height:24px;text-align:left!important" class="popup-text">
{{POPUP_TEXT}}
    </div>
</div>`;
    const sscTemplate = `<!DOCTYPE html><html lang="tr"><head><title>n11</title><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover"></head><body></body></html>`;

    const setStatus = (message, type = "info") => {
      statusEl.textContent = message || "";
      statusEl.className = `status ${type}`;
      statusEl.style.display = message ? "block" : "none";
    };

    const minifyHtml = (html) => {
      if (!html) return "";
      return String(html)
        .replace(/<!--[\s\S]*?-->/g, "")
        .replace(/\r?\n|\r|\t/g, "")
        .replace(/>\s+</g, "><")
        .trim();
    };

    const buildSscHtml = (innerHtml) => {
      try {
        const doc = new DOMParser().parseFromString(sscTemplate, "text/html");
        if (!doc || !doc.body) return "";
        doc.body.insertAdjacentHTML("beforeend", innerHtml);
        const serialized = `<!DOCTYPE html>${doc.documentElement.outerHTML}`;
        return minifyHtml(serialized);
      } catch {
        return "";
      }
    };

    const parseMailingContent = (rawHtml) => {
      try {
        const doc = new DOMParser().parseFromString(String(rawHtml || ""), "text/html");
        const targetTd = doc.querySelector("td.mailing-content, td.mail-content");
        if (!targetTd) return null;
        return String(targetTd.innerHTML || "").trim();
      } catch {
        return null;
      }
    };

    const handleHtmlText = (rawHtml) => {
      const innerHtml = parseMailingContent(rawHtml);
      if (!innerHtml) {
        setStatus("mailing-content / mail-content alanı bulunamadı.", "error");
        generatedHtml = "";
        generatedSscHtml = "";
        extractedMailingInnerHtml = "";
        downloadBtn.disabled = true;
        sscBtn.disabled = true;
        outputWrap.style.display = "none";
        outputEl.value = "";
        return;
      }
      extractedMailingInnerHtml = innerHtml;
      generatedHtml = popupTemplate.replace("{{POPUP_TEXT}}", innerHtml);
      generatedSscHtml = buildSscHtml(innerHtml);
      outputEl.value = generatedHtml;
      outputWrap.style.display = "block";
      downloadBtn.disabled = false;
      sscBtn.disabled = !generatedSscHtml;
      setStatus("Popup HTML hazırlandı.", "success");
    };

    const readFileAsText = (file) =>
      new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = () => reject(new Error("Dosya okunamadı."));
        reader.readAsText(file, "UTF-8");
      });

    const handleFile = async (file) => {
      if (!file) return;
      if (!/\.html?$/i.test(file.name || "")) {
        setStatus("Lütfen HTML dosyası yükleyin.", "error");
        return;
      }
      setStatus("Dosya okunuyor...", "info");
      try {
        const htmlText = await readFileAsText(file);
        handleHtmlText(htmlText);
      } catch (err) {
        setStatus((err && err.message) || "Dosya okunamadı.", "error");
      }
    };

    dropZone.addEventListener("click", () => fileInput.click());
    dropZone.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        fileInput.click();
      }
    });
    dropZone.addEventListener("dragover", (e) => {
      e.preventDefault();
      dropZone.classList.add("so-announcement-popup-drop-zone-active");
    });
    dropZone.addEventListener("dragleave", (e) => {
      e.preventDefault();
      dropZone.classList.remove("so-announcement-popup-drop-zone-active");
    });
    dropZone.addEventListener("drop", (e) => {
      e.preventDefault();
      dropZone.classList.remove("so-announcement-popup-drop-zone-active");
      const file = e.dataTransfer?.files && e.dataTransfer.files[0] ? e.dataTransfer.files[0] : null;
      handleFile(file);
    });
    fileInput.addEventListener("change", () => {
      const file = fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;
      handleFile(file);
      fileInput.value = "";
    });

    downloadBtn.addEventListener("click", () => {
      if (!generatedHtml) {
        setStatus("Önce mailing.html yükleyin.", "error");
        return;
      }
      const blob = new Blob([generatedHtml], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `so-popup-${new Date().toISOString().slice(0, 10)}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setStatus("HTML indirildi.", "success");
    });

    sscBtn.addEventListener("click", () => {
      if (!extractedMailingInnerHtml) {
        setStatus("Önce mailing.html yükleyin.", "error");
        return;
      }
      if (!generatedSscHtml) {
        generatedSscHtml = buildSscHtml(extractedMailingInnerHtml);
      }
      if (!generatedSscHtml) {
        setStatus("SSC HTML oluşturulamadı.", "error");
        return;
      }
      const blob = new Blob([generatedSscHtml], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `so-popup-ssc-${new Date().toISOString().slice(0, 10)}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setStatus("SSC HTML indirildi.", "success");
    });

    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    closeBtn.addEventListener("click", () => { modal.style.display = "none"; });
    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

const openBannerMailingModal = () => {
  let modal = document.getElementById(BANNER_MAILING_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = BANNER_MAILING_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.style.position = "fixed";
    modal.style.inset = "0";
    modal.style.zIndex = "2147483647";
    modal.style.display = "none";
    modal.style.alignItems = "center";
    modal.style.justifyContent = "center";
    modal.style.background = "rgba(0, 0, 0, 0.64)";
    modal.innerHTML = `
      <div class="modal-card banner-mailing-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Banner Mailing</div>
        </div>
        <div class="banner-mailing-body">
          <div class="akakce-crawler-form banner-mailing-form">
            <div>
              <label for="banner-mailing-image-url">Banner Görsel URL</label>
              <input type="text" id="banner-mailing-image-url" class="akakce-crawler-textarea banner-mailing-input" placeholder="https://n11scdn.akamaized.net/a1/org/.../image.jpg" />
            </div>
            <div>
              <label for="banner-mailing-link-url">Link URL</label>
              <input type="text" id="banner-mailing-link-url" class="akakce-crawler-textarea banner-mailing-input" placeholder="https://www.n11.com/arama?promotions=2012417" />
            </div>
            <div>
              <label for="banner-mailing-campaign-param">Kampanya Parametresi</label>
              <input type="text" id="banner-mailing-campaign-param" class="akakce-crawler-textarea banner-mailing-input" placeholder="kasim" />
            </div>
            <div>
              <label for="banner-mailing-date-param">Tarih (YYYYMMDD)</label>
              <input type="text" id="banner-mailing-date-param" class="akakce-crawler-textarea banner-mailing-input" placeholder="20251109" />
            </div>
            <div class="akakce-crawler-buttons">
              <button type="button" class="akakce-run-btn" id="banner-mailing-generate-btn">Oluştur</button>
              <button type="button" class="akakce-run-btn" id="banner-mailing-preview-btn" disabled>Preview</button>
              <button type="button" class="akakce-run-btn" id="banner-mailing-copy-btn" disabled>HTML Kopyala</button>
              <button type="button" class="download-btn" id="banner-mailing-download-btn" disabled>HTML İndir</button>
              <button type="button" class="download-btn" id="banner-mailing-clear-btn">Temizle</button>
            </div>
          </div>
          <div id="banner-mailing-status" class="status info"></div>
          <div id="banner-mailing-output-wrap" style="display:none;">
            <label for="banner-mailing-output"><b>Oluşturulan HTML</b></label>
            <textarea id="banner-mailing-output" class="akakce-crawler-textarea" rows="12" readonly placeholder="HTML burada görünecek..."></textarea>
          </div>
          <div id="banner-mailing-preview-wrap" style="display:none;">
            <label><b>Preview</b></label>
            <iframe id="banner-mailing-preview-frame"></iframe>
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    modal.querySelector(".modal-close").addEventListener("click", () => { modal.style.display = "none"; });

    const BANNER_MAIL_TEMPLATE = `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>n11</title>
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/>
    <meta content="telephone=no" name="format-detection"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
    <style type="text/css"> body { margin: 0; padding: 0; width: 100% !important; -webkit-text-size-adjust: none; -ms-text-size-adjust: none } .ReadMsgBody, .ExternalClass { width: 100% } html { -webkit-text-size-adjust: none } .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100% } table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt } table td { border-collapse: collapse } #outlook a { padding: 0 } img { outline: none; text-decoration: none } a img { border: none; height: auto; max-height: none; max-width: 100% } .preheader { display: none !important } @media only screen and (max-device-width: 861px) { .cn { text-align: center !important } td[class="block"] { border-bottom: 1px solid #ebebeb; display: block !important; padding: 20px 0 !important } td[class="fullblocker"] { display: block !important; width: 100% !important } img[class="full"] { display: block !important; width: 100% !important } a[href="tel"], a[href="sms"] { text-decoration: none !important; color: #000 !important; pointer-events: none !important; cursor: default !important } .main { text-align: left !important; width: 98% !important } .tableContainer { width: 100% !important } .fs-small { font-size: 12px; } } </style>
</head>
<body yahoo="fix" style="margin:0;padding:0;background-color:#ffffff;width:100%!important;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;" bgcolor="#F1EEE7">
<table border="0" class="main" cellspacing="0" cellpadding="0" width="100%"><tr><td align="center" style="color:#f0f0f0; font-family:Arial;font-size: 1px; line-height:1px"><span class="preheader">Milyonlarca ürün, binlerce mağaza ve avantajlı alışveriş için doğru yerdesiniz.</span></td></tr></table>
<table align="center" bgcolor="#F1EEE7" border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr><td height="10"></td></tr>
    <tr><td align="center"><table align="center" bgcolor="#FFFFFF" border="0" cellpadding="0" cellspacing="0" width="700" class="main" style="border-radius: 8px;"><tbody><tr><td align="center" style="padding: 12px 0; "><a href="https://www.n11.com" target="_blank"><img src="https://n11scdn.akamaized.net/a1/org/25/11/09/62/44/17/33/46/80/82/71/77/87834046114606857690.png" alt="n11" border="0" width="144" style="display: block"></a></td></tr></tbody></table></td></tr>
    <tr>
        <td align="center">
            <table align="center" bgcolor="#FFFFFF" border="0" cellpadding="0" cellspacing="0" width="700" class="main" style="border-radius: 8px;">
                <tbody>
                <tr>
                    <td style="color:#242424; font-family: Arial; font-size: 16px; line-height: 22px; padding: 0 25px 30px 25px; border-radius: 8px;" valign="top">
                        <a href="{{ link }}" target="_blank"><img src="{{ imageUrl }}" alt="n11" border="0" width="100%"></a>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr><td height="16"></td></tr>
    <tr><td align="center"><table align="center" bgcolor="#FFD9FB" border="0" cellpadding="0" cellspacing="0" width="700" class="main" style="border-radius: 8px;font-family: Arial; font-size: 12px;"><tr><td style="color:#242424; font-family: Arial; font-size: 13px; line-height: 22px; padding: 16px; border-radius: 8px;"><p style="font-size: 16px; font-weight: bold; margin: 0 0 5px 0; padding: 0; line-height: 22px; text-align: center">Daha iyi bir deneyim için uygulamayı indir</p><table align="center" border="0" cellspacing="0" cellpadding="2"><tr><td width="33.333%" align="right"><a href="https://app.adjust.io/y2muq8" style="text-decoration:none;display:block;"><img src="https://n11scdn.akamaized.net/a1/org/23/09/01/46/82/05/72/03/76/26/26/37/31434631753252291647.png" alt="" border="0" width="110" style="display: block;"></a></td><td align="center" width="33.333%"><a href="https://app.adjust.io/8033xn" style="text-decoration:none;display:block;"><img src="https://n11scdn.akamaized.net/a1/org/23/09/01/85/95/83/95/77/18/31/53/66/25092729677829915093.png" alt="" border="0" width="110" style="display: block;"></a></td><td align="left" width="33.333%"><a href="https://appgallery.huawei.com/#/app/C101803793" rel="nofollow" target="_blank" style="text-decoration:none;display:block;"><img src="https://n11scdn.akamaized.net/a1/org/23/09/01/92/09/82/87/08/01/39/08/64/33722138255151087640.png" alt="" border="0" width="110" style="display: block;"></a></td></tr></table></td></tr></table></td></tr>
    <tr><td height="32"></td></tr>
    <tr>
        <td align="center">
            <table align="center" border="0" cellpadding="0" cellspacing="0" width="700" class="main" style="border-radius: 8px;font-family: Arial; font-size: 12px;">
                <tr>
                    <td style="color:#242424; font-family: Arial; font-size: 13px; line-height: 22px; padding: 16px; border-radius: 8px;">
                        <p style="font-size: 16px; font-weight: bold; margin: 0 0 5px 0; padding: 0; line-height: 22px; text-align: center">Bizi takip et!</p>
                        <table align="center" border="0" cellspacing="0" cellpadding="6">
                            <tr>
                                <td><a href="https://www.facebook.com/n11official" target="_blank" style="text-decoration: none"><img src="https://n11scdn.akamaized.net/a1/org/23/09/01/63/50/36/37/66/61/38/40/10/36318593434160576050.png" alt="" border="0" width="36"></a></td>
                                <td><a href="https://x.com/n11official" target="_blank" style="text-decoration: none"><img src="https://n11scdn.akamaized.net/a1/org/25/03/20/63/42/51/82/58/00/07/63/71/11147275503794501710.png" alt="" border="0" width="36"></a></td>
                                <td><a href="https://www.instagram.com/n11resmi/" target="_blank" style="text-decoration: none"><img src="https://n11scdn.akamaized.net/a1/org/23/09/01/66/57/91/87/71/27/65/90/26/04159153154365606028.png" alt="" border="0" width="36"></a></td>
                                <td><a href="https://www.youtube.com/user/n11comkanal" target="_blank" style="text-decoration: none"><img src="https://n11scdn.akamaized.net/a1/org/23/09/01/91/39/15/46/98/12/28/81/44/16274595379680427923.png" border="0" alt="" width="36"></a></td>
                            </tr>
                        </table>
                        <br>
                        <p style="color:#6B6B6B; font-size: 12px; margin: 0; padding: 0; text-align: center">Ürün fiyatları, promosyonlar ve promosyon tarihleri zaman içinde değişiklik gösterebilir. <br> Promosyon ve duyuru maili almak istemiyorsan '<a href="https://www.n11.com/hesabim/iletisim-tercihlerim" title="Üyelik Bilgileri" target="_blank" style="color:#6B6B6B; text-decoration: none;">Üyelik Bilgileri</a>' alanından tercihlerini değiştirebilirsin.</p>
                        <br>
                        <p style="color:#6B6B6B; font-size: 12px; margin: 0; padding: 0; text-align: center">n11 Elektronik Ticaret ve Bilişim Hizmetleri A.Ş. <br>
                            Reşitpaşa Mah. Katar Cad. İTÜ Arı Teknokent 3 Binası Blok No: 4
                            İç Kapı No: 902 Sarıyer/İstanbul - 34467 <br> Mersis No: 0309034533200013</p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr><td height="32"></td></tr>
</table>
</body>
</html>`;
    const CID_VALUE = "400000";
    const imageUrlInput = modal.querySelector("#banner-mailing-image-url");
    const linkUrlInput = modal.querySelector("#banner-mailing-link-url");
    const campaignParamInput = modal.querySelector("#banner-mailing-campaign-param");
    const dateParamInput = modal.querySelector("#banner-mailing-date-param");
    const generateBtn = modal.querySelector("#banner-mailing-generate-btn");
    const previewBtn = modal.querySelector("#banner-mailing-preview-btn");
    const copyBtn = modal.querySelector("#banner-mailing-copy-btn");
    const downloadBtn = modal.querySelector("#banner-mailing-download-btn");
    const clearBtn = modal.querySelector("#banner-mailing-clear-btn");
    const statusEl = modal.querySelector("#banner-mailing-status");
    const outputWrap = modal.querySelector("#banner-mailing-output-wrap");
    const previewWrap = modal.querySelector("#banner-mailing-preview-wrap");
    const outputEl = modal.querySelector("#banner-mailing-output");
    const previewFrame = modal.querySelector("#banner-mailing-preview-frame");
    let generatedHTML = "";
    const setStatus = (message, type = "info") => {
      statusEl.textContent = message || "";
      statusEl.className = `status ${type}`;
      statusEl.style.display = message ? "block" : "none";
    };
    const today = new Date();
    const todayFormatted = `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, "0")}${String(today.getDate()).padStart(2, "0")}`;
    dateParamInput.value = todayFormatted;

    generateBtn.addEventListener("click", () => {
      const imageUrl = String(imageUrlInput.value || "").trim();
      const linkUrl = String(linkUrlInput.value || "").trim();
      const campaignParam = String(campaignParamInput.value || "").trim();
      const dateParam = String(dateParamInput.value || "").trim();
      if (!imageUrl) {
        setStatus("Lütfen banner görsel URL'sini girin.", "error");
        return;
      }
      if (!linkUrl) {
        setStatus("Lütfen link URL'sini girin.", "error");
        return;
      }
      if (!campaignParam) {
        setStatus("Lütfen kampanya parametresini girin.", "error");
        return;
      }
      if (!dateParam || !/^\d{8}$/.test(dateParam)) {
        setStatus("Tarih YYYYMMDD formatında olmalı.", "error");
        return;
      }
      const utmCampaign = `${campaignParam}_${dateParam}`;
      const utmContent = `${campaignParam}_mailing`;
      const separator = linkUrl.includes("?") ? "&" : "?";
      const finalLink = `${linkUrl}${separator}cid=${CID_VALUE}&utm_source=n11_mail&utm_medium=campaign_manual&utm_campaign=${encodeURIComponent(utmCampaign)}&utm_content=${encodeURIComponent(utmContent)}`;
      generatedHTML = BANNER_MAIL_TEMPLATE
        .replace("{{ imageUrl }}", imageUrl)
        .replace("{{ link }}", finalLink);
      outputEl.value = generatedHTML;
      outputWrap.style.display = "block";
      previewBtn.disabled = false;
      copyBtn.disabled = false;
      downloadBtn.disabled = false;
      setStatus("HTML oluşturuldu.", "success");
    });

    previewBtn.addEventListener("click", () => {
      if (!generatedHTML) {
        setStatus("Önce HTML oluşturun.", "error");
        return;
      }
      previewWrap.style.display = "block";
      const iframeDoc = previewFrame.contentDocument || previewFrame.contentWindow.document;
      iframeDoc.open();
      iframeDoc.write(generatedHTML);
      iframeDoc.close();
      setStatus("Preview güncellendi.", "success");
    });

    copyBtn.addEventListener("click", async () => {
      if (!generatedHTML) {
        setStatus("Kopyalanacak HTML bulunamadı.", "error");
        return;
      }
      try {
        await navigator.clipboard.writeText(generatedHTML);
        setStatus("HTML kopyalandı.", "success");
      } catch (err) {
        setStatus("Kopyalama başarısız oldu.", "error");
      }
    });

    downloadBtn.addEventListener("click", () => {
      if (!generatedHTML) {
        setStatus("Önce HTML oluşturun.", "error");
        return;
      }
      const blob = new Blob([generatedHTML], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `banner-mailing-${new Date().toISOString().slice(0, 10)}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setStatus("HTML indirildi.", "success");
    });

    clearBtn.addEventListener("click", () => {
      imageUrlInput.value = "";
      linkUrlInput.value = "";
      campaignParamInput.value = "";
      dateParamInput.value = todayFormatted;
      outputEl.value = "";
      generatedHTML = "";
      outputWrap.style.display = "none";
      previewWrap.style.display = "none";
      previewBtn.disabled = true;
      copyBtn.disabled = true;
      downloadBtn.disabled = true;
      setStatus("Form temizlendi.", "info");
    });

    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

const openProductMailingModal = () => {
  let modal = document.getElementById(PRODUCT_MAILING_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = PRODUCT_MAILING_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.style.position = "fixed";
    modal.style.inset = "0";
    modal.style.zIndex = "2147483647";
    modal.style.display = "none";
    modal.style.alignItems = "center";
    modal.style.justifyContent = "center";
    modal.style.background = "rgba(0, 0, 0, 0.64)";
    modal.innerHTML = `
      <div class="modal-card banner-mailing-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Product Mailing</div>
        </div>
        <div class="banner-mailing-body">
          <div class="product-mailing-form">
            <div class="product-mailing-section">
              <div class="product-mailing-title"><b>Banner</b></div>
              <div class="product-mailing-groups">
                <div class="product-group">
                  <label for="product-mailing-image-url">Banner Image</label>
                  <input type="text" id="product-mailing-image-url" class="akakce-crawler-textarea banner-mailing-input" placeholder="https://n11scdn.akamaized.net/a1/org/.../image.jpg" />
                </div>
                <div class="product-group">
                  <label for="product-mailing-banner-link-url">Banner Link</label>
                  <input type="text" id="product-mailing-banner-link-url" class="akakce-crawler-textarea banner-mailing-input" placeholder="https://www.n11.com/..." />
                </div>
                <div class="product-group">
                  <label for="product-mailing-bg-color">Renk Kodu (hex)</label>
                  <input type="text" id="product-mailing-bg-color" class="akakce-crawler-textarea banner-mailing-input" placeholder="#E9F4FC" />
                </div>
              </div>
            </div>

            <div class="product-mailing-section">
              <div class="product-mailing-title"><b>Kampanya</b></div>
              <div class="product-mailing-groups">
                <div class="product-group">
                  <label for="product-mailing-campaign-param">Kampanya Parametresi</label>
                  <input type="text" id="product-mailing-campaign-param" class="akakce-crawler-textarea banner-mailing-input" placeholder="kasim" />
                </div>
                <div class="product-group">
                  <label for="product-mailing-date-param">Tarih (YYYYMMDD)</label>
                  <input type="text" id="product-mailing-date-param" class="akakce-crawler-textarea banner-mailing-input" placeholder="20251109" />
                </div>
              </div>
            </div>

            <div class="product-mailing-section">
              <div class="product-mailing-title"><b>Products</b></div>
              <div class="product-mailing-groups">
                <div class="product-group">
                  <label for="product-mailing-product-1-url">Product 1</label>
                  <input type="text" id="product-mailing-product-1-url" class="akakce-crawler-textarea banner-mailing-input" placeholder="https://www.n11.com/urun/..." />
                </div>
                <div class="product-group product-group--stock">
                  <label for="product-mailing-product-1-stock">Stok 1</label>
                  <input type="text" id="product-mailing-product-1-stock" class="akakce-crawler-textarea banner-mailing-input" placeholder="?" />
                </div>
                <div class="product-group">
                  <label for="product-mailing-product-2-url">Product 2</label>
                  <input type="text" id="product-mailing-product-2-url" class="akakce-crawler-textarea banner-mailing-input" placeholder="https://www.n11.com/urun/..." />
                </div>
                <div class="product-group product-group--stock">
                  <label for="product-mailing-product-2-stock">Stok 2</label>
                  <input type="text" id="product-mailing-product-2-stock" class="akakce-crawler-textarea banner-mailing-input" placeholder="?" />
                </div>
                <div class="product-group">
                  <label for="product-mailing-product-3-url">Product 3</label>
                  <input type="text" id="product-mailing-product-3-url" class="akakce-crawler-textarea banner-mailing-input" placeholder="https://www.n11.com/urun/..." />
                </div>
                <div class="product-group product-group--stock">
                  <label for="product-mailing-product-3-stock">Stok 3</label>
                  <input type="text" id="product-mailing-product-3-stock" class="akakce-crawler-textarea banner-mailing-input" placeholder="?" />
                </div>
                <div class="product-group">
                  <label for="product-mailing-product-4-url">Product 4</label>
                  <input type="text" id="product-mailing-product-4-url" class="akakce-crawler-textarea banner-mailing-input" placeholder="https://www.n11.com/urun/..." />
                </div>
                <div class="product-group product-group--stock">
                  <label for="product-mailing-product-4-stock">Stok 4</label>
                  <input type="text" id="product-mailing-product-4-stock" class="akakce-crawler-textarea banner-mailing-input" placeholder="?" />
                </div>
              </div>
            </div>
            <div class="akakce-crawler-buttons">
              <button type="button" class="akakce-run-btn" id="product-mailing-generate-btn">Oluştur</button>
              <button type="button" class="akakce-run-btn" id="product-mailing-preview-btn" disabled>Preview</button>
              <button type="button" class="akakce-run-btn" id="product-mailing-copy-btn" disabled>HTML Kopyala</button>
              <button type="button" class="download-btn" id="product-mailing-download-btn" disabled>HTML İndir</button>
              <button type="button" class="download-btn" id="product-mailing-clear-btn">Temizle</button>
            </div>
          </div>
          <div id="product-mailing-status" class="status info">
            Banner, kampanya ve 4 product alanlarini doldurabilirsiniz.
          </div>
          <div id="product-mailing-output-wrap" style="display:none;">
            <label for="product-mailing-output"><b>Oluşturulan HTML</b></label>
            <textarea id="product-mailing-output" class="akakce-crawler-textarea" rows="12" readonly placeholder="HTML burada görünecek..."></textarea>
          </div>
          <div id="product-mailing-preview-wrap" style="display:none;">
            <label><b>Preview</b></label>
            <iframe id="product-mailing-preview-frame"></iframe>
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    modal.querySelector(".modal-close").addEventListener("click", () => { modal.style.display = "none"; });

    const CID_VALUE = "400000";
    const imageUrlInput = modal.querySelector("#product-mailing-image-url");
    const bannerLinkUrlInput = modal.querySelector("#product-mailing-banner-link-url");
    const bgColorInput = modal.querySelector("#product-mailing-bg-color");
    const campaignParamInput = modal.querySelector("#product-mailing-campaign-param");
    const dateParamInput = modal.querySelector("#product-mailing-date-param");
    const product1Input = modal.querySelector("#product-mailing-product-1-url");
    const product2Input = modal.querySelector("#product-mailing-product-2-url");
    const product3Input = modal.querySelector("#product-mailing-product-3-url");
    const product4Input = modal.querySelector("#product-mailing-product-4-url");
    const stock1Input = modal.querySelector("#product-mailing-product-1-stock");
    const stock2Input = modal.querySelector("#product-mailing-product-2-stock");
    const stock3Input = modal.querySelector("#product-mailing-product-3-stock");
    const stock4Input = modal.querySelector("#product-mailing-product-4-stock");
    const generateBtn = modal.querySelector("#product-mailing-generate-btn");
    const previewBtn = modal.querySelector("#product-mailing-preview-btn");
    const copyBtn = modal.querySelector("#product-mailing-copy-btn");
    const downloadBtn = modal.querySelector("#product-mailing-download-btn");
    const clearBtn = modal.querySelector("#product-mailing-clear-btn");
    const statusEl = modal.querySelector("#product-mailing-status");
    const outputWrap = modal.querySelector("#product-mailing-output-wrap");
    const previewWrap = modal.querySelector("#product-mailing-preview-wrap");
    const outputEl = modal.querySelector("#product-mailing-output");
    const previewFrame = modal.querySelector("#product-mailing-preview-frame");
    let generatedHTML = "";
    let productMailTemplate = "";

    const setStatus = (message, type = "info") => {
      statusEl.textContent = message || "";
      statusEl.className = `status ${type}`;
      statusEl.style.display = message ? "block" : "none";
    };

    const today = new Date();
    const todayFormatted = `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, "0")}${String(today.getDate()).padStart(2, "0")}`;
    dateParamInput.value = todayFormatted;
    bgColorInput.value = "#E9F4FC";

    const appendTrackingParams = (rawUrl, utmCampaign, utmContent) => {
      const value = String(rawUrl || "").trim();
      const separator = value.includes("?") ? "&" : "?";
      return `${value}${separator}cid=${CID_VALUE}&utm_source=n11_mail&utm_medium=campaign_manual&utm_campaign=${encodeURIComponent(utmCampaign)}&utm_content=${encodeURIComponent(utmContent)}`;
    };

    const loadProductMailTemplate = async () => {
      if (productMailTemplate) return productMailTemplate;
      const templateUrl = chrome.runtime.getURL("product-mailing.html");
      const response = await chrome.runtime.sendMessage({
        type: "product-mailing-fetch-html",
        url: templateUrl
      });
      if (!response || !response.ok) {
        throw new Error(response?.error || "Template okunamadi");
      }
      productMailTemplate = String(response.html || "");
      return productMailTemplate;
    };

    const extractProductDataFromHtml = (html, fallbackUrl) => {
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const cleanText = (value) => String(value || "").replace(/\s+/g, " ").trim();
      const formatPriceForMail = (raw) => {
        const n = parsePriceStringToNumber(raw);
        if (n == null || Number.isNaN(n)) {
          return cleanText(raw || "");
        }
        if (Number.isInteger(n)) {
          return `${n.toLocaleString("tr-TR")} TL`;
        }
        const fixed = n.toFixed(2);
        const [intPart, decPart] = fixed.split(".");
        if (decPart === "00") {
          return `${Number(intPart).toLocaleString("tr-TR")} TL`;
        }
        return `${n.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} TL`;
      };
      const normalizeImagePath = (value) => {
        const raw = cleanText(value || "");
        if (!raw) return "";
        const replaced = raw.replace(/\{0\}/g, "320");
        if (/^https?:\/\//i.test(replaced)) return replaced;
        if (replaced.startsWith("//")) return `https:${replaced}`;
        if (replaced.startsWith("/")) return `https://n11scdn.akamaized.net${replaced}`;
        return replaced;
      };

      let title = "";
      let image = "";
      let price = "";
      let adDataName = "";
      let productSubTitle = "";

      const ogTitle = doc.querySelector('meta[property="og:title"]')?.getAttribute("content");
      const ogImage = doc.querySelector('meta[property="og:image"]')?.getAttribute("content");
      const ogPrice = doc.querySelector('meta[property="product:price:amount"]')?.getAttribute("content");
      if (ogTitle) title = cleanText(ogTitle);
      if (ogImage) image = cleanText(ogImage);
      if (ogPrice) price = cleanText(ogPrice);

      // n11 ürün sayfalarında sıkça değerler model.adData içinde gelir (price özellikle).
      try {
        const scriptsText = Array.from(doc.querySelectorAll("script"))
          .map((s) => String(s.textContent || ""))
          .join("\n");

        if (!productSubTitle) {
          const subTitlePatterns = [
            /model\.product\.subTitle\s*[=:]\s*["']([^"']+)["']/i,
            /"product"\s*:\s*\{[\s\S]*?"subTitle"\s*:\s*"([^"]+)"/i,
            /"subTitle"\s*:\s*"([^"]+)"/i
          ];
          for (const pattern of subTitlePatterns) {
            const m = scriptsText.match(pattern);
            if (m && m[1]) {
              productSubTitle = cleanText(m[1]);
              break;
            }
          }
        }

        if (!adDataName) {
          const namePatterns = [
            /model\.adData\.name\s*[=:]\s*["']([^"']+)["']/i,
            /"adData"\s*:\s*\{[\s\S]*?"name"\s*:\s*"([^"]+)"/i
          ];
          for (const pattern of namePatterns) {
            const m = scriptsText.match(pattern);
            if (m && m[1]) {
              adDataName = cleanText(m[1]);
              break;
            }
          }
        }

        if (!price) {
          const pricePatterns = [
            /model\.adData\.price\s*[=:]\s*["']?([\d.,]+)["']?/i,
            /model\[['"]adData['"]\]\[['"]price['"]\]\s*[=:]\s*["']?([\d.,]+)["']?/i,
            /"adData"\s*:\s*\{[\s\S]*?"price"\s*:\s*["']?([\d.,]+)["']?/i
          ];
          for (const pattern of pricePatterns) {
            const m = scriptsText.match(pattern);
            if (m && m[1]) {
              price = formatPriceForMail(m[1]);
              break;
            }
          }
        }

        if (!title) {
          // İstenen: title için öncelik model.product.subTitle
          if (productSubTitle) title = productSubTitle;
          else if (adDataName) title = adDataName;
          const titlePatterns = [
            /model\.product\.subTitle\s*[=:]\s*["']?([^"']+?)["']?/i,
            /model\.product\.title\s*[=:]\s*["']?([^"']+?)["']?/i,
            /model\.adData\.productTitle\s*[=:]\s*["']?([^"']+?)["']?/i,
            /model\.adData\.title\s*[=:]\s*["']?([^"']+?)["']?/i
          ];
          for (const pattern of titlePatterns) {
            const m = scriptsText.match(pattern);
            if (m && m[1]) {
              title = cleanText(m[1]);
              break;
            }
          }
          if (!title) {
            const h1El = doc.querySelector(".pdpMainInfo h1") || doc.querySelector("h1");
            if (h1El && h1El.textContent) title = cleanText(h1El.textContent);
          }
        }

        if (!image) {
          const imagePatterns = [
            /model\.product\.images\[\s*0\s*\]\.path\s*[=:]\s*["']([^"']+)["']/i,
            /"product"\s*:\s*\{[\s\S]*?"images"\s*:\s*\[\s*\{[\s\S]*?"path"\s*:\s*"([^"]+)"/i,
            /model\.adData\.(imageUrl|mainImage|defaultImage|productImage|coverImage|thumb)\s*[=:]\s*["']?([^"']+?)["']?/i,
            /model\.product\.(imageUrl|mainImage|defaultImage|productImage|coverImage|thumb)\s*[=:]\s*["']?([^"']+?)["']?/i
          ];
          for (const pattern of imagePatterns) {
            const m = scriptsText.match(pattern);
            const candidate = m ? (m[2] || m[1] || "") : "";
            if (candidate) {
              image = normalizeImagePath(candidate);
              break;
            }
          }
        }
      } catch (_) {
        // ignore script parsing errors
      }

      const jsonLdNodes = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));
      for (const node of jsonLdNodes) {
        const raw = String(node.textContent || "").trim();
        if (!raw) continue;
        try {
          const parsed = JSON.parse(raw);
          const candidates = Array.isArray(parsed) ? parsed : [parsed];
          for (const item of candidates) {
            const productLike = item && item["@type"] === "Product" ? item : null;
            if (!productLike) continue;
            if (!title && productLike.name) title = cleanText(productLike.name);
            if (!image) {
              if (Array.isArray(productLike.image)) image = cleanText(productLike.image[0] || "");
              else if (productLike.image) image = cleanText(productLike.image);
            }
            if (!price && productLike.offers) {
              const offer = Array.isArray(productLike.offers) ? productLike.offers[0] : productLike.offers;
              if (offer && offer.price != null) price = cleanText(offer.price);
            }
          }
        } catch (e) {
          // ignore invalid JSON-LD blocks
        }
      }

      if (!title) {
        const titleTag = cleanText(doc.querySelector("title")?.textContent || "");
        title = titleTag ? titleTag.split("|")[0].trim() : "";
      }
      if (!image) {
        image = normalizeImagePath(doc.querySelector('meta[name="twitter:image"]')?.getAttribute("content") || "");
      }
      if (!price) {
        price = cleanText(doc.querySelector('[itemprop="price"]')?.getAttribute("content") || "");
      }
      if (price && !/[^\d.,]/.test(price)) {
        price = formatPriceForMail(price);
      }

      return {
        link: fallbackUrl,
        title: title || "Urun",
        image: image || "",
        price: price || "-",
        utmContent: adDataName || title || "n11_product"
      };
    };

    const fetchProductData = async (rawUrl) => {
      const url = String(rawUrl || "").trim();
      const response = await chrome.runtime.sendMessage({
        type: "product-mailing-fetch-html",
        url
      });
      if (!response || !response.ok) {
        throw new Error(response?.error || "Urun sayfasi alinamadi");
      }
      const html = String(response.html || "");
      return extractProductDataFromHtml(html, url);
    };

    generateBtn.addEventListener("click", async () => {
      const imageUrl = String(imageUrlInput.value || "").trim();
      const bannerLinkUrl = String(bannerLinkUrlInput.value || "").trim();
      const bgColorRaw = String(bgColorInput.value || "").trim();
      const campaignParam = String(campaignParamInput.value || "").trim();
      const dateParam = String(dateParamInput.value || "").trim();
      const productLinks = [
        String(product1Input.value || "").trim(),
        String(product2Input.value || "").trim(),
        String(product3Input.value || "").trim(),
        String(product4Input.value || "").trim()
      ];
      const productStocks = [
        String(stock1Input.value || "").trim(),
        String(stock2Input.value || "").trim(),
        String(stock3Input.value || "").trim(),
        String(stock4Input.value || "").trim()
      ];

      if (!imageUrl) {
        setStatus("Lütfen banner image URL girin.", "error");
        return;
      }
      if (!bannerLinkUrl) {
        setStatus("Lütfen banner link URL girin.", "error");
        return;
      }
      if (!campaignParam) {
        setStatus("Lütfen kampanya parametresi girin.", "error");
        return;
      }
      if (!dateParam || !/^\d{8}$/.test(dateParam)) {
        setStatus("Tarih YYYYMMDD formatında olmalı.", "error");
        return;
      }
      const bgColor = bgColorRaw || "#E9F4FC";
      if (!/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(bgColor)) {
        setStatus("Renk kodu hex formatında olmalı. Örn: #E9F4FC", "error");
        return;
      }
      if (productLinks.some((link) => !link)) {
        setStatus("Lütfen 4 product URL alanını da doldurun.", "error");
        return;
      }

      try {
        setStatus("Template ve urun bilgileri hazirlaniyor...", "info");
        const template = await loadProductMailTemplate();
        const utmCampaign = `${campaignParam}_${dateParam}`;
        const bannerFinalLink = appendTrackingParams(
          bannerLinkUrl,
          utmCampaign,
          `${campaignParam}_mailing_banner`
        );
        const productDataList = await Promise.all(
          productLinks.map((link) => fetchProductData(link))
        );
        const productFinalLinks = productLinks.map((link, index) =>
          appendTrackingParams(
            link,
            utmCampaign,
            String(productDataList[index]?.utmContent || `product_${index + 1}`).trim()
          )
        );

        const escapeHtmlLocal = (value) => {
          return String(value == null ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
        };

        const escapeAttrLocal = (value) => escapeHtmlLocal(value);
        const replaceFirst = (str, find, replace) => str.replace(find, replace);

        let html = template;

        // Banner alanlarini doldur
        const bannerOpen = `<a href="" class="bnr-link" target="_blank"><img src="" alt="n11" class="bnr-img" border="0" width="100%" style="display: block">`;
        const bannerReplacement = `<a href="${escapeAttrLocal(bannerFinalLink)}" class="bnr-link" target="_blank"><img src="${escapeAttrLocal(imageUrl)}" alt="n11" class="bnr-img" border="0" width="100%" style="display: block">`;
        if (html.includes(bannerOpen)) {
          html = html.replace(bannerOpen, bannerReplacement);
        } else {
          // Fallback: href ve src'i ayri ayri degistir
          html = html.replace(/<a href="" class="bnr-link" target="_blank">/, `<a href="${escapeAttrLocal(bannerFinalLink)}" class="bnr-link" target="_blank">`);
          html = html.replace(/<img src=""/, `<img src="${escapeAttrLocal(imageUrl)}"`);
        }

        // Background color (template'te 2 adet td.bg-color var)
        html = html.replace(/bgcolor="[^"]*"\s+class="bg-color"/g, `bgcolor="${escapeAttrLocal(bgColor)}" class="bg-color"`);

        // Ürün kartlarindaki {title}/{price} + href=""/src="" bosluklarini sira ile doldur
        for (let i = 0; i < 4; i++) {
          const p = productDataList[i] || {};
          const safeTitle = escapeHtmlLocal(p.title || "Urun");
          const safePrice = escapeHtmlLocal(p.price || "-");
          const safeLink = escapeAttrLocal(p.link || productFinalLinks[i] || "");
          const safeImg = escapeAttrLocal(p.image || "");

          html = replaceFirst(html, "{title}", safeTitle);
          html = replaceFirst(html, "{price}", safePrice);

          html = replaceFirst(
            html,
            `<a href="" target="_blank" style="color:#000000; text-decoration: none;">`,
            `<a href="${escapeAttrLocal(productFinalLinks[i] || safeLink)}" target="_blank" style="color:#000000; text-decoration: none;">`
          );
          html = replaceFirst(
            html,
            `<img src="" style="border:1px solid #dedede" alt="n11" border="0" width="100%">`,
            `<img src="${safeImg}" style="border:1px solid #dedede" alt="n11" border="0" width="100%">`
          );

          const stockValue = productStocks[i];
          const stockLine = `<p style="color:#424242; margin: 10px 0 0 0; padding: 0; font-size: 12px;"><b>Stok: ?</b></p>`;
          const stockReplacement = stockValue
            ? `<p style="color:#424242; margin: 10px 0 0 0; padding: 0; font-size: 12px;"><b>Stok: ${escapeHtmlLocal(stockValue)}</b></p>`
            : "";
          html = replaceFirst(html, stockLine, stockReplacement);
        }

        generatedHTML = html;
        outputEl.value = generatedHTML;
        outputWrap.style.display = "block";
        previewWrap.style.display = "none";
        previewBtn.disabled = false;
        copyBtn.disabled = false;
        downloadBtn.disabled = false;
        setStatus("Product mailing HTML oluşturuldu.", "success");
      } catch (err) {
        setStatus(`Template oluşturulamadı: ${(err && err.message) || "Bilinmeyen hata"}`, "error");
      }
    });

    previewBtn.addEventListener("click", () => {
      if (!generatedHTML) {
        setStatus("Önce HTML oluşturun.", "error");
        return;
      }
      previewWrap.style.display = "block";
      const iframeDoc = previewFrame.contentDocument || previewFrame.contentWindow.document;
      iframeDoc.open();
      iframeDoc.write(generatedHTML);
      iframeDoc.close();
      setStatus("Preview güncellendi.", "success");
    });

    copyBtn.addEventListener("click", async () => {
      if (!generatedHTML) {
        setStatus("Kopyalanacak HTML bulunamadı.", "error");
        return;
      }
      try {
        await navigator.clipboard.writeText(generatedHTML);
        setStatus("HTML kopyalandı.", "success");
      } catch (err) {
        setStatus("Kopyalama başarısız oldu.", "error");
      }
    });

    downloadBtn.addEventListener("click", () => {
      if (!generatedHTML) {
        setStatus("Önce HTML oluşturun.", "error");
        return;
      }
      const blob = new Blob([generatedHTML], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `product-mailing-${new Date().toISOString().slice(0, 10)}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setStatus("HTML indirildi.", "success");
    });

    clearBtn.addEventListener("click", () => {
      imageUrlInput.value = "";
      bannerLinkUrlInput.value = "";
      bgColorInput.value = "#E9F4FC";
      campaignParamInput.value = "";
      dateParamInput.value = todayFormatted;
      product1Input.value = "";
      product2Input.value = "";
      product3Input.value = "";
      product4Input.value = "";
      stock1Input.value = "";
      stock2Input.value = "";
      stock3Input.value = "";
      stock4Input.value = "";
      outputEl.value = "";
      generatedHTML = "";
      outputWrap.style.display = "none";
      previewWrap.style.display = "none";
      previewBtn.disabled = true;
      copyBtn.disabled = true;
      downloadBtn.disabled = true;
      setStatus("Form temizlendi.", "info");
    });

    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

const openLogoListModal = () => {
  let modal = document.getElementById(LOGO_LIST_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = LOGO_LIST_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.innerHTML = `
      <div class="modal-card logo-list-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Logo Listesi</div>
          <div class="modal-subtitle" style="background-color:#EFFF99; border-radius: 6px; color:#444; display: inline-block; margin: 8px 0; font-size: 12px; padding: 8px;">Logoya tıkladığınızda kopyalanabilir.</div>
        </div>
        <div class="logo-list-body">
          <div class="logo-list-toolbar">
            <input type="text" id="logo-list-search" class="logo-list-search" placeholder="Marka ara..." />
          </div>
          <div id="logo-list-grid" class="logo-list-grid"></div>
          <div id="logo-list-status" class="status info"></div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    modal.querySelector(".modal-close").addEventListener("click", () => { modal.style.display = "none"; });

    const searchInput = modal.querySelector("#logo-list-search");
    const grid = modal.querySelector("#logo-list-grid");
    const statusEl = modal.querySelector("#logo-list-status");
    let allItems = [];

    const setStatus = (message, type = "info") => {
      statusEl.textContent = message || "";
      statusEl.className = `status ${type}`;
      statusEl.style.display = message ? "block" : "none";
    };

    const escapeHtmlLocal = (value) => String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

    const normalizeLogoUrl = (raw) => {
      const value = String(raw || "").trim();
      if (!value) return "";
      if (/^https?:\/\//i.test(value)) return value;
      if (value.startsWith("//")) return `https:${value}`;
      if (value.startsWith("/")) return `https://n11scdn.akamaized.net${value}`;
      if (/^[\w.-]+\.[a-z]{2,}\//i.test(value)) return `https://${value}`;
      return value;
    };

    const extractLogoItems = (payload) => {
      const out = [];
      const seen = new Set();
      const walk = (node) => {
        if (!node || typeof node !== "object") return;
        if (Array.isArray(node)) {
          node.forEach(walk);
          return;
        }
        const obj = node;
        const name = obj.brandName || obj.marka || obj.name || obj.brand || obj.title || obj.displayName;
        const logo = obj.logoPath || obj.logo || obj.logoUrl || obj.image || obj.imageUrl || obj.path;
        if (name && logo) {
          const brandName = String(name).trim();
          const logoUrl = normalizeLogoUrl(logo);
          const key = `${brandName}__${logoUrl}`;
          if (brandName && logoUrl && !seen.has(key)) {
            seen.add(key);
            out.push({ brandName, logoUrl });
          }
        }
        Object.values(obj).forEach((val) => {
          if (val && typeof val === "object") walk(val);
        });
      };
      walk(payload);
      return out.sort((a, b) => a.brandName.localeCompare(b.brandName, "tr"));
    };

    const renderGrid = () => {
      const query = String(searchInput.value || "").toLocaleLowerCase("tr-TR").trim();
      const items = query
        ? allItems.filter((item) => item.brandName.toLocaleLowerCase("tr-TR").includes(query))
        : allItems;
      if (!items.length) {
        grid.innerHTML = '<div class="logo-list-empty">Sonuc bulunamadi.</div>';
        return;
      }
      grid.innerHTML = items.map((item) => `
        <div class="logo-list-card" data-logo-url="${escapeHtmlLocal(item.logoUrl)}" title="Logo yolunu kopyala">
          <div class="logo-list-card-image-wrap">
            <img src="${escapeHtmlLocal(item.logoUrl)}" alt="${escapeHtmlLocal(item.brandName)}" class="logo-list-card-image" />
          </div>
          <div class="logo-list-card-name">${escapeHtmlLocal(item.brandName)}</div>
        </div>
      `).join("");
      grid.querySelectorAll(".logo-list-card[data-logo-url]").forEach((card) => {
        card.addEventListener("click", async () => {
          const logoUrl = String(card.getAttribute("data-logo-url") || "").trim();
          if (!logoUrl) return;
          try {
            await navigator.clipboard.writeText(logoUrl);
            setStatus("Logo path kopyalandi.", "success");
          } catch (err) {
            setStatus("Kopyalama basarisiz.", "error");
          }
        });
      });
    };

    const loadData = async () => {
      setStatus("Logo listesi yukleniyor...", "info");
      grid.innerHTML = "";
      try {
        const response = await chrome.runtime.sendMessage({
          type: "logo-list-fetch",
          url: "https://mobileapi.n11.com/mobileapi/rest/inventory/general/118332225"
        });
        if (!response || !response.ok) {
          setStatus((response && response.error) || "Logo listesi yuklenemedi.", "error");
          grid.innerHTML = '<div class="logo-list-empty">Veri alinamadi.</div>';
          return;
        }
        allItems = extractLogoItems(response.data);
        if (!allItems.length) {
          setStatus("Logo veya marka bilgisi bulunamadi.", "error");
          grid.innerHTML = '<div class="logo-list-empty">Kayit bulunamadi.</div>';
          return;
        }
        setStatus(`${allItems.length} kayit yuklendi.`, "success");
        renderGrid();
      } catch (err) {
        setStatus("Logo listesi yuklenemedi: " + ((err && err.message) || "Bilinmeyen hata"), "error");
        grid.innerHTML = '<div class="logo-list-empty">Veri alinamadi.</div>';
      }
    };

    searchInput.addEventListener("input", renderGrid);
    document.body.appendChild(modal);
    loadData();
  }
  modal.style.display = "flex";
};

const openLogoResizerModal = () => {
  let modal = document.getElementById(LOGO_RESIZER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = LOGO_RESIZER_MODAL_ID;
    modal.className = "pageid-extension-modal-overlay";
    modal.innerHTML = `
      <div class="modal-card logo-resizer-modal-card">
        <button class="modal-close" aria-label="Kapat">✕</button>
        <div class="modal-header">
          <div class="modal-title">Logo Resizer</div>
        </div>
        <div class="logo-resizer-body">
          <div class="logo-resizer-input-row">
            <input type="text" id="logo-resizer-image-url" class="logo-resizer-input" placeholder="Gorsel URL'i giriniz" />
            <button type="button" id="logo-resizer-load-btn" class="logo-resizer-primary-btn">Load Image</button>
          </div>
          <div class="logo-resizer-divider">OR</div>
          <div class="logo-resizer-input-row">
            <input type="file" id="logo-resizer-file-input" class="logo-resizer-file-input" accept="image/*" />
            <button type="button" id="logo-resizer-upload-btn" class="logo-resizer-secondary-btn">Upload Local Image</button>
          </div>
          <div class="logo-resizer-frame" id="logo-resizer-frame">
            <div class="logo-resizer-image-wrap" id="logo-resizer-image-wrap">
              <img id="logo-resizer-image" class="logo-resizer-image" alt="Resized" />
            </div>
          </div>
          <div id="logo-resizer-status" class="status info"></div>
          <div class="logo-resizer-actions">
            <button type="button" id="logo-resizer-save-btn" class="logo-resizer-save-btn" disabled>Save Image</button>
          </div>
          <div class="logo-resizer-note">
            <strong>Not:</strong> Bazi URL'lerde CORS sebebiyle kaydetme calismayabilir. Bu durumda yerel dosya yukleyin.
          </div>
        </div>
      </div>
    `;
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
    modal.querySelector(".modal-close").addEventListener("click", () => { modal.style.display = "none"; });

    const urlInput = modal.querySelector("#logo-resizer-image-url");
    const fileInput = modal.querySelector("#logo-resizer-file-input");
    const loadBtn = modal.querySelector("#logo-resizer-load-btn");
    const uploadBtn = modal.querySelector("#logo-resizer-upload-btn");
    const imageWrap = modal.querySelector("#logo-resizer-image-wrap");
    const imageEl = modal.querySelector("#logo-resizer-image");
    const saveBtn = modal.querySelector("#logo-resizer-save-btn");
    const statusEl = modal.querySelector("#logo-resizer-status");

    const setStatus = (message, type = "info") => {
      statusEl.textContent = message || "";
      statusEl.className = `status ${type}`;
      statusEl.style.display = message ? "block" : "none";
    };

    const enableImage = (src) => {
      imageEl.src = src;
    };

    imageEl.addEventListener("load", () => {
      imageEl.style.display = "block";
      saveBtn.disabled = false;
      setStatus("Resim basariyla yuklendi.", "success");
    });
    imageEl.addEventListener("error", () => {
      imageEl.style.display = "none";
      saveBtn.disabled = true;
      setStatus("Resim yuklenirken hata olustu.", "error");
    });

    loadBtn.addEventListener("click", () => {
      const url = String(urlInput.value || "").trim();
      if (!url) {
        setStatus("Lutfen bir resim URL'i girin.", "error");
        return;
      }
      setStatus("Resim yukleniyor...", "info");
      enableImage(url);
    });

    uploadBtn.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      const file = fileInput.files && fileInput.files[0];
      if (!file) return;
      if (!file.type || !file.type.startsWith("image/")) {
        setStatus("Lutfen sadece resim dosyasi yukleyin.", "error");
        fileInput.value = "";
        return;
      }
      setStatus("Resim yukleniyor...", "info");
      const reader = new FileReader();
      reader.onload = () => enableImage(String(reader.result || ""));
      reader.onerror = () => setStatus("Dosya okunamadi.", "error");
      reader.readAsDataURL(file);
      fileInput.value = "";
    });

    urlInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        loadBtn.click();
      }
    });

    imageWrap.addEventListener("dragover", (e) => {
      e.preventDefault();
      imageWrap.classList.add("dragover");
    });
    imageWrap.addEventListener("dragleave", (e) => {
      e.preventDefault();
      imageWrap.classList.remove("dragover");
    });
    imageWrap.addEventListener("drop", (e) => {
      e.preventDefault();
      imageWrap.classList.remove("dragover");
      const file = e.dataTransfer && e.dataTransfer.files ? e.dataTransfer.files[0] : null;
      if (!file) return;
      if (!file.type || !file.type.startsWith("image/")) {
        setStatus("Lutfen sadece resim dosyasi yukleyin.", "error");
        return;
      }
      setStatus("Resim yukleniyor...", "info");
      const reader = new FileReader();
      reader.onload = () => enableImage(String(reader.result || ""));
      reader.onerror = () => setStatus("Dosya okunamadi.", "error");
      reader.readAsDataURL(file);
    });

    saveBtn.addEventListener("click", () => {
      if (!imageEl.src) {
        setStatus("Kaydedilecek resim yok.", "error");
        return;
      }
      try {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          setStatus("Canvas olusturulamadi.", "error");
          return;
        }
        canvas.width = 600;
        canvas.height = 600;
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, 600, 600);
        const maxWidth = 600 * 0.78;
        const maxHeight = 600 * 0.78;
        const imageRatio = imageEl.naturalWidth / imageEl.naturalHeight;
        const boxRatio = maxWidth / maxHeight;
        let drawWidth = maxWidth;
        let drawHeight = maxHeight;
        if (imageRatio > boxRatio) {
          drawWidth = maxWidth;
          drawHeight = drawWidth / imageRatio;
        } else {
          drawHeight = maxHeight;
          drawWidth = drawHeight * imageRatio;
        }
        const dx = (600 - drawWidth) / 2;
        const dy = (600 - drawHeight) / 2;
        ctx.drawImage(imageEl, dx, dy, drawWidth, drawHeight);
        const a = document.createElement("a");
        a.download = "resized-image.png";
        a.href = canvas.toDataURL("image/png");
        a.click();
        setStatus("Resim basariyla kaydedildi.", "success");
      } catch (err) {
        setStatus("Resim kaydedilirken hata olustu: " + ((err && err.message) || "Bilinmeyen hata"), "error");
      }
    });

    document.body.appendChild(modal);
  }
  modal.style.display = "flex";
};

let productDealControllerWorkbook = null;
let productDealControllerFileName = "";

const readFileAsArrayBuffer = (file) =>
  new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error("Dosya okunamadı"));
    r.readAsArrayBuffer(file);
  });

const handleProductDealControllerFiles = async (files, modal) => {
  const status = modal.querySelector("#product-deal-controller-status");
  const analyzeBtn = modal.querySelector("#product-deal-controller-analyze-btn");
  const downloadBtn = modal.querySelector("#product-deal-controller-download-btn");
  const multiCheck = modal.querySelector("#product-deal-controller-multi-checkbox");
  const isMulti = multiCheck && multiCheck.checked && files.length > 1;
  productDealControllerWorkbook = null;
  productDealControllerFileName = files.length === 1 ? (files[0].name || "deal.xlsx") : "birlesik.xlsx";
  if (downloadBtn) downloadBtn.disabled = true;
  status.textContent = "Dosya(lar) okunuyor...";
  status.className = "status info";
  try {
    if (typeof XLSX === "undefined") {
      status.textContent = "XLSX kütüphanesi yüklenmedi. Sayfayı yenileyin.";
      status.className = "status error";
      return;
    }
    if (isMulti) {
      const mergedRows = [];
      for (let i = 0; i < files.length; i++) {
        const buf = await readFileAsArrayBuffer(files[i]);
        const wb = XLSX.read(new Uint8Array(buf), { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "", raw: true });
        if (rows.length === 0) continue;
        if (i === 0) {
          mergedRows.push(...rows);
        } else {
          for (let r = 1; r < rows.length; r++) mergedRows.push(rows[r]);
        }
      }
      const ws = XLSX.utils.aoa_to_sheet(mergedRows);
      productDealControllerWorkbook = { SheetNames: ["Sheet1"], Sheets: { Sheet1: ws } };
      status.textContent = `${files.length} dosya birleştirildi. Toplam ${mergedRows.length} satır. "Analiz Et" ile devam edin.`;
    } else {
      const file = files[0];
      const buf = await readFileAsArrayBuffer(file);
      const wb = XLSX.read(new Uint8Array(buf), { type: "array" });
      productDealControllerWorkbook = wb;
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rowCount = ws["!ref"] ? XLSX.utils.decode_range(ws["!ref"]).e.r + 1 : 0;
      status.textContent = `"${file.name}" yüklendi. ${rowCount} satır. "Analiz Et" ile Duplicate Pims ID kontrolü yapın.`;
    }
    status.className = "status info";
    if (analyzeBtn) analyzeBtn.disabled = false;
  } catch (err) {
    status.textContent = "Dosya okunamadı: " + (err?.message || "Geçersiz Excel");
    status.className = "status error";
    if (analyzeBtn) analyzeBtn.disabled = true;
  }
};

const parseProductDealPrice = (raw) => {
  if (raw === undefined || raw === null || raw === "") return null;
  if (typeof raw === "number" && !Number.isNaN(raw)) return raw;
  const s = String(raw).trim().replace(/\s/g, "").replace(/\./g, "").replace(",", ".");
  if (!s) return null;
  const n = parseFloat(s, 10);
  return Number.isNaN(n) ? null : n;
};

const getSheetUsedRange = (ws) => {
  if (!ws) return "A1";
  let minR = Infinity;
  let minC = Infinity;
  let maxR = -1;
  let maxC = -1;
  Object.keys(ws).forEach((key) => {
    if (key[0] === "!") return;
    if (!/^[A-Z]+[0-9]+$/.test(key)) return;
    const decoded = XLSX.utils.decode_cell(key);
    if (decoded.r < minR) minR = decoded.r;
    if (decoded.c < minC) minC = decoded.c;
    if (decoded.r > maxR) maxR = decoded.r;
    if (decoded.c > maxC) maxC = decoded.c;
  });
  if (maxR < 0 || maxC < 0) return "A1";
  return XLSX.utils.encode_range({ s: { r: minR, c: minC }, e: { r: maxR, c: maxC } });
};

const runProductDealControllerAnalyze = (modal) => {
  const status = modal.querySelector("#product-deal-controller-status");
  const downloadBtn = modal.querySelector("#product-deal-controller-download-btn");
  if (!productDealControllerWorkbook || typeof XLSX === "undefined") {
    status.textContent = "Önce Excel dosyası yükleyin.";
    status.className = "status error";
    return;
  }
  const firstSheet = productDealControllerWorkbook.SheetNames[0];
  const ws = productDealControllerWorkbook.Sheets[firstSheet];
  const colA = 0;
  const colK = 10;
  const colL = 11;
  const colM = 12;
  const colN = 13;
  const colO = 14;
  const colD = 3;
  const colE = 4;
  const colF = 5;
  const colG = 6;
  const colH = 7;
  const colI = 8;
  const colJ = 9;
  const colP = 15;
  const colsDToJ = [colD, colE, colF, colG, colH, colI, colJ];
  const colLettersDToJ = ["D", "E", "F", "G", "H", "I", "J"];
  const rawRows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "", raw: true });
  const rowErrors = {};
  const addError = (rowIndex, text) => {
    if (!rowErrors[rowIndex]) rowErrors[rowIndex] = [];
    rowErrors[rowIndex].push(text);
  };
  const pimsIds = [];
  for (let i = 1; i < rawRows.length; i++) {
    const row = rawRows[i];
    const raw = row && row[0];
    const val = (raw !== undefined && raw !== null && raw !== "") ? String(raw).trim() : "";
    pimsIds.push({ row: i, value: val });
  }
  const countByPims = {};
  for (let i = 0; i < pimsIds.length; i++) {
    const v = pimsIds[i].value;
    if (v === "") continue;
    countByPims[v] = (countByPims[v] || 0) + 1;
  }
  const duplicatePims = new Set(Object.keys(countByPims).filter((id) => countByPims[id] > 1));
  for (let i = 0; i < pimsIds.length; i++) {
    const { row: r, value: val } = pimsIds[i];
    if (duplicatePims.has(val)) addError(r, "Duplicate Pims ID");
  }
  let pimsGroupEqualCount = 0;
  for (let i = 1; i < rawRows.length; i++) {
    const row = rawRows[i];
    const aRaw = row && row[colA];
    const kRaw = row && row[colK];
    const aVal = (aRaw !== undefined && aRaw !== null && aRaw !== "") ? String(aRaw).trim() : "";
    const kVal = (kRaw !== undefined && kRaw !== null && kRaw !== "") ? String(kRaw).trim() : "";
    if (aVal === "" || kVal === "") continue;
    const aNum = parseProductDealPrice(aRaw);
    const kNum = parseProductDealPrice(kRaw);
    const isEqual = (aNum != null && kNum != null && Math.abs(aNum - kNum) < 1e-6) || aVal === kVal;
    if (isEqual) {
      addError(i, "Pims ve Group ID Eşit");
      pimsGroupEqualCount += 1;
    }
  }
  let dToJInvalidCount = 0;
  for (let i = 1; i < rawRows.length; i++) {
    const row = rawRows[i];
    const invalidCols = [];
    for (let idx = 0; idx < colsDToJ.length; idx++) {
      const col = colsDToJ[idx];
      const raw = row && row[col];
      const isEmpty = raw === undefined || raw === null || (typeof raw === "string" && raw.trim() === "");
      if (isEmpty) {
        invalidCols.push(colLettersDToJ[idx] + ": Boş bırakılmış");
        continue;
      }
      const num = parseProductDealPrice(raw);
      if (num === null) {
        invalidCols.push(colLettersDToJ[idx] + ": Geçersiz değer");
        continue;
      }
      if (num === 0 || (typeof num === "number" && Math.abs(num) < 1e-9)) {
        invalidCols.push(colLettersDToJ[idx] + ": Sıfır yazıyor");
      }
    }
    if (invalidCols.length > 0) {
      addError(i, invalidCols.join(", "));
      dToJInvalidCount += 1;
    }
  }
  let sortErrorCount = 0;
  for (let i = 1; i < rawRows.length; i++) {
    const row = rawRows[i];
    const d = parseProductDealPrice(row && row[colD]);
    const f = parseProductDealPrice(row && row[colF]);
    const h = parseProductDealPrice(row && row[colH]);
    const values = [d, f, h].filter((x) => x != null);
    if (values.length < 2) continue;
    const sorted = [...values].sort((a, b) => b - a);
    const high = sorted[0];
    const mid = sorted.length >= 2 ? sorted[1] : sorted[0];
    const low = sorted.length >= 3 ? sorted[2] : sorted[sorted.length - 1];
    const needFix =
      (d != null && f != null && h != null) &&
      (Math.abs(d - high) > 1e-6 || Math.abs(f - mid) > 1e-6 || Math.abs(h - low) > 1e-6);
    if (needFix) {
      const r = i;
      const setNum = (col, num) => {
        const ref = XLSX.utils.encode_cell({ r, c: col });
        if (!ws[ref]) ws[ref] = { t: "n", v: 0 };
        ws[ref].t = "n";
        ws[ref].v = num;
      };
      setNum(colD, high);
      setNum(colF, mid);
      setNum(colH, low);
      addError(r, "Sıralama hatası");
      sortErrorCount += 1;
    }
  }
  let sortErrorCountEGI = 0;
  for (let i = 1; i < rawRows.length; i++) {
    const row = rawRows[i];
    const e = parseProductDealPrice(row && row[colE]);
    const g = parseProductDealPrice(row && row[colG]);
    const iVal = parseProductDealPrice(row && row[colI]);
    const valuesEGI = [e, g, iVal].filter((x) => x != null);
    if (valuesEGI.length < 2) continue;
    const sortedEGI = [...valuesEGI].sort((a, b) => b - a);
    const highEGI = sortedEGI[0];
    const midEGI = sortedEGI.length >= 2 ? sortedEGI[1] : sortedEGI[0];
    const lowEGI = sortedEGI.length >= 3 ? sortedEGI[2] : sortedEGI[sortedEGI.length - 1];
    const needFixEGI =
      (e != null && g != null && iVal != null) &&
      (Math.abs(e - highEGI) > 1e-6 || Math.abs(g - midEGI) > 1e-6 || Math.abs(iVal - lowEGI) > 1e-6);
    if (needFixEGI) {
      const r = i;
      const setNum = (col, num) => {
        const ref = XLSX.utils.encode_cell({ r, c: col });
        if (!ws[ref]) ws[ref] = { t: "n", v: 0 };
        ws[ref].t = "n";
        ws[ref].v = num;
      };
      setNum(colE, highEGI);
      setNum(colG, midEGI);
      setNum(colI, lowEGI);
      addError(r, "E-G-I sıralama hatası");
      sortErrorCountEGI += 1;
    }
  }
  for (let i = 1; i < rawRows.length; i++) {
    if (rowErrors[i] && rowErrors[i].length > 0) {
      const lRef = XLSX.utils.encode_cell({ r: i, c: colL });
      if (!ws[lRef]) ws[lRef] = { t: "s", v: "" };
      ws[lRef].t = "s";
      ws[lRef].v = rowErrors[i].join(", ");
      ws[lRef].s = {
        ...(ws[lRef].s || {}),
        font: {
          ...((ws[lRef].s && ws[lRef].s.font) || {}),
          color: { rgb: "FFFF0000" }
        }
      };
    }
  }
  const ref = XLSX.utils.decode_range(ws["!ref"] || "A1");
  ref.e.c = Math.max(ref.e.c, colL);
  ws["!ref"] = XLSX.utils.encode_range(ref);
  if (downloadBtn) downloadBtn.disabled = false;
  const dupCount = duplicatePims.size;
  const dupRowCount = pimsIds.filter((p) => duplicatePims.has(p.value)).length;
  let msg = `${dupRowCount} satırda Duplicate Pims ID (${dupCount} benzersiz).`;
  if (pimsGroupEqualCount > 0) msg += ` ${pimsGroupEqualCount} satırda A ve K eşit.`;
  if (dToJInvalidCount > 0) msg += ` ${dToJInvalidCount} satırda D-J boş/0/geçersiz.`;
  if (sortErrorCount > 0) msg += ` ${sortErrorCount} satırda fiyat sıralaması düzeltildi (D≥F≥H).`;
  if (sortErrorCountEGI > 0) msg += ` ${sortErrorCountEGI} satırda fiyat sıralaması düzeltildi (E≥G≥I).`;
  msg += " Tüm hatalar L kolonunda virgülle listelenir. \"Düzeltilmiş Dosyayı İndir (XLSX)\" ile kaydedin.";
  status.textContent = msg;
  status.className = "status info";
};

const downloadProductDealControllerExcel = (modal) => {
  const status = modal.querySelector("#product-deal-controller-status");
  if (!productDealControllerWorkbook || typeof XLSX === "undefined") return;
  try {
    status.textContent = "Düzeltilmiş XLSX hazırlanıyor...";
    status.className = "status info";
    const firstSheetName = productDealControllerWorkbook.SheetNames && productDealControllerWorkbook.SheetNames[0];
    const sourceWs = firstSheetName ? productDealControllerWorkbook.Sheets[firstSheetName] : null;
    if (!sourceWs) {
      status.textContent = "İndirilecek sayfa bulunamadı.";
      status.className = "status error";
      return;
    }
    sourceWs["!ref"] = getSheetUsedRange(sourceWs);
    const baseName = (productDealControllerFileName || "deal").replace(/\.xlsx?$/i, "") || "deal";
    XLSX.writeFile(productDealControllerWorkbook, `${baseName}_duplicate_fixed.xlsx`, {
      compression: true,
      cellStyles: true
    });
    status.textContent = "İndirme başlatıldı (XLSX).";
    status.className = "status success";
  } catch (err) {
    status.textContent = "XLSX indirme hatası: " + (err?.message || "Bilinmeyen hata");
    status.className = "status error";
  }
};

const openBannerCheckerModal = () => {
  let modal = document.getElementById(BANNER_CHECKER_MODAL_ID);
  if (!modal) {
    modal = document.createElement("div");
    modal.id = BANNER_CHECKER_MODAL_ID;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Banner Checker</div>
          <button class="modal-close" aria-label="Kapat">✕</button>
        </div>
        <div class="status info" id="bannerchecker-status">Hazırlanıyor...</div>
        <div class="bannerchecker-errors" id="bannerchecker-errors"></div>
        <div class="bannerchecker-table-wrap">
          <table class="bannerchecker-table">
            <thead>
              <tr>
                <th>Görsel</th>
                <th>Promosyon Linki</th>
                <th>Durum</th>
              </tr>
            </thead>
            <tbody id="bannerchecker-body"></tbody>
          </table>
        </div>
      </div>
    `;
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector(".modal-close");
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }

  modal.style.display = "flex";

  const status = modal.querySelector("#bannerchecker-status");
  const tableBody = modal.querySelector("#bannerchecker-body");
  const tableWrap = modal.querySelector(".bannerchecker-table-wrap");
  const errorList = modal.querySelector("#bannerchecker-errors");
  const hasCouponFaqs = Boolean(document.querySelector("iframe#coupon-faqs"));
  const isKampanyalarPage = window.location.pathname.includes("/kampanyalar");
  const isKampanyaPage =
    window.location.pathname.includes("/kampanya") && !isKampanyalarPage;
  if (status) {
    status.textContent = "Analiz başlıyor..";
    status.className = "status info";
    status.style.display = "block";
  }
  if (tableBody) {
    tableBody.innerHTML = "";
  }
  if (tableWrap) {
    tableWrap.style.display = "none";
  }
  if (errorList) {
    errorList.innerHTML = "";
    errorList.style.display = "none";
  }

  if (isKampanyaPage) {
    if (status) {
      status.textContent = "Kampanya sayfaları analiz edilmiyor.";
      status.className = "status error";
    }
    return;
  }

  const addError = (message) => {
    if (!errorList) {
      return;
    }
    const item = document.createElement("div");
    item.className = "bannerchecker-error";
    item.textContent = message;
    errorList.appendChild(item);
    errorList.style.display = "block";
  };

  const addTableErrorRow = (message) => {
    if (!tableBody) {
      return;
    }
    const tr = document.createElement("tr");
    const imgTd = document.createElement("td");
    const linkTd = document.createElement("td");
    const statusTd = document.createElement("td");
    imgTd.textContent = "-";
    linkTd.textContent = message;
    statusTd.textContent = "Hata";
    statusTd.className = "status-closed";
    tr.append(imgTd, linkTd, statusTd);
    tableBody.appendChild(tr);
    if (tableWrap) {
      tableWrap.style.display = "block";
    }
  };

  if (isKampanyaPage && !hasCouponFaqs) {
    const message = `iframe#coupon-faqs bulunamadı: ${window.location.href}`;
    addError(message);
    addTableErrorRow(message);
  }

  const scrollToBottom = (done) => {
    const doc = document.documentElement;
    const bottom = doc.scrollTop + window.innerHeight >= doc.scrollHeight - 2;
    if (bottom) {
      done();
      return;
    }
    window.scrollBy({ top: window.innerHeight, left: 0, behavior: "smooth" });
    window.setTimeout(() => scrollToBottom(done), 2000);
  };

  const normalizePromotionUrl = (href) => {
    try {
      const url = new URL(href, window.location.href);
      if (!url.hostname.endsWith("n11.com")) {
        return null;
      }
      if (!url.pathname.startsWith("/arama")) {
        return null;
      }
      const promotionId = url.searchParams.get("promotions");
      if (!promotionId) {
        return null;
      }
      return {
        id: promotionId,
        url: `https://www.n11.com/arama?promotions=${encodeURIComponent(promotionId)}`
      };
    } catch {
      return null;
    }
  };

  const showCopyTooltip = (button) => {
    if (!button) {
      return;
    }
    button.classList.add("copied");
    window.setTimeout(() => {
      button.classList.remove("copied");
    }, 1200);
  };

  const extractImage = (anchor) => {
    if (!anchor) {
      return "";
    }
    const img = anchor.querySelector("img");
    if (img) {
      return img.currentSrc || img.src || "";
    }
    return "";
  };

  const fetchPromotionStatus = async (url) => {
    try {
      const response = await fetch(url, { credentials: "omit" });
      if (!response.ok) {
        return { closed: false, error: `HTTP ${response.status}` };
      }
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const notFound = doc.querySelector(".notFoundContainer");
      return { closed: Boolean(notFound) };
    } catch (error) {
      return { closed: false, error: String(error) };
    }
  };

  const getCampaignAnchors = () => {
    const iframe = document.querySelector("iframe#coupon-faqs");
    if (!iframe) {
      return null;
    }
    try {
      const doc = iframe.contentDocument || iframe.contentWindow?.document;
      if (!doc) {
        return null;
      }
      return Array.from(doc.querySelectorAll("a[href]"));
    } catch (error) {
      addError("iframe#coupon-faqs içerisine erişilemiyor.");
      addTableErrorRow("iframe#coupon-faqs içerisine erişilemiyor.");
      return null;
    }
  };

  const runCheck = async () => {
    const anchors = isKampanyalarPage
      ? Array.from(document.querySelectorAll("a[href]"))
      : Array.from(document.querySelectorAll('a[href*="promotions="]'));
    const rows = [];
    const seen = new Set();
    for (const anchor of anchors) {
      const href = anchor.getAttribute("href") || "";
      const normalized = normalizePromotionUrl(href);
      if (!normalized || seen.has(normalized.url)) {
        continue;
      }
      seen.add(normalized.url);
      rows.push({
        url: normalized.url,
        id: normalized.id,
        image: extractImage(anchor)
      });
    }

    if (rows.length === 0) {
    if (status) {
        status.textContent = "Promosyon linki bulunamadı.";
        status.className = "status error";
      }
      return;
    }

    if (status) {
      status.innerHTML = `<span class="bannerchecker-loading" aria-hidden="true"></span> ${rows.length} promosyon kontrol ediliyor...`;
      status.className = "status info";
    }

    let closedCount = 0;
    for (const row of rows) {
      // eslint-disable-next-line no-await-in-loop
      const result = await fetchPromotionStatus(row.url);
      if (!result.closed) {
        continue;
      }
      closedCount += 1;
      const tr = document.createElement("tr");
      const imgTd = document.createElement("td");
      const linkTd = document.createElement("td");
      const statusTd = document.createElement("td");
      if (row.image) {
        const img = document.createElement("img");
        img.src = row.image;
        img.alt = "Banner";
        imgTd.appendChild(img);
      } else {
        imgTd.textContent = "-";
      }
      const copyButton = document.createElement("button");
      copyButton.type = "button";
      copyButton.className = "bannerchecker-copy";
      copyButton.textContent = row.id || "-";
      copyButton.dataset.copy = row.id || "";
      copyButton.addEventListener("click", async () => {
        if (!copyButton.dataset.copy) {
          return;
        }
        try {
          await navigator.clipboard.writeText(copyButton.dataset.copy);
          showCopyTooltip(copyButton);
        } catch (error) {
          // ignore copy errors
        }
      });
      linkTd.appendChild(copyButton);
      statusTd.textContent = "Kapalı";
      statusTd.className = "status-closed";
      tr.append(imgTd, linkTd, statusTd);
      if (tableBody) {
        tableBody.appendChild(tr);
      }
    }

    if (status) {
      if (closedCount === 0) {
        status.innerHTML = "<b>Harika!</b> 🎉<br> Tüm banner linkleri doğru çalışıyor. <br> Bu kalite standardını koruduğunuz için teşekkürler.";
      } else {
        status.textContent = `${closedCount} kapalı promosyon bulundu.`;
      }
      status.className = "status success";
    }
    if (tableWrap) {
      tableWrap.style.display = closedCount > 0 ? "block" : "none";
    }
  };

  scrollToBottom(runCheck);
};

const renderHomeBox = () => {
  if (document.getElementById(DEEPLINK_BOX_ID)) {
    const tabBox = ensureBox(TAB_COPY_BOX_ID, "Sekme linkleri");
    setBoxContent(tabBox, "Sekmeler", "", "Sekme Linkleri");
    tabBox.onclick = () => {
      openModal();
    };
    const urlProductBox = ensureBox(URL_PRODUCT_BOX_ID, "URL ürün ID");
    setBoxContent(urlProductBox, "URL", "", "URL > Product ID");
    urlProductBox.onclick = () => {
      openUrlProductModal();
    };
    const productIdUrlBox = ensureBox(PRODUCTID_URL_BOX_ID, "ID ürün URL");
    setBoxContent(productIdUrlBox, "ID", "", "Product ID > URL");
    productIdUrlBox.onclick = () => {
      openProductIdUrlModal();
    };
    const idSkuBox = ensureBox(ID_SKU_BOX_ID, "ID SKU");
    setBoxContent(idSkuBox, "ID>SKU", "", "ID > SKU");
    idSkuBox.onclick = () => {
      openIdSkuModal();
    };
    const pimsIdBox = ensureBox(PIMS_ID_BOX_ID, "Product ID Scanner");
    const pimsIdValue = findPimsIdFromPage() || "bulunamadı";
    setBoxContent(pimsIdBox, "Product ID Scanner", pimsIdValue, "Product ID Scanner");
    pimsIdBox.dataset.copy = pimsIdValue;
    pimsIdBox.onclick = () => {
      openPimsIdModal();
    };
    let listingProductCrawlerBox = null;
    if (shouldShowListingProductCrawler()) {
      listingProductCrawlerBox = ensureBox(LISTING_PRODUCT_CRAWLER_BOX_ID, "Listing Product Crawler");
      setBoxContent(listingProductCrawlerBox, "Crawler", "", "Listing Product Crawler");
      listingProductCrawlerBox.onclick = () => {
        openListingProductCrawlerModal();
      };
    } else {
      const existing = document.getElementById(LISTING_PRODUCT_CRAWLER_BOX_ID);
      if (existing && existing.parentNode) {
        existing.parentNode.removeChild(existing);
      }
    }
    const hasEditorialSection = Boolean(
      document.querySelector(".THREE_ROW_SQUARE_BANNER_WEB")
    );
    let editorialControllerBox = null;
    if (hasEditorialSection) {
      editorialControllerBox = ensureBox(
        EDITORIAL_CONTROLLER_BOX_ID,
        "Editorial Controller"
      );
      setBoxContent(editorialControllerBox, "Edit", "", "Editorial Controller");
      editorialControllerBox.onclick = () => {
        openEditorialControllerModal();
      };
    }

    const container = ensureContainer();
    const elements = [
      document.getElementById(DEEPLINK_BOX_ID),
      urlProductBox,
      productIdUrlBox,
      idSkuBox,
      pimsIdBox
    ];
    if (listingProductCrawlerBox) {
      elements.push(listingProductCrawlerBox);
    }
    if (editorialControllerBox) {
      elements.push(editorialControllerBox);
    }
    const akakceProductCrawlerBox = ensureBox(
      AKAKCE_PRODUCT_CRAWLER_BOX_ID,
      "Akakce Product Crawler"
    );
    setBoxContent(akakceProductCrawlerBox, "Akakce", "", "Akakce Product Crawler");
    akakceProductCrawlerBox.onclick = () => {
      openAkakceProductCrawlerModal();
    };
    const akakceIdN11Box = ensureBox(
      AKAKCE_ID_N11_PRODUCT_BOX_ID,
      "Akakce ID > n11 Product"
    );
    setBoxContent(akakceIdN11Box, "Ak→Link", "", "Akakce ID > n11 Product");
    akakceIdN11Box.onclick = () => openAkakceIdN11ProductModal();
    const akakceCustomDealBox = ensureBox(
      AKAKCE_CUSTOM_DEAL_BOX_ID,
      "Akakce Custom Deal"
    );
    setBoxContent(akakceCustomDealBox, "Ak Deal", "", "Akakce Custom Deal");
    akakceCustomDealBox.onclick = () => openAkakceCustomDealModal();
    const akakceFullCategoryBox = ensureBox(
      AKAKCE_FULL_CATEGORY_BOX_ID,
      "Akakce Cat Products"
    );
    setBoxContent(akakceFullCategoryBox, "Ak Kat.", "", "Akakce Cat Products");
    akakceFullCategoryBox.onclick = () => openAkakceFullCategoryModal();
    const productMatchScoreBox = ensureBox(
      PRODUCT_MATCH_SCORE_BOX_ID,
      "Product Match Score"
    );
    setBoxContent(productMatchScoreBox, "Match Score", "", "Product Match Score");
    productMatchScoreBox.onclick = () => openProductMatchScoreModal();
    const priceProtectorBox = ensureBox(PRICE_PROTECTOR_BOX_ID, "Price Protector");
    setBoxContent(priceProtectorBox, "Price Protector", "", "Price Protector");
    priceProtectorBox.onclick = () => openPriceProtectorModal();
    const productPriceTrackingBox = ensureBox(PRODUCT_PRICE_TRACKING_BOX_ID, "Product Price Tracking");
    setBoxContent(productPriceTrackingBox, "Price Tracking", "", "Product Price Tracking");
    productPriceTrackingBox.onclick = () => openProductPriceTrackingModal();
    const promotionThemePinBox = ensureBox(PROMOTION_THEME_PIN_BOX_ID, "Promotion Theme Pin");
    setBoxContent(promotionThemePinBox, "Theme Pin", "", "Promotion Theme Pin");
    promotionThemePinBox.onclick = () => openPromotionThemePinModal();
    const soAnnouncementPopupBox = ensureBox(SO_ANNOUNCEMENT_POPUP_BOX_ID, "SO Duyuru & Popup, SSC");
    setBoxContent(soAnnouncementPopupBox, "SO Popup", "", "SO Duyuru & Popup, SSC");
    soAnnouncementPopupBox.onclick = () => openSoAnnouncementPopupModal();
    const bannerMailingBox = ensureBox(BANNER_MAILING_BOX_ID, "Banner Mailing");
    setBoxContent(bannerMailingBox, "Mailing", "", "Banner Mailing");
    bannerMailingBox.onclick = () => openBannerMailingModal();
    const productMailingBox = ensureBox(PRODUCT_MAILING_BOX_ID, "Product Mailing");
    setBoxContent(productMailingBox, "Product Mail", "", "Product Mailing");
    productMailingBox.onclick = () => openProductMailingModal();
    const logoResizerBox = ensureBox(LOGO_RESIZER_BOX_ID, "Logo Resizer");
    setBoxContent(logoResizerBox, "Logo Resize", "", "Logo Resizer");
    logoResizerBox.onclick = () => openLogoResizerModal();
    const logoListBox = ensureBox(LOGO_LIST_BOX_ID, "Logo List");
    setBoxContent(logoListBox, "Logo List", "", "Logo List");
    logoListBox.onclick = () => openLogoListModal();
    elements.push(akakceProductCrawlerBox);
    elements.push(akakceIdN11Box);
    elements.push(akakceCustomDealBox);
    elements.push(akakceFullCategoryBox);
    elements.push(productMatchScoreBox);
    elements.push(tabBox);
    elements.push(priceProtectorBox);
    elements.push(productPriceTrackingBox);
    elements.push(promotionThemePinBox);
    elements.push(soAnnouncementPopupBox);
    elements.push(bannerMailingBox);
    elements.push(productMailingBox);
    elements.push(logoResizerBox);
    elements.push(logoListBox);
    appendGroupedBoxes(container, elements);
    scheduleListingCrawlerCheck();
    return;
  }

  const box = ensureBox(DEEPLINK_BOX_ID, "Deeplink kopyala");
  setBoxContent(box, "Deeplink", HOME_DEEPLINK, "Deeplink Kopyala");

  box.onclick = async () => {
    try {
      await navigator.clipboard.writeText(HOME_DEEPLINK);
      animateCopy(box);
    } catch (error) {
      console.error("Kopyalama hatası:", error);
    }
  };
  const tabBox = ensureBox(TAB_COPY_BOX_ID, "Sekme linkleri");
  setBoxContent(tabBox, "Sekmeler", "", "Sekme Linkleri");
  tabBox.onclick = () => {
    openModal();
  };

  const urlProductBox = ensureBox(URL_PRODUCT_BOX_ID, "URL ürün ID");
  setBoxContent(urlProductBox, "URL", "", "URL > Product ID");
  urlProductBox.onclick = () => {
    openUrlProductModal();
  };
  const productIdUrlBox = ensureBox(PRODUCTID_URL_BOX_ID, "ID ürün URL");
  setBoxContent(productIdUrlBox, "ID", "", "Product ID > URL");
  productIdUrlBox.onclick = () => {
    openProductIdUrlModal();
  };
  const idSkuBox = ensureBox(ID_SKU_BOX_ID, "ID SKU");
  setBoxContent(idSkuBox, "ID>SKU", "", "ID > SKU");
  idSkuBox.onclick = () => {
    openIdSkuModal();
  };
  const pimsIdBox = ensureBox(PIMS_ID_BOX_ID, "Product ID Scanner");
  const pimsIdValue = findPimsIdFromPage() || "bulunamadı";
  setBoxContent(pimsIdBox, "Product ID Scanner", pimsIdValue, "Product ID Scanner");
  pimsIdBox.dataset.copy = pimsIdValue;
  pimsIdBox.onclick = () => {
    openPimsIdModal();
  };
  let listingProductCrawlerBox = null;
  if (shouldShowListingProductCrawler()) {
    listingProductCrawlerBox = ensureBox(LISTING_PRODUCT_CRAWLER_BOX_ID, "Listing Product Crawler");
    setBoxContent(listingProductCrawlerBox, "Crawler", "", "Listing Product Crawler");
    listingProductCrawlerBox.onclick = () => {
      openListingProductCrawlerModal();
    };
  } else {
    const existing = document.getElementById(LISTING_PRODUCT_CRAWLER_BOX_ID);
    if (existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
  }
  const hasEditorialSection = Boolean(
    document.querySelector(".THREE_ROW_SQUARE_BANNER_WEB")
  );
  let editorialControllerBox = null;
  if (hasEditorialSection) {
    editorialControllerBox = ensureBox(
      EDITORIAL_CONTROLLER_BOX_ID,
      "Editorial Controller"
    );
    setBoxContent(editorialControllerBox, "Edit", "", "Editorial Controller");
    editorialControllerBox.onclick = () => {
      openEditorialControllerModal();
    };
  }
  const akakceProductCrawlerBox = ensureBox(
    AKAKCE_PRODUCT_CRAWLER_BOX_ID,
    "Akakce Product Crawler"
  );
  setBoxContent(akakceProductCrawlerBox, "Akakce", "", "Akakce Product Crawler");
  akakceProductCrawlerBox.onclick = () => {
    openAkakceProductCrawlerModal();
  };
  const akakceIdN11Box = ensureBox(
    AKAKCE_ID_N11_PRODUCT_BOX_ID,
    "Akakce ID > n11 Product"
  );
  setBoxContent(akakceIdN11Box, "Ak→Link", "", "Akakce ID > n11 Product");
  akakceIdN11Box.onclick = () => openAkakceIdN11ProductModal();
  const akakceCustomDealBox = ensureBox(
    AKAKCE_CUSTOM_DEAL_BOX_ID,
    "Akakce Custom Deal"
  );
  setBoxContent(akakceCustomDealBox, "Ak Deal", "", "Akakce Custom Deal");
  akakceCustomDealBox.onclick = () => openAkakceCustomDealModal();
  const akakceFullCategoryBox = ensureBox(
    AKAKCE_FULL_CATEGORY_BOX_ID,
    "Akakce Cat Products"
  );
  setBoxContent(akakceFullCategoryBox, "Ak Kat.", "", "Akakce Cat Products");
  akakceFullCategoryBox.onclick = () => openAkakceFullCategoryModal();
  const productMatchScoreBox = ensureBox(
    PRODUCT_MATCH_SCORE_BOX_ID,
    "Product Match Score"
  );
  setBoxContent(productMatchScoreBox, "Match Score", "", "Product Match Score");
  productMatchScoreBox.onclick = () => openProductMatchScoreModal();
  const priceProtectorBox = ensureBox(PRICE_PROTECTOR_BOX_ID, "Price Protector");
  setBoxContent(priceProtectorBox, "Price Protector", "", "Price Protector");
  priceProtectorBox.onclick = () => openPriceProtectorModal();
  const productPriceTrackingBox = ensureBox(PRODUCT_PRICE_TRACKING_BOX_ID, "Product Price Tracking");
  setBoxContent(productPriceTrackingBox, "Price Tracking", "", "Product Price Tracking");
  productPriceTrackingBox.onclick = () => openProductPriceTrackingModal();
  const container = ensureContainer();
  const elements = [box, urlProductBox, productIdUrlBox, idSkuBox, pimsIdBox];
  if (listingProductCrawlerBox) {
    elements.push(listingProductCrawlerBox);
  }
  if (editorialControllerBox) {
    elements.push(editorialControllerBox);
  }
  elements.push(akakceProductCrawlerBox);
  elements.push(akakceIdN11Box);
  elements.push(akakceCustomDealBox);
  elements.push(akakceFullCategoryBox);
  elements.push(productMatchScoreBox);
  elements.push(tabBox);
  elements.push(priceProtectorBox);
  elements.push(productPriceTrackingBox);
  appendGroupedBoxes(container, elements);
  scheduleListingCrawlerCheck();
};

const renderBox = () => {
  if (isHepsiburadaHost() && !isHepsiburadaMagazaPage()) {
    const existingContainer = document.getElementById(CONTAINER_ID);
    if (existingContainer) {
      existingContainer.style.display = "none";
    }
    return;
  }
  applyExtensionVisibility();
  if (isTrendyolHost()) {
    const sellerProductsCrawlerBox = ensureBox(
      SELLER_PRODUCTS_CRAWLER_BOX_ID,
      "Seller Products Crawler"
    );
    setBoxContent(
      sellerProductsCrawlerBox,
      "Seller Crawler",
      "",
      "Seller Products Crawler"
    );
    sellerProductsCrawlerBox.onclick = () => {
      const magazaMid = getTrendyolMagazaMidFromPath();
      if (magazaMid) {
        window.location.href = `https://www.trendyol.com/sr?mid=${magazaMid}&os=1`;
      } else {
        openSellerProductsCrawlerModal();
      }
    };
    const container = ensureContainer();
    Array.from(container.children).forEach((c) => {
      if (c.id !== VERSION_BANNER_ID) c.remove();
    });
    appendGroupedBoxes(container, [sellerProductsCrawlerBox]);
    return;
  }
  if (isHepsiburadaMagazaPage()) {
    const hepsiburadaBox = ensureBox(
      HEPSIBURADA_SELLER_PRODUCTS_CRAWLER_BOX_ID,
      "Seller Products Crawler"
    );
    setBoxContent(hepsiburadaBox, "Seller Crawler", "", "Seller Products Crawler");
    hepsiburadaBox.onclick = () => openHepsiburadaSellerProductsCrawlerModal();
    const container = ensureContainer();
    Array.from(container.children).forEach((c) => {
      if (c.id !== VERSION_BANNER_ID) c.remove();
    });
    appendGroupedBoxes(container, [hepsiburadaBox]);
    return;
  }
  if (isBoPromotionPage()) {
    const boBox = ensureBox(BO_BOX_ID, "BO ürün ID topla");
    setBoxContent(boBox, "BO", "", "BO Product ID");
    boBox.onclick = () => {
      openBoModal();
    };
    const container = ensureContainer();
    Array.from(container.children).forEach((c) => { if (c.id !== VERSION_BANNER_ID) c.remove(); });
    container.append(boBox);
    return;
  }

  if (isBoCampaignPage()) {
    const checkerBox = ensureBox(PAGE_CHECKER_BOX_ID, "Page Checker");
    setBoxContent(checkerBox, "Checker", "", "Page Checker");
    checkerBox.onclick = () => {
      openPageCheckerModal();
    };
    const container = ensureContainer();
    Array.from(container.children).forEach((c) => { if (c.id !== VERSION_BANNER_ID) c.remove(); });
    container.append(checkerBox);
    return;
  }

  const promotionId = findPromotionIdFromUrl();
  const isProductUrl = isProductPageUrl();
  const productId = isProductUrl
    ? (findProductIdFromProductMeta() || findProductIdFromUrl() || findProductIdFromModel())
    : "";
  const dynamicPageId = findDynamicPageIdFromModel();
  const sellerId = findSellerIdFromModel();
  const categoryId = findCategoryIdFromModel();
  const isCategoryPage = isCategoryListingPage();
  const searchQuery = getSearchQuery();
  const isSearchPage = window.location.pathname === "/arama" && Boolean(searchQuery);
  const cartPage = isCartPage();
  const accountDeeplink = getAccountDeeplink();
  const isAccountPage = Boolean(accountDeeplink);
  const isDynamicPage =
    Boolean(dynamicPageId) &&
    !promotionId &&
    !productId &&
    !sellerId &&
    !categoryId &&
    !isSearchPage &&
    !window.location.pathname.startsWith("/urun/") &&
    !window.location.search.includes("promotions=");
  const pageId = promotionId || productId || sellerId || categoryId || dynamicPageId || getPageId();
  const deeplinkParam = promotionId
    ? `${PROMOTION_DEEPLINK_PREFIX}${encodeURIComponent(promotionId)}`
    : productId
      ? `n11mf://n11.com?pt=pd&pd=${encodeURIComponent(productId)}`
      : sellerId
        ? `n11mf://n11.com?pt=nss&pd=${encodeURIComponent(sellerId)}`
      : isSearchPage
        ? `n11mf://n11.com?pt=sr&pd=${encodeURIComponent(searchQuery)}`
        : cartPage
          ? "n11mf://n11.com?pt=ca&pd=-"
          : isAccountPage
            ? accountDeeplink
            : isCategoryPage
              ? `n11mf://n11.com?pt=ct&pd=${encodeURIComponent(categoryId || "-")}`
              : dynamicPageId
                ? `${DYNAMIC_DEEPLINK_PREFIX}${encodeURIComponent(dynamicPageId)}`
                : buildDeeplinkParam(pageId);

  const idBox = ensureBox(PAGE_ID_BOX_ID, "ID kopyala");
  const idLabel = promotionId
    ? "ID"
    : productId
      ? "Ürün"
      : sellerId
        ? "Mağaza"
      : cartPage
        ? "ID"
        : isSearchPage
        ? "ID"
        : isCategoryPage
          ? "Kategori"
          : dynamicPageId
            ? "Dynamic Page"
            : "ID";
  const idValue = pageId || "bulunamadı";
  if (isSearchPage || cartPage || isAccountPage) {
    idBox.remove();
  } else {
    setBoxContent(
      idBox,
      idLabel,
      idValue,
      `${idLabel}: <b>${idValue}</b>`
    );
    idBox.dataset.copy = `${pageId || "bulunamadı"}`;

    idBox.onclick = async () => {
      const text = idBox.dataset.copy || "bulunamadı";
      try {
        await navigator.clipboard.writeText(text);
        animateCopy(idBox);
      } catch (error) {
        console.error("Kopyalama hatası:", error);
      }
    };
  }

  let inlinePimsIdBox = null;
  if (!isSearchPage && !cartPage && !isAccountPage && shouldShowInlinePimsIdBox()) {
    inlinePimsIdBox = ensureBox(INLINE_PIMS_ID_BOX_ID, "Pims : ID");
    const setInlinePimsContent = () => {
      const value = getInlinePimsIdFromModel() || "bulunamadı";
      const safeValue = escapeHtml(value);
      setBoxContent(inlinePimsIdBox, "Pims", value, `Pims : <b style="color:#f4e">${safeValue}</b>`);
      inlinePimsIdBox.dataset.copy = value;
      return value;
    };
    const inlinePimsIdValue = setInlinePimsContent();
    inlinePimsIdBox.onclick = async () => {
      const text = inlinePimsIdBox.dataset.copy || "bulunamadı";
      try {
        await navigator.clipboard.writeText(text);
        animateCopy(inlinePimsIdBox);
      } catch (error) {
        console.error("Kopyalama hatası:", error);
      }
    };
    if (inlinePimsIdValue === "bulunamadı") {
      [400, 1200, 2500].forEach((delay) => {
        window.setTimeout(() => {
          if (!document.getElementById(INLINE_PIMS_ID_BOX_ID)) return;
          setInlinePimsContent();
        }, delay);
      });
    }
  } else {
    const existingInlinePims = document.getElementById(INLINE_PIMS_ID_BOX_ID);
    if (existingInlinePims && existingInlinePims.parentNode) {
      existingInlinePims.parentNode.removeChild(existingInlinePims);
    }
  }

  const deeplinkBox = ensureBox(DEEPLINK_BOX_ID, "Deeplink kopyala");
  setBoxContent(
    deeplinkBox,
    "Deeplink",
    deeplinkParam || "bulunamadı",
    "Deeplink Kopyala"
  );
  deeplinkBox.dataset.copy = deeplinkParam || "bulunamadı";

  deeplinkBox.onclick = async () => {
    const text = deeplinkBox.dataset.copy || "bulunamadı";
    try {
      await navigator.clipboard.writeText(text);
      animateCopy(deeplinkBox);
    } catch (error) {
      console.error("Kopyalama hatası:", error);
    }
  };

  const tabBox = ensureBox(TAB_COPY_BOX_ID, "Sekme linkleri");
  setBoxContent(tabBox, "Sekmeler", "", "Sekme Linkleri");
  tabBox.onclick = () => {
    openModal();
  };

  const urlProductBox = ensureBox(URL_PRODUCT_BOX_ID, "URL ürün ID");
  setBoxContent(urlProductBox, "URL", "", "URL > Product ID");
  urlProductBox.onclick = () => {
    openUrlProductModal();
  };
  const productIdUrlBox = ensureBox(PRODUCTID_URL_BOX_ID, "ID ürün URL");
  setBoxContent(productIdUrlBox, "ID", "", "Product ID > URL");
  productIdUrlBox.onclick = () => {
    openProductIdUrlModal();
  };
  const idSkuBox = ensureBox(ID_SKU_BOX_ID, "ID SKU");
  setBoxContent(idSkuBox, "ID>SKU", "", "ID > SKU");
  idSkuBox.onclick = () => {
    openIdSkuModal();
  };
  const pimsIdBox = ensureBox(PIMS_ID_BOX_ID, "Product ID Scanner");
  const pimsIdValue = findPimsIdFromPage() || "bulunamadı";
  setBoxContent(pimsIdBox, "Product ID Scanner", pimsIdValue, "Product ID Scanner");
  pimsIdBox.dataset.copy = pimsIdValue;
  pimsIdBox.onclick = () => {
    openPimsIdModal();
  };
  let listingProductCrawlerBox = null;
  if (shouldShowListingProductCrawler()) {
    listingProductCrawlerBox = ensureBox(LISTING_PRODUCT_CRAWLER_BOX_ID, "Listing Product Crawler");
    setBoxContent(listingProductCrawlerBox, "Crawler", "", "Listing Product Crawler");
    listingProductCrawlerBox.onclick = () => {
      openListingProductCrawlerModal();
    };
  } else {
    const existing = document.getElementById(LISTING_PRODUCT_CRAWLER_BOX_ID);
    if (existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
  }
  let offerControllerBox = null;
  if (isOfferControllerPage()) {
    offerControllerBox = ensureBox(OFFER_CONTROLLER_BOX_ID, "Offer Controller");
    setBoxContent(offerControllerBox, "Offer Controller", "", "Offer Controller");
    offerControllerBox.onclick = () => {
      openOfferControllerModal();
    };
  } else {
    const existingOffer = document.getElementById(OFFER_CONTROLLER_BOX_ID);
    if (existingOffer && existingOffer.parentNode) {
      existingOffer.parentNode.removeChild(existingOffer);
    }
  }
  const akakceProductCrawlerBox = ensureBox(
    AKAKCE_PRODUCT_CRAWLER_BOX_ID,
    "Akakce Product Crawler"
  );
  setBoxContent(
    akakceProductCrawlerBox,
    "Akakce",
    "",
    "Akakce Product Crawler"
  );
  akakceProductCrawlerBox.onclick = () => {
    openAkakceProductCrawlerModal();
  };
  const akakceIdN11Box = ensureBox(
    AKAKCE_ID_N11_PRODUCT_BOX_ID,
    "Akakce ID > n11 Product"
  );
  setBoxContent(
    akakceIdN11Box,
    "Ak→Link",
    "",
    "Akakce ID > n11 Product"
  );
  akakceIdN11Box.onclick = () => {
    openAkakceIdN11ProductModal();
  };
  const akakceCustomDealBox = ensureBox(
    AKAKCE_CUSTOM_DEAL_BOX_ID,
    "Akakce Custom Deal"
  );
  setBoxContent(akakceCustomDealBox, "Ak Deal", "", "Akakce Custom Deal");
  akakceCustomDealBox.onclick = () => {
    openAkakceCustomDealModal();
  };
  const akakceFullCategoryBox = ensureBox(
    AKAKCE_FULL_CATEGORY_BOX_ID,
    "Akakce Cat Products"
  );
  setBoxContent(akakceFullCategoryBox, "Ak Kat.", "", "Akakce Cat Products");
  akakceFullCategoryBox.onclick = () => openAkakceFullCategoryModal();
  const productMatchScoreBox = ensureBox(
    PRODUCT_MATCH_SCORE_BOX_ID,
    "Product Match Score"
  );
  setBoxContent(productMatchScoreBox, "Match Score", "", "Product Match Score");
  productMatchScoreBox.onclick = () => openProductMatchScoreModal();
  const boProductManagementBox = ensureBox(
    BO_PRODUCT_MANAGEMENT_BOX_ID,
    "BO Ürün Yönetimi"
  );
  setBoxContent(
    boProductManagementBox,
    "BO",
    "",
    "BO Ürün Yönetimi"
  );
  boProductManagementBox.onclick = () => {
    openBoProductManagement(productId || findProductIdFromUrl());
  };
  const hasEditorialSection = Boolean(
    document.querySelector(".THREE_ROW_SQUARE_BANNER_WEB")
  );
  let editorialControllerBox = null;
  if (hasEditorialSection) {
    editorialControllerBox = ensureBox(
      EDITORIAL_CONTROLLER_BOX_ID,
      "Editorial Controller"
    );
    setBoxContent(editorialControllerBox, "Edit", "", "Editorial Controller");
    editorialControllerBox.onclick = () => {
      openEditorialControllerModal();
    };
  }

  const bannerCheckerBox = ensureBox(BANNER_CHECKER_BOX_ID, "Banner Checker");
  setBoxContent(bannerCheckerBox, "Banner", "", "Banner Checker");
  bannerCheckerBox.onclick = () => {
    openBannerCheckerModal();
  };
  const sellerProductMatchBox = ensureBox(SELLER_PRODUCT_MATCH_BOX_ID, "Seller Product Match");
  setBoxContent(sellerProductMatchBox, "Match", "", "Seller Product Match");
  sellerProductMatchBox.onclick = () => openSellerProductMatchModal();

  const productDealControllerBox = ensureBox(PRODUCT_DEAL_CONTROLLER_BOX_ID, "Product Deal Controller");
  setBoxContent(productDealControllerBox, "Deal", "", "Product Deal Controller");
  productDealControllerBox.onclick = () => openProductDealControllerModal();

  const clearCacheBox = ensureBox(CLEAR_CACHE_BOX_ID, "Clear Cache");
  setBoxContent(clearCacheBox, "Cache", "", "Clear Cache");

  const priceProtectorBox = ensureBox(PRICE_PROTECTOR_BOX_ID, "Price Protector");
  setBoxContent(priceProtectorBox, "Price Protector", "", "Price Protector");
  priceProtectorBox.onclick = () => openPriceProtectorModal();
  const productPriceTrackingBox = ensureBox(PRODUCT_PRICE_TRACKING_BOX_ID, "Product Price Tracking");
  setBoxContent(productPriceTrackingBox, "Price Tracking", "", "Product Price Tracking");
  productPriceTrackingBox.onclick = () => openProductPriceTrackingModal();

  const sellerProductCountBox = ensureBox(SELLER_PRODUCT_COUNT_BOX_ID, "Seller Product Count");
  setBoxContent(sellerProductCountBox, "Ürün Sayısı", "", "Seller Product Count");
  sellerProductCountBox.onclick = () => openSellerProductCountModal();
  const promotionThemePinBox = ensureBox(PROMOTION_THEME_PIN_BOX_ID, "Promotion Theme Pin");
  setBoxContent(promotionThemePinBox, "Theme Pin", "", "Promotion Theme Pin");
  promotionThemePinBox.onclick = () => openPromotionThemePinModal();
  const soAnnouncementPopupBox = ensureBox(SO_ANNOUNCEMENT_POPUP_BOX_ID, "SO Duyuru & Popup, SSC");
  setBoxContent(soAnnouncementPopupBox, "SO Popup", "", "SO Duyuru & Popup, SSC");
  soAnnouncementPopupBox.onclick = () => openSoAnnouncementPopupModal();
  const bannerMailingBox = ensureBox(BANNER_MAILING_BOX_ID, "Banner Mailing");
  setBoxContent(bannerMailingBox, "Mailing", "", "Banner Mailing");
  bannerMailingBox.onclick = () => openBannerMailingModal();
  const productMailingBox = ensureBox(PRODUCT_MAILING_BOX_ID, "Product Mailing");
  setBoxContent(productMailingBox, "Product Mail", "", "Product Mailing");
  productMailingBox.onclick = () => openProductMailingModal();
  const logoResizerBox = ensureBox(LOGO_RESIZER_BOX_ID, "Logo Resizer");
  setBoxContent(logoResizerBox, "Logo Resize", "", "Logo Resizer");
  logoResizerBox.onclick = () => openLogoResizerModal();
  const logoListBox = ensureBox(LOGO_LIST_BOX_ID, "Logo List");
  setBoxContent(logoListBox, "Logo List", "", "Logo List");
  logoListBox.onclick = () => openLogoListModal();

  clearCacheBox.onclick = async () => {
    if (!dynamicPageId) {
      alert("Dynamic Page ID bulunamadı.");
      return;
    }
    try {
      chrome.runtime.sendMessage(
        {
          type: "clear-dynamic-page-cache",
          dynamicPageId
        },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error("Clear cache hatası:", chrome.runtime.lastError.message);
            return;
          }
          if (!response || !response.ok) {
            console.error("Clear cache başlatılamadı:", response?.error);
          }
        }
      );
    } catch (error) {
      console.error("Clear cache hatası:", error);
    }
  };

  const container = ensureContainer();
  const ordered = [];
  if (!isSearchPage && !cartPage && !isAccountPage) {
    ordered.push(idBox);
    if (inlinePimsIdBox) {
      ordered.push(inlinePimsIdBox);
    }
    if (window.location.pathname.startsWith("/urun/")) {
      ordered.push(boProductManagementBox);
    }
  }
  if (isPublicN11Host()) {
    ordered.push(urlProductBox);
    ordered.push(productIdUrlBox);
    ordered.push(idSkuBox);
    ordered.push(pimsIdBox);
    if (listingProductCrawlerBox) {
      ordered.push(listingProductCrawlerBox);
    }
    if (offerControllerBox) {
      ordered.push(offerControllerBox);
    }
    if (editorialControllerBox) {
      ordered.push(editorialControllerBox);
    }
    ordered.push(akakceProductCrawlerBox);
    ordered.push(akakceIdN11Box);
    ordered.push(akakceCustomDealBox);
    ordered.push(akakceFullCategoryBox);
    ordered.push(productMatchScoreBox);
    ordered.push(bannerCheckerBox);
    ordered.push(sellerProductMatchBox);
    ordered.push(productDealControllerBox);
  }
  if (isDynamicPage) {
    ordered.push(clearCacheBox);
  }
  ordered.push(deeplinkBox, tabBox);
  ordered.push(priceProtectorBox);
  ordered.push(productPriceTrackingBox);
  ordered.push(sellerProductCountBox);
  ordered.push(promotionThemePinBox);
  ordered.push(soAnnouncementPopupBox);
  ordered.push(bannerMailingBox);
  ordered.push(productMailingBox);
  ordered.push(logoResizerBox);
  ordered.push(logoListBox);
  appendGroupedBoxes(container, ordered);
  scheduleListingCrawlerCheck();
};

const injectPageScript = () => {
  if (document.getElementById(INJECTED_SCRIPT_ID)) {
    return;
  }

  const script = document.createElement("script");
  script.id = INJECTED_SCRIPT_ID;
  script.src = chrome.runtime.getURL("page-bridge.js");
  script.dataset.source = MESSAGE_SOURCE;
  script.async = false;
  document.documentElement.appendChild(script);
};

const listenForDynamicPageId = () => {
  window.addEventListener("message", (event) => {
    if (event.source !== window) {
      return;
    }
    const data = event.data;
    if (!data || data.source !== MESSAGE_SOURCE) {
      return;
    }
    if (data.productId) {
      productIdFromPage = String(data.productId);
      renderBox();
    }
    if (data.sellerId) {
      sellerIdFromPage = String(data.sellerId);
      renderBox();
    }
    if (data.categoryId) {
      categoryIdFromPage = String(data.categoryId);
      renderBox();
    }
    if (typeof data.isCategoryPage !== "undefined") {
      isCategoryPageFromPage = Boolean(data.isCategoryPage);
      renderBox();
    }
    if (data.dynamicPageId) {
      dynamicPageIdFromPage = String(data.dynamicPageId);
      renderBox();
    }
    if (data.dataLayerPageName != null) {
      const next = String(data.dataLayerPageName || "").trim();
      if (next !== dataLayerPageNameFromPage) {
        dataLayerPageNameFromPage = next;
        const pmsModal = document.getElementById(PRODUCT_MATCH_SCORE_MODAL_ID);
        if (pmsModal && pmsModal.style.display === "flex") {
          syncProductMatchScoreModal(pmsModal);
        }
        try {
          if (
            sessionStorage.getItem(PRODUCT_MATCH_SCORE_FLOW_ARMED) === "1" &&
            sessionStorage.getItem(PRODUCT_MATCH_SCORE_STORAGE_AUTO)
          ) {
            window.setTimeout(tryResumeProductMatchScoreAuto, 150);
          }
        } catch {
          /* ignore */
        }
      }
    }
    if (
      typeof data.modelTotalCount === "number" &&
      Number.isFinite(data.modelTotalCount)
    ) {
      if (data.modelTotalCount !== modelTotalCountFromPage) {
        modelTotalCountFromPage = data.modelTotalCount;
        const pmsModal = document.getElementById(PRODUCT_MATCH_SCORE_MODAL_ID);
        if (pmsModal && pmsModal.style.display === "flex") {
          syncProductMatchScoreModal(pmsModal);
        }
        try {
          if (
            sessionStorage.getItem(PRODUCT_MATCH_SCORE_FLOW_ARMED) === "1" &&
            sessionStorage.getItem(PRODUCT_MATCH_SCORE_STORAGE_AUTO)
          ) {
            window.setTimeout(tryResumeProductMatchScoreAuto, 150);
          }
        } catch {
          /* ignore */
        }
      }
    }
  });
};

const init = () => {
  if (isBoHost() && !isBoPromotionPage() && !isBoInventoryPage()) {
    return;
  }
  loadExtensionVisibilityState();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      if (isBoInventoryPage()) {
        initBoEditorialController();
        return;
      }
      if (isPublicN11Host() && !isBoPromotionPage() && !isBoInventoryPage()) {
        listenForDynamicPageId();
        injectPageScript();
      }
      renderBox();
      scheduleVersionCheckAfterLoad();
      scheduleProductMatchScoreModalReopenIfPending();
      if (isPublicN11Host() && !isBoPromotionPage() && !isBoInventoryPage()) {
        window.setTimeout(() => {
          try {
            if (sessionStorage.getItem(PRODUCT_MATCH_SCORE_FLOW_ARMED) === "1") {
              tryResumeProductMatchScoreAuto();
            }
          } catch {
            /* ignore */
          }
        }, 700);
      }
    });
    return;
  }
  if (isBoInventoryPage()) {
    initBoEditorialController();
    return;
  }
  if (isPublicN11Host() && !isBoPromotionPage() && !isBoInventoryPage()) {
    listenForDynamicPageId();
    injectPageScript();
  }
  renderBox();
  scheduleVersionCheckAfterLoad();
  scheduleProductMatchScoreModalReopenIfPending();

  if (isPublicN11Host() && !isBoPromotionPage() && !isBoInventoryPage()) {
    window.setTimeout(() => {
      try {
        if (sessionStorage.getItem(PRODUCT_MATCH_SCORE_FLOW_ARMED) === "1") {
          tryResumeProductMatchScoreAuto();
        }
      } catch {
        /* ignore */
      }
    }, 700);
  }

  if (isPublicN11Host() && !isHomePage()) {
    let tries = 0;
    const maxTries = 20;
    const interval = window.setInterval(() => {
      tries += 1;
      const dynamicPageId = findDynamicPageIdFromModel();
      if (dynamicPageId) {
        renderBox();
        window.clearInterval(interval);
      } else if (tries >= maxTries) {
        window.clearInterval(interval);
      }
    }, 500);
  }
};

document.addEventListener(
  "mousedown",
  (event) => {
    if (event.button === 2) {
      lastRightClickTarget = event.target;
    }
  },
  true
);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "toggle-extension-ui") {
    toggleExtensionVisibility();
    sendResponse({ ok: true, hidden: isExtensionHidden });
    return true;
  }
  if (message && message.type === "akakce-custom-deal-progress") {
    if (typeof akakceCustomDealProgressHandler === "function") {
      akakceCustomDealProgressHandler(message.rows || [], Number(message.pageCount || 0));
    }
    sendResponse({ ok: true });
    return true;
  }
  if (message && message.type === "akakce-custom-deal-captcha-wait") {
    if (typeof akakceCustomDealCaptchaHandler === "function") {
      akakceCustomDealCaptchaHandler(message.hint || "");
    }
    sendResponse({ ok: true });
    return true;
  }
  if (message && message.type === "akakce-full-category-update") {
    const el = document.getElementById(AKAKCE_FULL_CATEGORY_MODAL_ID);
    if (el && el.style.display === "flex") {
      const s = el.querySelector("#akakce-full-category-status");
      if (s && message.statusText != null) {
        const msg = String(message.statusText);
        s.textContent = msg;
        s.className = "status akakce-full-category-crawl-progress";
        if (msg) s.removeAttribute("hidden");
      }
    }
    sendResponse({ ok: true });
    return true;
  }
  return false;
});

init();
