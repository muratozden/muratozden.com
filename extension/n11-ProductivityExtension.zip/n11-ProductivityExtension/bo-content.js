// BO promosyon ürün listesi sayfasında ürün ID toplama
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "bo-product-search") {
    const productId = String(request.productId || "").trim();
    if (!productId) {
      sendResponse({ success: false, error: "Product ID bulunamadı." });
      return false;
    }
    const textarea = document.querySelector("textarea#idProductIds");
    const button = document.querySelector("button#searchComp\\:btnSearch_action");
    if (!textarea || !button) {
      sendResponse({ success: false, error: "BO ürün alanları bulunamadı." });
      return false;
    }
    textarea.value = productId;
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    textarea.dispatchEvent(new Event("change", { bubbles: true }));
    button.click();
    const maxTries = 40;
    let tries = 0;
    const tryClick = () => {
      tries += 1;
      const links = document.querySelectorAll(
        "#idDataTable_data a.ui-commandlink, table#idDataTable_data a.ui-commandlink, tbody#idDataTable_data a.ui-commandlink"
      );
      let targetLink = null;
      links.forEach((link) => {
        if ((link.textContent || "").trim() === productId) {
          targetLink = link;
        }
      });
      if (!targetLink) {
        const fallbackLinks = document.querySelectorAll("a.ui-commandlink");
        fallbackLinks.forEach((link) => {
          if ((link.textContent || "").trim() === productId) {
            targetLink = link;
          }
        });
      }
      if (targetLink) {
        if (typeof targetLink.onclick === "function") {
          targetLink.onclick();
        } else {
          targetLink.click();
        }
        sendResponse({ success: true });
        return;
      }
      if (tries >= maxTries) {
        sendResponse({ success: false, error: "Ürün linki bulunamadı." });
        return;
      }
      window.setTimeout(tryClick, 500);
    };
    window.setTimeout(tryClick, 1000);
    return true;
  }
  if (request.action === "collectProductIds") {
    collectProductIds()
      .then((result) => {
        sendResponse({ success: true, data: result });
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  if (request.action === "clearDynamicPageCache") {
    const dynamicPageId = String(request.dynamicPageId || "").trim();
    if (!dynamicPageId) {
      sendResponse({ success: false, error: "Dynamic Page ID bulunamadı." });
      return false;
    }
    clearDynamicPageCache(dynamicPageId)
      .then(() => {
        sendResponse({ success: true });
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  if (request.action === "getCollectedProducts") {
    getStoredProducts()
      .then((products) => {
        sendResponse({ success: true, data: products });
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  if (request.action === "clearCollectedProducts") {
    clearStoredProducts()
      .then(() => {
        sendResponse({ success: true });
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

const getPromotionIdFromUrl = () => {
  try {
    const url = new URL(window.location.href);
    return url.searchParams.get("promotionId") || "unknown";
  } catch {
    return "unknown";
  }
};

const getStorageKey = () => {
  return `n11_promotion_products_${getPromotionIdFromUrl()}`;
};

const getStoredProducts = async () => {
  const key = getStorageKey();
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (res) => {
      if (chrome.runtime.lastError) {
        resolve([]);
        return;
      }
      resolve(Array.isArray(res[key]) ? res[key] : []);
    });
  });
};

const saveProductsIncremental = async (newProducts) => {
  const key = getStorageKey();
  const existing = await getStoredProducts();
  const seen = new Set(existing.map((p) => p.id));
  let added = 0;
  newProducts.forEach((p) => {
    if (p && p.id && !seen.has(p.id)) {
      existing.push(p);
      seen.add(p.id);
      added += 1;
    }
  });
  await new Promise((resolve) => {
    chrome.storage.local.set({ [key]: existing }, () => resolve());
  });
  return { total: existing.length, added };
};

const clearStoredProducts = async () => {
  const key = getStorageKey();
  await new Promise((resolve) => {
    chrome.storage.local.remove([key], () => resolve());
  });
};

const collectProductIds = async () => {
  const storedAtStart = await getStoredProducts();
  const products = Array.isArray(storedAtStart) ? [...storedAtStart] : [];
  const seenIds = new Set(products.map((p) => p.id));

  const selectElement = document.querySelector("select.ui-paginator-rpp-options");
  if (selectElement) {
    const option200 = selectElement.querySelector('option[value="200"]');
    if (option200) {
      option200.selected = true;
      selectElement.dispatchEvent(new Event("change"));
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }
  }

  const getCurrentPage = () => {
    const paginatorBottom = document.querySelector("td#tblPromotionProductId_paginator_bottom");
    if (!paginatorBottom) {
      return 1;
    }
    const activePage = paginatorBottom.querySelector(
      "span.ui-paginator-pages > .ui-paginator-page.ui-state-active"
    );
    if (activePage) {
      const pageNum = parseInt(activePage.textContent.trim(), 10);
      return Number.isNaN(pageNum) ? 1 : pageNum;
    }
    return 1;
  };

  let currentPage = getCurrentPage();
  let hasMorePages = true;
  const MAX_PRODUCTS = 10000;

  while (hasMorePages && products.length < MAX_PRODUCTS) {
    const rows = document.querySelectorAll("tbody#tblPromotionProductId_data tr");
    if (rows.length === 0) {
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }

    let pageProductCount = 0;
    rows.forEach((row) => {
      const cells = row.querySelectorAll("td");
      if (cells.length >= 4) {
        const productId = (cells[2]?.textContent || "").trim();
        const productName = (cells[3]?.textContent || "").trim();
        if (productId && !seenIds.has(productId)) {
          seenIds.add(productId);
          products.push({ id: productId, name: productName });
          pageProductCount += 1;
        }
      }
    });

    if (pageProductCount > 0) {
      await saveProductsIncremental(products.slice(-pageProductCount));
    }

    const paginatorBottom = document.querySelector("td#tblPromotionProductId_paginator_bottom");
    let nextButton = null;
    let disabledNextButton = null;
    if (paginatorBottom) {
      nextButton = paginatorBottom.querySelector("span.ui-paginator-next:not(.ui-state-disabled)");
      disabledNextButton = paginatorBottom.querySelector("span.ui-paginator-next.ui-state-disabled");
    }

    if (disabledNextButton) {
      hasMorePages = false;
      break;
    }

    if (nextButton) {
      nextButton.click();
      currentPage += 1;
      await new Promise((resolve) => setTimeout(resolve, 3000));
    } else {
      hasMorePages = false;
    }
  }

  return products;
};

const waitForElement = async (finder, tries = 30, delay = 500) => {
  for (let attempt = 0; attempt < tries; attempt += 1) {
    const result = finder();
    if (result) {
      return result;
    }
    await new Promise((resolve) => setTimeout(resolve, delay));
  }
  return null;
};

const findDynamicPageRowLink = (dynamicPageId) => {
  const table = document.querySelector("#dynamicPageDatatable_data");
  if (!table) {
    return null;
  }
  const links = Array.from(table.querySelectorAll("a"));
  if (links.length === 0) {
    return null;
  }
  const exact = links.find((link) => link.textContent.trim() === dynamicPageId);
  return exact || links[0];
};

const clearDynamicPageCache = async (dynamicPageId) => {
  const input = await waitForElement(() => document.querySelector("input#dynamicPageId"));
  if (!input) {
    throw new Error("dynamicPageId input bulunamadı.");
  }
  input.value = dynamicPageId;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));

  const searchButton = document.querySelector("button#searchComp\\:btnSearch_action");
  if (searchButton) {
    searchButton.click();
  }

  await new Promise((resolve) => setTimeout(resolve, 800));

  const link = await waitForElement(() => findDynamicPageRowLink(dynamicPageId));
  if (!link) {
    throw new Error("Dynamic Page linki bulunamadı.");
  }
  sessionStorage.setItem("n11ClearCachePending", "1");
  link.click();

};

const showCacheSuccessMessage = () => {
  const existing = document.getElementById("n11-clearcache-modal");
  if (existing) {
    existing.remove();
  }

  if (!document.getElementById("n11-clearcache-style")) {
    const style = document.createElement("style");
    style.id = "n11-clearcache-style";
    style.textContent = `
      .n11-clearcache-modal {
        position: fixed;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0, 0, 0, 0.35);
        z-index: 2147483647;
        opacity: 0;
        transition: opacity 0.25s ease;
      }
      .n11-clearcache-modal.visible {
        opacity: 1;
      }
      .n11-clearcache-card {
        background: #ffffff;
        color: #1c1c1e;
        border-radius: 10px;
        padding: 16px 20px;
        font-size: 14px;
        font-weight: 600;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
      }
    `;
    document.head.appendChild(style);
  }

  const modal = document.createElement("div");
  modal.id = "n11-clearcache-modal";
  modal.className = "n11-clearcache-modal";
  modal.innerHTML = `
    <div class="n11-clearcache-card">Cache temizlendi</div>
  `;
  document.body.appendChild(modal);

  window.setTimeout(() => {
    modal.classList.add("visible");
  }, 10);

  window.setTimeout(() => {
    modal.classList.remove("visible");
  }, 1800);

  window.setTimeout(() => {
    modal.remove();
  }, 2300);
};

const showPendingCacheMessage = () => {
  if (sessionStorage.getItem("n11ClearCacheSuccess") !== "1") {
    return;
  }
  sessionStorage.removeItem("n11ClearCacheSuccess");
  showCacheSuccessMessage();
};

const runPendingClearCache = async () => {
  if (sessionStorage.getItem("n11ClearCachePending") !== "1") {
    return;
  }
  const clearButton = await waitForElement(() => document.querySelector("button#btnClearCache"));
  if (!clearButton) {
    return;
  }
  sessionStorage.removeItem("n11ClearCachePending");
  sessionStorage.setItem("n11ClearCacheSuccess", "1");
  console.log("Clear Cache tıklandı.");
  clearButton.style.background = "#10b981";
  clearButton.style.borderColor = "#10b981";
  clearButton.style.color = "#ffffff";
  clearButton.click();
  if (typeof window.PrimeFaces !== "undefined" && window.PrimeFaces.ab) {
    window.PrimeFaces.ab({
      source: "btnClearCache",
      process: "componentGroupPanel",
      update: "componentGroupPanel"
    });
  }
};

const isInventoryManagementPage = () => {
  return window.location.pathname === "/backoffice/inventory/inventoryManagement.xhtml";
};

const initInventoryNameSync = () => {
  if (!isInventoryManagementPage()) {
    return;
  }

  const attach = () => {
    const nameSource = document.querySelector("input#contentBannerName");
    const nameTarget = document.querySelector("input#imageSEODescription");
    const urlSource = document.querySelector("input#contentBannerUrl");
    const urlTarget = document.querySelector("input#contentMobileWebUrl");
    const seoTarget = document.querySelector("input#imageSEODescription");

    if (!nameSource || !nameTarget || !urlSource || !urlTarget) {
      return false;
    }

    if (seoTarget && !seoTarget.dataset.n11MessageAdded) {
      const messageSpan = document.createElement("span");
      messageSpan.textContent = "Önemli(!): Offer veya anlamsız metinler yerine, marka ya da kampanyayı tanımlayan açıklayıcı bir metin giriniz.";
      messageSpan.className = "n11-seo-message";
      messageSpan.style.fontSize = "11px";
      messageSpan.style.color = "#1c1c1e";
      messageSpan.style.marginTop = "6px";
      messageSpan.style.lineHeight = "15px";
      messageSpan.style.padding = "6px";
      messageSpan.style.borderRadius = "4px";
      messageSpan.style.display = "block";
      messageSpan.style.maxWidth = "240px";
      messageSpan.style.fontWeight = "500";
      messageSpan.style.backgroundColor = "#FFD10D";
      seoTarget.insertAdjacentElement("afterend", messageSpan);
      seoTarget.dataset.n11MessageAdded = "1";
    }

    const mobileBannerLabel = document.querySelector('label[for="contentDeepLinkPage"]');
    if (mobileBannerLabel && !mobileBannerLabel.dataset.n11AppUrlMessageAdded) {
      const appUrlMessage = document.createElement("div");
      appUrlMessage.className = "n11-appurl-message";
      appUrlMessage.innerHTML = 'Banner eklerken “<b>Mobile Banner URL</b>” seçilmeli ve <b>sayfa ID</b> girilmelidir; aksi halde APP yönlendirmesi <u>çalışmaz.</u>';
      mobileBannerLabel.insertAdjacentElement("afterend", appUrlMessage);
      mobileBannerLabel.dataset.n11AppUrlMessageAdded = "1";
    }

    if (nameSource.dataset.n11SyncBound === "1" && urlSource.dataset.n11SyncBound === "1") {
      return true;
    }

    const syncName = () => {
      nameTarget.value = nameSource.value || "";
      nameTarget.dispatchEvent(new Event("input", { bubbles: true }));
      nameTarget.dispatchEvent(new Event("change", { bubbles: true }));
    };

    const syncUrl = () => {
      const value = urlSource.value || "";
      urlTarget.value = value;
      urlTarget.dispatchEvent(new Event("input", { bubbles: true }));
      urlTarget.dispatchEvent(new Event("change", { bubbles: true }));

      if (urlSource.dataset.n11UrlInit !== "1") {
        urlSource.dataset.n11UrlInit = "1";
        if (value) {
          return;
        }
      }

      const promotionId = (() => {
        try {
          const url = new URL(value);
          return url.searchParams.get("promotions") || "";
        } catch {
          return "";
        }
      })();

      if (promotionId) {
        const panel = document.querySelector(
          "div#contentDeepLinkPage_panel ul.ui-selectonemenu-items"
        );
        if (panel) {
          const items = panel.querySelectorAll("li.ui-selectonemenu-item");
          for (const item of items) {
            if (item.textContent.trim() === "Promotion") {
              item.click();
              break;
            }
          }
        }

        window.setTimeout(() => {
          const detailInput = document.querySelector("#contentDeepLinkDetail");
          if (detailInput) {
            const currentValue = (detailInput.value || "").trim();
            const lastApplied = detailInput.dataset.n11PromotionId || "";
            if (currentValue && currentValue !== lastApplied) {
              return;
            }
            detailInput.value = promotionId;
            detailInput.dataset.n11PromotionId = promotionId;
            detailInput.dispatchEvent(new Event("input", { bubbles: true }));
            detailInput.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }, 500);
      }
    };

    nameSource.addEventListener("input", syncName);
    nameSource.addEventListener("change", syncName);
    urlSource.addEventListener("input", syncUrl);
    urlSource.addEventListener("change", syncUrl);
    nameSource.dataset.n11SyncBound = "1";
    urlSource.dataset.n11SyncBound = "1";
    syncName();
    syncUrl();
    return true;
  };

  attach();

  const observer = new MutationObserver(() => {
    attach();
  });
  observer.observe(document.body, { childList: true, subtree: true });
};

initInventoryNameSync();
showPendingCacheMessage();
runPendingClearCache();

const isCampaignPage = () => {
  return window.location.pathname === "/backoffice/campaign/campaign.xhtml";
};

const stripTrailingN11 = (value) => {
  if (!value) {
    return "";
  }
  return value.replace(/\s*-\s*n11\s*$/i, "");
};

const initCampaignFieldSync = () => {
  if (!isCampaignPage()) {
    return;
  }

  const formatTodayStart = () => {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, "0");
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const year = String(now.getFullYear());
    return `${day}/${month}/${year} 00:00`;
  };

  const typeInputValue = (input, value, delay = 120, onDone = null) => {
    if (!input) {
      return;
    }
    if (input.dataset.n11Typing === "1") {
      return;
    }
    input.dataset.n11Typing = "1";
    input.focus();
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    let index = 0;
    const step = () => {
      if (index >= value.length) {
        input.dataset.n11Typing = "0";
        input.dispatchEvent(new Event("change", { bubbles: true }));
        if (onDone) {
          onDone();
        }
        return;
      }
      const char = value[index];
      const keydown = new KeyboardEvent("keydown", { key: char, bubbles: true });
      const keypress = new KeyboardEvent("keypress", { key: char, bubbles: true });
      const keyup = new KeyboardEvent("keyup", { key: char, bubbles: true });
      input.dispatchEvent(keydown);
      input.dispatchEvent(keypress);
      if (typeof input.setRangeText === "function") {
        const end = input.value.length;
        input.setRangeText(char, end, end, "end");
      } else {
        input.value += char;
      }
      input.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          inputType: "insertText",
          data: char
        })
      );
      input.dispatchEvent(keyup);
      index += 1;
      window.setTimeout(step, delay);
    };
    window.setTimeout(step, delay);
  };

  const setInputValue = (input, value, onlyIfEmpty = false) => {
    if (!input) {
      return;
    }
    if (onlyIfEmpty && input.value.trim()) {
      return;
    }
    if (input.value === value) {
      return;
    }
    input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  };

  let instantCampaignClicked = false;
  const clickInstantCampaignItem = () => {
    if (instantCampaignClicked) {
      return;
    }
    const items = document.querySelectorAll(
      "li.ui-selectonemenu-item.ui-selectonemenu-list-item.ui-corner-all"
    );
    for (const item of items) {
      if (item.textContent.trim() === "Instant Campaign") {
        item.click();
        instantCampaignClicked = true;
        break;
      }
    }
  };

  const clickSelectItem = (panelSelector, label, forceOpen = false) => {
    const panel = document.querySelector(panelSelector);
    if (!panel || panel.style.display === "none") {
      if (forceOpen) {
        const triggerId = panelSelector.replace(/_panel$/, "");
        const trigger = document.querySelector(triggerId);
        if (trigger) {
          trigger.click();
        }
      }
      return;
    }
    const wrapper = panel.querySelector("div.ui-selectonemenu-items-wrapper");
    if (!wrapper) {
      return;
    }
    const items = wrapper.querySelectorAll("li.ui-selectonemenu-item");
    for (const item of items) {
      if (item.textContent.trim() === label) {
        if (!item.classList.contains("ui-state-highlight")) {
          item.click();
        }
        break;
      }
    }
  };

  const selectCampaignTemplate = () => {
    clickSelectItem(
      "div#campaignTemplateType_panel",
      "n11.com’a özel kampanya"
    );
    clickSelectItem("div#campaignOption", "Instant Campaign", true);
  };

  const ensureCampaignToggles = () => {
    const toggles = [
      document.querySelector("div#useMobileCampaign .ui-chkbox-box"),
      document.querySelector("div#useMobileWebCampaign .ui-chkbox-box")
    ];
    toggles.forEach((toggle) => {
      if (!toggle) {
        return;
      }
      if (!toggle.classList.contains("ui-state-active")) {
        toggle.click();
      }
    });
  };

  const ensureHideCampaignChecked = () => {
    const box = document.querySelector(
      "#hideCampaign .ui-chkbox-box"
    );
    if (!box) {
      return;
    }
    if (!box.classList.contains("ui-state-active")) {
      box.click();
    }
  };

  const attach = () => {
    const urlInput = document.querySelector("input#url");
    const htmlInventoryNameInput = document.querySelector("input#htmlInventoryName");
    const nameInput = document.querySelector("input#name");
    const breadCrumbInput = document.querySelector("input#breadCrumbText");
    const trackingPageNameInput = document.querySelector("input#trackingPageName");
    const seoTitleInput = document.querySelector("input#seoTitle");
    const landingPageTitle = document.querySelector("textarea#landingPageTitle");
    const seoDescription = document.querySelector("textarea#seoDescription");
    const landingPageContent = document.querySelector("textarea#landingPageContent");
    const startDateInput = document.querySelector(
      "input#campaignActiveInterval\\:createdStartDate_input"
    );
    const endDateInput = document.querySelector(
      "input#campaignActiveInterval\\:createdEndDate_input"
    );
    const exposureFilterInput = document.querySelector(
      "#pickExposureCategory_source_filter"
    );

    if (
      !urlInput &&
      !seoTitleInput &&
      !startDateInput &&
      !endDateInput &&
      !exposureFilterInput
    ) {
      return false;
    }

    const syncFromUrl = () => {
      const rawValue = urlInput?.value || "";
      if (htmlInventoryNameInput) {
        htmlInventoryNameInput.value = rawValue;
        htmlInventoryNameInput.dispatchEvent(new Event("input", { bubbles: true }));
        htmlInventoryNameInput.dispatchEvent(new Event("change", { bubbles: true }));
      }
      const promotionId = (() => {
        try {
          const url = new URL(rawValue);
          return url.searchParams.get("promotions") || "";
        } catch {
          return "";
        }
      })();
      if (promotionId) {
        const panel = document.querySelector(
          "div#contentDeepLinkPage_panel ul.ui-selectonemenu-items"
        );
        if (panel) {
          const items = panel.querySelectorAll("li.ui-selectonemenu-item");
          for (const item of items) {
            if (item.textContent.trim() === "Promotion") {
              item.click();
              break;
            }
          }
        }

        window.setTimeout(() => {
          const detailInput = document.querySelector("#contentDeepLinkDetail");
          if (detailInput) {
            const currentValue = (detailInput.value || "").trim();
            const lastApplied = detailInput.dataset.n11PromotionId || "";
            if (currentValue && currentValue !== lastApplied) {
              return;
            }
            detailInput.value = promotionId;
            detailInput.dataset.n11PromotionId = promotionId;
            detailInput.dispatchEvent(new Event("input", { bubbles: true }));
            detailInput.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }, 500);
      }
    };

    const syncSeoTitle = () => {
      if (!seoTitleInput) {
        return;
      }
      const rawValue = seoTitleInput.value || "";
      const cleanValue = stripTrailingN11(rawValue);

      [nameInput, breadCrumbInput, trackingPageNameInput].forEach((input) => {
        if (!input) {
          return;
        }
        input.value = cleanValue;
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
      });

      if (landingPageTitle) {
        landingPageTitle.value = cleanValue;
        landingPageTitle.dispatchEvent(new Event("input", { bubbles: true }));
        landingPageTitle.dispatchEvent(new Event("change", { bubbles: true }));
      }
    };

    const syncSeoDescription = () => {
      if (!seoDescription || !landingPageContent) {
        return;
      }
      landingPageContent.value = seoDescription.value || "";
      landingPageContent.dispatchEvent(new Event("input", { bubbles: true }));
      landingPageContent.dispatchEvent(new Event("change", { bubbles: true }));
    };

    if (urlInput && urlInput.dataset.n11CampaignSync !== "1") {
      urlInput.addEventListener("input", syncFromUrl);
      urlInput.addEventListener("change", syncFromUrl);
      urlInput.dataset.n11CampaignSync = "1";
      syncFromUrl();
    }

    if (seoTitleInput && seoTitleInput.dataset.n11CampaignSync !== "1") {
      seoTitleInput.addEventListener("input", syncSeoTitle);
      seoTitleInput.addEventListener("change", syncSeoTitle);
      seoTitleInput.dataset.n11CampaignSync = "1";
      syncSeoTitle();
    }

    if (seoDescription && seoDescription.dataset.n11CampaignSync !== "1") {
      seoDescription.addEventListener("input", syncSeoDescription);
      seoDescription.addEventListener("change", syncSeoDescription);
      seoDescription.dataset.n11CampaignSync = "1";
      syncSeoDescription();
    }

    setInputValue(startDateInput, formatTodayStart(), true);
    setInputValue(endDateInput, "01/01/2050 00:00", true);
    if (exposureFilterInput && exposureFilterInput.value !== "kampanya") {
      typeInputValue(exposureFilterInput, "kampanya", 120, () => {
        const addAllButton = document.querySelector(
          "button.ui-picklist-button-add-all"
        );
        window.setTimeout(() => {
          if (
            addAllButton &&
            addAllButton.getAttribute("aria-disabled") !== "true"
          ) {
            addAllButton.click();
          }
        }, 1000);
      });
    }

    selectCampaignTemplate();
    ensureHideCampaignChecked();
    clickInstantCampaignItem();
    ensureCampaignToggles();
    return true;
  };

  attach();

  const observer = new MutationObserver(() => {
    attach();
    selectCampaignTemplate();
    ensureHideCampaignChecked();
    clickInstantCampaignItem();
    ensureCampaignToggles();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  const tryClick = () => {
    clickInstantCampaignItem();
    if (!instantCampaignClicked) {
      window.setTimeout(tryClick, 500);
    }
  };
  window.setTimeout(tryClick, 500);
};

initCampaignFieldSync();

const isCampaignManagePage = () => {
  try {
    const url = new URL(window.location.href);
    const isHost =
      url.hostname === "bo.n11.com" || url.hostname === "testbo.n11.com";
    return (
      isHost &&
      url.pathname.includes("/backoffice/campaignManagementTool/campaignManage.xhtml")
    );
  } catch {
    return false;
  }
};

const CAMPAIGN_PRODUCT_LIST_CONTAINER_ID = "pageid-extension-container";
const CAMPAIGN_PRODUCT_LIST_BOX_ID = "campaign-product-list-extension-box";
const CAMPAIGN_PRODUCT_LIST_MODAL_ID = "campaign-product-list-extension-modal";

const initCampaignProductListUI = () => {
  if (!isCampaignManagePage()) {
    return;
  }
  let container = document.getElementById(CAMPAIGN_PRODUCT_LIST_CONTAINER_ID);
  if (!container) {
    container = document.createElement("div");
    container.id = CAMPAIGN_PRODUCT_LIST_CONTAINER_ID;
    container.style.cssText =
      "position:fixed;top:16px;right:16px;z-index:2147483647;display:flex;flex-direction:column;gap:10px;align-items:flex-end;";
    document.body.appendChild(container);
  }

  let box = document.getElementById(CAMPAIGN_PRODUCT_LIST_BOX_ID);
  if (!box) {
    box = document.createElement("div");
    box.id = CAMPAIGN_PRODUCT_LIST_BOX_ID;
    box.className = "pageid-extension-box";
    box.setAttribute("role", "button");
    box.setAttribute("aria-label", "Campaign Product List");
    box.innerHTML = '<div class="hint">Campaign Product List</div>';
    box.style.cursor = "pointer";
    container.appendChild(box);
  }

  const openModal = () => {
    let modal = document.getElementById(CAMPAIGN_PRODUCT_LIST_MODAL_ID);
    if (!modal) {
      modal = document.createElement("div");
      modal.id = CAMPAIGN_PRODUCT_LIST_MODAL_ID;
      modal.style.cssText =
        "position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.64);";
      modal.innerHTML = `
        <div class="modal-card" style="width:560px;max-width:95%;background:#fff;color:#1c1c1e;border-radius:12px;box-shadow:0 12px 30px rgba(0,0,0,0.25);padding:16px;">
          <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
            <div class="modal-title" style="font-size:14px;font-weight:600;">Campaign Product List</div>
            <button class="modal-close" type="button" aria-label="Kapat" style="border:none;background:transparent;font-size:16px;cursor:pointer;">✕</button>
          </div>
          <div class="modal-controls" style="display:flex;gap:12px;margin-bottom:12px;">
            <button type="button" class="collect-btn" id="campaign-product-list-collect" style="padding:0 12px;height:36px;border:none;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600;background:#1c1c1c;color:#fff;">ID Topla</button>
            <button type="button" class="download-btn" id="campaign-product-list-download" disabled style="padding:0 12px;height:36px;border:none;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600;background:#2B86D1;color:#fff;">Excel İndir</button>
          </div>
          <div class="textarea-group" style="margin-bottom:12px;">
            <label for="campaign-product-list-ids" style="display:block;margin-bottom:6px;font-size:12px;">Product ID'ler</label>
            <textarea id="campaign-product-list-ids" placeholder="ID Topla butonuna tıklayın..." style="width:100%;min-height:200px;resize:vertical;border:1px solid #bfbfbf;border-radius:6px;padding:8px;font-size:12px;box-sizing:border-box;font-family:ui-monospace,monospace;"></textarea>
          </div>
        </div>
      `;
      modal.addEventListener("click", (e) => {
        if (e.target === modal) {
          modal.style.display = "none";
        }
      });
      document.body.appendChild(modal);

      const closeBtn = modal.querySelector(".modal-close");
      const collectBtn = modal.querySelector("#campaign-product-list-collect");
      const downloadBtn = modal.querySelector("#campaign-product-list-download");
      const textarea = modal.querySelector("#campaign-product-list-ids");

      closeBtn.addEventListener("click", () => {
        modal.style.display = "none";
      });

      const collectIdsFromCurrentPage = () => {
        const tbody = document.querySelector(
          'tbody[id="tabView:campaignProductDataTable_data"]'
        );
        if (!tbody) return [];
        const ids = [];
        tbody.querySelectorAll("tr").forEach((tr) => {
          const secondTd = tr.querySelector("td:nth-child(2)");
          if (!secondTd) return;
          const div = secondTd.querySelector("div.ui-dt-c");
          if (div && div.textContent) {
            const id = div.textContent.trim();
            if (id) ids.push(id);
          }
        });
        return ids;
      };

      const getNextPageButton = () => {
        const paginator = document.querySelector(
          '[id="tabView:campaignProductDataTable_paginator_bottom"]'
        );
        if (!paginator) return null;
        const next = paginator.querySelector(".ui-paginator-next");
        if (!next || next.classList.contains("ui-state-disabled")) return null;
        return next;
      };

      collectBtn.addEventListener("click", async () => {
        const tbody = document.querySelector(
          'tbody[id="tabView:campaignProductDataTable_data"]'
        );
        if (!tbody) {
          textarea.value = "Tablo bulunamadı. tbody#tabView:campaignProductDataTable_data";
          return;
        }
        collectBtn.disabled = true;
        collectBtn.textContent = "Toplanıyor...";
        const allIds = [];
        let page = 1;
        for (;;) {
          const pageIds = collectIdsFromCurrentPage();
          pageIds.forEach((id) => allIds.push(id));
          textarea.value = allIds.join("\n") || "Ürün ID bulunamadı.";
          textarea.placeholder = `Sayfa ${page}: ${pageIds.length} ID. Toplam: ${allIds.length}`;
          const nextBtn = getNextPageButton();
          if (!nextBtn) break;
          nextBtn.click();
          page += 1;
          await new Promise((r) => setTimeout(r, 1200));
        }
        textarea.value = allIds.length > 0 ? allIds.join("\n") : "Ürün ID bulunamadı.";
        textarea.placeholder = "ID Topla butonuna tıklayın...";
        downloadBtn.disabled = allIds.length === 0;
        collectBtn.disabled = false;
        collectBtn.textContent = "ID Topla";
      });

      downloadBtn.addEventListener("click", () => {
        const text = (textarea.value || "").trim();
        if (!text || text.startsWith("Tablo") || text.startsWith("Ürün")) {
          return;
        }
        const lines = text.split("\n").filter((l) => l.trim());
        const header = "Product ID\n";
        const body = lines.map((l) => (l.includes(";") || l.includes('"') ? `"${l.replace(/"/g, '""')}"` : l)).join("\n");
        const content = "\uFEFF" + header + body;
        const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `campaign_product_ids_${new Date().toISOString().split("T")[0]}.csv`;
        a.style.visibility = "hidden";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(a.href);
      });
    }
    modal.style.display = "flex";
  };

  box.onclick = openModal;
};

if (isCampaignManagePage()) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initCampaignProductListUI);
  } else {
    initCampaignProductListUI();
  }
}