/**
 * Akakce Product Crawler – n11 ürün linklerinden başlık alıp Google'da "akakce + başlık" aratır,
 * ilk akakce.com sonucunu açar. Diğer özelliklerden ayrı tutulur.
 */
(function () {
  const N11_PRODUCT_URL_RE = /^https?:\/\/(www\.)?n11\.com\/urun\/[^/]+-\d+(?:\/|\?|$)/i;

  function getProductTitleFromHtml(html) {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const h1 = doc.querySelector(".product-summary h1");
      return h1 ? (h1.textContent || "").trim() : null;
    } catch {
      return null;
    }
  }

  function getProductPriceFromHtml(html) {
    if (!html || typeof html !== "string") return null;
    try {
      const doc = new DOMParser().parseFromString(html, "text/html");
      const sels = [".product-summary .price", ".product-summary [class*='price']", ".unf-p-summary-price", "[data-price]"];
      for (const sel of sels) {
        const el = doc.querySelector(sel);
        if (el) {
          const t = (el.textContent || el.getAttribute("data-price") || "").trim();
          const m = t.match(/(\d[\d.,]*)\s*TL/i) || t.match(/(\d[\d.,]+)/);
          if (m && m[1]) return m[1].trim() + " TL";
        }
      }
      const jm = html.match(/"price"\s*:\s*["']?([\d.,]+)["']?/i) || html.match(/"salePrice"\s*:\s*["']?([\d.,]+)["']?/i);
      if (jm && jm[1]) return jm[1].trim() + " TL";
      return null;
    } catch { return null; }
  }

  function getProductSellerFromHtml(html) {
    if (!html || typeof html !== "string") return null;
    try {
      const re = [/"seller"\s*:\s*\{[^}]*"nickName"\s*:\s*"([^"]+)"/, /"sellerNickName"\s*:\s*"([^"]+)"/, /model\.product\.seller\.nickName\s*=\s*"([^"]+)"/];
      for (const r of re) { const m = html.match(r); if (m && m[1]) return String(m[1]).trim(); }
      return null;
    } catch { return null; }
  }

  function setStatus(msg, type) {
    const el = document.getElementById("akakce-crawler-status");
    if (!el) return;
    el.textContent = msg;
    el.className = "status " + (type === "error" ? "error" : type === "success" ? "success" : "info");
  }

  function parseInputsFromTextarea() {
    const ta = document.getElementById("akakce-crawler-urls");
    if (!ta) return [];
    return (ta.value || "")
      .split(/\n/)
      .map((s) => s.trim())
      .filter((s) => s && (N11_PRODUCT_URL_RE.test(s) || /^\d+$/.test(s)));
  }

  function getProductIdFromUrl(url) {
    if (!url) return "";
    const m = String(url).match(/-(\d+)(?:\/|\?|$)/);
    return m ? m[1] : "";
  }

  /** Akakce ürün URL'sinden ürün ID'sini çıkarır (örn. ...-p-123456.html veya .../123456) */
  function getAkakceIdFromUrl(url) {
    if (!url || typeof url !== "string") return "";
    const u = String(url).split("?")[0].split("#")[0];
    const m = u.match(/-p-?(\d+)(?:\.html)?\/?$/i) || u.match(/\/(\d+)(?:\.html)?\/?$/);
    return m ? m[1] : "";
  }

  function getProductIdFromModel() {
    try {
      if (typeof window.model !== "undefined" && window.model) {
        if (window.model.product != null && window.model.product.id != null) {
          return String(window.model.product.id);
        }
        if (window.model.productMeta != null && window.model.productMeta.productId != null) {
          return String(window.model.productMeta.productId);
        }
      }
    } catch (e) {}
    return "";
  }

  function getProductIdFromHtml(html) {
    if (!html || typeof html !== "string") return "";
    try {
      const patterns = [
        /["']product["']\s*:\s*\{[^}]*["']id["']\s*:\s*["']?(\d{7,})["']?/,
        /["']product["']\s*:\s*\{[^}]*["']id["']\s*:\s*(\d+)/,
        /\.product\s*=\s*\{[^}]*\.id\s*[=:]\s*["']?(\d+)/,
        /model\.product\.id\s*[=:]\s*["']?(\d+)["']?/,
        /window\.model\.product\.id\s*[=:]\s*["']?(\d+)["']?/,
        /["']productMeta["']\s*:\s*\{[^}]*["']productId["']\s*:\s*["']?(\d+)["']?/,
        /model\.productMeta\.productId\s*[=:]\s*["']?(\d+)["']?/,
        /__NUXT__[^}]*["']product["'][^}]*["']id["']\s*:\s*["']?(\d+)["']?/,
        /"id"\s*:\s*["']?(\d{7,})["']?\s*[,}]/
      ];
      for (const re of patterns) {
        const m = html.match(re);
        if (m && m[1]) return m[1];
      }
    } catch (e) {}
    return "";
  }

  function getProductIdForUrl(url, fetchedHtml) {
    if (window.location.pathname && window.location.pathname.startsWith("/urun/")) {
      const fromModel = getProductIdFromModel();
      if (fromModel) {
        const currentBase = (window.location && window.location.href) ? window.location.href.split("?")[0] : "";
        const inputBase = (url || "").split("?")[0];
        if (currentBase === inputBase) {
          return fromModel;
        }
      }
    }
    if (fetchedHtml) {
      const fromHtml = getProductIdFromHtml(fetchedHtml);
      if (fromHtml) return fromHtml;
    }
    return "";
  }

  async function runOne(input, index, total) {
    let productId, productName, productUrl, n11Price, sellerNickName, googleUrl;
    if (/^\d+$/.test(input)) {
      productId = String(input);
      productName = String(input);
      productUrl = "";
      n11Price = "";
      sellerNickName = "";
      googleUrl = "https://www.google.com/search?q=akakce+" + encodeURIComponent(productName);
      setStatus(`${index + 1}/${total}: Google'da aranıyor, akakce sayfası açılıyor...`, "info");
    } else {
      setStatus(`${index + 1}/${total}: Ürün sayfası alınıyor...`, "info");
      let html;
      try {
        const res = await fetch(input, { credentials: "omit" });
        if (!res.ok) throw new Error("Sayfa alınamadı.");
        html = await res.text();
      } catch (err) {
        setStatus("Hata: " + (err && err.message ? err.message : "Sayfa alınamadı"), "error");
        return;
      }
      const title = getProductTitleFromHtml(html);
      if (!title) {
        setStatus("Hata: Bu sayfada .product-summary h1 bulunamadı.", "error");
        return;
      }
      productId = getProductIdForUrl(input, html);
      if (!productId) {
        setStatus(`${index + 1}/${total}: model.product.id alınıyor...`, "info");
        const resp = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: "akakce-get-product-id-from-n11", url: input }, (r) => resolve(r || {}));
        });
        productId = (resp && resp.productId) ? String(resp.productId) : "";
      }
      if (!productId) {
        setStatus("Hata: n11 sayfasından ürün ID (model.product.id) alınamadı.", "error");
        return;
      }
      productName = title;
      productUrl = input.split("?")[0].trim();
      n11Price = getProductPriceFromHtml(html) || "";
      sellerNickName = getProductSellerFromHtml(html) || "";
      googleUrl = "https://www.google.com/search?q=akakce+" + encodeURIComponent(title);
      setStatus(`${index + 1}/${total}: Google'da aranıyor, akakce sayfası açılıyor...`, "info");
    }
    return new Promise((resolve) => {
      const port = chrome.runtime.connect({ name: "akakce-flow" });
      port.onMessage.addListener((msg) => {
        if (msg.error) {
          setStatus("Hata: " + msg.error, "error");
        } else if (index + 1 >= total) {
          setStatus("İşlem tamamlandı.", "success");
        }
        port.disconnect();
        resolve();
      });
      port.onDisconnect.addListener(() => resolve());
      const isFromN11Url = Boolean(productUrl && productUrl.indexOf("n11.com/urun/") !== -1);
      port.postMessage({ googleUrl, productId, productName, productUrl: productUrl || "", n11Price: n11Price || "", sellerNickName: sellerNickName || "", isFromN11Url });
    });
  }

  var akakceTableRows = [];

  var runInProgress = false;
  function run() {
    if (runInProgress) return;
    const inputs = parseInputsFromTextarea();
    if (inputs.length === 0) {
      setStatus("Geçerli link veya ID bulunamadı. Her satıra bir n11 linki veya ürün ID'si girin.", "error");
      return;
    }
    runInProgress = true;
    clearResult();
    (async () => {
      try {
        for (let i = 0; i < inputs.length; i++) {
          await runOne(inputs[i], i, inputs.length);
        }
      } finally {
        runInProgress = false;
      }
    })();
  }

  function clearResult() {
    akakceTableRows = [];
    renderAkakceTable();
  }

  function priceCell(val) {
    if (val == null || val === "") return "-";
    const s = String(val).replace(/</g, "&lt;").replace(/>/g, "&gt;").trim();
    return s || "-";
  }

  function escapeHtml(s) {
    return (s || "").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  /** Türkçe/US fiyat string'ini sayıya çevirir. 5.800 → 5800, 5,80 → 5.80 */
  function parsePriceToNumber(str) {
    if (str == null || String(str).trim() === "" || String(str) === "-") return null;
    const s = String(str).replace(/[^\d,.]/g, "").replace(/\s/g, "");
    if (!s) return null;
    const lastComma = s.lastIndexOf(",");
    const lastDot = s.lastIndexOf(".");
    if (lastComma >= 0 && lastDot >= 0) {
      if (lastComma > lastDot) return parseFloat(s.replace(/\./g, "").replace(",", "."));
      return parseFloat(s.replace(/,/g, ""));
    }
    if (lastDot >= 0 && lastComma < 0) {
      const afterDot = s.slice(lastDot + 1);
      if (afterDot.length === 3) return parseFloat(s.replace(/\./g, ""));
      return parseFloat(s);
    }
    if (lastComma >= 0 && lastDot < 0) {
      const afterComma = s.slice(lastComma + 1);
      if (afterComma.length === 3) return parseFloat(s.replace(/,/g, ""));
      return parseFloat(s.replace(",", "."));
    }
    return parseFloat(s) || null;
  }

  function computeBuybox(
    n11Price,
    trendyolPrice,
    hbPrice,
    amazonPrice,
    pttavmPrice,
    idefixPrice
  ) {
    const n11Num = parsePriceToNumber(n11Price);
    const prices = [
      { brand: "n11", num: n11Num },
      { brand: "trendyol", num: parsePriceToNumber(trendyolPrice) },
      { brand: "hb", num: parsePriceToNumber(hbPrice) },
      { brand: "amazon", num: parsePriceToNumber(amazonPrice) },
      { brand: "pttavm", num: parsePriceToNumber(pttavmPrice) },
      { brand: "idefix", num: parsePriceToNumber(idefixPrice) }
    ].filter((p) => p.num != null && !isNaN(p.num));
    if (prices.length === 0 || n11Num == null || isNaN(n11Num)) return "";
    const lowest = Math.min(...prices.map((p) => p.num));
    return lowest === n11Num ? "Yes" : "No";
  }

  function hasMissingPrice(r) {
    const empty = (v) => v == null || String(v).trim() === "" || String(v) === "-";
    return (
      empty(r.n11Price) ||
      empty(r.trendyolPrice) ||
      empty(r.hbPrice) ||
      empty(r.amazonPrice) ||
      empty(r.pttavmPrice) ||
      empty(r.idefixPrice)
    );
  }

  function getBuyboxBrand(r) {
    const prices = [
      { key: "n11", num: parsePriceToNumber(r.n11Price) },
      { key: "trendyol", num: parsePriceToNumber(r.trendyolPrice) },
      { key: "hb", num: parsePriceToNumber(r.hbPrice) },
      { key: "amazon", num: parsePriceToNumber(r.amazonPrice) },
      { key: "pttavm", num: parsePriceToNumber(r.pttavmPrice) },
      { key: "idefix", num: parsePriceToNumber(r.idefixPrice) }
    ].filter((p) => p.num != null && !isNaN(p.num));
    if (prices.length === 0) return null;
    const lowest = Math.min(...prices.map((p) => p.num));
    const winner = prices.find((p) => p.num === lowest);
    return winner ? winner.key : null;
  }

  function computePriceAverage(allPrices) {
    if (!Array.isArray(allPrices) || allPrices.length === 0) return null;
    const nums = allPrices.map(function (p) { return parsePriceToNumber(p); }).filter(function (n) { return n != null && !isNaN(n); });
    if (nums.length === 0) return null;
    const avg = nums.reduce(function (a, b) { return a + b; }, 0) / nums.length;
    return avg.toFixed(2).replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  }

  function formatStatusNote(note, platform, url) {
    if (!note || String(note).trim() === "") return "-";
    let s = String(note).replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    if (platform && url && String(platform).trim() && String(url).trim()) {
      const esc = function (x) { return String(x).replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); };
      const re = new RegExp("(" + platform.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")(?![^<]*>)", "i");
      s = s.replace(re, '<a href="' + esc(url) + '" target="_blank" rel="noopener" class="status-platform-link"><b>$1</b></a>');
    }
    s = s.replace(/(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?|\d+[.,]\d+)\s*TL/gi, "<b>$&</b>");
    return s;
  }

  function priceCellWithBuybox(val, brandKey, buyboxBrand, priceUrl) {
    const html = priceCell(val);
    const empty = (v) => v == null || String(v).trim() === "" || String(v) === "-";
    if (empty(val)) return html;
    const content = (priceUrl && String(priceUrl).trim()) ? '<a href="' + String(priceUrl).replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;") + '" target="_blank" rel="noopener" class="akakce-price-link">' + html + "</a>" : html;
    if (brandKey === buyboxBrand) return '<span class="akakce-price-buybox">' + content + "</span>";
    if (brandKey === "n11" && buyboxBrand) return '<span class="akakce-price-n11-losing">' + content + "</span>";
    return content;
  }

  function renderAkakceTable() {
    const wrap = document.getElementById("akakce-crawler-result");
    if (!wrap) return;
    const rows = akakceTableRows;
    let html =
      '<table class="akakce-crawler-table">' +
      '<thead><tr><th width="60">n11 ID</th><th>Akakce ID</th><th>ÜRÜN ADI</th><th><img src="https://n11scdn.akamaized.net/custom/upload/52/78/8763995404733138810.svg" alt="akakce"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/56/71/4643320758776974115.svg" alt="n11"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/52/34/8306016460707706841.svg" alt="trendyol"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/49/75/9137271869470559939.svg" alt="hepsiburada"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/67/31/4443647868650764054.svg" alt="amazon"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/69/20/3989916881263112432.svg" alt="pttavm"></th><th><img src="https://n11scdn.akamaized.net/custom/upload/77/62/6970520296776748069.svg" alt="idefix"></th><th>Best Price?</th><th>Buybox Yes/No</th><th>Status</th><th>Güncelleme</th></tr></thead><tbody>';
    if (rows.length === 0) {
      html += '<tr><td colspan="14" class="akakce-crawler-empty">Henüz veri yok veya sayfa yüklenmedi.</td></tr>';
    } else {
      rows.forEach(function (r, idx) {
        const linkCell = r.akakceUrl
          ? '<a href="' + (r.akakceUrl || "").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;") + '" target="_blank" rel="noopener" class="akakce-link"><b>Link &#128279;</b></a>'
          : "-";
        const empty = function (v) { return v == null || String(v).trim() === "" || String(v) === "-"; };
        const noCompetitorData =
          empty(r.trendyolPrice) &&
          empty(r.hbPrice) &&
          empty(r.amazonPrice) &&
          empty(r.pttavmPrice) &&
          empty(r.idefixPrice);
        const redirectedToHome = r.redirectedToHome === true;
        const needsDeepAnalysis = (!r.akakceUrl || noCompetitorData) && !redirectedToHome;
        const needsManual = (r.akakceUrl && hasMissingPrice(r) && !noCompetitorData) || (redirectedToHome && r.akakceUrl);
        let updateCell = "-";
        if (needsDeepAnalysis && r.productUrl) {
          updateCell = '<button type="button" class="akakce-manuel-btn akakce-deep-analysis-btn" data-row-idx="' + idx + '"><b>Deep Analysis</b></button>';
        } else if (needsManual) {
          updateCell = '<button type="button" class="akakce-manuel-btn" data-row-idx="' + idx + '"><b>MANUEL GÜNCELLE</b></button>';
        }
        const buyboxBrand = getBuyboxBrand(r);
        const n11Id = (r.idFromN11Url && r.productId && String(r.productId).trim()) ? String(r.productId).trim() : "";
        const akakceId = (r.akakceId != null && String(r.akakceId).trim() !== "") ? String(r.akakceId).trim() : "";
        const n11IdCell = n11Id
          ? '<a href="https://www.n11.com/arama?q=' + escapeHtml(encodeURIComponent(n11Id)) + '" target="_blank" rel="noopener" class="akakce-id-link">' + escapeHtml(n11Id) + "</a>"
          : "-";
        const akakceIdCell = akakceId ? escapeHtml(akakceId) : "-";
        html +=
          "<tr><td>" + n11IdCell + "</td><td>" + akakceIdCell + "</td><td>" + escapeHtml(r.productName) +
          "</td><td>" + linkCell +
          "</td><td>" + priceCellWithBuybox(r.n11Price, "n11", buyboxBrand, null) +
          "</td><td>" + priceCellWithBuybox(r.trendyolPrice, "trendyol", buyboxBrand, r.trendyolPriceUrl) +
          "</td><td>" + priceCellWithBuybox(r.hbPrice, "hb", buyboxBrand, r.hbPriceUrl) +
          "</td><td>" + priceCellWithBuybox(r.amazonPrice, "amazon", buyboxBrand, r.amazonPriceUrl) +
          "</td><td>" + priceCellWithBuybox(r.pttavmPrice, "pttavm", buyboxBrand, r.pttavmPriceUrl) +
          "</td><td>" + priceCellWithBuybox(r.idefixPrice, "idefix", buyboxBrand, r.idefixPriceUrl) +
          "</td><td>" + (r.bestPrice != null && String(r.bestPrice).trim() !== "" ? escapeHtml(String(r.bestPrice).trim()) : "-") +
          "</td><td align='center'><b>" + escapeHtml(r.buybox) + "</b></td><td class='status-cell'><span class='status-note-wrap'>" + formatStatusNote(r.deepAnalysisNote, r.deepAnalysisPlatform, r.deepAnalysisUrl) + "</span></td><td>" + updateCell + "</td></tr>";
      });
    }
    html += "</tbody></table>";
    wrap.innerHTML = html;
    wrap.querySelectorAll(".akakce-manuel-btn").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const idx = parseInt(btn.getAttribute("data-row-idx"), 10);
        const row = akakceTableRows[idx];
        if (!row) return;
        if (btn.classList.contains("akakce-deep-analysis-btn")) {
          const productUrl = row.productUrl || (row.productId ? "https://www.n11.com/urun/urun-" + row.productId : "");
          if (!productUrl) {
            setStatus("Ürün linki bulunamadı.", "error");
            return;
          }
          btn.disabled = true;
          btn.textContent = "Analiz ediliyor...";
          setStatus("Gemini ile fiyat analizi yapılıyor...", "info");
          chrome.runtime.sendMessage({
            type: "akakce-deep-analysis",
            productUrl: productUrl,
            n11Price: row.n11Price || "",
            sellerNickName: row.sellerNickName || "",
            productName: row.productName || "",
            rowIndex: idx
          });
        } else {
          if (!row.akakceUrl) return;
          btn.disabled = true;
          btn.textContent = "Yükleniyor...";
          chrome.runtime.sendMessage({
            type: "akakce-manuel-update",
            productId: row.productId,
            productName: row.productName,
            akakceUrl: row.akakceUrl,
            rowIndex: idx
          });
        }
      });
    });
  }

  function renderAkakceResult(payload) {
    const data = Array.isArray(payload.data) ? payload.data : [];
    const allPrices = Array.isArray(payload.allPrices) ? payload.allPrices : [];
    const productId = payload.productId != null ? String(payload.productId) : "";
    const productName = payload.productName != null ? String(payload.productName) : "";
    const idFromN11Url = payload.idFromN11Url === true;
    const productUrl = (payload.productUrl != null && String(payload.productUrl).trim() !== "") ? String(payload.productUrl).trim() : (idFromN11Url && productId ? "https://www.n11.com/urun/urun-" + productId : "");
    const n11FromPayload = (payload.n11Price != null && String(payload.n11Price).trim() !== "") ? String(payload.n11Price).trim() : "";
    const sellerNickName = (payload.sellerNickName != null && String(payload.sellerNickName).trim() !== "") ? String(payload.sellerNickName).trim() : "";
    const n11 = data.find(function (x) { return x.brand === "n11"; });
    const trendyol = data.find(function (x) { return x.brand === "Trendyol"; });
    const hepsiburada = data.find(function (x) { return x.brand === "Hepsiburada"; });
    const amazon = data.find(function (x) { return x.brand === "Amazon Türkiye"; });
    const pttavm = data.find(function (x) { return x.brand === "PttAVM" || x.brand === "pttavm"; });
    const idefix = data.find(function (x) { return x.brand === "idefix" || x.brand === "Idefix"; });
    const n11PriceStr = n11 ? (n11.price || "").trim() : n11FromPayload;
    const trendyolPriceStr = trendyol ? (trendyol.price || "").trim() : "";
    const hbPriceStr = hepsiburada ? (hepsiburada.price || "").trim() : "";
    const amazonPriceStr = amazon ? (amazon.price || "").trim() : "";
    const pttavmPriceStr = pttavm ? (pttavm.price || "").trim() : "";
    const idefixPriceStr = idefix ? (idefix.price || "").trim() : "";
    const akakceSourceUrl = (payload.akakceOriginalUrl != null && String(payload.akakceOriginalUrl).trim() !== "") ? String(payload.akakceOriginalUrl).trim() : "";
    const akakceFromPayload = (payload.akakceUrl != null && payload.akakceUrl !== "") ? String(payload.akakceUrl) : "";
    const akakceUrl = akakceSourceUrl || akakceFromPayload;
    const priceAverage = computePriceAverage(allPrices);
    const bestPrice = (payload.bestPrice != null && String(payload.bestPrice).trim() !== "") ? String(payload.bestPrice).trim() : "";
    const redirectedToHome = payload.redirectedToHome === true;
    const n11Id = idFromN11Url ? productId : "";
    const akakceId = idFromN11Url ? getAkakceIdFromUrl(akakceUrl) : productId;
    const row = {
      productId: productId,
      n11Id: n11Id,
      akakceId: akakceId,
      productName: productName,
      productUrl: productUrl,
      idFromN11Url: idFromN11Url,
      sellerNickName: sellerNickName,
      akakceUrl: akakceUrl,
      n11Price: n11PriceStr,
      trendyolPrice: trendyolPriceStr,
      hbPrice: hbPriceStr,
      amazonPrice: amazonPriceStr,
      pttavmPrice: pttavmPriceStr,
      idefixPrice: idefixPriceStr,
      priceAverage: priceAverage != null ? priceAverage : "",
      bestPrice: bestPrice,
      buybox: computeBuybox(
        n11PriceStr,
        trendyolPriceStr,
        hbPriceStr,
        amazonPriceStr,
        pttavmPriceStr,
        idefixPriceStr
      ),
      deepAnalysisNote: redirectedToHome ? "Akakce ürün sayfası yerine ana sayfaya yönlendirdi (ürün görüntülenemedi)." : "",
      redirectedToHome: redirectedToHome
    };
    akakceTableRows.push(row);
    renderAkakceTable();
  }

  function applyManuelUpdateResult(productId, data, rowIndex, allPrices, bestPrice, redirectedToHome) {
    let row = null;
    if (typeof rowIndex === "number" && rowIndex >= 0 && rowIndex < akakceTableRows.length) {
      row = akakceTableRows[rowIndex];
    }
    if (!row) row = akakceTableRows.find(function (r) { return r.productId === productId; });
    if (!row) return;
    const brandToKey = {
      "n11": "n11Price",
      "Trendyol": "trendyolPrice",
      "Hepsiburada": "hbPrice",
      "Amazon Türkiye": "amazonPrice",
      "PttAVM": "pttavmPrice",
      "pttavm": "pttavmPrice",
      "idefix": "idefixPrice",
      "Idefix": "idefixPrice"
    };
    const empty = function (v) { return v == null || String(v).trim() === "" || String(v) === "-"; };
    data.forEach(function (item) {
      const key = brandToKey[item.brand];
      if (key && empty(row[key]) && item.price) row[key] = String(item.price).trim();
    });
    if (Array.isArray(allPrices) && allPrices.length > 0) {
      row.priceAverage = computePriceAverage(allPrices) || row.priceAverage || "";
    }
    if (bestPrice != null && String(bestPrice).trim() !== "") {
      row.bestPrice = String(bestPrice).trim();
    }
    if (redirectedToHome) {
      row.deepAnalysisNote = "Akakce ürün sayfası yerine ana sayfaya yönlendirdi (manuel güncelleme).";
    }
    row.buybox = computeBuybox(
      row.n11Price,
      row.trendyolPrice,
      row.hbPrice,
      row.amazonPrice,
      row.pttavmPrice,
      row.idefixPrice
    );
    renderAkakceTable();
  }

  chrome.runtime.onMessage.addListener(function (message) {
    if (message && message.type === "akakce-throttle-wait") {
      const sec = typeof message.seconds === "number" ? message.seconds : 5;
      setStatus("Her " + 25 + " üründe " + sec + " saniye bekleniyor (akakce.com yükünü azaltmak için)...", "info");
      return;
    }
    if (message && message.type === "akakce-page-data") {
      renderAkakceResult({
        productId: message.productId,
        productName: message.productName,
        productUrl: message.productUrl || "",
        idFromN11Url: message.idFromN11Url === true,
        n11Price: message.n11Price || "",
        sellerNickName: message.sellerNickName || "",
        data: Array.isArray(message.data) ? message.data : [],
        akakceUrl: message.akakceUrl || "",
        allPrices: Array.isArray(message.allPrices) ? message.allPrices : [],
        bestPrice: message.bestPrice != null ? String(message.bestPrice).trim() : "",
        redirectedToHome: message.redirectedToHome === true
      });
    }
    if (message && message.type === "akakce-manuel-update-result") {
      applyManuelUpdateResult(
        message.productId != null ? String(message.productId) : "",
        Array.isArray(message.data) ? message.data : [],
        message.rowIndex,
        Array.isArray(message.allPrices) ? message.allPrices : [],
        message.bestPrice != null ? String(message.bestPrice).trim() : "",
        message.redirectedToHome === true
      );
    }
    if (message && message.type === "akakce-deep-analysis-result") {
      const idx = typeof message.rowIndex === "number" ? message.rowIndex : -1;
      const row = idx >= 0 && idx < akakceTableRows.length ? akakceTableRows[idx] : null;
      const resWrap = document.getElementById("akakce-crawler-result");
      if (resWrap) resWrap.querySelectorAll(".akakce-deep-analysis-btn").forEach(function (btn) {
        btn.disabled = false;
        btn.textContent = "Deep Analysis";
      });
      if (message.error) {
        setStatus("Deep Analysis hatası: " + message.error, "error");
        if (row) row.deepAnalysisNote = "Hata: " + message.error;
      } else if (row && message.result) {
        const note = (message.result.analysis_note && String(message.result.analysis_note).trim()) ? String(message.result.analysis_note).trim() : (message.result.found ? "Fiyat bulundu." : "Rakip fiyat bulunamadı.");
        row.deepAnalysisNote = note;
        let deepAnalysisUrl = "";
        if (message.result.platform === "Hepsiburada" && (row.productName || "").trim()) {
          deepAnalysisUrl = "https://www.hepsiburada.com/ara?q=" + encodeURIComponent(String(row.productName).trim());
        } else if (message.result.source_url && String(message.result.source_url).trim()) {
          deepAnalysisUrl = String(message.result.source_url).trim();
        }
        if (deepAnalysisUrl) row.deepAnalysisUrl = deepAnalysisUrl;
        if (message.result.platform) row.deepAnalysisPlatform = String(message.result.platform).trim();
        if (message.result.found && message.result.platform && message.result.competitor_price != null) {
          const platformToKey = {
            "Hepsiburada": "hbPrice",
            "Trendyol": "trendyolPrice",
            "Amazon": "amazonPrice",
            "Amazon Türkiye": "amazonPrice",
            "PttAVM": "pttavmPrice",
            "pttavm": "pttavmPrice",
            "idefix": "idefixPrice",
            "Idefix": "idefixPrice"
          };
          const platformToUrlKey = {
            "Hepsiburada": "hbPriceUrl",
            "Trendyol": "trendyolPriceUrl",
            "Amazon": "amazonPriceUrl",
            "Amazon Türkiye": "amazonPriceUrl",
            "PttAVM": "pttavmPriceUrl",
            "pttavm": "pttavmPriceUrl",
            "idefix": "idefixPriceUrl",
            "Idefix": "idefixPriceUrl"
          };
          const key = platformToKey[message.result.platform];
          const urlKey = platformToUrlKey[message.result.platform];
          if (key) {
            const p = message.result.competitor_price;
            const priceStr = typeof p === "number" ? p.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL" : String(p);
            row[key] = priceStr;
            const finalUrl = (message.result.platform === "Hepsiburada" && (row.productName || "").trim()) ? "https://www.hepsiburada.com/ara?q=" + encodeURIComponent(String(row.productName).trim()) : (message.result.source_url ? String(message.result.source_url).trim() : "");
            if (urlKey && finalUrl) row[urlKey] = finalUrl;
            row.buybox = computeBuybox(
              row.n11Price,
              row.trendyolPrice,
              row.hbPrice,
              row.amazonPrice,
              row.pttavmPrice,
              row.idefixPrice
            );
            setStatus("Bulundu: " + message.result.platform + " - " + priceStr, "success");
          } else {
            setStatus("Bulundu: " + message.result.platform, "success");
          }
        } else {
          setStatus("Rakip fiyat bulunamadı.", "info");
        }
      }
      if (row) renderAkakceTable();
    }
  });

  function escapeXml(s) {
    const str = String(s == null ? "" : s);
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }

  function cellXml(value, type) {
    const t = type === "Number" ? "Number" : "String";
    return "<Cell><Data ss:Type=\"" + t + "\">" + escapeXml(value) + "</Data></Cell>";
  }

  function downloadExcel() {
    if (akakceTableRows.length === 0) return;
    const headers = [
      "n11 ID",
      "Akakce ID",
      "Ürün Adı",
      "Akakce Link",
      "N11 Fiyat",
      "Trendyol Fiyat",
      "Hepsiburada Fiyat",
      "Amazon Fiyat",
      "PttAVM Fiyat",
      "idefix Fiyat",
      "Buybox"
    ];
    const headerRow = "<Row>" + headers.map(function (h) { return cellXml(h); }).join("") + "</Row>";
    const dataRows = akakceTableRows.map(function (r) {
      const cells = [
        r.n11Id != null ? r.n11Id : "",
        r.akakceId != null ? r.akakceId : "",
        r.productName,
        r.akakceUrl || "",
        r.n11Price,
        r.trendyolPrice,
        r.hbPrice,
        r.amazonPrice,
        r.pttavmPrice,
        r.idefixPrice,
        r.buybox
      ].map(function (v) { return cellXml(v); });
      return "<Row>" + cells.join("") + "</Row>";
    }).join("");
    const worksheet = "<Worksheet ss:Name=\"Akakce Fiyatlar\"><Table>" + headerRow + dataRows + "</Table></Worksheet>";
    const workbook =
      "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
      "<?mso-application progid=\"Excel.Sheet\"?>\n" +
      "<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">\n" +
      worksheet + "\n" +
      "</Workbook>";
    const blob = new Blob(["\uFEFF" + workbook], { type: "application/vnd.ms-excel;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "akakce_fiyatlar_" + new Date().toISOString().split("T")[0] + ".xls";
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  }

  function fillCurrentProductIfEmpty() {
    const ta = document.getElementById("akakce-crawler-urls");
    if (!ta || (ta.value && ta.value.trim())) return;
    try {
      if (window.location.pathname && window.location.pathname.startsWith("/urun/")) {
        const id = getProductIdFromModel();
        if (id) {
          ta.value = window.location.href;
        }
      }
    } catch (e) {}
  }
  window.fillAkakceCurrentProduct = fillCurrentProductIfEmpty;

  window.registerAkakceCrawlerButton = function (modal) {
    const btn = modal && modal.querySelector("#akakce-crawler-run-btn");
    if (btn) btn.onclick = run;
    fillCurrentProductIfEmpty();
    const downloadBtn = modal && modal.querySelector("#akakce-crawler-download-btn");
    if (downloadBtn) {
      downloadBtn.addEventListener("click", downloadExcel);
      const origRender = renderAkakceTable;
      renderAkakceTable = function () {
        origRender();
        downloadBtn.disabled = akakceTableRows.length === 0;
      };
      downloadBtn.disabled = akakceTableRows.length === 0;
    }
  };
})();
