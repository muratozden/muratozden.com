window.PRICE_POOL_CONFIG = {
  SUPABASE_URL: "https://sucwofhmbixakitmkabp.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "sb_publishable_mgH0JXdGknUknTl-FHRCUA_KN-yPyhv",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN1Y3dvZmhtYml4YWtpdG1rYWJwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMyOTQwMjIsImV4cCI6MjA4ODg3MDAyMn0.2ak3dTJyEJ30xUayS-RyXFR7qBQOwI07_-OUrmCCbxE",
  PRICE_POOL_USER_TABLE: "price_pool_users"
};
