#!/usr/bin/env python3
"""
Resolve n11 + Trendyol store links for brands listed in seller.json.

Strategy:
  1) n11: treat each line as seller nickname → /magaza/{slug}, accept only if
     page <title> is not the soft-404 "n11.com".
  2) trendyol: web search (Brave) for site:trendyol.com/magaza, score slug vs brand;
     optionally Gemini with google_search if GEMINI_API_KEY is set.

Usage:
  python3 scripts/resolve-seller-store-links.py
  GEMINI_API_KEY=... python3 scripts/resolve-seller-store-links.py --use-gemini
  python3 scripts/resolve-seller-store-links.py --limit 10
  python3 scripts/resolve-seller-store-links.py --offset 0 --limit 100
"""

from __future__ import annotations

import argparse
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SELLER_FILE = ROOT / "seller.json"
OUT_FILE = ROOT / "seller-store-links.json"
STATE_FILE = ROOT / "seller-store-links.state.json"

UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)
CTX = ssl._create_unverified_context()
TY_RE = re.compile(r"https://www\.trendyol\.com/magaza/([a-zA-Z0-9\-]+)", re.I)
N11_RE = re.compile(r"https://www\.n11\.com/magaza/([a-zA-Z0-9\-_%]+)", re.I)
TR_MAP = str.maketrans(
    {
        "ç": "c",
        "Ç": "c",
        "ğ": "g",
        "Ğ": "g",
        "ı": "i",
        "I": "i",
        "İ": "i",
        "ö": "o",
        "Ö": "o",
        "ş": "s",
        "Ş": "s",
        "ü": "u",
        "Ü": "u",
    }
)


def http_get(url: str, timeout: int = 30) -> str:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": UA,
            "Accept": "text/html,application/json",
            "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.8",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout, context=CTX) as resp:
        return resp.read().decode("utf-8", "ignore")


def n11_slug(brand: str) -> str:
    return re.sub(r"[^a-z0-9]", "", brand.translate(TR_MAP).lower())


def normalize_alnum(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.translate(TR_MAP).lower())


def resolve_n11(brand: str) -> str:
    slug = n11_slug(brand)
    if not slug:
        return ""
    url = f"https://www.n11.com/magaza/{slug}"
    try:
        html = http_get(url, timeout=20)
    except Exception:
        return ""
    m = re.search(r"<title>([^<]+)</title>", html, re.I)
    title = (m.group(1) if m else "").strip()
    if not title or title == "n11.com":
        return ""
    return url


def score_ty_slug(slug: str, brand: str) -> int:
    bn = normalize_alnum(brand)
    base = slug.split("-m-")[0] if "-m-" in slug else slug
    sn = normalize_alnum(base)
    score = 0
    if bn and sn and bn == sn:
        score += 40
    elif bn and sn and (bn in sn or sn in bn):
        score += 22
    btoks = set(re.findall(r"[a-z0-9]{2,}", brand.translate(TR_MAP).lower()))
    stoks = set(base.lower().replace("-", " ").split())
    score += 6 * len(btoks & stoks)
    if re.search(r"-m-\d+$", slug):
        score += 4
    return score


def brave_ty_candidates(brand: str) -> list[str]:
    queries = [
        f"{brand} site:trendyol.com/magaza",
        f'"{brand}" site:trendyol.com/magaza',
    ]
    found: list[str] = []
    for q in queries:
        url = "https://search.brave.com/search?q=" + urllib.parse.quote(q)
        try:
            html = http_get(url, timeout=30)
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(20)
            continue
        except Exception:
            continue
        found.extend(TY_RE.findall(html))
        time.sleep(3.5)
    return found


def resolve_trendyol_brave(brand: str) -> str:
    slugs = brave_ty_candidates(brand)
    ranked = sorted(
        {(score_ty_slug(s, brand), s) for s in slugs},
        reverse=True,
    )
    if not ranked or ranked[0][0] < 20:
        return ""
    return f"https://www.trendyol.com/magaza/{ranked[0][1]}"


def extract_json_array(text: str) -> list:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    m = re.search(r"\[[\s\S]*\]", text)
    if not m:
        return []
    try:
        data = json.loads(m.group(0))
        return data if isinstance(data, list) else []
    except json.JSONDecodeError:
        return []


def resolve_batch_gemini(brands: list[str], api_key: str) -> dict[str, dict]:
    """Ask Gemini (with Google Search grounding) for store links."""
    brand_lines = "\n".join(brands)
    prompt = f"""Aşağıdaki satıcı/marka adlarının n11.com ve trendyol.com resmi mağaza sayfası URL'lerini bul.

Kurallar:
- Sadece gerçek mağaza URL'si ver. Emin değilsen ilgili alanı boş string "" yap.
- n11 formatı genelde: https://www.n11.com/magaza/{{slug}}
- trendyol formatı genelde: https://www.trendyol.com/magaza/{{slug}}-m-{{id}}
- Tahmini/uydurma link yazma. Trendyol'da -m-{{id}} olmayan link yazma.
- Sadece geçerli JSON dizi döndür, markdown veya açıklama ekleme.

Markalar:
{brand_lines}

Çıktı formatı:
[
  {{"brand":"DeFacto","n11_link":"...","trendyol_link":"..."}},
  ...
]
"""
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-2.0-flash:generateContent?key={urllib.parse.quote(api_key)}"
    )
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "tools": [{"google_search": {}}],
        "generationConfig": {"temperature": 0.1, "maxOutputTokens": 8192},
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120, context=CTX) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    text = (
        payload.get("candidates", [{}])[0]
        .get("content", {})
        .get("parts", [{}])[0]
        .get("text", "")
    )
    out: dict[str, dict] = {}
    for row in extract_json_array(text):
        if not isinstance(row, dict):
            continue
        brand = str(row.get("brand") or "").strip()
        if not brand:
            continue
        n11 = str(row.get("n11_link") or "").strip()
        ty = str(row.get("trendyol_link") or "").strip()
        if n11 and "n11.com/magaza/" not in n11:
            n11 = ""
        if ty and "trendyol.com/magaza/" not in ty:
            ty = ""
        if ty and not re.search(r"-m-\d+", ty):
            ty = ""
        out[brand] = {"n11_link": n11, "trendyol_link": ty}
    return out


def load_brands() -> list[str]:
    lines = SELLER_FILE.read_text(encoding="utf-8").splitlines()
    return [ln.strip() for ln in lines if ln.strip()]


def load_state() -> dict:
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    return {"results": {}, "done": []}


def save_state(state: dict) -> None:
    STATE_FILE.write_text(
        json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def export_results(brands: list[str], results: dict) -> None:
    rows = []
    for brand in brands:
        item = results.get(brand) or {}
        rows.append(
            {
                "brand": brand,
                "n11_link": item.get("n11_link") or "",
                "trendyol_link": item.get("trendyol_link") or "",
            }
        )
    OUT_FILE.write_text(
        json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--limit", type=int, default=0, help="0 = all")
    parser.add_argument("--use-gemini", action="store_true")
    parser.add_argument("--gemini-batch", type=int, default=10)
    parser.add_argument("--skip-trendyol", action="store_true")
    parser.add_argument("--n11-only", action="store_true")
    args = parser.parse_args()

    brands = load_brands()
    end = len(brands) if args.limit <= 0 else min(len(brands), args.offset + args.limit)
    slice_brands = brands[args.offset : end]

    state = load_state()
    results: dict = state.get("results") or {}
    done = set(state.get("done") or [])

    api_key = (os.environ.get("GEMINI_API_KEY") or "").strip()
    if args.use_gemini and not api_key:
        raise SystemExit("GEMINI_API_KEY required with --use-gemini")

    print(f"Processing {len(slice_brands)} brands (offset={args.offset})")

    if args.use_gemini:
        batch = []
        for brand in slice_brands:
            if brand in done and results.get(brand, {}).get("trendyol_link"):
                continue
            batch.append(brand)
            if len(batch) >= args.gemini_batch:
                try:
                    mapped = resolve_batch_gemini(batch, api_key)
                    for b in batch:
                        n11 = resolve_n11(b) or (mapped.get(b) or {}).get("n11_link") or ""
                        ty = (mapped.get(b) or {}).get("trendyol_link") or ""
                        results[b] = {"n11_link": n11, "trendyol_link": ty}
                        done.add(b)
                        print(f"OK {b} | n11={bool(n11)} ty={bool(ty)}")
                except Exception as e:
                    print(f"GEMINI_BATCH_ERR {e}")
                    for b in batch:
                        results[b] = {
                            "n11_link": resolve_n11(b),
                            "trendyol_link": results.get(b, {}).get("trendyol_link") or "",
                        }
                        done.add(b)
                state = {"results": results, "done": sorted(done)}
                save_state(state)
                export_results(brands, results)
                batch = []
                time.sleep(2)
        if batch:
            mapped = resolve_batch_gemini(batch, api_key)
            for b in batch:
                n11 = resolve_n11(b) or (mapped.get(b) or {}).get("n11_link") or ""
                ty = (mapped.get(b) or {}).get("trendyol_link") or ""
                results[b] = {"n11_link": n11, "trendyol_link": ty}
                done.add(b)
                print(f"OK {b} | n11={bool(n11)} ty={bool(ty)}")
    else:
        for i, brand in enumerate(slice_brands, 1):
            if brand in done and (args.n11_only or args.skip_trendyol or results.get(brand, {}).get("trendyol_link") is not None):
                # still refresh n11 if missing
                cur = results.get(brand) or {}
                if not cur.get("n11_link"):
                    cur["n11_link"] = resolve_n11(brand)
                    results[brand] = cur
                continue

            n11 = resolve_n11(brand)
            ty = ""
            if not args.skip_trendyol and not args.n11_only:
                ty = resolve_trendyol_brave(brand)
                time.sleep(2)

            results[brand] = {"n11_link": n11, "trendyol_link": ty}
            done.add(brand)
            print(f"[{i}/{len(slice_brands)}] {brand} | n11={bool(n11)} ty={bool(ty)}")

            if i % 25 == 0:
                state = {"results": results, "done": sorted(done)}
                save_state(state)
                export_results(brands, results)

    state = {"results": results, "done": sorted(done)}
    save_state(state)
    export_results(brands, results)
    print(f"Wrote {OUT_FILE}")


if __name__ == "__main__":
    main()
